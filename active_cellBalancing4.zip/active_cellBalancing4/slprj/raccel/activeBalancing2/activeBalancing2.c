#include "rt_logging_mmi.h"
#include "activeBalancing2_capi.h"
#include <math.h>
#include "activeBalancing2.h"
#include "activeBalancing2_private.h"
#include "activeBalancing2_dt.h"
#include "sfcn_loader_c_api.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 8 , & stopRequested ) ; }
rtExtModeShutdown ( 8 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 0 ; int_T gbl_raccel_NumST = 9 ; const char_T
* gbl_raccel_Version = "9.5 (R2021a) 14-Nov-2020" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; const char *
raccelLoadInputsAndAperiodicHitTimes ( SimStruct * S , const char *
inportFileName , int * matFileFormat ) { return rt_RAccelReadInportsMatFile (
S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
B rtB ; X rtX ; DW rtDW ; PrevZCX rtPrevZCX ; static SimStruct model_S ;
SimStruct * const rtS = & model_S ; static void au3syv53da ( const real_T x [
101 ] , const real_T params [ 3 ] , real_T y [ 101 ] ) ; static real_T
mh4svv2yac ( real_T x , const real_T params [ 3 ] ) ; static void au3syv53da
( const real_T x [ 101 ] , const real_T params [ 3 ] , real_T y [ 101 ] ) {
real_T a ; real_T b ; real_T c ; real_T x_p ; int32_T i ; a = params [ 0 ] ;
b = params [ 1 ] ; c = params [ 2 ] ; for ( i = 0 ; i < 101 ; i ++ ) { x_p =
x [ i ] ; y [ i ] = 0.0 ; if ( ( a != b ) && ( a < x_p ) && ( x_p < b ) ) { y
[ i ] = 1.0 / ( b - a ) * ( x_p - a ) ; } if ( ( b != c ) && ( b < x_p ) && (
x_p < c ) ) { y [ i ] = 1.0 / ( c - b ) * ( c - x_p ) ; } if ( x_p == b ) { y
[ i ] = 1.0 ; } } } void a0xcadlxa3 ( real_T ovnolcfzzb , real_T he14wg0npp ,
const real_T nzgwomno2g [ 9 ] , const real_T pdvriydai4 [ 101 ] , g4qsegj2g0
* localB ) { real_T outputMFCache [ 505 ] ; real_T tmp [ 101 ] ; real_T tmp_g
[ 101 ] ; real_T tmp_i [ 101 ] ; real_T tmp_m [ 101 ] ; real_T tmp_p [ 101 ]
; real_T tmp_e [ 3 ] ; real_T mfVal ; real_T x_idx_0 ; real_T x_idx_1 ;
int32_T i ; int32_T sampleID ; static const real_T b [ 3 ] = { 0.04167 , 0.25
, 0.4583 } ; static const real_T c [ 3 ] = { 0.2917 , 0.5 , 0.7083 } ; static
const int8_T d [ 9 ] = { 1 , 4 , 2 , 2 , 5 , 3 , 3 , 3 , 3 } ; localB ->
odhgoorqbc [ 0 ] = ovnolcfzzb ; localB -> odhgoorqbc [ 1 ] = he14wg0npp ;
au3syv53da ( pdvriydai4 , b , tmp ) ; au3syv53da ( pdvriydai4 , c , tmp_p ) ;
tmp_e [ 0 ] = 0.5417 ; tmp_e [ 1 ] = 0.75 ; tmp_e [ 2 ] = 0.9583 ; au3syv53da
( pdvriydai4 , tmp_e , tmp_i ) ; tmp_e [ 0 ] = 0.25 ; tmp_e [ 1 ] = 0.375 ;
tmp_e [ 2 ] = 0.5 ; au3syv53da ( pdvriydai4 , tmp_e , tmp_m ) ; tmp_e [ 0 ] =
0.5 ; tmp_e [ 1 ] = 0.625 ; tmp_e [ 2 ] = 0.75 ; au3syv53da ( pdvriydai4 ,
tmp_e , tmp_g ) ; for ( i = 0 ; i < 101 ; i ++ ) { localB -> nbuwrhuier [ i ]
= 0.0 ; outputMFCache [ 5 * i ] = tmp [ i ] ; outputMFCache [ 5 * i + 1 ] =
tmp_p [ i ] ; outputMFCache [ 5 * i + 2 ] = tmp_i [ i ] ; outputMFCache [ 5 *
i + 3 ] = tmp_m [ i ] ; outputMFCache [ 5 * i + 4 ] = tmp_g [ i ] ; } for ( i
= 0 ; i < 9 ; i ++ ) { x_idx_1 = nzgwomno2g [ i ] ; for ( sampleID = 0 ;
sampleID < 101 ; sampleID ++ ) { x_idx_0 = outputMFCache [ ( 5 * sampleID + d
[ i ] ) - 1 ] ; if ( ( x_idx_0 > x_idx_1 ) || ( muDoubleScalarIsNaN ( x_idx_0
) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { mfVal = x_idx_1 ; } else {
mfVal = x_idx_0 ; } x_idx_0 = localB -> nbuwrhuier [ sampleID ] ; if ( (
x_idx_0 < mfVal ) || ( muDoubleScalarIsNaN ( x_idx_0 ) && ( !
muDoubleScalarIsNaN ( mfVal ) ) ) ) { localB -> nbuwrhuier [ sampleID ] =
mfVal ; } else { localB -> nbuwrhuier [ sampleID ] = x_idx_0 ; } } } } static
real_T mh4svv2yac ( real_T x , const real_T params [ 3 ] ) { real_T y ; y =
0.0 ; if ( ( params [ 0 ] != params [ 1 ] ) && ( params [ 0 ] < x ) && ( x <
params [ 1 ] ) ) { y = 1.0 / ( params [ 1 ] - params [ 0 ] ) * ( x - params [
0 ] ) ; } if ( ( params [ 1 ] != params [ 2 ] ) && ( params [ 1 ] < x ) && (
x < params [ 2 ] ) ) { y = 1.0 / ( params [ 2 ] - params [ 1 ] ) * ( params [
2 ] - x ) ; } if ( x == params [ 1 ] ) { y = 1.0 ; } return y ; } void
MdlInitialize ( void ) { boolean_T tmp ; rtDW . mx5vjacu5q = rtP .
itinit1_InitialCondition ; rtX . foozkkgumc = 0.0 ; rtDW . gu33m3cujr = rtP .
itinit_InitialCondition ; rtDW . g55jrpbizl = 1 ; if ( ssIsFirstInitCond (
rtS ) ) { rtX . axoluperv2 = 0.0 ; tmp = slIsRapidAcceleratorSimulating ( ) ;
if ( tmp ) { tmp = ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW .
g55jrpbizl = ! tmp ; } else { rtDW . g55jrpbizl = 1 ; } rtX . bhkc4j1ohz =
0.0 ; } rtX . iftoftjjsf = rtP . Integrator2_IC ; rtX . iwofyqttuz = 0.0 ;
rtDW . ihabibaari = rtP . itinit1_InitialCondition_l3j5mkh0dv ; rtX .
jsonadfc25 = 0.0 ; rtDW . g45xtcsm1y = rtP .
itinit_InitialCondition_pv4h4vt0ps ; rtDW . ojsrsvfc4d = 1 ; if (
ssIsFirstInitCond ( rtS ) ) { tmp = slIsRapidAcceleratorSimulating ( ) ; if (
tmp ) { tmp = ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . ojsrsvfc4d =
! tmp ; } else { rtDW . ojsrsvfc4d = 1 ; } rtX . aczscrflwb = 0.0 ; } rtX .
m13n11gqh5 = rtP . Integrator2_IC_finfcihmmt ; rtX . cveknlxk0w = 0.0 ; rtDW
. mde444qrus = rtP . itinit1_InitialCondition_go30gfvhlp ; rtX . iqfvbswlqx =
0.0 ; rtDW . egfu4zp5ck = rtP . itinit_InitialCondition_nf4pvnucgc ; rtDW .
lldjl4eyzi = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . lldjl4eyzi = ! tmp ; }
else { rtDW . lldjl4eyzi = 1 ; } rtX . bz3dftuo0x = 0.0 ; } rtX . a20yshtbnb
= rtP . Integrator2_IC_kqbwod02j2 ; rtX . m2tz1exxd4 = 0.0 ; rtDW .
jjpmmqdhaq = rtP . itinit1_InitialCondition_ia2mtm2bdv ; rtX . n3r5zcmpoi =
0.0 ; rtDW . knijrjnyhh = rtP . itinit_InitialCondition_atlhsczubb ; rtDW .
gxvtetrs04 = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . gxvtetrs04 = ! tmp ; }
else { rtDW . gxvtetrs04 = 1 ; } rtX . lgrzwldtuz = 0.0 ; } rtX . e02u4qxaaf
= rtP . Integrator2_IC_gtek0x1of0 ; rtX . lkcwi10nsx = 0.0 ; rtDW .
curbfhmvfh = rtP . itinit1_InitialCondition_po45v3mmic ; rtX . l1c0yrfxl4 =
0.0 ; rtDW . h51d42z1yp = rtP . itinit_InitialCondition_mh2yj0opxq ; rtDW .
frtlsutffh = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . frtlsutffh = ! tmp ; }
else { rtDW . frtlsutffh = 1 ; } } rtX . aacuquz0zq = rtP .
Integrator2_IC_iw5ohpmyuz ; rtX . lnia4pzqrd = 0.0 ; { SimStruct * rts =
ssGetSFunction ( rtS , 0 ) ; sfcnInitializeConditions ( rts ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } rtDW . evcbaypssu =
ssGetTaskTime ( rtS , 6 ) ; rtDW . icvovv1jq2 = true ; rtDW . fwfrplulil =
true ; rtDW . fcr2tgbfvo = ssGetTaskTime ( rtS , 6 ) ; rtDW . glz3hn24br = (
rtMinusInf ) ; rtDW . jvh5mician = 0ULL ; rtDW . dxjlf0kpmf = true ; rtDW .
os5dfkhn1w = true ; rtDW . peu253ymia = ssGetTaskTime ( rtS , 5 ) ; rtDW .
iw1ylkptc1 = true ; rtDW . ggmjvv0lb3 = true ; rtDW . b0muitc2hd =
ssGetTaskTime ( rtS , 5 ) ; rtDW . llaf3ewbkp = ( rtMinusInf ) ; rtDW .
cdm1pyiexh = 0ULL ; rtDW . fbe3y1q2sg = true ; rtDW . aslrlvkkcc = true ;
rtDW . axv0fdx2my = ssGetTaskTime ( rtS , 7 ) ; rtDW . hekwrhnl5m = true ;
rtDW . doiwoekzov = true ; rtDW . azndzkmkcs = ssGetTaskTime ( rtS , 7 ) ;
rtDW . nthq3z5tt5 = ( rtMinusInf ) ; rtDW . k0umb4nsxj = 0ULL ; rtDW .
jdnmbiwx3f = true ; rtDW . aphrz0r2os = true ; rtDW . plxwewmbjw =
ssGetTaskTime ( rtS , 4 ) ; rtDW . offqujpaki = true ; rtDW . bhhlshfa0t =
true ; rtDW . ftugzjzi0o = ssGetTaskTime ( rtS , 4 ) ; rtDW . gipv354qpb = (
rtMinusInf ) ; rtDW . a1ahum4gsl = 0ULL ; rtDW . hxxbbgmykq = true ; rtDW .
md1zdgbsoe = true ; rtDW . j1mmhsj1qj = ssGetTaskTime ( rtS , 3 ) ; rtDW .
hlvtogm2ca = true ; rtDW . ot0jlfqn3i = true ; rtDW . k4c4pmfnv2 =
ssGetTaskTime ( rtS , 3 ) ; rtDW . mfqivfq3il = ( rtMinusInf ) ; rtDW .
fmvszapqpi = 0ULL ; rtDW . awhbfmptso = true ; rtDW . fdy0jfy1tu = true ;
rtDW . pxyvizid1y = ssGetTaskTime ( rtS , 2 ) ; rtDW . i2lws3rgth = true ;
rtDW . oasl5bklsg = true ; rtDW . feyc5lmf2r = ssGetTaskTime ( rtS , 2 ) ;
rtDW . ebuw4ix1ne = ( rtMinusInf ) ; rtDW . ko5gsxzsuc = 0ULL ; rtDW .
l0150x51ms = true ; rtDW . p4r02ywybb = true ; } void MdlEnable ( void ) {
_ssSetSampleHit ( rtS , 6 , 1 ) ; _ssSetTaskTime ( rtS , 6 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 4 , ssGetT ( rtS ) ) ; ; rtDW . icvovv1jq2 =
true ; rtDW . fwfrplulil = true ; rtDW . fcr2tgbfvo = ssGetTaskTime ( rtS , 6
) ; rtDW . glz3hn24br = ( rtMinusInf ) ; rtDW . jvh5mician = 0ULL ;
_ssSetSampleHit ( rtS , 5 , 1 ) ; _ssSetTaskTime ( rtS , 5 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 3 , ssGetT ( rtS ) ) ; ; rtDW . iw1ylkptc1 =
true ; rtDW . ggmjvv0lb3 = true ; rtDW . b0muitc2hd = ssGetTaskTime ( rtS , 5
) ; rtDW . llaf3ewbkp = ( rtMinusInf ) ; rtDW . cdm1pyiexh = 0ULL ;
_ssSetSampleHit ( rtS , 7 , 1 ) ; _ssSetTaskTime ( rtS , 7 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 5 , ssGetT ( rtS ) ) ; ; rtDW . hekwrhnl5m =
true ; rtDW . doiwoekzov = true ; rtDW . azndzkmkcs = ssGetTaskTime ( rtS , 7
) ; rtDW . nthq3z5tt5 = ( rtMinusInf ) ; rtDW . k0umb4nsxj = 0ULL ;
_ssSetSampleHit ( rtS , 4 , 1 ) ; _ssSetTaskTime ( rtS , 4 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 2 , ssGetT ( rtS ) ) ; ; rtDW . offqujpaki =
true ; rtDW . bhhlshfa0t = true ; rtDW . ftugzjzi0o = ssGetTaskTime ( rtS , 4
) ; rtDW . gipv354qpb = ( rtMinusInf ) ; rtDW . a1ahum4gsl = 0ULL ;
_ssSetSampleHit ( rtS , 3 , 1 ) ; _ssSetTaskTime ( rtS , 3 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 1 , ssGetT ( rtS ) ) ; ; rtDW . hlvtogm2ca =
true ; rtDW . ot0jlfqn3i = true ; rtDW . k4c4pmfnv2 = ssGetTaskTime ( rtS , 3
) ; rtDW . mfqivfq3il = ( rtMinusInf ) ; rtDW . fmvszapqpi = 0ULL ;
_ssSetSampleHit ( rtS , 2 , 1 ) ; _ssSetTaskTime ( rtS , 2 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 0 , ssGetT ( rtS ) ) ; ; rtDW . i2lws3rgth =
true ; rtDW . oasl5bklsg = true ; rtDW . feyc5lmf2r = ssGetTaskTime ( rtS , 2
) ; rtDW . ebuw4ix1ne = ( rtMinusInf ) ; rtDW . ko5gsxzsuc = 0ULL ; } void
MdlStart ( void ) { { bool externalInputIsInDatasetFormat = false ; void *
pISigstreamManager = rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} { { { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "SOC2" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "<SOC (%)>" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"activeBalancing2/Bus Selector1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "SOC2" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . dbblrjj2tk . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "bc928828-f7de-48f6-9ec8-b6dc569c33a2" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. dbblrjj2tk . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . dbblrjj2tk
. AQHandles , "Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime
( rtDW . dbblrjj2tk . AQHandles , ssGetTaskTime ( rtS , 1 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . dbblrjj2tk . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . dbblrjj2tk . AQHandles ,
loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } } { { { { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"activeBalancing2/Bus Selector1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. l22qnqwzjn . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"dc40be72-4db7-4137-bbe8-15e107fa0caa" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . l22qnqwzjn . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . l22qnqwzjn . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . l22qnqwzjn .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . l22qnqwzjn . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . l22qnqwzjn . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC3" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing2/Bus Selector2" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC3" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. fo3wh2yatx . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"a514b898-4976-4bee-a1ac-8413caef0228" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . fo3wh2yatx . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . fo3wh2yatx . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . fo3wh2yatx .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . fo3wh2yatx . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . fo3wh2yatx . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing2/Bus Selector2"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. k2ffp3ntfr . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"141e062c-9d6d-4d13-9c94-8b4bba7503c3" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . k2ffp3ntfr . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . k2ffp3ntfr . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . k2ffp3ntfr .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . k2ffp3ntfr . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . k2ffp3ntfr . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC4" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing2/Bus Selector3" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC4" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. nyfzlmf145 . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"64e5b82e-3a05-4427-8055-b0dc4a4e5225" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . nyfzlmf145 . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . nyfzlmf145 . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . nyfzlmf145 .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . nyfzlmf145 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . nyfzlmf145 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing2/Bus Selector3"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. h04wi2qgv5 . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"629ccaab-13f8-47b0-b182-ebe006cd73e6" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . h04wi2qgv5 . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . h04wi2qgv5 . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . h04wi2qgv5 .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . h04wi2qgv5 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . h04wi2qgv5 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC5" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing2/Bus Selector4" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC5" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. jgsevaes2d . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"e753d860-6817-4def-9046-bcc29b14f700" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . jgsevaes2d . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . jgsevaes2d . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . jgsevaes2d .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . jgsevaes2d . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . jgsevaes2d . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing2/Bus Selector4"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. j2pvryuk2u . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"4a575a04-7830-4cab-ba5a-587d9c457182" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . j2pvryuk2u . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . j2pvryuk2u . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . j2pvryuk2u .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . j2pvryuk2u . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . j2pvryuk2u . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC1" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing2/Bus Selector" ) ; sdiLabelU blockSID
= sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( ""
) ; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "SOC1" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . hqpvabyibc . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "3030bc16-1ac7-4b16-a924-f1470b0899e9" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. hqpvabyibc . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . hqpvabyibc
. AQHandles , "Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime
( rtDW . hqpvabyibc . AQHandles , ssGetTaskTime ( rtS , 1 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . hqpvabyibc . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . hqpvabyibc . AQHandles ,
loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } } { SimStruct * rts = ssGetSFunction ( rtS
, 0 ) ; sfcnStart ( rts ) ; if ( ssGetErrorStatus ( rts ) != ( NULL ) )
return ; } MdlInitialize ( ) ; MdlEnable ( ) ; } void MdlOutputs ( int_T tid
) { real_T j2ki5b5bge ; real_T kxuzmahy5q ; real_T b53hsyj2rm ; real_T
cgpn5xbggm ; real_T p4zz55422p ; real_T ntqwdwg3ka ; real_T l4xk434goc ;
real_T bmr0wof1hl ; real_T ie4fkoj5zo ; real_T aa12daxney ; real_T crwwbme23f
; real_T j1doyw2v5m ; real_T cn5bvst0om [ 9 ] ; real_T fxw2ruvdsa [ 9 ] ;
real_T dthqwcoahr [ 9 ] ; real_T khbcap1kpw [ 9 ] ; real_T dwlffapnhu [ 9 ] ;
real_T jaur2fpzjp [ 9 ] ; real_T inputMFCache [ 6 ] ; real_T tmp_p [ 3 ] ;
real_T jmuz0todoh ; real_T k0qu5tzxih ; real_T x_idx_1 ; int_T iy ; boolean_T
tmp ; ZCEventType zcEvent ; static const real_T b [ 3 ] = { 0.4167 , 2.5 ,
4.583 } ; static const real_T c [ 3 ] = { 2.917 , 5.0 , 7.085 } ; static
const real_T d [ 3 ] = { 8.333 , 50.0 , 91.67 } ; static const real_T e [ 3 ]
= { 58.33 , 100.0 , 141.7 } ; static const int8_T f [ 18 ] = { 1 , 1 , 1 , 2
, 2 , 2 , 3 , 3 , 3 , 3 , 2 , 1 , 3 , 2 , 1 , 1 , 2 , 3 } ; rtB . jjv3khbcgz
= 0.0 ; rtB . jjv3khbcgz += rtP . Currentfilter_C * rtX . foozkkgumc ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . kjybbipaii = rtDW . mx5vjacu5q ; rtB
. kddmvh240q = rtP . R2_Gain * rtB . kjybbipaii ; rtB . o04pwljhiy = 1.000001
* rtB . kddmvh240q * 0.96711798839458663 / 0.9999 ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . exu1prz21a = ( rtB . jjv3khbcgz >
rtP . Constant_Value ) ; } rtB . mypk2tqufk = rtDW . exu1prz21a ; rtB .
exs5fmp5lc = rtDW . gu33m3cujr ; } tmp = ssGetIsOkayToUpdateMode ( rtS ) ; if
( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
oztcuusllf , ( rtB . mypk2tqufk ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . g55jrpbizl != 0 ) ) { rtX . axoluperv2 = rtB . exs5fmp5lc ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . axoluperv2
>= rtP . inti_UpperSat ) { if ( rtX . axoluperv2 != rtP . inti_UpperSat ) {
rtX . axoluperv2 = rtP . inti_UpperSat ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . m3sjkfetzr = 3
; } else if ( rtX . axoluperv2 <= rtP . inti_LowerSat ) { if ( rtX .
axoluperv2 != rtP . inti_LowerSat ) { rtX . axoluperv2 = rtP . inti_LowerSat
; ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . m3sjkfetzr =
4 ; } else { if ( rtDW . m3sjkfetzr != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . m3sjkfetzr = 0
; } rtB . d0ekxmir1r = rtX . axoluperv2 ; } else { rtB . d0ekxmir1r = rtX .
axoluperv2 ; } rtB . cuhexdvcd3 = rtP . Gain_Gain * rtB . d0ekxmir1r ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . bs0tfwzjp3 = ( rtB . cuhexdvcd3 > rtB . kddmvh240q ) ; } rtB .
kmc5f3pvgr = rtDW . bs0tfwzjp3 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . msxvlyne10 = ( rtB . cuhexdvcd3 < rtP . Constant9_Value ) ; } rtB .
ottjrsvg2b = rtDW . msxvlyne10 ; } if ( rtB . kmc5f3pvgr ) { rtB . ocwszegfxg
= rtB . kddmvh240q ; } else { if ( rtB . ottjrsvg2b ) { rtB . okwsnxfcwm =
rtP . Constant9_Value ; } else { rtB . okwsnxfcwm = rtB . cuhexdvcd3 ; } rtB
. ocwszegfxg = rtB . okwsnxfcwm ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . owram20lcx = ( rtB . o04pwljhiy
<= rtB . ocwszegfxg ) ; } rtB . gbl1xcr4zw = rtDW . owram20lcx ; } if ( rtB .
gbl1xcr4zw ) { rtB . h3wghvdhvb = rtB . kddmvh240q ; } else { rtB .
h3wghvdhvb = rtB . ocwszegfxg ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
kjybbipaii / ( rtB . kjybbipaii - rtB . h3wghvdhvb ) * rtB . h3wghvdhvb ;
jmuz0todoh = - rtB . mypk2tqufk * 0.00461995246297257 * rtB . jjv3khbcgz *
rtB . kjybbipaii / ( rtB . kjybbipaii - rtB . h3wghvdhvb ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . mlf4o50fzo = rtP . R3_Gain * rtB .
kjybbipaii ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . ktypzgdlxt = (
rtB . cuhexdvcd3 > rtB . mlf4o50fzo ) ; } rtB . jz1nhvdeap = rtDW .
ktypzgdlxt ; rtB . e5s2aj4bft = - rtB . mlf4o50fzo * 0.999 * 0.1 * 0.9999 ;
if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . otvz1o3ztq = ( rtB .
cuhexdvcd3 < rtB . e5s2aj4bft ) ; } rtB . gvvtz2d2av = rtDW . otvz1o3ztq ; }
if ( rtB . jz1nhvdeap ) { rtB . ocazt2vdhl = rtB . mlf4o50fzo ; } else { if (
rtB . gvvtz2d2av ) { rtB . l40n3fusaj = rtB . e5s2aj4bft ; } else { rtB .
l40n3fusaj = rtB . cuhexdvcd3 ; } rtB . ocazt2vdhl = rtB . l40n3fusaj ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . pkopjswp3e = ( rtB . jjv3khbcgz < rtP . Constant_Value_efypwvyyax ) ;
} rtB . m40orrweos = rtDW . pkopjswp3e ; } switch ( ( int32_T ) rtP .
Battery1_BatType ) { case 1 : rtB . mvyppbw32h [ 0 ] = rtP . Constant4_Value
* rtB . ocazt2vdhl ; rtB . mvyppbw32h [ 1 ] = rtP . Constant4_Value * rtB .
jjv3khbcgz ; rtB . mvyppbw32h [ 2 ] = rtP . Constant4_Value * rtB .
m40orrweos ; rtB . mvyppbw32h [ 3 ] = rtP . Constant4_Value * rtB .
kjybbipaii ; rtB . jymoxqqazt = - rtB . mvyppbw32h [ 2 ] *
0.00461995246297257 * rtB . mvyppbw32h [ 1 ] * ( 6.2039999999999846 / ( rtB .
mvyppbw32h [ 0 ] + 0.62039999999999851 ) ) ; break ; case 2 : rtB .
h40smwlveg [ 0 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . ocazt2vdhl ; rtB
. h40smwlveg [ 1 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . jjv3khbcgz ;
rtB . h40smwlveg [ 2 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . m40orrweos
; rtB . h40smwlveg [ 3 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB .
kjybbipaii ; rtB . jymoxqqazt = - rtB . h40smwlveg [ 2 ] *
0.00461995246297257 * rtB . h40smwlveg [ 1 ] * rtB . h40smwlveg [ 3 ] / ( rtB
. h40smwlveg [ 3 ] * 0.1 + rtB . h40smwlveg [ 0 ] ) ; break ; case 3 : rtB .
c4dz3ztpxj [ 0 ] = rtP . Constant3_Value * rtB . ocazt2vdhl ; rtB .
c4dz3ztpxj [ 1 ] = rtP . Constant3_Value * rtB . jjv3khbcgz ; rtB .
c4dz3ztpxj [ 2 ] = rtP . Constant3_Value * rtB . m40orrweos ; rtB .
c4dz3ztpxj [ 3 ] = rtP . Constant3_Value * rtB . kjybbipaii ; rtB .
jymoxqqazt = - rtB . c4dz3ztpxj [ 2 ] * 0.00461995246297257 * rtB .
c4dz3ztpxj [ 1 ] * ( 6.2039999999999846 / ( muDoubleScalarAbs ( rtB .
c4dz3ztpxj [ 0 ] ) + 0.62039999999999851 ) ) ; break ; default : rtB .
hhvpdaqnq4 [ 0 ] = rtP . Constant2_Value * rtB . ocazt2vdhl ; rtB .
hhvpdaqnq4 [ 1 ] = rtP . Constant2_Value * rtB . jjv3khbcgz ; rtB .
hhvpdaqnq4 [ 2 ] = rtP . Constant2_Value * rtB . m40orrweos ; rtB .
hhvpdaqnq4 [ 3 ] = rtP . Constant2_Value * rtB . kjybbipaii ; rtB .
jymoxqqazt = - rtB . hhvpdaqnq4 [ 2 ] * 0.00461995246297257 * rtB .
hhvpdaqnq4 [ 1 ] * ( 6.2039999999999846 / ( muDoubleScalarAbs ( rtB .
hhvpdaqnq4 [ 0 ] ) + 0.62039999999999851 ) ) ; break ; } rtB . ohbzci5slc =
rtX . iftoftjjsf ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . jmxabr1urn = rtB
. h3wghvdhvb >= rtP . Saturation_UpperSat ? 1 : rtB . h3wghvdhvb > rtP .
Saturation_LowerSat ? 0 : - 1 ; } rtB . gly2zbjwjb = rtDW . jmxabr1urn == 1 ?
rtP . Saturation_UpperSat : rtDW . jmxabr1urn == - 1 ? rtP .
Saturation_LowerSat : rtB . h3wghvdhvb ; switch ( ( int32_T ) rtP .
Battery1_BatType ) { case 1 : rtB . engb4yawhy = rtB . ohbzci5slc ; break ;
case 2 : rtB . engb4yawhy = muDoubleScalarExp ( - 10.176991150442477 * rtB .
gly2zbjwjb ) * 0.310711063328515 ; break ; case 3 : rtB . engb4yawhy = rtB .
ohbzci5slc ; break ; default : rtB . engb4yawhy = rtB . ohbzci5slc ; break ;
} rtB . i5byuauteo = ( ( ( k0qu5tzxih + jmuz0todoh ) + rtB . jymoxqqazt ) +
rtB . engb4yawhy ) + - 0.0 * rtB . h3wghvdhvb ; rtB . lkmpaypb2p = rtP .
Constant_Value_jorngiczgp + rtB . i5byuauteo ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . e0qedsyqjn = ( rtB .
lkmpaypb2p > rtP . Constant1_Value ) ; } rtB . o4wzll3qjg = rtDW . e0qedsyqjn
; } rtB . c3jgwjjxsi = 0.0 ; rtB . c3jgwjjxsi += rtP . BAL_C * rtX .
iwofyqttuz ; rtB . drwy5mjekt = rtP . R1_Gain * rtB . c3jgwjjxsi ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . pkpw1tsasy = ( rtB . lkmpaypb2p < rtB . drwy5mjekt ) ; } rtB .
jrlz1gdkjb = rtDW . pkpw1tsasy ; rtB . ilnbwvckzb = rtDW . ihabibaari ; rtB .
gytt55q4rf = rtP . R2_Gain_jrqfqsl4vo * rtB . ilnbwvckzb ; rtB . jzbhnekpdw =
1.000001 * rtB . gytt55q4rf * 0.96711798839458663 / 0.9999 ; } if ( rtB .
o4wzll3qjg ) { rtB . luoecyht3u = rtP . Constant1_Value ; } else { if ( rtB .
jrlz1gdkjb ) { rtB . hzuw02gvc4 = rtB . drwy5mjekt ; } else { rtB .
hzuw02gvc4 = rtB . lkmpaypb2p ; } rtB . luoecyht3u = rtB . hzuw02gvc4 ; } rtB
. habvcjn5vp = 0.0 ; rtB . habvcjn5vp += rtP . Currentfilter_C_ldprzne4qv *
rtX . jsonadfc25 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . mx41mp51rp = ( rtB . habvcjn5vp >
rtP . Constant_Value_pbqzqfbpnm ) ; } rtB . ax0agqaio3 = rtDW . mx41mp51rp ;
rtB . expk2fcvrk = rtDW . g45xtcsm1y ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
omisk5z2rc , ( rtB . ax0agqaio3 ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . ojsrsvfc4d != 0 ) ) { rtX . bhkc4j1ohz = rtB . expk2fcvrk ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . bhkc4j1ohz
>= rtP . inti_UpperSat_itldayqrxp ) { if ( rtX . bhkc4j1ohz != rtP .
inti_UpperSat_itldayqrxp ) { rtX . bhkc4j1ohz = rtP .
inti_UpperSat_itldayqrxp ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . hrm4dgu33i = 3 ; } else if ( rtX . bhkc4j1ohz <= rtP .
inti_LowerSat_lz3gh0icex ) { if ( rtX . bhkc4j1ohz != rtP .
inti_LowerSat_lz3gh0icex ) { rtX . bhkc4j1ohz = rtP .
inti_LowerSat_lz3gh0icex ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . hrm4dgu33i = 4 ; } else { if ( rtDW . hrm4dgu33i != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . hrm4dgu33i = 0
; } rtB . kq4wgxleiz = rtX . bhkc4j1ohz ; } else { rtB . kq4wgxleiz = rtX .
bhkc4j1ohz ; } rtB . ftwzojqrpo = rtP . Gain_Gain_ozvwrv1fuy * rtB .
kq4wgxleiz ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . jansurp50c = ( rtB . ftwzojqrpo >
rtB . gytt55q4rf ) ; } rtB . fzgromwfrh = rtDW . jansurp50c ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . c4szg1j5wf = ( rtB . ftwzojqrpo <
rtP . Constant9_Value_bfo0fnc5l1 ) ; } rtB . n0hhvlmhsx = rtDW . c4szg1j5wf ;
} if ( rtB . fzgromwfrh ) { rtB . ehiwj5javn = rtB . gytt55q4rf ; } else { if
( rtB . n0hhvlmhsx ) { rtB . b133p02glv = rtP . Constant9_Value_bfo0fnc5l1 ;
} else { rtB . b133p02glv = rtB . ftwzojqrpo ; } rtB . ehiwj5javn = rtB .
b133p02glv ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . izsp05gss2 = ( rtB . jzbhnekpdw <=
rtB . ehiwj5javn ) ; } rtB . le2uootisz = rtDW . izsp05gss2 ; } if ( rtB .
le2uootisz ) { rtB . a3dofhbrxy = rtB . gytt55q4rf ; } else { rtB .
a3dofhbrxy = rtB . ehiwj5javn ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
ilnbwvckzb / ( rtB . ilnbwvckzb - rtB . a3dofhbrxy ) * rtB . a3dofhbrxy ;
jmuz0todoh = - rtB . ax0agqaio3 * 0.00461995246297257 * rtB . habvcjn5vp *
rtB . ilnbwvckzb / ( rtB . ilnbwvckzb - rtB . a3dofhbrxy ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . ma2bkws5c2 = rtP . R3_Gain_dgx1dntlxw
* rtB . ilnbwvckzb ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
b554rpqups = ( rtB . ftwzojqrpo > rtB . ma2bkws5c2 ) ; } rtB . n30sif3yf3 =
rtDW . b554rpqups ; rtB . ebarhnnaj2 = - rtB . ma2bkws5c2 * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . pbezlulnm5 = ( rtB .
ftwzojqrpo < rtB . ebarhnnaj2 ) ; } rtB . fanfrrdn0p = rtDW . pbezlulnm5 ; }
if ( rtB . n30sif3yf3 ) { rtB . ccww5ibchs = rtB . ma2bkws5c2 ; } else { if (
rtB . fanfrrdn0p ) { rtB . fzjqlg4y3i = rtB . ebarhnnaj2 ; } else { rtB .
fzjqlg4y3i = rtB . ftwzojqrpo ; } rtB . ccww5ibchs = rtB . fzjqlg4y3i ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . oyiznhfz3f = ( rtB . habvcjn5vp < rtP . Constant_Value_hu3rmuppbn ) ;
} rtB . gfojdvphy5 = rtDW . oyiznhfz3f ; } switch ( ( int32_T ) rtP .
Battery2_BatType ) { case 1 : rtB . fhqvahxlzh [ 0 ] = rtP .
Constant4_Value_p1xz0cpgth * rtB . ccww5ibchs ; rtB . fhqvahxlzh [ 1 ] = rtP
. Constant4_Value_p1xz0cpgth * rtB . habvcjn5vp ; rtB . fhqvahxlzh [ 2 ] =
rtP . Constant4_Value_p1xz0cpgth * rtB . gfojdvphy5 ; rtB . fhqvahxlzh [ 3 ]
= rtP . Constant4_Value_p1xz0cpgth * rtB . ilnbwvckzb ; rtB . ch24s33jrc = -
rtB . fhqvahxlzh [ 2 ] * 0.00461995246297257 * rtB . fhqvahxlzh [ 1 ] * (
6.2039999999999846 / ( rtB . fhqvahxlzh [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . i4xsfrvnpt [ 0 ] = rtP . Constant1_Value_jxqfbvs00y *
rtB . ccww5ibchs ; rtB . i4xsfrvnpt [ 1 ] = rtP . Constant1_Value_jxqfbvs00y
* rtB . habvcjn5vp ; rtB . i4xsfrvnpt [ 2 ] = rtP .
Constant1_Value_jxqfbvs00y * rtB . gfojdvphy5 ; rtB . i4xsfrvnpt [ 3 ] = rtP
. Constant1_Value_jxqfbvs00y * rtB . ilnbwvckzb ; rtB . ch24s33jrc = - rtB .
i4xsfrvnpt [ 2 ] * 0.00461995246297257 * rtB . i4xsfrvnpt [ 1 ] * rtB .
i4xsfrvnpt [ 3 ] / ( rtB . i4xsfrvnpt [ 3 ] * 0.1 + rtB . i4xsfrvnpt [ 0 ] )
; break ; case 3 : rtB . ad1xsvu0e2 [ 0 ] = rtP . Constant3_Value_k030zkojhy
* rtB . ccww5ibchs ; rtB . ad1xsvu0e2 [ 1 ] = rtP .
Constant3_Value_k030zkojhy * rtB . habvcjn5vp ; rtB . ad1xsvu0e2 [ 2 ] = rtP
. Constant3_Value_k030zkojhy * rtB . gfojdvphy5 ; rtB . ad1xsvu0e2 [ 3 ] =
rtP . Constant3_Value_k030zkojhy * rtB . ilnbwvckzb ; rtB . ch24s33jrc = -
rtB . ad1xsvu0e2 [ 2 ] * 0.00461995246297257 * rtB . ad1xsvu0e2 [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . ad1xsvu0e2 [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . mtmk2ehsha [ 0 ] = rtP .
Constant2_Value_nbkvr3eqsy * rtB . ccww5ibchs ; rtB . mtmk2ehsha [ 1 ] = rtP
. Constant2_Value_nbkvr3eqsy * rtB . habvcjn5vp ; rtB . mtmk2ehsha [ 2 ] =
rtP . Constant2_Value_nbkvr3eqsy * rtB . gfojdvphy5 ; rtB . mtmk2ehsha [ 3 ]
= rtP . Constant2_Value_nbkvr3eqsy * rtB . ilnbwvckzb ; rtB . ch24s33jrc = -
rtB . mtmk2ehsha [ 2 ] * 0.00461995246297257 * rtB . mtmk2ehsha [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . mtmk2ehsha [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . mszxp2nb10 = rtX . m13n11gqh5 ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . ge34ybq3a0 = rtB . a3dofhbrxy >= rtP .
Saturation_UpperSat_lxx4j3fnoa ? 1 : rtB . a3dofhbrxy > rtP .
Saturation_LowerSat_kwi433xk5g ? 0 : - 1 ; } rtB . hrkgmangdo = rtDW .
ge34ybq3a0 == 1 ? rtP . Saturation_UpperSat_lxx4j3fnoa : rtDW . ge34ybq3a0 ==
- 1 ? rtP . Saturation_LowerSat_kwi433xk5g : rtB . a3dofhbrxy ; switch ( (
int32_T ) rtP . Battery2_BatType ) { case 1 : rtB . f3w2xtsvho = rtB .
mszxp2nb10 ; break ; case 2 : rtB . f3w2xtsvho = muDoubleScalarExp ( -
10.176991150442477 * rtB . hrkgmangdo ) * 0.310711063328515 ; break ; case 3
: rtB . f3w2xtsvho = rtB . mszxp2nb10 ; break ; default : rtB . f3w2xtsvho =
rtB . mszxp2nb10 ; break ; } rtB . pcyqjx4sd2 = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . ch24s33jrc ) + rtB . f3w2xtsvho ) + - 0.0 * rtB . a3dofhbrxy ; rtB
. cxeawbkrpo = rtP . Constant_Value_fzmb45jy2r + rtB . pcyqjx4sd2 ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . djo5beq3n0 = ( rtB . cxeawbkrpo > rtP . Constant1_Value_jelmmtr1rj ) ;
} rtB . hy1qp5kmnb = rtDW . djo5beq3n0 ; } rtB . ag14fyi5we = 0.0 ; rtB .
ag14fyi5we += rtP . BAL_C_pnvzkp4ayj * rtX . cveknlxk0w ; rtB . gdlqjdwsgs =
rtP . R1_Gain_k1h1x1zryv * rtB . ag14fyi5we ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . gil4ie50ol = ( rtB .
cxeawbkrpo < rtB . gdlqjdwsgs ) ; } rtB . ixe2myxgue = rtDW . gil4ie50ol ;
rtB . ihicpd1xdt = rtDW . mde444qrus ; rtB . mil2gvjxva = rtP .
R2_Gain_fij43s2whq * rtB . ihicpd1xdt ; rtB . d1gujx31mw = 1.000001 * rtB .
mil2gvjxva * 0.96711798839458663 / 0.9999 ; } if ( rtB . hy1qp5kmnb ) { rtB .
pfiy5maj4o = rtP . Constant1_Value_jelmmtr1rj ; } else { if ( rtB .
ixe2myxgue ) { rtB . orsju1bbcs = rtB . gdlqjdwsgs ; } else { rtB .
orsju1bbcs = rtB . cxeawbkrpo ; } rtB . pfiy5maj4o = rtB . orsju1bbcs ; } rtB
. pw25npqcl5 = 0.0 ; rtB . pw25npqcl5 += rtP . Currentfilter_C_hx4sknoziy *
rtX . iqfvbswlqx ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . aarpnpqgmu = ( rtB . pw25npqcl5 >
rtP . Constant_Value_bksqnhysc0 ) ; } rtB . ik5rmfzive = rtDW . aarpnpqgmu ;
rtB . nqrbrzc3qp = rtDW . egfu4zp5ck ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
dwwhqwbiro , ( rtB . ik5rmfzive ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . lldjl4eyzi != 0 ) ) { rtX . aczscrflwb = rtB . nqrbrzc3qp ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . aczscrflwb
>= rtP . inti_UpperSat_nowwhgaxwk ) { if ( rtX . aczscrflwb != rtP .
inti_UpperSat_nowwhgaxwk ) { rtX . aczscrflwb = rtP .
inti_UpperSat_nowwhgaxwk ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . ed3nvtxxjm = 3 ; } else if ( rtX . aczscrflwb <= rtP .
inti_LowerSat_cwekkzbyq1 ) { if ( rtX . aczscrflwb != rtP .
inti_LowerSat_cwekkzbyq1 ) { rtX . aczscrflwb = rtP .
inti_LowerSat_cwekkzbyq1 ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . ed3nvtxxjm = 4 ; } else { if ( rtDW . ed3nvtxxjm != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . ed3nvtxxjm = 0
; } rtB . chktlyn3xt = rtX . aczscrflwb ; } else { rtB . chktlyn3xt = rtX .
aczscrflwb ; } rtB . p55huzvwwq = rtP . Gain_Gain_jbuudt1ftk * rtB .
chktlyn3xt ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . cgfl554d0l = ( rtB . p55huzvwwq >
rtB . mil2gvjxva ) ; } rtB . db3qyyuroe = rtDW . cgfl554d0l ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . p51wmaigg2 = ( rtB . p55huzvwwq <
rtP . Constant9_Value_nhyzz1ckmw ) ; } rtB . hqnpeamwdn = rtDW . p51wmaigg2 ;
} if ( rtB . db3qyyuroe ) { rtB . ncsmjyn2oi = rtB . mil2gvjxva ; } else { if
( rtB . hqnpeamwdn ) { rtB . ienzqz0wrj = rtP . Constant9_Value_nhyzz1ckmw ;
} else { rtB . ienzqz0wrj = rtB . p55huzvwwq ; } rtB . ncsmjyn2oi = rtB .
ienzqz0wrj ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . geb4p4zdgn = ( rtB . d1gujx31mw <=
rtB . ncsmjyn2oi ) ; } rtB . dixauele0b = rtDW . geb4p4zdgn ; } if ( rtB .
dixauele0b ) { rtB . lpwkyiqyni = rtB . mil2gvjxva ; } else { rtB .
lpwkyiqyni = rtB . ncsmjyn2oi ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
ihicpd1xdt / ( rtB . ihicpd1xdt - rtB . lpwkyiqyni ) * rtB . lpwkyiqyni ;
jmuz0todoh = - rtB . ik5rmfzive * 0.00461995246297257 * rtB . pw25npqcl5 *
rtB . ihicpd1xdt / ( rtB . ihicpd1xdt - rtB . lpwkyiqyni ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . mudvde1asq = rtP . R3_Gain_de1tgv0zzw
* rtB . ihicpd1xdt ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
opozmxoahv = ( rtB . p55huzvwwq > rtB . mudvde1asq ) ; } rtB . ggsuorkr3o =
rtDW . opozmxoahv ; rtB . n35vhllexk = - rtB . mudvde1asq * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . p3ylutwfna = ( rtB .
p55huzvwwq < rtB . n35vhllexk ) ; } rtB . ndpfkqx0ft = rtDW . p3ylutwfna ; }
if ( rtB . ggsuorkr3o ) { rtB . m5mcuoxuhb = rtB . mudvde1asq ; } else { if (
rtB . ndpfkqx0ft ) { rtB . bsptkj545k = rtB . n35vhllexk ; } else { rtB .
bsptkj545k = rtB . p55huzvwwq ; } rtB . m5mcuoxuhb = rtB . bsptkj545k ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . fma5ryxgkz = ( rtB . pw25npqcl5 < rtP . Constant_Value_owtewy0ssm ) ;
} rtB . dbom2viqze = rtDW . fma5ryxgkz ; } switch ( ( int32_T ) rtP .
Battery3_BatType ) { case 1 : rtB . oypuqwf0gd [ 0 ] = rtP .
Constant4_Value_cmgjzabbd1 * rtB . m5mcuoxuhb ; rtB . oypuqwf0gd [ 1 ] = rtP
. Constant4_Value_cmgjzabbd1 * rtB . pw25npqcl5 ; rtB . oypuqwf0gd [ 2 ] =
rtP . Constant4_Value_cmgjzabbd1 * rtB . dbom2viqze ; rtB . oypuqwf0gd [ 3 ]
= rtP . Constant4_Value_cmgjzabbd1 * rtB . ihicpd1xdt ; rtB . euguupc5q0 = -
rtB . oypuqwf0gd [ 2 ] * 0.00461995246297257 * rtB . oypuqwf0gd [ 1 ] * (
6.2039999999999846 / ( rtB . oypuqwf0gd [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . jhubv1l5zc [ 0 ] = rtP . Constant1_Value_gbfcrdkgqa *
rtB . m5mcuoxuhb ; rtB . jhubv1l5zc [ 1 ] = rtP . Constant1_Value_gbfcrdkgqa
* rtB . pw25npqcl5 ; rtB . jhubv1l5zc [ 2 ] = rtP .
Constant1_Value_gbfcrdkgqa * rtB . dbom2viqze ; rtB . jhubv1l5zc [ 3 ] = rtP
. Constant1_Value_gbfcrdkgqa * rtB . ihicpd1xdt ; rtB . euguupc5q0 = - rtB .
jhubv1l5zc [ 2 ] * 0.00461995246297257 * rtB . jhubv1l5zc [ 1 ] * rtB .
jhubv1l5zc [ 3 ] / ( rtB . jhubv1l5zc [ 3 ] * 0.1 + rtB . jhubv1l5zc [ 0 ] )
; break ; case 3 : rtB . meyjept3hg [ 0 ] = rtP . Constant3_Value_hat1prtoip
* rtB . m5mcuoxuhb ; rtB . meyjept3hg [ 1 ] = rtP .
Constant3_Value_hat1prtoip * rtB . pw25npqcl5 ; rtB . meyjept3hg [ 2 ] = rtP
. Constant3_Value_hat1prtoip * rtB . dbom2viqze ; rtB . meyjept3hg [ 3 ] =
rtP . Constant3_Value_hat1prtoip * rtB . ihicpd1xdt ; rtB . euguupc5q0 = -
rtB . meyjept3hg [ 2 ] * 0.00461995246297257 * rtB . meyjept3hg [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . meyjept3hg [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . eiglycnzan [ 0 ] = rtP .
Constant2_Value_gnk2tjoo5o * rtB . m5mcuoxuhb ; rtB . eiglycnzan [ 1 ] = rtP
. Constant2_Value_gnk2tjoo5o * rtB . pw25npqcl5 ; rtB . eiglycnzan [ 2 ] =
rtP . Constant2_Value_gnk2tjoo5o * rtB . dbom2viqze ; rtB . eiglycnzan [ 3 ]
= rtP . Constant2_Value_gnk2tjoo5o * rtB . ihicpd1xdt ; rtB . euguupc5q0 = -
rtB . eiglycnzan [ 2 ] * 0.00461995246297257 * rtB . eiglycnzan [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . eiglycnzan [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . oa1h22e1nc = rtX . a20yshtbnb ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . dsor1ukpll = rtB . lpwkyiqyni >= rtP .
Saturation_UpperSat_blj3ug4rzx ? 1 : rtB . lpwkyiqyni > rtP .
Saturation_LowerSat_o0i20janpw ? 0 : - 1 ; } rtB . hby04c2n1x = rtDW .
dsor1ukpll == 1 ? rtP . Saturation_UpperSat_blj3ug4rzx : rtDW . dsor1ukpll ==
- 1 ? rtP . Saturation_LowerSat_o0i20janpw : rtB . lpwkyiqyni ; switch ( (
int32_T ) rtP . Battery3_BatType ) { case 1 : rtB . fqmyfgc0km = rtB .
oa1h22e1nc ; break ; case 2 : rtB . fqmyfgc0km = muDoubleScalarExp ( -
10.176991150442477 * rtB . hby04c2n1x ) * 0.310711063328515 ; break ; case 3
: rtB . fqmyfgc0km = rtB . oa1h22e1nc ; break ; default : rtB . fqmyfgc0km =
rtB . oa1h22e1nc ; break ; } rtB . ekirprgoht = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . euguupc5q0 ) + rtB . fqmyfgc0km ) + - 0.0 * rtB . lpwkyiqyni ; rtB
. bbekmjhgcu = rtP . Constant_Value_kiu123temw + rtB . ekirprgoht ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . khxogtuz1l = ( rtB . bbekmjhgcu > rtP . Constant1_Value_jj3f5fu3xp ) ;
} rtB . jatdb2hgzm = rtDW . khxogtuz1l ; } rtB . grb5xsoeik = 0.0 ; rtB .
grb5xsoeik += rtP . BAL_C_ix2bm3qtha * rtX . m2tz1exxd4 ; rtB . nyjzof0rx3 =
rtP . R1_Gain_elo0441xsu * rtB . grb5xsoeik ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . d4qmht1xff = ( rtB .
bbekmjhgcu < rtB . nyjzof0rx3 ) ; } rtB . cvyse4x1ck = rtDW . d4qmht1xff ;
rtB . pbs4th3eaf = rtDW . jjpmmqdhaq ; rtB . leccoparpy = rtP .
R2_Gain_akgkexbqnd * rtB . pbs4th3eaf ; rtB . ogcju0kfgh = 1.000001 * rtB .
leccoparpy * 0.96711798839458663 / 0.9999 ; } if ( rtB . jatdb2hgzm ) { rtB .
aq2lacmksf = rtP . Constant1_Value_jj3f5fu3xp ; } else { if ( rtB .
cvyse4x1ck ) { rtB . nxkj21olit = rtB . nyjzof0rx3 ; } else { rtB .
nxkj21olit = rtB . bbekmjhgcu ; } rtB . aq2lacmksf = rtB . nxkj21olit ; } rtB
. c4wkrk0zxw = 0.0 ; rtB . c4wkrk0zxw += rtP . Currentfilter_C_muylregegy *
rtX . n3r5zcmpoi ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hjxqlr4sag = ( rtB . c4wkrk0zxw >
rtP . Constant_Value_kedzfrfegv ) ; } rtB . jtgqzbh1iz = rtDW . hjxqlr4sag ;
rtB . ctwhtsiqht = rtDW . knijrjnyhh ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
lm2mnmnxo1 , ( rtB . jtgqzbh1iz ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . gxvtetrs04 != 0 ) ) { rtX . bz3dftuo0x = rtB . ctwhtsiqht ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . bz3dftuo0x
>= rtP . inti_UpperSat_itde10ibkj ) { if ( rtX . bz3dftuo0x != rtP .
inti_UpperSat_itde10ibkj ) { rtX . bz3dftuo0x = rtP .
inti_UpperSat_itde10ibkj ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . cokzwj0i4g = 3 ; } else if ( rtX . bz3dftuo0x <= rtP .
inti_LowerSat_nb1wwuftgl ) { if ( rtX . bz3dftuo0x != rtP .
inti_LowerSat_nb1wwuftgl ) { rtX . bz3dftuo0x = rtP .
inti_LowerSat_nb1wwuftgl ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . cokzwj0i4g = 4 ; } else { if ( rtDW . cokzwj0i4g != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . cokzwj0i4g = 0
; } rtB . fdxkmdm50j = rtX . bz3dftuo0x ; } else { rtB . fdxkmdm50j = rtX .
bz3dftuo0x ; } rtB . cgevkfqtmb = rtP . Gain_Gain_l5lbde12wy * rtB .
fdxkmdm50j ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . eg3zr5htps = ( rtB . cgevkfqtmb >
rtB . leccoparpy ) ; } rtB . m5lqxlhg5k = rtDW . eg3zr5htps ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . gazfgp55bt = ( rtB . cgevkfqtmb <
rtP . Constant9_Value_ffsooduwum ) ; } rtB . egc5tqeng4 = rtDW . gazfgp55bt ;
} if ( rtB . m5lqxlhg5k ) { rtB . py4io1p2ai = rtB . leccoparpy ; } else { if
( rtB . egc5tqeng4 ) { rtB . mqsdawspxk = rtP . Constant9_Value_ffsooduwum ;
} else { rtB . mqsdawspxk = rtB . cgevkfqtmb ; } rtB . py4io1p2ai = rtB .
mqsdawspxk ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . jkumuiblmb = ( rtB . ogcju0kfgh <=
rtB . py4io1p2ai ) ; } rtB . hdec1eqbit = rtDW . jkumuiblmb ; } if ( rtB .
hdec1eqbit ) { rtB . e2fmskpokg = rtB . leccoparpy ; } else { rtB .
e2fmskpokg = rtB . py4io1p2ai ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
pbs4th3eaf / ( rtB . pbs4th3eaf - rtB . e2fmskpokg ) * rtB . e2fmskpokg ;
jmuz0todoh = - rtB . jtgqzbh1iz * 0.00461995246297257 * rtB . c4wkrk0zxw *
rtB . pbs4th3eaf / ( rtB . pbs4th3eaf - rtB . e2fmskpokg ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . pqnqe2hboi = rtP . R3_Gain_nk0ujvzftk
* rtB . pbs4th3eaf ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
nt4ghy3024 = ( rtB . cgevkfqtmb > rtB . pqnqe2hboi ) ; } rtB . dxpca0qb4k =
rtDW . nt4ghy3024 ; rtB . lwf12tqfq2 = - rtB . pqnqe2hboi * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . aux30da2zu = ( rtB .
cgevkfqtmb < rtB . lwf12tqfq2 ) ; } rtB . hd4g4dpfnd = rtDW . aux30da2zu ; }
if ( rtB . dxpca0qb4k ) { rtB . ahonmvrnyx = rtB . pqnqe2hboi ; } else { if (
rtB . hd4g4dpfnd ) { rtB . h524nvoxyr = rtB . lwf12tqfq2 ; } else { rtB .
h524nvoxyr = rtB . cgevkfqtmb ; } rtB . ahonmvrnyx = rtB . h524nvoxyr ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . aqmi0ximsk = ( rtB . c4wkrk0zxw < rtP . Constant_Value_opaksbgo21 ) ;
} rtB . fvxbq05uoi = rtDW . aqmi0ximsk ; } switch ( ( int32_T ) rtP .
Battery4_BatType ) { case 1 : rtB . igqicy0x3l [ 0 ] = rtP .
Constant4_Value_ohbtynzx54 * rtB . ahonmvrnyx ; rtB . igqicy0x3l [ 1 ] = rtP
. Constant4_Value_ohbtynzx54 * rtB . c4wkrk0zxw ; rtB . igqicy0x3l [ 2 ] =
rtP . Constant4_Value_ohbtynzx54 * rtB . fvxbq05uoi ; rtB . igqicy0x3l [ 3 ]
= rtP . Constant4_Value_ohbtynzx54 * rtB . pbs4th3eaf ; rtB . nk05l4h0y2 = -
rtB . igqicy0x3l [ 2 ] * 0.00461995246297257 * rtB . igqicy0x3l [ 1 ] * (
6.2039999999999846 / ( rtB . igqicy0x3l [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . p0apn1tlxl [ 0 ] = rtP . Constant1_Value_am3al2n15v *
rtB . ahonmvrnyx ; rtB . p0apn1tlxl [ 1 ] = rtP . Constant1_Value_am3al2n15v
* rtB . c4wkrk0zxw ; rtB . p0apn1tlxl [ 2 ] = rtP .
Constant1_Value_am3al2n15v * rtB . fvxbq05uoi ; rtB . p0apn1tlxl [ 3 ] = rtP
. Constant1_Value_am3al2n15v * rtB . pbs4th3eaf ; rtB . nk05l4h0y2 = - rtB .
p0apn1tlxl [ 2 ] * 0.00461995246297257 * rtB . p0apn1tlxl [ 1 ] * rtB .
p0apn1tlxl [ 3 ] / ( rtB . p0apn1tlxl [ 3 ] * 0.1 + rtB . p0apn1tlxl [ 0 ] )
; break ; case 3 : rtB . ftuq1tkirb [ 0 ] = rtP . Constant3_Value_mujtf1guv4
* rtB . ahonmvrnyx ; rtB . ftuq1tkirb [ 1 ] = rtP .
Constant3_Value_mujtf1guv4 * rtB . c4wkrk0zxw ; rtB . ftuq1tkirb [ 2 ] = rtP
. Constant3_Value_mujtf1guv4 * rtB . fvxbq05uoi ; rtB . ftuq1tkirb [ 3 ] =
rtP . Constant3_Value_mujtf1guv4 * rtB . pbs4th3eaf ; rtB . nk05l4h0y2 = -
rtB . ftuq1tkirb [ 2 ] * 0.00461995246297257 * rtB . ftuq1tkirb [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . ftuq1tkirb [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . ooxivauy2x [ 0 ] = rtP .
Constant2_Value_odhbgl2n1s * rtB . ahonmvrnyx ; rtB . ooxivauy2x [ 1 ] = rtP
. Constant2_Value_odhbgl2n1s * rtB . c4wkrk0zxw ; rtB . ooxivauy2x [ 2 ] =
rtP . Constant2_Value_odhbgl2n1s * rtB . fvxbq05uoi ; rtB . ooxivauy2x [ 3 ]
= rtP . Constant2_Value_odhbgl2n1s * rtB . pbs4th3eaf ; rtB . nk05l4h0y2 = -
rtB . ooxivauy2x [ 2 ] * 0.00461995246297257 * rtB . ooxivauy2x [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . ooxivauy2x [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . pm301io1ny = rtX . e02u4qxaaf ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . gnfw0t231h = rtB . e2fmskpokg >= rtP .
Saturation_UpperSat_c0l2pkijii ? 1 : rtB . e2fmskpokg > rtP .
Saturation_LowerSat_g1ovkjgj1x ? 0 : - 1 ; } rtB . gey35a0elw = rtDW .
gnfw0t231h == 1 ? rtP . Saturation_UpperSat_c0l2pkijii : rtDW . gnfw0t231h ==
- 1 ? rtP . Saturation_LowerSat_g1ovkjgj1x : rtB . e2fmskpokg ; switch ( (
int32_T ) rtP . Battery4_BatType ) { case 1 : rtB . ac3qvilnfk = rtB .
pm301io1ny ; break ; case 2 : rtB . ac3qvilnfk = muDoubleScalarExp ( -
10.176991150442477 * rtB . gey35a0elw ) * 0.310711063328515 ; break ; case 3
: rtB . ac3qvilnfk = rtB . pm301io1ny ; break ; default : rtB . ac3qvilnfk =
rtB . pm301io1ny ; break ; } rtB . ejxcm2rvyf = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . nk05l4h0y2 ) + rtB . ac3qvilnfk ) + - 0.0 * rtB . e2fmskpokg ; rtB
. gc2gnhaysc = rtP . Constant_Value_em2zyolrnm + rtB . ejxcm2rvyf ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . bf132dfs4i = ( rtB . gc2gnhaysc > rtP . Constant1_Value_myhrse5szs ) ;
} rtB . cj3lmhi2x0 = rtDW . bf132dfs4i ; } rtB . btlvzhj54h = 0.0 ; rtB .
btlvzhj54h += rtP . BAL_C_hfghx3gysd * rtX . lkcwi10nsx ; rtB . bxllmuyk2m =
rtP . R1_Gain_ay3u4mrv4p * rtB . btlvzhj54h ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . n22ezzj533 = ( rtB .
gc2gnhaysc < rtB . bxllmuyk2m ) ; } rtB . ewvip3v1vs = rtDW . n22ezzj533 ;
rtB . ok2bxp4qq0 = rtDW . curbfhmvfh ; rtB . ffmj4w3cmt = rtP .
R2_Gain_axv50jbqfg * rtB . ok2bxp4qq0 ; rtB . lqzzl3sci3 = 1.000001 * rtB .
ffmj4w3cmt * 0.96711798839458663 / 0.9999 ; } if ( rtB . cj3lmhi2x0 ) { rtB .
huhl4ltvhz = rtP . Constant1_Value_myhrse5szs ; } else { if ( rtB .
ewvip3v1vs ) { rtB . otljw5bfqz = rtB . bxllmuyk2m ; } else { rtB .
otljw5bfqz = rtB . gc2gnhaysc ; } rtB . huhl4ltvhz = rtB . otljw5bfqz ; } rtB
. lwj3vtbuti = 0.0 ; rtB . lwj3vtbuti += rtP . Currentfilter_C_e5mev0pk52 *
rtX . l1c0yrfxl4 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . egy3i3psvd = ( rtB . lwj3vtbuti >
rtP . Constant_Value_epq2rsx4ba ) ; } rtB . lbo2irmbzd = rtDW . egy3i3psvd ;
rtB . lirqj0t5wl = rtDW . h51d42z1yp ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
eqomayvlng , ( rtB . lbo2irmbzd ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . frtlsutffh != 0 ) ) { rtX . lgrzwldtuz = rtB . lirqj0t5wl ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . lgrzwldtuz
>= rtP . inti_UpperSat_ff0nysnmjy ) { if ( rtX . lgrzwldtuz != rtP .
inti_UpperSat_ff0nysnmjy ) { rtX . lgrzwldtuz = rtP .
inti_UpperSat_ff0nysnmjy ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . lv22brfstt = 3 ; } else if ( rtX . lgrzwldtuz <= rtP .
inti_LowerSat_hzpmw3xl5s ) { if ( rtX . lgrzwldtuz != rtP .
inti_LowerSat_hzpmw3xl5s ) { rtX . lgrzwldtuz = rtP .
inti_LowerSat_hzpmw3xl5s ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . lv22brfstt = 4 ; } else { if ( rtDW . lv22brfstt != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . lv22brfstt = 0
; } rtB . n1240az2ry = rtX . lgrzwldtuz ; } else { rtB . n1240az2ry = rtX .
lgrzwldtuz ; } rtB . fomxtscak4 = rtP . Gain_Gain_a4qiy5rws3 * rtB .
n1240az2ry ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . i5m44h50ql = ( rtB . fomxtscak4 >
rtB . ffmj4w3cmt ) ; } rtB . aj1fizh15j = rtDW . i5m44h50ql ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . axjy40izfe = ( rtB . fomxtscak4 <
rtP . Constant9_Value_bcezbzp4a1 ) ; } rtB . ekz0c33q4s = rtDW . axjy40izfe ;
} if ( rtB . aj1fizh15j ) { rtB . eu0tsijyvf = rtB . ffmj4w3cmt ; } else { if
( rtB . ekz0c33q4s ) { rtB . n4uk00kdia = rtP . Constant9_Value_bcezbzp4a1 ;
} else { rtB . n4uk00kdia = rtB . fomxtscak4 ; } rtB . eu0tsijyvf = rtB .
n4uk00kdia ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . jq3vvbxrjf = ( rtB . lqzzl3sci3 <=
rtB . eu0tsijyvf ) ; } rtB . gkdril5bnk = rtDW . jq3vvbxrjf ; } if ( rtB .
gkdril5bnk ) { rtB . pr00fiymmv = rtB . ffmj4w3cmt ; } else { rtB .
pr00fiymmv = rtB . eu0tsijyvf ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
ok2bxp4qq0 / ( rtB . ok2bxp4qq0 - rtB . pr00fiymmv ) * rtB . pr00fiymmv ;
jmuz0todoh = - rtB . lbo2irmbzd * 0.00461995246297257 * rtB . lwj3vtbuti *
rtB . ok2bxp4qq0 / ( rtB . ok2bxp4qq0 - rtB . pr00fiymmv ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . ir1j5szgpu = rtP . R3_Gain_hslbhc5rsq
* rtB . ok2bxp4qq0 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
okvjyaztbz = ( rtB . fomxtscak4 > rtB . ir1j5szgpu ) ; } rtB . bklkra2upj =
rtDW . okvjyaztbz ; rtB . kiqwsofa1f = - rtB . ir1j5szgpu * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . mez5whsqc3 = ( rtB .
fomxtscak4 < rtB . kiqwsofa1f ) ; } rtB . azrlqv35vl = rtDW . mez5whsqc3 ; }
if ( rtB . bklkra2upj ) { rtB . dg5blmqnoc = rtB . ir1j5szgpu ; } else { if (
rtB . azrlqv35vl ) { rtB . bkczs0rgig = rtB . kiqwsofa1f ; } else { rtB .
bkczs0rgig = rtB . fomxtscak4 ; } rtB . dg5blmqnoc = rtB . bkczs0rgig ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . pbjw4010b3 = ( rtB . lwj3vtbuti < rtP . Constant_Value_h45zreb2fb ) ;
} rtB . n2t5rlh5a1 = rtDW . pbjw4010b3 ; } switch ( ( int32_T ) rtP .
Battery5_BatType ) { case 1 : rtB . odqk34pxv4 [ 0 ] = rtP .
Constant4_Value_om2zghpbx3 * rtB . dg5blmqnoc ; rtB . odqk34pxv4 [ 1 ] = rtP
. Constant4_Value_om2zghpbx3 * rtB . lwj3vtbuti ; rtB . odqk34pxv4 [ 2 ] =
rtP . Constant4_Value_om2zghpbx3 * rtB . n2t5rlh5a1 ; rtB . odqk34pxv4 [ 3 ]
= rtP . Constant4_Value_om2zghpbx3 * rtB . ok2bxp4qq0 ; rtB . kme0uunwwt = -
rtB . odqk34pxv4 [ 2 ] * 0.00461995246297257 * rtB . odqk34pxv4 [ 1 ] * (
6.2039999999999846 / ( rtB . odqk34pxv4 [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . ljcv0f20dx [ 0 ] = rtP . Constant1_Value_ny1xdqiske *
rtB . dg5blmqnoc ; rtB . ljcv0f20dx [ 1 ] = rtP . Constant1_Value_ny1xdqiske
* rtB . lwj3vtbuti ; rtB . ljcv0f20dx [ 2 ] = rtP .
Constant1_Value_ny1xdqiske * rtB . n2t5rlh5a1 ; rtB . ljcv0f20dx [ 3 ] = rtP
. Constant1_Value_ny1xdqiske * rtB . ok2bxp4qq0 ; rtB . kme0uunwwt = - rtB .
ljcv0f20dx [ 2 ] * 0.00461995246297257 * rtB . ljcv0f20dx [ 1 ] * rtB .
ljcv0f20dx [ 3 ] / ( rtB . ljcv0f20dx [ 3 ] * 0.1 + rtB . ljcv0f20dx [ 0 ] )
; break ; case 3 : rtB . mkps5lmqxp [ 0 ] = rtP . Constant3_Value_kuyjih2run
* rtB . dg5blmqnoc ; rtB . mkps5lmqxp [ 1 ] = rtP .
Constant3_Value_kuyjih2run * rtB . lwj3vtbuti ; rtB . mkps5lmqxp [ 2 ] = rtP
. Constant3_Value_kuyjih2run * rtB . n2t5rlh5a1 ; rtB . mkps5lmqxp [ 3 ] =
rtP . Constant3_Value_kuyjih2run * rtB . ok2bxp4qq0 ; rtB . kme0uunwwt = -
rtB . mkps5lmqxp [ 2 ] * 0.00461995246297257 * rtB . mkps5lmqxp [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . mkps5lmqxp [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . c5ubn1fw3x [ 0 ] = rtP .
Constant2_Value_ppmjeluned * rtB . dg5blmqnoc ; rtB . c5ubn1fw3x [ 1 ] = rtP
. Constant2_Value_ppmjeluned * rtB . lwj3vtbuti ; rtB . c5ubn1fw3x [ 2 ] =
rtP . Constant2_Value_ppmjeluned * rtB . n2t5rlh5a1 ; rtB . c5ubn1fw3x [ 3 ]
= rtP . Constant2_Value_ppmjeluned * rtB . ok2bxp4qq0 ; rtB . kme0uunwwt = -
rtB . c5ubn1fw3x [ 2 ] * 0.00461995246297257 * rtB . c5ubn1fw3x [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . c5ubn1fw3x [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . n0aabzszil = rtX . aacuquz0zq ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . as2ykd4ql3 = rtB . pr00fiymmv >= rtP .
Saturation_UpperSat_dr1jmbb0we ? 1 : rtB . pr00fiymmv > rtP .
Saturation_LowerSat_haspwmkdbs ? 0 : - 1 ; } rtB . ay2k2e2iso = rtDW .
as2ykd4ql3 == 1 ? rtP . Saturation_UpperSat_dr1jmbb0we : rtDW . as2ykd4ql3 ==
- 1 ? rtP . Saturation_LowerSat_haspwmkdbs : rtB . pr00fiymmv ; switch ( (
int32_T ) rtP . Battery5_BatType ) { case 1 : rtB . c0ny2m5ibm = rtB .
n0aabzszil ; break ; case 2 : rtB . c0ny2m5ibm = muDoubleScalarExp ( -
10.176991150442477 * rtB . ay2k2e2iso ) * 0.310711063328515 ; break ; case 3
: rtB . c0ny2m5ibm = rtB . n0aabzszil ; break ; default : rtB . c0ny2m5ibm =
rtB . n0aabzszil ; break ; } rtB . kxsazgkodr = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . kme0uunwwt ) + rtB . c0ny2m5ibm ) + - 0.0 * rtB . pr00fiymmv ; rtB
. eal3yj23jh = rtP . Constant_Value_pfu1thap3i + rtB . kxsazgkodr ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . oyet01vjge = ( rtB . eal3yj23jh > rtP . Constant1_Value_h1thd4w1zg ) ;
} rtB . ldbnroag1b = rtDW . oyet01vjge ; } rtB . a0auqpldt3 = 0.0 ; rtB .
a0auqpldt3 += rtP . BAL_C_cq3wtorxkj * rtX . lnia4pzqrd ; rtB . krcxrj0fwb =
rtP . R1_Gain_bdgjwewy0w * rtB . a0auqpldt3 ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . bu03oe0pwq = ( rtB .
eal3yj23jh < rtB . krcxrj0fwb ) ; } rtB . ovwc5iskjn = rtDW . bu03oe0pwq ; }
if ( rtB . ldbnroag1b ) { rtB . kht02mkzqz = rtP . Constant1_Value_h1thd4w1zg
; } else { if ( rtB . ovwc5iskjn ) { rtB . gqznk4ohus = rtB . krcxrj0fwb ; }
else { rtB . gqznk4ohus = rtB . eal3yj23jh ; } rtB . kht02mkzqz = rtB .
gqznk4ohus ; } { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnOutputs (
rts , 0 ) ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . lm0gtrxle5 = rtP .
R4_Gain * rtB . ilnbwvckzb ; } rtB . hn4ssoozf0 = ( 1.0 - rtB . a3dofhbrxy /
rtB . lm0gtrxle5 ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW .
dcn3au535t = rtB . hn4ssoozf0 >= rtP . Saturation_UpperSat_aqwzuangfk ? 1 :
rtB . hn4ssoozf0 > rtP . Saturation_LowerSat_bcd3czsgyq ? 0 : - 1 ; } rtB .
ej54wy1bqz = rtDW . dcn3au535t == 1 ? rtP . Saturation_UpperSat_aqwzuangfk :
rtDW . dcn3au535t == - 1 ? rtP . Saturation_LowerSat_bcd3czsgyq : rtB .
hn4ssoozf0 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . d2s5el1uur = rtP .
R4_Gain_ckkisgzyfx * rtB . ihicpd1xdt ; } rtB . clgffaez3j = ( 1.0 - rtB .
lpwkyiqyni / rtB . d2s5el1uur ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . jertq5slcs = rtB . clgffaez3j >= rtP . Saturation_UpperSat_i3x3oscagf
? 1 : rtB . clgffaez3j > rtP . Saturation_LowerSat_gnz45aadu0 ? 0 : - 1 ; }
rtB . ijlr2pyucw = rtDW . jertq5slcs == 1 ? rtP .
Saturation_UpperSat_i3x3oscagf : rtDW . jertq5slcs == - 1 ? rtP .
Saturation_LowerSat_gnz45aadu0 : rtB . clgffaez3j ; rtB . lzsrkuhyhd = rtB .
ej54wy1bqz - rtB . ijlr2pyucw ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW
. l0t1omik1w = ( rtB . lzsrkuhyhd >= 0.0 ) ; } j2ki5b5bge = rtDW . l0t1omik1w
> 0 ? rtB . lzsrkuhyhd : - rtB . lzsrkuhyhd ; kxuzmahy5q = ( rtB . ej54wy1bqz
+ rtB . ijlr2pyucw ) * rtP . Constant7_Value ; rtB . f1qegg10im [ 0 ] =
j2ki5b5bge ; rtB . f1qegg10im [ 1 ] = kxuzmahy5q ; k0qu5tzxih = 0.0 ; tmp_p [
0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ]
= mh4svv2yac ( rtB . f1qegg10im [ 0 ] , tmp_p ) ; inputMFCache [ 1 ] =
mh4svv2yac ( rtB . f1qegg10im [ 0 ] , b ) ; inputMFCache [ 2 ] = mh4svv2yac (
rtB . f1qegg10im [ 0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ;
tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ] = mh4svv2yac ( rtB . f1qegg10im [ 1
] , tmp_p ) ; inputMFCache [ 4 ] = mh4svv2yac ( rtB . f1qegg10im [ 1 ] , d )
; inputMFCache [ 5 ] = mh4svv2yac ( rtB . f1qegg10im [ 1 ] , e ) ; for ( iy =
0 ; iy < 9 ; iy ++ ) { dthqwcoahr [ iy ] = 1.0 ; jmuz0todoh = dthqwcoahr [ iy
] ; x_idx_1 = inputMFCache [ f [ iy ] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 )
|| ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1
) ) ) ) { dthqwcoahr [ iy ] = x_idx_1 ; } else { dthqwcoahr [ iy ] =
jmuz0todoh ; } jmuz0todoh = dthqwcoahr [ iy ] ; x_idx_1 = inputMFCache [ f [
iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN (
jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { dthqwcoahr [ iy ]
= x_idx_1 ; } else { dthqwcoahr [ iy ] = jmuz0todoh ; } k0qu5tzxih +=
dthqwcoahr [ iy ] ; } a0xcadlxa3 ( j2ki5b5bge , kxuzmahy5q , dthqwcoahr , rtP
. OutputSamplePoints_Value_h5oozv5nnj , & rtB . dc2alimajs ) ; if (
k0qu5tzxih == 0.0 ) { rtB . jfxa2yvvgk = 0.5 ; } else { k0qu5tzxih = 0.0 ;
jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh += rtB .
dc2alimajs . nbuwrhuier [ iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB .
jfxa2yvvgk = ( rtP . OutputSamplePoints_Value_h5oozv5nnj [ 0 ] + rtP .
OutputSamplePoints_Value_h5oozv5nnj [ 100 ] ) / 2.0 ; } else { for ( iy = 0 ;
iy < 101 ; iy ++ ) { k0qu5tzxih += rtP . OutputSamplePoints_Value_h5oozv5nnj
[ iy ] * rtB . dc2alimajs . nbuwrhuier [ iy ] ; } rtB . jfxa2yvvgk = 1.0 /
jmuz0todoh * k0qu5tzxih ; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB .
pcwr2c4ky1 = rtP . R4_Gain_dz5jfuhlfd * rtB . kjybbipaii ; } rtB . mvut4g1kur
= ( 1.0 - rtB . h3wghvdhvb / rtB . pcwr2c4ky1 ) * 100.0 ; if (
ssIsMajorTimeStep ( rtS ) ) { rtDW . hdetrxmovp = rtB . mvut4g1kur >= rtP .
Saturation_UpperSat_pcz043fnep ? 1 : rtB . mvut4g1kur > rtP .
Saturation_LowerSat_b05y2t0vvl ? 0 : - 1 ; } rtB . ci24bcb2ae = rtDW .
hdetrxmovp == 1 ? rtP . Saturation_UpperSat_pcz043fnep : rtDW . hdetrxmovp ==
- 1 ? rtP . Saturation_LowerSat_b05y2t0vvl : rtB . mvut4g1kur ; rtB .
g0dxdurozf = rtB . ci24bcb2ae - rtB . ej54wy1bqz ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . d4gcz4s4op = ( rtB . g0dxdurozf >=
0.0 ) ; } b53hsyj2rm = rtDW . d4gcz4s4op > 0 ? rtB . g0dxdurozf : - rtB .
g0dxdurozf ; cgpn5xbggm = ( rtB . ci24bcb2ae + rtB . ej54wy1bqz ) * rtP .
Constant6_Value ; rtB . pvnl3mgpar [ 0 ] = b53hsyj2rm ; rtB . pvnl3mgpar [ 1
] = cgpn5xbggm ; k0qu5tzxih = 0.0 ; tmp_p [ 0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0
; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ] = mh4svv2yac ( rtB . pvnl3mgpar [
0 ] , tmp_p ) ; inputMFCache [ 1 ] = mh4svv2yac ( rtB . pvnl3mgpar [ 0 ] , b
) ; inputMFCache [ 2 ] = mh4svv2yac ( rtB . pvnl3mgpar [ 0 ] , c ) ; tmp_p [
0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ]
= mh4svv2yac ( rtB . pvnl3mgpar [ 1 ] , tmp_p ) ; inputMFCache [ 4 ] =
mh4svv2yac ( rtB . pvnl3mgpar [ 1 ] , d ) ; inputMFCache [ 5 ] = mh4svv2yac (
rtB . pvnl3mgpar [ 1 ] , e ) ; for ( iy = 0 ; iy < 9 ; iy ++ ) { dwlffapnhu [
iy ] = 1.0 ; jmuz0todoh = dwlffapnhu [ iy ] ; x_idx_1 = inputMFCache [ f [ iy
] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN ( jmuz0todoh
) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { dwlffapnhu [ iy ] = x_idx_1
; } else { dwlffapnhu [ iy ] = jmuz0todoh ; } jmuz0todoh = dwlffapnhu [ iy ]
; x_idx_1 = inputMFCache [ f [ iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 )
|| ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1
) ) ) ) { dwlffapnhu [ iy ] = x_idx_1 ; } else { dwlffapnhu [ iy ] =
jmuz0todoh ; } k0qu5tzxih += dwlffapnhu [ iy ] ; } a0xcadlxa3 ( b53hsyj2rm ,
cgpn5xbggm , dwlffapnhu , rtP . OutputSamplePoints_Value_bs0he10brt , & rtB .
g3klpnnfu2 ) ; if ( k0qu5tzxih == 0.0 ) { rtB . bpvwc2wtxs = 0.5 ; } else {
k0qu5tzxih = 0.0 ; jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) {
jmuz0todoh += rtB . g3klpnnfu2 . nbuwrhuier [ iy ] ; } if ( jmuz0todoh == 0.0
) { rtB . bpvwc2wtxs = ( rtP . OutputSamplePoints_Value_bs0he10brt [ 0 ] +
rtP . OutputSamplePoints_Value_bs0he10brt [ 100 ] ) / 2.0 ; } else { for ( iy
= 0 ; iy < 101 ; iy ++ ) { k0qu5tzxih += rtP .
OutputSamplePoints_Value_bs0he10brt [ iy ] * rtB . g3klpnnfu2 . nbuwrhuier [
iy ] ; } rtB . bpvwc2wtxs = 1.0 / jmuz0todoh * k0qu5tzxih ; } } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . b2v2matgmh = rtP . R4_Gain_nfptou1h22
* rtB . pbs4th3eaf ; } rtB . mvmrxossef = ( 1.0 - rtB . e2fmskpokg / rtB .
b2v2matgmh ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . o0qveok2yn =
rtB . mvmrxossef >= rtP . Saturation_UpperSat_luxvjfmfd3 ? 1 : rtB .
mvmrxossef > rtP . Saturation_LowerSat_mqcesji40p ? 0 : - 1 ; } rtB .
babnbnweud = rtDW . o0qveok2yn == 1 ? rtP . Saturation_UpperSat_luxvjfmfd3 :
rtDW . o0qveok2yn == - 1 ? rtP . Saturation_LowerSat_mqcesji40p : rtB .
mvmrxossef ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . mc4wzz2sor = rtP .
R4_Gain_e51nv5aiyc * rtB . ok2bxp4qq0 ; } rtB . ndew4yws5j = ( 1.0 - rtB .
pr00fiymmv / rtB . mc4wzz2sor ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . jpp24x3j0b = rtB . ndew4yws5j >= rtP . Saturation_UpperSat_p4wbgcsokm
? 1 : rtB . ndew4yws5j > rtP . Saturation_LowerSat_gdbbvpyvzg ? 0 : - 1 ; }
rtB . pnwi4fjn00 = rtDW . jpp24x3j0b == 1 ? rtP .
Saturation_UpperSat_p4wbgcsokm : rtDW . jpp24x3j0b == - 1 ? rtP .
Saturation_LowerSat_gdbbvpyvzg : rtB . ndew4yws5j ; rtB . e2rllfvmiw = rtB .
babnbnweud - rtB . pnwi4fjn00 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW
. dkr0lmfwa5 = ( rtB . e2rllfvmiw >= 0.0 ) ; } p4zz55422p = rtDW . dkr0lmfwa5
> 0 ? rtB . e2rllfvmiw : - rtB . e2rllfvmiw ; ntqwdwg3ka = ( rtB . babnbnweud
+ rtB . pnwi4fjn00 ) * rtP . Constant9_Value_crabpzohh2 ; rtB . lfs2dofdda [
0 ] = p4zz55422p ; rtB . lfs2dofdda [ 1 ] = ntqwdwg3ka ; k0qu5tzxih = 0.0 ;
tmp_p [ 0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ;
inputMFCache [ 0 ] = mh4svv2yac ( rtB . lfs2dofdda [ 0 ] , tmp_p ) ;
inputMFCache [ 1 ] = mh4svv2yac ( rtB . lfs2dofdda [ 0 ] , b ) ; inputMFCache
[ 2 ] = mh4svv2yac ( rtB . lfs2dofdda [ 0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ;
tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ] = mh4svv2yac (
rtB . lfs2dofdda [ 1 ] , tmp_p ) ; inputMFCache [ 4 ] = mh4svv2yac ( rtB .
lfs2dofdda [ 1 ] , d ) ; inputMFCache [ 5 ] = mh4svv2yac ( rtB . lfs2dofdda [
1 ] , e ) ; for ( iy = 0 ; iy < 9 ; iy ++ ) { cn5bvst0om [ iy ] = 1.0 ;
jmuz0todoh = cn5bvst0om [ iy ] ; x_idx_1 = inputMFCache [ f [ iy ] - 1 ] ; if
( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( !
muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { cn5bvst0om [ iy ] = x_idx_1 ; } else
{ cn5bvst0om [ iy ] = jmuz0todoh ; } jmuz0todoh = cn5bvst0om [ iy ] ; x_idx_1
= inputMFCache [ f [ iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 ) || (
muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) )
) { cn5bvst0om [ iy ] = x_idx_1 ; } else { cn5bvst0om [ iy ] = jmuz0todoh ; }
k0qu5tzxih += cn5bvst0om [ iy ] ; } a0xcadlxa3 ( p4zz55422p , ntqwdwg3ka ,
cn5bvst0om , rtP . OutputSamplePoints_Value_k42vy4v1xv , & rtB . o1zcbbtrng )
; if ( k0qu5tzxih == 0.0 ) { rtB . jxwilkiy2q = 0.5 ; } else { k0qu5tzxih =
0.0 ; jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh +=
rtB . o1zcbbtrng . nbuwrhuier [ iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB .
jxwilkiy2q = ( rtP . OutputSamplePoints_Value_k42vy4v1xv [ 0 ] + rtP .
OutputSamplePoints_Value_k42vy4v1xv [ 100 ] ) / 2.0 ; } else { for ( iy = 0 ;
iy < 101 ; iy ++ ) { k0qu5tzxih += rtP . OutputSamplePoints_Value_k42vy4v1xv
[ iy ] * rtB . o1zcbbtrng . nbuwrhuier [ iy ] ; } rtB . jxwilkiy2q = 1.0 /
jmuz0todoh * k0qu5tzxih ; } } rtB . nvas3hhzkc = rtB . ijlr2pyucw - rtB .
babnbnweud ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nrpmm2hefl = (
rtB . nvas3hhzkc >= 0.0 ) ; } l4xk434goc = rtDW . nrpmm2hefl > 0 ? rtB .
nvas3hhzkc : - rtB . nvas3hhzkc ; bmr0wof1hl = ( rtB . ijlr2pyucw + rtB .
babnbnweud ) * rtP . Constant8_Value ; rtB . klne3bbc2d [ 0 ] = l4xk434goc ;
rtB . klne3bbc2d [ 1 ] = bmr0wof1hl ; k0qu5tzxih = 0.0 ; tmp_p [ 0 ] = -
2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ] =
mh4svv2yac ( rtB . klne3bbc2d [ 0 ] , tmp_p ) ; inputMFCache [ 1 ] =
mh4svv2yac ( rtB . klne3bbc2d [ 0 ] , b ) ; inputMFCache [ 2 ] = mh4svv2yac (
rtB . klne3bbc2d [ 0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ;
tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ] = mh4svv2yac ( rtB . klne3bbc2d [ 1
] , tmp_p ) ; inputMFCache [ 4 ] = mh4svv2yac ( rtB . klne3bbc2d [ 1 ] , d )
; inputMFCache [ 5 ] = mh4svv2yac ( rtB . klne3bbc2d [ 1 ] , e ) ; for ( iy =
0 ; iy < 9 ; iy ++ ) { fxw2ruvdsa [ iy ] = 1.0 ; jmuz0todoh = fxw2ruvdsa [ iy
] ; x_idx_1 = inputMFCache [ f [ iy ] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 )
|| ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1
) ) ) ) { fxw2ruvdsa [ iy ] = x_idx_1 ; } else { fxw2ruvdsa [ iy ] =
jmuz0todoh ; } jmuz0todoh = fxw2ruvdsa [ iy ] ; x_idx_1 = inputMFCache [ f [
iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN (
jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { fxw2ruvdsa [ iy ]
= x_idx_1 ; } else { fxw2ruvdsa [ iy ] = jmuz0todoh ; } k0qu5tzxih +=
fxw2ruvdsa [ iy ] ; } a0xcadlxa3 ( l4xk434goc , bmr0wof1hl , fxw2ruvdsa , rtP
. OutputSamplePoints_Value_mkqnjleygm , & rtB . dieezpzkpy ) ; if (
k0qu5tzxih == 0.0 ) { rtB . ibr3y1gjec = 0.5 ; } else { k0qu5tzxih = 0.0 ;
jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh += rtB .
dieezpzkpy . nbuwrhuier [ iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB .
ibr3y1gjec = ( rtP . OutputSamplePoints_Value_mkqnjleygm [ 0 ] + rtP .
OutputSamplePoints_Value_mkqnjleygm [ 100 ] ) / 2.0 ; } else { for ( iy = 0 ;
iy < 101 ; iy ++ ) { k0qu5tzxih += rtP . OutputSamplePoints_Value_mkqnjleygm
[ iy ] * rtB . dieezpzkpy . nbuwrhuier [ iy ] ; } rtB . ibr3y1gjec = 1.0 /
jmuz0todoh * k0qu5tzxih ; } } rtB . p00h0g1otp = cgpn5xbggm - bmr0wof1hl ; if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . audfqsd0mm = ( rtB . p00h0g1otp
>= 0.0 ) ; } ie4fkoj5zo = rtDW . audfqsd0mm > 0 ? rtB . p00h0g1otp : - rtB .
p00h0g1otp ; aa12daxney = ( cgpn5xbggm + bmr0wof1hl ) * rtP .
Constant2_Value_e4jyxae25b ; rtB . mrmctl4ouh [ 0 ] = ie4fkoj5zo ; rtB .
mrmctl4ouh [ 1 ] = aa12daxney ; k0qu5tzxih = 0.0 ; tmp_p [ 0 ] = - 2.085 ;
tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ] = mh4svv2yac (
rtB . mrmctl4ouh [ 0 ] , tmp_p ) ; inputMFCache [ 1 ] = mh4svv2yac ( rtB .
mrmctl4ouh [ 0 ] , b ) ; inputMFCache [ 2 ] = mh4svv2yac ( rtB . mrmctl4ouh [
0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ;
inputMFCache [ 3 ] = mh4svv2yac ( rtB . mrmctl4ouh [ 1 ] , tmp_p ) ;
inputMFCache [ 4 ] = mh4svv2yac ( rtB . mrmctl4ouh [ 1 ] , d ) ; inputMFCache
[ 5 ] = mh4svv2yac ( rtB . mrmctl4ouh [ 1 ] , e ) ; for ( iy = 0 ; iy < 9 ;
iy ++ ) { jaur2fpzjp [ iy ] = 1.0 ; jmuz0todoh = jaur2fpzjp [ iy ] ; x_idx_1
= inputMFCache [ f [ iy ] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 ) || (
muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) )
) { jaur2fpzjp [ iy ] = x_idx_1 ; } else { jaur2fpzjp [ iy ] = jmuz0todoh ; }
jmuz0todoh = jaur2fpzjp [ iy ] ; x_idx_1 = inputMFCache [ f [ iy + 9 ] + 2 ]
; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN ( jmuz0todoh ) && (
! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { jaur2fpzjp [ iy ] = x_idx_1 ; }
else { jaur2fpzjp [ iy ] = jmuz0todoh ; } k0qu5tzxih += jaur2fpzjp [ iy ] ; }
a0xcadlxa3 ( ie4fkoj5zo , aa12daxney , jaur2fpzjp , rtP .
OutputSamplePoints_Value , & rtB . ph0zzilf0u ) ; if ( k0qu5tzxih == 0.0 ) {
rtB . fh1zk0jwdl = 0.5 ; } else { k0qu5tzxih = 0.0 ; jmuz0todoh = 0.0 ; for (
iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh += rtB . ph0zzilf0u . nbuwrhuier [
iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB . fh1zk0jwdl = ( rtP .
OutputSamplePoints_Value [ 0 ] + rtP . OutputSamplePoints_Value [ 100 ] ) /
2.0 ; } else { for ( iy = 0 ; iy < 101 ; iy ++ ) { k0qu5tzxih += rtP .
OutputSamplePoints_Value [ iy ] * rtB . ph0zzilf0u . nbuwrhuier [ iy ] ; }
rtB . fh1zk0jwdl = 1.0 / jmuz0todoh * k0qu5tzxih ; } } rtB . mjehla4ytu =
kxuzmahy5q - ntqwdwg3ka ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
hwrms4izrt = ( rtB . mjehla4ytu >= 0.0 ) ; } crwwbme23f = rtDW . hwrms4izrt >
0 ? rtB . mjehla4ytu : - rtB . mjehla4ytu ; j1doyw2v5m = ( kxuzmahy5q +
ntqwdwg3ka ) * rtP . Constant3_Value_bkb3mktfvw ; rtB . a5y3jy0hyc [ 0 ] =
crwwbme23f ; rtB . a5y3jy0hyc [ 1 ] = j1doyw2v5m ; k0qu5tzxih = 0.0 ; tmp_p [
0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ]
= mh4svv2yac ( rtB . a5y3jy0hyc [ 0 ] , tmp_p ) ; inputMFCache [ 1 ] =
mh4svv2yac ( rtB . a5y3jy0hyc [ 0 ] , b ) ; inputMFCache [ 2 ] = mh4svv2yac (
rtB . a5y3jy0hyc [ 0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ;
tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ] = mh4svv2yac ( rtB . a5y3jy0hyc [ 1
] , tmp_p ) ; inputMFCache [ 4 ] = mh4svv2yac ( rtB . a5y3jy0hyc [ 1 ] , d )
; inputMFCache [ 5 ] = mh4svv2yac ( rtB . a5y3jy0hyc [ 1 ] , e ) ; for ( iy =
0 ; iy < 9 ; iy ++ ) { khbcap1kpw [ iy ] = 1.0 ; jmuz0todoh = khbcap1kpw [ iy
] ; x_idx_1 = inputMFCache [ f [ iy ] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 )
|| ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1
) ) ) ) { khbcap1kpw [ iy ] = x_idx_1 ; } else { khbcap1kpw [ iy ] =
jmuz0todoh ; } jmuz0todoh = khbcap1kpw [ iy ] ; x_idx_1 = inputMFCache [ f [
iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN (
jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { khbcap1kpw [ iy ]
= x_idx_1 ; } else { khbcap1kpw [ iy ] = jmuz0todoh ; } k0qu5tzxih +=
khbcap1kpw [ iy ] ; } a0xcadlxa3 ( crwwbme23f , j1doyw2v5m , khbcap1kpw , rtP
. OutputSamplePoints_Value_mmzz2j1vii , & rtB . cq21slkg0n ) ; if (
k0qu5tzxih == 0.0 ) { rtB . btdu3f30fd = 0.5 ; } else { k0qu5tzxih = 0.0 ;
jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh += rtB .
cq21slkg0n . nbuwrhuier [ iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB .
btdu3f30fd = ( rtP . OutputSamplePoints_Value_mmzz2j1vii [ 0 ] + rtP .
OutputSamplePoints_Value_mmzz2j1vii [ 100 ] ) / 2.0 ; } else { for ( iy = 0 ;
iy < 101 ; iy ++ ) { k0qu5tzxih += rtP . OutputSamplePoints_Value_mmzz2j1vii
[ iy ] * rtB . cq21slkg0n . nbuwrhuier [ iy ] ; } rtB . btdu3f30fd = 1.0 /
jmuz0todoh * k0qu5tzxih ; } } rtB . pkqxjtkxkb = ( ( ( ( rtB . ci24bcb2ae +
rtB . ej54wy1bqz ) + rtB . ijlr2pyucw ) + rtB . babnbnweud ) + rtB .
pnwi4fjn00 ) * rtP . Constant1_Value_kwlajmttwi ; if ( ssIsSampleHit ( rtS ,
1 , 0 ) ) { { if ( rtDW . dbblrjj2tk . AQHandles && ssGetLogOutput ( rtS ) )
{ sdiWriteSignal ( rtDW . dbblrjj2tk . AQHandles , ssGetTaskTime ( rtS , 1 )
, ( char * ) & rtB . ej54wy1bqz + 0 ) ; } } } rtB . hrmd1scdop = rtP .
donotdeletethisgain_Gain * rtB . e0hcimvo4b [ 1 ] ; rtB . oummy1cytb = rtB .
pfiy5maj4o - rtP . R_Gain * rtB . hrmd1scdop ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { { if ( rtDW . l22qnqwzjn . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . l22qnqwzjn . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . oummy1cytb + 0 ) ; } } { if ( rtDW . fo3wh2yatx .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . fo3wh2yatx .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . ijlr2pyucw + 0 ) ;
} } } rtB . heo3elq2ut = rtP . donotdeletethisgain_Gain_o42imifl5k * rtB .
e0hcimvo4b [ 2 ] ; rtB . gpvrv2cxlg = rtB . aq2lacmksf - rtP .
R_Gain_g4gmpqe5wx * rtB . heo3elq2ut ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . k2ffp3ntfr . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . k2ffp3ntfr . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . gpvrv2cxlg + 0 ) ; } } { if ( rtDW . nyfzlmf145 .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . nyfzlmf145 .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . babnbnweud + 0 ) ;
} } } rtB . fdbodvkrba = rtP . donotdeletethisgain_Gain_fjipbfzkks * rtB .
e0hcimvo4b [ 3 ] ; rtB . phw53k4pue = rtB . huhl4ltvhz - rtP .
R_Gain_biqz0al5hr * rtB . fdbodvkrba ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . h04wi2qgv5 . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . h04wi2qgv5 . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . phw53k4pue + 0 ) ; } } { if ( rtDW . jgsevaes2d .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . jgsevaes2d .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . pnwi4fjn00 + 0 ) ;
} } } rtB . ercy54k5it = rtP . donotdeletethisgain_Gain_ave45anr4u * rtB .
e0hcimvo4b [ 4 ] ; rtB . ie2kjjwcmg = rtB . kht02mkzqz - rtP .
R_Gain_bq04dmcpzt * rtB . ercy54k5it ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . j2pvryuk2u . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . j2pvryuk2u . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . ie2kjjwcmg + 0 ) ; } } { if ( rtDW . hqpvabyibc .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . hqpvabyibc .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . ci24bcb2ae + 0 ) ;
} } } rtB . m00kcxurwn = rtP . donotdeletethisgain_Gain_dywzmacz1o * rtB .
e0hcimvo4b [ 0 ] ; rtB . expbt1v2tz = rtB . luoecyht3u - rtP .
R_Gain_cwdppwgit4 * rtB . m00kcxurwn ; if ( ssGetIsOkayToUpdateMode ( rtS ) )
{ rtDW . gtcdjshroe = ( rtB . m00kcxurwn >= 0.0 ) ; } rtB . ekjp04xkv2 = rtDW
. gtcdjshroe > 0 ? rtB . m00kcxurwn : - rtB . m00kcxurwn ; if ( ssIsSampleHit
( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
n1fso1av4u = ( rtB . m00kcxurwn < rtP . Constant_Value_ogegtmkzv0 ) ; } rtB .
p0xfzbei1b = rtP . Gain4_Gain * ( real_T ) rtDW . n1fso1av4u ; } rtB .
bwtepwli4m = rtB . p0xfzbei1b - rtB . ohbzci5slc ; rtB . oslkgg532a = rtB .
ekjp04xkv2 * rtB . bwtepwli4m ; rtB . efpo04tyla = rtP . Gain1_Gain * rtB .
oslkgg532a ; rtB . hni1tcmitz = rtP . Gain2_Gain * rtB . h3wghvdhvb ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . fqhd2sk321 = ( rtB . hrmd1scdop >=
0.0 ) ; } rtB . civdr4g0u0 = rtDW . fqhd2sk321 > 0 ? rtB . hrmd1scdop : - rtB
. hrmd1scdop ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . orvtgsw01i = ( rtB . hrmd1scdop <
rtP . Constant_Value_h5irp45zuu ) ; } rtB . cwzjkwv2ox = rtP .
Gain4_Gain_kh00znyazs * ( real_T ) rtDW . orvtgsw01i ; } rtB . nndxmuz5qy =
rtB . cwzjkwv2ox - rtB . mszxp2nb10 ; rtB . kofeg0zb1z = rtB . civdr4g0u0 *
rtB . nndxmuz5qy ; rtB . m3dolrlfxz = rtP . Gain1_Gain_og11bwmhu2 * rtB .
kofeg0zb1z ; rtB . mdtzkyg1bb = rtP . Gain2_Gain_m4x3vq3y1f * rtB .
a3dofhbrxy ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . kxwxa3byt5 = (
rtB . heo3elq2ut >= 0.0 ) ; } rtB . fqdwuj2k1s = rtDW . kxwxa3byt5 > 0 ? rtB
. heo3elq2ut : - rtB . heo3elq2ut ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . i0pn21xe2p = ( rtB . heo3elq2ut
< rtP . Constant_Value_k5pwul1wle ) ; } rtB . l5tc3gqfzb = rtP .
Gain4_Gain_fstjjgzlds * ( real_T ) rtDW . i0pn21xe2p ; } rtB . m113skf5al =
rtB . l5tc3gqfzb - rtB . oa1h22e1nc ; rtB . gbknmusepz = rtB . fqdwuj2k1s *
rtB . m113skf5al ; rtB . gxyxfqaxjb = rtP . Gain1_Gain_anymdqpqln * rtB .
gbknmusepz ; rtB . odzmgjgd13 = rtP . Gain2_Gain_jptbha03po * rtB .
lpwkyiqyni ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . fogzt5jbmz = (
rtB . fdbodvkrba >= 0.0 ) ; } rtB . fi2b3dhkb3 = rtDW . fogzt5jbmz > 0 ? rtB
. fdbodvkrba : - rtB . fdbodvkrba ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . gljdehuiwg = ( rtB . fdbodvkrba
< rtP . Constant_Value_pp4lg2cwxs ) ; } rtB . m40urup0vc = rtP .
Gain4_Gain_n2oajsg4xg * ( real_T ) rtDW . gljdehuiwg ; } rtB . gbpkktvpuo =
rtB . m40urup0vc - rtB . pm301io1ny ; rtB . pyxgvfzagh = rtB . fi2b3dhkb3 *
rtB . gbpkktvpuo ; rtB . k5sv02vyqu = rtP . Gain1_Gain_baecfd2g1g * rtB .
pyxgvfzagh ; rtB . ne45ydwxry = rtP . Gain2_Gain_fe3eihrk0b * rtB .
e2fmskpokg ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . oq1utabldx = (
rtB . ercy54k5it >= 0.0 ) ; } rtB . gssybcpcse = rtDW . oq1utabldx > 0 ? rtB
. ercy54k5it : - rtB . ercy54k5it ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . mmoscpngve = ( rtB . ercy54k5it
< rtP . Constant_Value_khiqevv1tc ) ; } rtB . lm2n4ijyor = rtP .
Gain4_Gain_j4eqtusam3 * ( real_T ) rtDW . mmoscpngve ; } rtB . oxjq4swpla =
rtB . lm2n4ijyor - rtB . n0aabzszil ; rtB . hj3gx0gkev = rtB . gssybcpcse *
rtB . oxjq4swpla ; rtB . oncblw0ccg = rtP . Gain1_Gain_dq4vkdpk0h * rtB .
hj3gx0gkev ; rtB . lmx1f3qcpw = rtP . Gain2_Gain_of2pa5ka31 * rtB .
pr00fiymmv ; if ( ssIsSampleHit ( rtS , 6 , 0 ) ) { if ( ( rtB . btdu3f30fd *
rtP . PWM5_Period + ssGetTaskTime ( rtS , 6 ) <= ssGetTaskTime ( rtS , 6 ) +
2.8421709430404007E-14 ) && rtDW . fwfrplulil ) { rtB . gvzvt5tv3i = 0.0 ;
rtDW . icvovv1jq2 = false ; } else { rtB . gvzvt5tv3i = rtDW . icvovv1jq2 ; }
} if ( ssIsSampleHit ( rtS , 5 , 0 ) ) { if ( ( rtB . fh1zk0jwdl * rtP .
PWM_Period + ssGetTaskTime ( rtS , 5 ) <= ssGetTaskTime ( rtS , 5 ) +
2.8421709430404007E-14 ) && rtDW . ggmjvv0lb3 ) { rtB . juwmydw0tr = 0.0 ;
rtDW . iw1ylkptc1 = false ; } else { rtB . juwmydw0tr = rtDW . iw1ylkptc1 ; }
} if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . db4zg1qvnr = ! ( rtB .
gvzvt5tv3i != 0.0 ) ; } if ( ssIsSampleHit ( rtS , 7 , 0 ) ) { if ( ( rtB .
bpvwc2wtxs * rtP . PWM1_Period + ssGetTaskTime ( rtS , 7 ) <= ssGetTaskTime (
rtS , 7 ) + 2.8421709430404007E-14 ) && rtDW . doiwoekzov ) { rtB .
jrbeh4gjon = 0.0 ; rtDW . hekwrhnl5m = false ; } else { rtB . jrbeh4gjon =
rtDW . hekwrhnl5m ; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB .
babbdjgwl2 = ! ( rtB . juwmydw0tr != 0.0 ) ; } if ( ssIsSampleHit ( rtS , 4 ,
0 ) ) { if ( ( rtB . jfxa2yvvgk * rtP . PWM2_Period + ssGetTaskTime ( rtS , 4
) <= ssGetTaskTime ( rtS , 4 ) + 2.8421709430404007E-14 ) && rtDW .
bhhlshfa0t ) { rtB . h0sbflpvzu = 0.0 ; rtDW . offqujpaki = false ; } else {
rtB . h0sbflpvzu = rtDW . offqujpaki ; } } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtB . m0rozdflil = ! ( rtB . jrbeh4gjon != 0.0 ) ; } if ( ssIsSampleHit (
rtS , 3 , 0 ) ) { if ( ( rtB . ibr3y1gjec * rtP . PWM3_Period + ssGetTaskTime
( rtS , 3 ) <= ssGetTaskTime ( rtS , 3 ) + 2.8421709430404007E-14 ) && rtDW .
ot0jlfqn3i ) { rtB . cddvon4kch = 0.0 ; rtDW . hlvtogm2ca = false ; } else {
rtB . cddvon4kch = rtDW . hlvtogm2ca ; } } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtB . le12ofiyut = ! ( rtB . h0sbflpvzu != 0.0 ) ; } if ( ssIsSampleHit (
rtS , 2 , 0 ) ) { if ( ( rtB . jxwilkiy2q * rtP . PWM4_Period + ssGetTaskTime
( rtS , 2 ) <= ssGetTaskTime ( rtS , 2 ) + 2.8421709430404007E-14 ) && rtDW .
oasl5bklsg ) { rtB . jwyopjqrrt = 0.0 ; rtDW . i2lws3rgth = false ; } else {
rtB . jwyopjqrrt = rtDW . i2lws3rgth ; } } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtB . dnh3ifiezd = ! ( rtB . cddvon4kch != 0.0 ) ; rtB . grdrezphge = ! (
rtB . jwyopjqrrt != 0.0 ) ; } UNUSED_PARAMETER ( tid ) ; } void
MdlOutputsTID8 ( int_T tid ) { rtB . grnwe52eh1 = rtP . gate_Value ; rtB .
cckn1bvi00 = rtP . gate_Value_ghlgnnffhp ; rtB . jsgmo5wnpv = rtP .
gate_Value_e2pzllcxv0 ; rtB . nfqfvnlxj5 = rtP . gate_Value_odvaswnitz ; rtB
. ajs4brrkkk = rtP . gate_Value_hrisjp3q0m ; rtB . kmzuanhyxk = rtP .
gate_Value_gy4tkqzmme ; rtB . epnsbymmm2 = rtP . gate_Value_hu4hogb4lk ; rtB
. jffgurm1tz = rtP . gate_Value_hob43axlzj ; rtB . ef3o0lqjl4 = rtP .
gate_Value_o02a13bzdb ; rtB . hpvgxobeuc = rtP . gate_Value_awsbj1udfy ; rtB
. e0jfdwewz4 = rtP . gate_Value_lcm302k1d0 ; rtB . hdoahn5d4v = rtP .
gate_Value_hzvnhzjbik ; UNUSED_PARAMETER ( tid ) ; } void MdlUpdate ( int_T
tid ) { XDis * _rtXdis ; real_T dc ; SimStruct * S ; void * diag ; _rtXdis =
( ( XDis * ) ssGetContStateDisabled ( rtS ) ) ; if ( ssIsSampleHit ( rtS , 1
, 0 ) ) { rtDW . mx5vjacu5q = rtP . Constant12_Value ; rtDW . gu33m3cujr =
rtB . hni1tcmitz ; } rtDW . g55jrpbizl = 0 ; switch ( rtDW . m3sjkfetzr ) {
case 3 : if ( rtB . m00kcxurwn < 0.0 ) { rtDW . m3sjkfetzr = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . m00kcxurwn > 0.0 ) { rtDW . m3sjkfetzr = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
axoluperv2 = ( ( rtDW . m3sjkfetzr == 3 ) || ( rtDW . m3sjkfetzr == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . ihabibaari = rtP .
Constant12_Value_df3z3yuypl ; rtDW . g45xtcsm1y = rtB . mdtzkyg1bb ; } rtDW .
ojsrsvfc4d = 0 ; switch ( rtDW . hrm4dgu33i ) { case 3 : if ( rtB .
hrmd1scdop < 0.0 ) { rtDW . hrm4dgu33i = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . hrmd1scdop > 0.0 ) { rtDW . hrm4dgu33i = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
bhkc4j1ohz = ( ( rtDW . hrm4dgu33i == 3 ) || ( rtDW . hrm4dgu33i == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . mde444qrus = rtP .
Constant12_Value_ktnzmkcekm ; rtDW . egfu4zp5ck = rtB . odzmgjgd13 ; } rtDW .
lldjl4eyzi = 0 ; switch ( rtDW . ed3nvtxxjm ) { case 3 : if ( rtB .
heo3elq2ut < 0.0 ) { rtDW . ed3nvtxxjm = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . heo3elq2ut > 0.0 ) { rtDW . ed3nvtxxjm = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
aczscrflwb = ( ( rtDW . ed3nvtxxjm == 3 ) || ( rtDW . ed3nvtxxjm == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . jjpmmqdhaq = rtP .
Constant12_Value_jkrk5dvljw ; rtDW . knijrjnyhh = rtB . ne45ydwxry ; } rtDW .
gxvtetrs04 = 0 ; switch ( rtDW . cokzwj0i4g ) { case 3 : if ( rtB .
fdbodvkrba < 0.0 ) { rtDW . cokzwj0i4g = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . fdbodvkrba > 0.0 ) { rtDW . cokzwj0i4g = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
bz3dftuo0x = ( ( rtDW . cokzwj0i4g == 3 ) || ( rtDW . cokzwj0i4g == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . curbfhmvfh = rtP .
Constant12_Value_oujd2whfki ; rtDW . h51d42z1yp = rtB . lmx1f3qcpw ; } rtDW .
frtlsutffh = 0 ; switch ( rtDW . lv22brfstt ) { case 3 : if ( rtB .
ercy54k5it < 0.0 ) { rtDW . lv22brfstt = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . ercy54k5it > 0.0 ) { rtDW . lv22brfstt = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
lgrzwldtuz = ( ( rtDW . lv22brfstt == 3 ) || ( rtDW . lv22brfstt == 4 ) ) ; {
SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnUpdate ( rts , 0 ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } if ( ssIsSampleHit ( rtS ,
6 , 0 ) ) { if ( rtDW . icvovv1jq2 ) { dc = rtB . btdu3f30fd ; if ( ( rtP .
PWM5_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM5_Period ) || ( rtP
. PWM5_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr
( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM5/Variable Pulse Generator" , 2 , rtP . PWM5_Period , 2
, ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM5_Period + ssGetTaskTime ( rtS , 6 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 6 ) + ssGetTaskTime ( rtS , 6 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing2/PWM5/Variable Pulse Generator" , 2 , rtB . btdu3f30fd , 2 ,
rtP . PWM5_Period , 2 , ssGetTaskTime ( rtS , 6 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . dxjlf0kpmf ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
6 ) , 2 , rtB . btdu3f30fd , 3 ,
"activeBalancing2/PWM5/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . dxjlf0kpmf = false ; } }
if ( ( rtDW . glz3hn24br > 0.0 ) && ( rtDW . glz3hn24br == rtP . PWM5_Period
) ) { rtDW . jvh5mician ++ ; } else { rtDW . jvh5mician = 1ULL ; rtDW .
glz3hn24br = rtP . PWM5_Period ; rtDW . fcr2tgbfvo = ssGetTaskTime ( rtS , 6
) ; } rtDW . evcbaypssu = rtDW . glz3hn24br * ( real_T ) rtDW . jvh5mician +
rtDW . fcr2tgbfvo ; if ( rtDW . evcbaypssu - ( dc * rtP . PWM5_Period +
ssGetTaskTime ( rtS , 6 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
6 ) ) { _ssSetVarNextHitTime ( rtS , 4 , ssGetTaskTime ( rtS , 6 ) + dc * rtP
. PWM5_Period ) ; rtDW . icvovv1jq2 = false ; rtDW . fwfrplulil = false ; }
else if ( ( rtDW . evcbaypssu - ( dc * rtP . PWM5_Period + ssGetTaskTime (
rtS , 6 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 6 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM5/Variable Pulse Generator" , 2 , rtP . PWM5_Period , 2
, ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 4 , rtDW . evcbaypssu ) ; rtDW . icvovv1jq2 =
true ; rtDW . fwfrplulil = true ; } } else { if ( rtDW . fwfrplulil ) { if (
( rtP . PWM5_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM5_Period )
|| ( rtP . PWM5_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM5/Variable Pulse Generator" , 2 , rtP . PWM5_Period , 2
, ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. btdu3f30fd < 0.0 ) && rtDW . os5dfkhn1w ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 6 ) , 2 , rtB . btdu3f30fd , 3 ,
"activeBalancing2/PWM5/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . os5dfkhn1w = false ; }
if ( ( rtDW . glz3hn24br > 0.0 ) && ( rtDW . glz3hn24br == rtP . PWM5_Period
) ) { rtDW . jvh5mician ++ ; } else { rtDW . jvh5mician = 1ULL ; rtDW .
glz3hn24br = rtP . PWM5_Period ; rtDW . fcr2tgbfvo = ssGetTaskTime ( rtS , 6
) ; } _ssSetVarNextHitTime ( rtS , 4 , ssGetTaskTime ( rtS , 6 ) + rtP .
PWM5_Period ) ; } else if ( rtDW . evcbaypssu > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 6 ) + ssGetTaskTime ( rtS , 6 ) ) {
_ssSetVarNextHitTime ( rtS , 4 , rtDW . evcbaypssu ) ; } rtDW . icvovv1jq2 =
true ; rtDW . fwfrplulil = true ; } } if ( ssIsSampleHit ( rtS , 5 , 0 ) ) {
if ( rtDW . iw1ylkptc1 ) { dc = rtB . fh1zk0jwdl ; if ( ( rtP . PWM_Period <=
0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM_Period ) || ( rtP . PWM_Period ==
( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM/Variable Pulse Generator" , 2 , rtP . PWM_Period , 2 ,
ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM_Period + ssGetTaskTime ( rtS , 5 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 5 ) + ssGetTaskTime ( rtS , 5 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing2/PWM/Variable Pulse Generator" , 2 , rtB . fh1zk0jwdl , 2 ,
rtP . PWM_Period , 2 , ssGetTaskTime ( rtS , 5 ) , 2 , 2.8421709430404007E-14
* ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc >
1.0 ) { dc = 1.0 ; if ( rtDW . fbe3y1q2sg ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleGreaterThanOne" , 3
, 2 , ssGetTaskTime ( rtS , 5 ) , 2 , rtB . fh1zk0jwdl , 3 ,
"activeBalancing2/PWM/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . fbe3y1q2sg = false ; } }
if ( ( rtDW . llaf3ewbkp > 0.0 ) && ( rtDW . llaf3ewbkp == rtP . PWM_Period )
) { rtDW . cdm1pyiexh ++ ; } else { rtDW . cdm1pyiexh = 1ULL ; rtDW .
llaf3ewbkp = rtP . PWM_Period ; rtDW . b0muitc2hd = ssGetTaskTime ( rtS , 5 )
; } rtDW . peu253ymia = rtDW . llaf3ewbkp * ( real_T ) rtDW . cdm1pyiexh +
rtDW . b0muitc2hd ; if ( rtDW . peu253ymia - ( dc * rtP . PWM_Period +
ssGetTaskTime ( rtS , 5 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
5 ) ) { _ssSetVarNextHitTime ( rtS , 3 , ssGetTaskTime ( rtS , 5 ) + dc * rtP
. PWM_Period ) ; rtDW . iw1ylkptc1 = false ; rtDW . ggmjvv0lb3 = false ; }
else if ( ( rtDW . peu253ymia - ( dc * rtP . PWM_Period + ssGetTaskTime ( rtS
, 5 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 5 ) ) && ( dc > 0.0
) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM/Variable Pulse Generator" , 2 , rtP . PWM_Period , 2 ,
ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 3 , rtDW . peu253ymia ) ; rtDW . iw1ylkptc1 =
true ; rtDW . ggmjvv0lb3 = true ; } } else { if ( rtDW . ggmjvv0lb3 ) { if (
( rtP . PWM_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM_Period ) ||
( rtP . PWM_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM/Variable Pulse Generator" , 2 , rtP . PWM_Period , 2 ,
ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB .
fh1zk0jwdl < 0.0 ) && rtDW . aslrlvkkcc ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 5 ) , 2 , rtB . fh1zk0jwdl , 3 ,
"activeBalancing2/PWM/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . aslrlvkkcc = false ; }
if ( ( rtDW . llaf3ewbkp > 0.0 ) && ( rtDW . llaf3ewbkp == rtP . PWM_Period )
) { rtDW . cdm1pyiexh ++ ; } else { rtDW . cdm1pyiexh = 1ULL ; rtDW .
llaf3ewbkp = rtP . PWM_Period ; rtDW . b0muitc2hd = ssGetTaskTime ( rtS , 5 )
; } _ssSetVarNextHitTime ( rtS , 3 , ssGetTaskTime ( rtS , 5 ) + rtP .
PWM_Period ) ; } else if ( rtDW . peu253ymia > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 5 ) + ssGetTaskTime ( rtS , 5 ) ) {
_ssSetVarNextHitTime ( rtS , 3 , rtDW . peu253ymia ) ; } rtDW . iw1ylkptc1 =
true ; rtDW . ggmjvv0lb3 = true ; } } if ( ssIsSampleHit ( rtS , 7 , 0 ) ) {
if ( rtDW . hekwrhnl5m ) { dc = rtB . bpvwc2wtxs ; if ( ( rtP . PWM1_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM1_Period ) || ( rtP .
PWM1_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM1/Variable Pulse Generator" , 2 , rtP . PWM1_Period , 2
, ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM1_Period + ssGetTaskTime ( rtS , 7 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 7 ) + ssGetTaskTime ( rtS , 7 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing2/PWM1/Variable Pulse Generator" , 2 , rtB . bpvwc2wtxs , 2 ,
rtP . PWM1_Period , 2 , ssGetTaskTime ( rtS , 7 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . jdnmbiwx3f ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
7 ) , 2 , rtB . bpvwc2wtxs , 3 ,
"activeBalancing2/PWM1/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . jdnmbiwx3f = false ; } }
if ( ( rtDW . nthq3z5tt5 > 0.0 ) && ( rtDW . nthq3z5tt5 == rtP . PWM1_Period
) ) { rtDW . k0umb4nsxj ++ ; } else { rtDW . k0umb4nsxj = 1ULL ; rtDW .
nthq3z5tt5 = rtP . PWM1_Period ; rtDW . azndzkmkcs = ssGetTaskTime ( rtS , 7
) ; } rtDW . axv0fdx2my = rtDW . nthq3z5tt5 * ( real_T ) rtDW . k0umb4nsxj +
rtDW . azndzkmkcs ; if ( rtDW . axv0fdx2my - ( dc * rtP . PWM1_Period +
ssGetTaskTime ( rtS , 7 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
7 ) ) { _ssSetVarNextHitTime ( rtS , 5 , ssGetTaskTime ( rtS , 7 ) + dc * rtP
. PWM1_Period ) ; rtDW . hekwrhnl5m = false ; rtDW . doiwoekzov = false ; }
else if ( ( rtDW . axv0fdx2my - ( dc * rtP . PWM1_Period + ssGetTaskTime (
rtS , 7 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 7 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM1/Variable Pulse Generator" , 2 , rtP . PWM1_Period , 2
, ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 5 , rtDW . axv0fdx2my ) ; rtDW . hekwrhnl5m =
true ; rtDW . doiwoekzov = true ; } } else { if ( rtDW . doiwoekzov ) { if (
( rtP . PWM1_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM1_Period )
|| ( rtP . PWM1_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM1/Variable Pulse Generator" , 2 , rtP . PWM1_Period , 2
, ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. bpvwc2wtxs < 0.0 ) && rtDW . aphrz0r2os ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 7 ) , 2 , rtB . bpvwc2wtxs , 3 ,
"activeBalancing2/PWM1/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . aphrz0r2os = false ; }
if ( ( rtDW . nthq3z5tt5 > 0.0 ) && ( rtDW . nthq3z5tt5 == rtP . PWM1_Period
) ) { rtDW . k0umb4nsxj ++ ; } else { rtDW . k0umb4nsxj = 1ULL ; rtDW .
nthq3z5tt5 = rtP . PWM1_Period ; rtDW . azndzkmkcs = ssGetTaskTime ( rtS , 7
) ; } _ssSetVarNextHitTime ( rtS , 5 , ssGetTaskTime ( rtS , 7 ) + rtP .
PWM1_Period ) ; } else if ( rtDW . axv0fdx2my > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 7 ) + ssGetTaskTime ( rtS , 7 ) ) {
_ssSetVarNextHitTime ( rtS , 5 , rtDW . axv0fdx2my ) ; } rtDW . hekwrhnl5m =
true ; rtDW . doiwoekzov = true ; } } if ( ssIsSampleHit ( rtS , 4 , 0 ) ) {
if ( rtDW . offqujpaki ) { dc = rtB . jfxa2yvvgk ; if ( ( rtP . PWM2_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM2_Period ) || ( rtP .
PWM2_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM2/Variable Pulse Generator" , 2 , rtP . PWM2_Period , 2
, ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM2_Period + ssGetTaskTime ( rtS , 4 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 4 ) + ssGetTaskTime ( rtS , 4 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing2/PWM2/Variable Pulse Generator" , 2 , rtB . jfxa2yvvgk , 2 ,
rtP . PWM2_Period , 2 , ssGetTaskTime ( rtS , 4 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . hxxbbgmykq ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
4 ) , 2 , rtB . jfxa2yvvgk , 3 ,
"activeBalancing2/PWM2/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . hxxbbgmykq = false ; } }
if ( ( rtDW . gipv354qpb > 0.0 ) && ( rtDW . gipv354qpb == rtP . PWM2_Period
) ) { rtDW . a1ahum4gsl ++ ; } else { rtDW . a1ahum4gsl = 1ULL ; rtDW .
gipv354qpb = rtP . PWM2_Period ; rtDW . ftugzjzi0o = ssGetTaskTime ( rtS , 4
) ; } rtDW . plxwewmbjw = rtDW . gipv354qpb * ( real_T ) rtDW . a1ahum4gsl +
rtDW . ftugzjzi0o ; if ( rtDW . plxwewmbjw - ( dc * rtP . PWM2_Period +
ssGetTaskTime ( rtS , 4 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
4 ) ) { _ssSetVarNextHitTime ( rtS , 2 , ssGetTaskTime ( rtS , 4 ) + dc * rtP
. PWM2_Period ) ; rtDW . offqujpaki = false ; rtDW . bhhlshfa0t = false ; }
else if ( ( rtDW . plxwewmbjw - ( dc * rtP . PWM2_Period + ssGetTaskTime (
rtS , 4 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 4 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM2/Variable Pulse Generator" , 2 , rtP . PWM2_Period , 2
, ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 2 , rtDW . plxwewmbjw ) ; rtDW . offqujpaki =
true ; rtDW . bhhlshfa0t = true ; } } else { if ( rtDW . bhhlshfa0t ) { if (
( rtP . PWM2_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM2_Period )
|| ( rtP . PWM2_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM2/Variable Pulse Generator" , 2 , rtP . PWM2_Period , 2
, ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. jfxa2yvvgk < 0.0 ) && rtDW . md1zdgbsoe ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 4 ) , 2 , rtB . jfxa2yvvgk , 3 ,
"activeBalancing2/PWM2/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . md1zdgbsoe = false ; }
if ( ( rtDW . gipv354qpb > 0.0 ) && ( rtDW . gipv354qpb == rtP . PWM2_Period
) ) { rtDW . a1ahum4gsl ++ ; } else { rtDW . a1ahum4gsl = 1ULL ; rtDW .
gipv354qpb = rtP . PWM2_Period ; rtDW . ftugzjzi0o = ssGetTaskTime ( rtS , 4
) ; } _ssSetVarNextHitTime ( rtS , 2 , ssGetTaskTime ( rtS , 4 ) + rtP .
PWM2_Period ) ; } else if ( rtDW . plxwewmbjw > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 4 ) + ssGetTaskTime ( rtS , 4 ) ) {
_ssSetVarNextHitTime ( rtS , 2 , rtDW . plxwewmbjw ) ; } rtDW . offqujpaki =
true ; rtDW . bhhlshfa0t = true ; } } if ( ssIsSampleHit ( rtS , 3 , 0 ) ) {
if ( rtDW . hlvtogm2ca ) { dc = rtB . ibr3y1gjec ; if ( ( rtP . PWM3_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM3_Period ) || ( rtP .
PWM3_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM3/Variable Pulse Generator" , 2 , rtP . PWM3_Period , 2
, ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM3_Period + ssGetTaskTime ( rtS , 3 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 3 ) + ssGetTaskTime ( rtS , 3 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing2/PWM3/Variable Pulse Generator" , 2 , rtB . ibr3y1gjec , 2 ,
rtP . PWM3_Period , 2 , ssGetTaskTime ( rtS , 3 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . awhbfmptso ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
3 ) , 2 , rtB . ibr3y1gjec , 3 ,
"activeBalancing2/PWM3/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . awhbfmptso = false ; } }
if ( ( rtDW . mfqivfq3il > 0.0 ) && ( rtDW . mfqivfq3il == rtP . PWM3_Period
) ) { rtDW . fmvszapqpi ++ ; } else { rtDW . fmvszapqpi = 1ULL ; rtDW .
mfqivfq3il = rtP . PWM3_Period ; rtDW . k4c4pmfnv2 = ssGetTaskTime ( rtS , 3
) ; } rtDW . j1mmhsj1qj = rtDW . mfqivfq3il * ( real_T ) rtDW . fmvszapqpi +
rtDW . k4c4pmfnv2 ; if ( rtDW . j1mmhsj1qj - ( dc * rtP . PWM3_Period +
ssGetTaskTime ( rtS , 3 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
3 ) ) { _ssSetVarNextHitTime ( rtS , 1 , ssGetTaskTime ( rtS , 3 ) + dc * rtP
. PWM3_Period ) ; rtDW . hlvtogm2ca = false ; rtDW . ot0jlfqn3i = false ; }
else if ( ( rtDW . j1mmhsj1qj - ( dc * rtP . PWM3_Period + ssGetTaskTime (
rtS , 3 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 3 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM3/Variable Pulse Generator" , 2 , rtP . PWM3_Period , 2
, ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 1 , rtDW . j1mmhsj1qj ) ; rtDW . hlvtogm2ca =
true ; rtDW . ot0jlfqn3i = true ; } } else { if ( rtDW . ot0jlfqn3i ) { if (
( rtP . PWM3_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM3_Period )
|| ( rtP . PWM3_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM3/Variable Pulse Generator" , 2 , rtP . PWM3_Period , 2
, ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. ibr3y1gjec < 0.0 ) && rtDW . fdy0jfy1tu ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 3 ) , 2 , rtB . ibr3y1gjec , 3 ,
"activeBalancing2/PWM3/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . fdy0jfy1tu = false ; }
if ( ( rtDW . mfqivfq3il > 0.0 ) && ( rtDW . mfqivfq3il == rtP . PWM3_Period
) ) { rtDW . fmvszapqpi ++ ; } else { rtDW . fmvszapqpi = 1ULL ; rtDW .
mfqivfq3il = rtP . PWM3_Period ; rtDW . k4c4pmfnv2 = ssGetTaskTime ( rtS , 3
) ; } _ssSetVarNextHitTime ( rtS , 1 , ssGetTaskTime ( rtS , 3 ) + rtP .
PWM3_Period ) ; } else if ( rtDW . j1mmhsj1qj > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 3 ) + ssGetTaskTime ( rtS , 3 ) ) {
_ssSetVarNextHitTime ( rtS , 1 , rtDW . j1mmhsj1qj ) ; } rtDW . hlvtogm2ca =
true ; rtDW . ot0jlfqn3i = true ; } } if ( ssIsSampleHit ( rtS , 2 , 0 ) ) {
if ( rtDW . i2lws3rgth ) { dc = rtB . jxwilkiy2q ; if ( ( rtP . PWM4_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM4_Period ) || ( rtP .
PWM4_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM4/Variable Pulse Generator" , 2 , rtP . PWM4_Period , 2
, ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM4_Period + ssGetTaskTime ( rtS , 2 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 2 ) + ssGetTaskTime ( rtS , 2 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing2/PWM4/Variable Pulse Generator" , 2 , rtB . jxwilkiy2q , 2 ,
rtP . PWM4_Period , 2 , ssGetTaskTime ( rtS , 2 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . l0150x51ms ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
2 ) , 2 , rtB . jxwilkiy2q , 3 ,
"activeBalancing2/PWM4/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . l0150x51ms = false ; } }
if ( ( rtDW . ebuw4ix1ne > 0.0 ) && ( rtDW . ebuw4ix1ne == rtP . PWM4_Period
) ) { rtDW . ko5gsxzsuc ++ ; } else { rtDW . ko5gsxzsuc = 1ULL ; rtDW .
ebuw4ix1ne = rtP . PWM4_Period ; rtDW . feyc5lmf2r = ssGetTaskTime ( rtS , 2
) ; } rtDW . pxyvizid1y = rtDW . ebuw4ix1ne * ( real_T ) rtDW . ko5gsxzsuc +
rtDW . feyc5lmf2r ; if ( rtDW . pxyvizid1y - ( dc * rtP . PWM4_Period +
ssGetTaskTime ( rtS , 2 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
2 ) ) { _ssSetVarNextHitTime ( rtS , 0 , ssGetTaskTime ( rtS , 2 ) + dc * rtP
. PWM4_Period ) ; rtDW . i2lws3rgth = false ; rtDW . oasl5bklsg = false ; }
else if ( ( rtDW . pxyvizid1y - ( dc * rtP . PWM4_Period + ssGetTaskTime (
rtS , 2 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 2 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM4/Variable Pulse Generator" , 2 , rtP . PWM4_Period , 2
, ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 0 , rtDW . pxyvizid1y ) ; rtDW . i2lws3rgth =
true ; rtDW . oasl5bklsg = true ; } } else { if ( rtDW . oasl5bklsg ) { if (
( rtP . PWM4_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM4_Period )
|| ( rtP . PWM4_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing2/PWM4/Variable Pulse Generator" , 2 , rtP . PWM4_Period , 2
, ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. jxwilkiy2q < 0.0 ) && rtDW . p4r02ywybb ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 2 ) , 2 , rtB . jxwilkiy2q , 3 ,
"activeBalancing2/PWM4/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . p4r02ywybb = false ; }
if ( ( rtDW . ebuw4ix1ne > 0.0 ) && ( rtDW . ebuw4ix1ne == rtP . PWM4_Period
) ) { rtDW . ko5gsxzsuc ++ ; } else { rtDW . ko5gsxzsuc = 1ULL ; rtDW .
ebuw4ix1ne = rtP . PWM4_Period ; rtDW . feyc5lmf2r = ssGetTaskTime ( rtS , 2
) ; } _ssSetVarNextHitTime ( rtS , 0 , ssGetTaskTime ( rtS , 2 ) + rtP .
PWM4_Period ) ; } else if ( rtDW . pxyvizid1y > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 2 ) + ssGetTaskTime ( rtS , 2 ) ) {
_ssSetVarNextHitTime ( rtS , 0 , rtDW . pxyvizid1y ) ; } rtDW . i2lws3rgth =
true ; rtDW . oasl5bklsg = true ; } } UNUSED_PARAMETER ( tid ) ; } void
MdlUpdateTID8 ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void
MdlDerivatives ( void ) { XDis * _rtXdis ; XDot * _rtXdot ; _rtXdis = ( (
XDis * ) ssGetContStateDisabled ( rtS ) ) ; _rtXdot = ( ( XDot * ) ssGetdX (
rtS ) ) ; _rtXdot -> foozkkgumc = 0.0 ; _rtXdot -> foozkkgumc += rtP .
Currentfilter_A * rtX . foozkkgumc ; _rtXdot -> foozkkgumc += rtB .
m00kcxurwn ; if ( _rtXdis -> axoluperv2 ) { _rtXdot -> axoluperv2 = 0.0 ; }
else { _rtXdot -> axoluperv2 = rtB . m00kcxurwn ; } _rtXdot -> iftoftjjsf =
rtB . efpo04tyla ; _rtXdot -> iwofyqttuz = 0.0 ; _rtXdot -> iwofyqttuz += rtP
. BAL_A * rtX . iwofyqttuz ; _rtXdot -> iwofyqttuz += rtB . m00kcxurwn ;
_rtXdot -> jsonadfc25 = 0.0 ; _rtXdot -> jsonadfc25 += rtP .
Currentfilter_A_hazdhojaym * rtX . jsonadfc25 ; _rtXdot -> jsonadfc25 += rtB
. hrmd1scdop ; if ( _rtXdis -> bhkc4j1ohz ) { _rtXdot -> bhkc4j1ohz = 0.0 ; }
else { _rtXdot -> bhkc4j1ohz = rtB . hrmd1scdop ; } _rtXdot -> m13n11gqh5 =
rtB . m3dolrlfxz ; _rtXdot -> cveknlxk0w = 0.0 ; _rtXdot -> cveknlxk0w += rtP
. BAL_A_cudqa1u03y * rtX . cveknlxk0w ; _rtXdot -> cveknlxk0w += rtB .
hrmd1scdop ; _rtXdot -> iqfvbswlqx = 0.0 ; _rtXdot -> iqfvbswlqx += rtP .
Currentfilter_A_pyl0ygpghg * rtX . iqfvbswlqx ; _rtXdot -> iqfvbswlqx += rtB
. heo3elq2ut ; if ( _rtXdis -> aczscrflwb ) { _rtXdot -> aczscrflwb = 0.0 ; }
else { _rtXdot -> aczscrflwb = rtB . heo3elq2ut ; } _rtXdot -> a20yshtbnb =
rtB . gxyxfqaxjb ; _rtXdot -> m2tz1exxd4 = 0.0 ; _rtXdot -> m2tz1exxd4 += rtP
. BAL_A_n35zxahhei * rtX . m2tz1exxd4 ; _rtXdot -> m2tz1exxd4 += rtB .
heo3elq2ut ; _rtXdot -> n3r5zcmpoi = 0.0 ; _rtXdot -> n3r5zcmpoi += rtP .
Currentfilter_A_bsszjj1hem * rtX . n3r5zcmpoi ; _rtXdot -> n3r5zcmpoi += rtB
. fdbodvkrba ; if ( _rtXdis -> bz3dftuo0x ) { _rtXdot -> bz3dftuo0x = 0.0 ; }
else { _rtXdot -> bz3dftuo0x = rtB . fdbodvkrba ; } _rtXdot -> e02u4qxaaf =
rtB . k5sv02vyqu ; _rtXdot -> lkcwi10nsx = 0.0 ; _rtXdot -> lkcwi10nsx += rtP
. BAL_A_jgidwk4hmh * rtX . lkcwi10nsx ; _rtXdot -> lkcwi10nsx += rtB .
fdbodvkrba ; _rtXdot -> l1c0yrfxl4 = 0.0 ; _rtXdot -> l1c0yrfxl4 += rtP .
Currentfilter_A_o3r40a2fs0 * rtX . l1c0yrfxl4 ; _rtXdot -> l1c0yrfxl4 += rtB
. ercy54k5it ; if ( _rtXdis -> lgrzwldtuz ) { _rtXdot -> lgrzwldtuz = 0.0 ; }
else { _rtXdot -> lgrzwldtuz = rtB . ercy54k5it ; } _rtXdot -> aacuquz0zq =
rtB . oncblw0ccg ; _rtXdot -> lnia4pzqrd = 0.0 ; _rtXdot -> lnia4pzqrd += rtP
. BAL_A_oad34lr4nf * rtX . lnia4pzqrd ; _rtXdot -> lnia4pzqrd += rtB .
ercy54k5it ; { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; real_T *
sfcndX_fx = ( real_T * ) & ( ( XDot * ) ssGetdX ( rtS ) ) -> odntevo1ki [ 0 ]
; ssSetdX ( rts , sfcndX_fx ) ; sfcnDerivatives ( rts ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } } void MdlProjection ( void
) { { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnProjection ( rts ) ;
if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } } void
MdlZeroCrossings ( void ) { ZCV * _rtZCSV ; _rtZCSV = ( ( ZCV * )
ssGetSolverZcSignalVector ( rtS ) ) ; _rtZCSV -> lv1ldnbijf = rtB .
jjv3khbcgz - rtP . Constant_Value ; switch ( rtDW . m3sjkfetzr ) { case 1 :
_rtZCSV -> mxtfujwshi = 0.0 ; _rtZCSV -> o5nrgmy4nz = rtP . inti_UpperSat -
rtP . inti_LowerSat ; break ; case 2 : _rtZCSV -> mxtfujwshi = rtP .
inti_LowerSat - rtP . inti_UpperSat ; _rtZCSV -> o5nrgmy4nz = 0.0 ; break ;
default : _rtZCSV -> mxtfujwshi = rtX . axoluperv2 - rtP . inti_UpperSat ;
_rtZCSV -> o5nrgmy4nz = rtX . axoluperv2 - rtP . inti_LowerSat ; break ; } if
( ( rtDW . m3sjkfetzr == 3 ) || ( rtDW . m3sjkfetzr == 4 ) ) { _rtZCSV ->
dpdbl2hz4o = rtB . m00kcxurwn ; } else { _rtZCSV -> dpdbl2hz4o = 0.0 ; }
_rtZCSV -> bkmypk1tls = rtB . cuhexdvcd3 - rtB . kddmvh240q ; _rtZCSV ->
fb1hqmnssy = rtB . cuhexdvcd3 - rtP . Constant9_Value ; _rtZCSV -> lokiv24w4v
= rtB . o04pwljhiy - rtB . ocwszegfxg ; _rtZCSV -> ki3plwbnao = rtB .
cuhexdvcd3 - rtB . mlf4o50fzo ; _rtZCSV -> fqlrimlatx = rtB . cuhexdvcd3 -
rtB . e5s2aj4bft ; _rtZCSV -> m0mytkt4p5 = rtB . jjv3khbcgz - rtP .
Constant_Value_efypwvyyax ; _rtZCSV -> agiqfpoa25 = rtB . h3wghvdhvb - rtP .
Saturation_UpperSat ; _rtZCSV -> kr1o5ks5dg = rtB . h3wghvdhvb - rtP .
Saturation_LowerSat ; _rtZCSV -> oqqii3frkp = rtB . lkmpaypb2p - rtP .
Constant1_Value ; _rtZCSV -> mquwzfkrsr = rtB . lkmpaypb2p - rtB . drwy5mjekt
; _rtZCSV -> apedymnbja = rtB . habvcjn5vp - rtP . Constant_Value_pbqzqfbpnm
; switch ( rtDW . hrm4dgu33i ) { case 1 : _rtZCSV -> hqdiuv1g0m = 0.0 ;
_rtZCSV -> efcgqgintq = rtP . inti_UpperSat_itldayqrxp - rtP .
inti_LowerSat_lz3gh0icex ; break ; case 2 : _rtZCSV -> hqdiuv1g0m = rtP .
inti_LowerSat_lz3gh0icex - rtP . inti_UpperSat_itldayqrxp ; _rtZCSV ->
efcgqgintq = 0.0 ; break ; default : _rtZCSV -> hqdiuv1g0m = rtX . bhkc4j1ohz
- rtP . inti_UpperSat_itldayqrxp ; _rtZCSV -> efcgqgintq = rtX . bhkc4j1ohz -
rtP . inti_LowerSat_lz3gh0icex ; break ; } if ( ( rtDW . hrm4dgu33i == 3 ) ||
( rtDW . hrm4dgu33i == 4 ) ) { _rtZCSV -> pevep1w4d0 = rtB . hrmd1scdop ; }
else { _rtZCSV -> pevep1w4d0 = 0.0 ; } _rtZCSV -> mab5xkr5sd = rtB .
ftwzojqrpo - rtB . gytt55q4rf ; _rtZCSV -> lt5x5ywv3t = rtB . ftwzojqrpo -
rtP . Constant9_Value_bfo0fnc5l1 ; _rtZCSV -> pybraqgztd = rtB . jzbhnekpdw -
rtB . ehiwj5javn ; _rtZCSV -> e1xpqp5l3u = rtB . ftwzojqrpo - rtB .
ma2bkws5c2 ; _rtZCSV -> c4zh0k0bej = rtB . ftwzojqrpo - rtB . ebarhnnaj2 ;
_rtZCSV -> aozqeb31jh = rtB . habvcjn5vp - rtP . Constant_Value_hu3rmuppbn ;
_rtZCSV -> labtuntw2t = rtB . a3dofhbrxy - rtP .
Saturation_UpperSat_lxx4j3fnoa ; _rtZCSV -> mvharsolbx = rtB . a3dofhbrxy -
rtP . Saturation_LowerSat_kwi433xk5g ; _rtZCSV -> jukadkkdms = rtB .
cxeawbkrpo - rtP . Constant1_Value_jelmmtr1rj ; _rtZCSV -> lkbvthqtea = rtB .
cxeawbkrpo - rtB . gdlqjdwsgs ; _rtZCSV -> nwhr2t5dlx = rtB . pw25npqcl5 -
rtP . Constant_Value_bksqnhysc0 ; switch ( rtDW . ed3nvtxxjm ) { case 1 :
_rtZCSV -> oa4weauol3 = 0.0 ; _rtZCSV -> kzmepttb1m = rtP .
inti_UpperSat_nowwhgaxwk - rtP . inti_LowerSat_cwekkzbyq1 ; break ; case 2 :
_rtZCSV -> oa4weauol3 = rtP . inti_LowerSat_cwekkzbyq1 - rtP .
inti_UpperSat_nowwhgaxwk ; _rtZCSV -> kzmepttb1m = 0.0 ; break ; default :
_rtZCSV -> oa4weauol3 = rtX . aczscrflwb - rtP . inti_UpperSat_nowwhgaxwk ;
_rtZCSV -> kzmepttb1m = rtX . aczscrflwb - rtP . inti_LowerSat_cwekkzbyq1 ;
break ; } if ( ( rtDW . ed3nvtxxjm == 3 ) || ( rtDW . ed3nvtxxjm == 4 ) ) {
_rtZCSV -> kdifkciuuy = rtB . heo3elq2ut ; } else { _rtZCSV -> kdifkciuuy =
0.0 ; } _rtZCSV -> eh5cr0zpfu = rtB . p55huzvwwq - rtB . mil2gvjxva ; _rtZCSV
-> nsv0ssbqyn = rtB . p55huzvwwq - rtP . Constant9_Value_nhyzz1ckmw ; _rtZCSV
-> iyiqllgstj = rtB . d1gujx31mw - rtB . ncsmjyn2oi ; _rtZCSV -> ez043ntvvt =
rtB . p55huzvwwq - rtB . mudvde1asq ; _rtZCSV -> b55vsxgh4h = rtB .
p55huzvwwq - rtB . n35vhllexk ; _rtZCSV -> m3s1nxr3fn = rtB . pw25npqcl5 -
rtP . Constant_Value_owtewy0ssm ; _rtZCSV -> ns5spo4pzq = rtB . lpwkyiqyni -
rtP . Saturation_UpperSat_blj3ug4rzx ; _rtZCSV -> akwa0mqavd = rtB .
lpwkyiqyni - rtP . Saturation_LowerSat_o0i20janpw ; _rtZCSV -> nf0pfx4osx =
rtB . bbekmjhgcu - rtP . Constant1_Value_jj3f5fu3xp ; _rtZCSV -> ow1nryaayc =
rtB . bbekmjhgcu - rtB . nyjzof0rx3 ; _rtZCSV -> e4t4jcks4u = rtB .
c4wkrk0zxw - rtP . Constant_Value_kedzfrfegv ; switch ( rtDW . cokzwj0i4g ) {
case 1 : _rtZCSV -> gmm22ho0aa = 0.0 ; _rtZCSV -> ls4enu1ia3 = rtP .
inti_UpperSat_itde10ibkj - rtP . inti_LowerSat_nb1wwuftgl ; break ; case 2 :
_rtZCSV -> gmm22ho0aa = rtP . inti_LowerSat_nb1wwuftgl - rtP .
inti_UpperSat_itde10ibkj ; _rtZCSV -> ls4enu1ia3 = 0.0 ; break ; default :
_rtZCSV -> gmm22ho0aa = rtX . bz3dftuo0x - rtP . inti_UpperSat_itde10ibkj ;
_rtZCSV -> ls4enu1ia3 = rtX . bz3dftuo0x - rtP . inti_LowerSat_nb1wwuftgl ;
break ; } if ( ( rtDW . cokzwj0i4g == 3 ) || ( rtDW . cokzwj0i4g == 4 ) ) {
_rtZCSV -> fajzq5dgay = rtB . fdbodvkrba ; } else { _rtZCSV -> fajzq5dgay =
0.0 ; } _rtZCSV -> o0l3c1xpkx = rtB . cgevkfqtmb - rtB . leccoparpy ; _rtZCSV
-> ne4mvfzecv = rtB . cgevkfqtmb - rtP . Constant9_Value_ffsooduwum ; _rtZCSV
-> g0fmbdqnmd = rtB . ogcju0kfgh - rtB . py4io1p2ai ; _rtZCSV -> gluy4g0la2 =
rtB . cgevkfqtmb - rtB . pqnqe2hboi ; _rtZCSV -> nyquoq334g = rtB .
cgevkfqtmb - rtB . lwf12tqfq2 ; _rtZCSV -> i401ozk4hx = rtB . c4wkrk0zxw -
rtP . Constant_Value_opaksbgo21 ; _rtZCSV -> dwrykibtsx = rtB . e2fmskpokg -
rtP . Saturation_UpperSat_c0l2pkijii ; _rtZCSV -> fm5tv2ceml = rtB .
e2fmskpokg - rtP . Saturation_LowerSat_g1ovkjgj1x ; _rtZCSV -> mo3qp40mxa =
rtB . gc2gnhaysc - rtP . Constant1_Value_myhrse5szs ; _rtZCSV -> nniraww0ei =
rtB . gc2gnhaysc - rtB . bxllmuyk2m ; _rtZCSV -> igluv5v0xe = rtB .
lwj3vtbuti - rtP . Constant_Value_epq2rsx4ba ; switch ( rtDW . lv22brfstt ) {
case 1 : _rtZCSV -> hyftmg40ml = 0.0 ; _rtZCSV -> epeqai5nl0 = rtP .
inti_UpperSat_ff0nysnmjy - rtP . inti_LowerSat_hzpmw3xl5s ; break ; case 2 :
_rtZCSV -> hyftmg40ml = rtP . inti_LowerSat_hzpmw3xl5s - rtP .
inti_UpperSat_ff0nysnmjy ; _rtZCSV -> epeqai5nl0 = 0.0 ; break ; default :
_rtZCSV -> hyftmg40ml = rtX . lgrzwldtuz - rtP . inti_UpperSat_ff0nysnmjy ;
_rtZCSV -> epeqai5nl0 = rtX . lgrzwldtuz - rtP . inti_LowerSat_hzpmw3xl5s ;
break ; } if ( ( rtDW . lv22brfstt == 3 ) || ( rtDW . lv22brfstt == 4 ) ) {
_rtZCSV -> i1d11fku1s = rtB . ercy54k5it ; } else { _rtZCSV -> i1d11fku1s =
0.0 ; } _rtZCSV -> l00pjbeskf = rtB . fomxtscak4 - rtB . ffmj4w3cmt ; _rtZCSV
-> c4qkchwurf = rtB . fomxtscak4 - rtP . Constant9_Value_bcezbzp4a1 ; _rtZCSV
-> f1ch1zsae5 = rtB . lqzzl3sci3 - rtB . eu0tsijyvf ; _rtZCSV -> pe44n104x3 =
rtB . fomxtscak4 - rtB . ir1j5szgpu ; _rtZCSV -> iygiqxkdmd = rtB .
fomxtscak4 - rtB . kiqwsofa1f ; _rtZCSV -> ksddoqclas = rtB . lwj3vtbuti -
rtP . Constant_Value_h45zreb2fb ; _rtZCSV -> dzwzucqogj = rtB . pr00fiymmv -
rtP . Saturation_UpperSat_dr1jmbb0we ; _rtZCSV -> durrtkxsj3 = rtB .
pr00fiymmv - rtP . Saturation_LowerSat_haspwmkdbs ; _rtZCSV -> bqujeoiiyh =
rtB . eal3yj23jh - rtP . Constant1_Value_h1thd4w1zg ; _rtZCSV -> csh4qv0sky =
rtB . eal3yj23jh - rtB . krcxrj0fwb ; { SimStruct * rts = ssGetSFunction (
rtS , 0 ) ; ssSetNonsampledZCs ( rts , & ( ( ( ZCV * )
ssGetSolverZcSignalVector ( rtS ) ) -> cyaaehthyd [ 0 ] ) ) ;
sfcnZeroCrossings ( rts ) ; if ( ssGetErrorStatus ( rts ) != ( NULL ) )
return ; } _rtZCSV -> o240grp02d = rtB . hn4ssoozf0 - rtP .
Saturation_UpperSat_aqwzuangfk ; _rtZCSV -> oqmvo2cu14 = rtB . hn4ssoozf0 -
rtP . Saturation_LowerSat_bcd3czsgyq ; _rtZCSV -> komcu0xtcs = rtB .
clgffaez3j - rtP . Saturation_UpperSat_i3x3oscagf ; _rtZCSV -> b214vo0xpz =
rtB . clgffaez3j - rtP . Saturation_LowerSat_gnz45aadu0 ; _rtZCSV ->
fuig2kilyn = rtB . lzsrkuhyhd ; _rtZCSV -> o1xlxw0vrj = rtB . mvut4g1kur -
rtP . Saturation_UpperSat_pcz043fnep ; _rtZCSV -> ltrxsgne22 = rtB .
mvut4g1kur - rtP . Saturation_LowerSat_b05y2t0vvl ; _rtZCSV -> orm2g5z1gx =
rtB . g0dxdurozf ; _rtZCSV -> d3hdyujfc4 = rtB . mvmrxossef - rtP .
Saturation_UpperSat_luxvjfmfd3 ; _rtZCSV -> bm4n5kngen = rtB . mvmrxossef -
rtP . Saturation_LowerSat_mqcesji40p ; _rtZCSV -> apymty03ju = rtB .
ndew4yws5j - rtP . Saturation_UpperSat_p4wbgcsokm ; _rtZCSV -> gstktqd5i3 =
rtB . ndew4yws5j - rtP . Saturation_LowerSat_gdbbvpyvzg ; _rtZCSV ->
cuewc354vy = rtB . e2rllfvmiw ; _rtZCSV -> kmhgfqqcl3 = rtB . nvas3hhzkc ;
_rtZCSV -> hfconau3ej = rtB . p00h0g1otp ; _rtZCSV -> nc25b1z01a = rtB .
mjehla4ytu ; _rtZCSV -> mb04eqwxow = rtB . m00kcxurwn ; _rtZCSV -> gx3vhtzm3j
= rtB . m00kcxurwn - rtP . Constant_Value_ogegtmkzv0 ; _rtZCSV -> c1kz5znm0i
= rtB . hrmd1scdop ; _rtZCSV -> ghxapd0dwh = rtB . hrmd1scdop - rtP .
Constant_Value_h5irp45zuu ; _rtZCSV -> onkswacg1y = rtB . heo3elq2ut ;
_rtZCSV -> nzvmf3uvos = rtB . heo3elq2ut - rtP . Constant_Value_k5pwul1wle ;
_rtZCSV -> ifaulpvrbp = rtB . fdbodvkrba ; _rtZCSV -> dq1z1zxhuc = rtB .
fdbodvkrba - rtP . Constant_Value_pp4lg2cwxs ; _rtZCSV -> kend2ejss5 = rtB .
ercy54k5it ; _rtZCSV -> jed2c0xquo = rtB . ercy54k5it - rtP .
Constant_Value_khiqevv1tc ; } void MdlTerminate ( void ) { { SimStruct * rts
= ssGetSFunction ( rtS , 0 ) ; sfcnTerminate ( rts ) ; } { if ( rtDW .
dbblrjj2tk . AQHandles ) { sdiTerminateStreaming ( & rtDW . dbblrjj2tk .
AQHandles ) ; } } { if ( rtDW . l22qnqwzjn . AQHandles ) {
sdiTerminateStreaming ( & rtDW . l22qnqwzjn . AQHandles ) ; } } { if ( rtDW .
fo3wh2yatx . AQHandles ) { sdiTerminateStreaming ( & rtDW . fo3wh2yatx .
AQHandles ) ; } } { if ( rtDW . k2ffp3ntfr . AQHandles ) {
sdiTerminateStreaming ( & rtDW . k2ffp3ntfr . AQHandles ) ; } } { if ( rtDW .
nyfzlmf145 . AQHandles ) { sdiTerminateStreaming ( & rtDW . nyfzlmf145 .
AQHandles ) ; } } { if ( rtDW . h04wi2qgv5 . AQHandles ) {
sdiTerminateStreaming ( & rtDW . h04wi2qgv5 . AQHandles ) ; } } { if ( rtDW .
jgsevaes2d . AQHandles ) { sdiTerminateStreaming ( & rtDW . jgsevaes2d .
AQHandles ) ; } } { if ( rtDW . j2pvryuk2u . AQHandles ) {
sdiTerminateStreaming ( & rtDW . j2pvryuk2u . AQHandles ) ; } } { if ( rtDW .
hqpvabyibc . AQHandles ) { sdiTerminateStreaming ( & rtDW . hqpvabyibc .
AQHandles ) ; } } } static void mr_activeBalancing2_cacheDataAsMxArray (
mxArray * destArray , mwIndex i , int j , const void * srcData , size_t
numBytes ) ; static void mr_activeBalancing2_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) {
mxArray * newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void mr_activeBalancing2_restoreDataFromMxArray (
void * destData , const mxArray * srcArray , mwIndex i , int j , size_t
numBytes ) ; static void mr_activeBalancing2_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) {
memcpy ( ( uint8_T * ) destData , ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) , numBytes ) ; } static void
mr_activeBalancing2_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) ; static void
mr_activeBalancing2_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_activeBalancing2_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_activeBalancing2_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_activeBalancing2_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_activeBalancing2_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_activeBalancing2_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void mr_activeBalancing2_restoreDataFromMxArrayWithOffset
( void * destData , const mxArray * srcArray , mwIndex i , int j , mwIndex
offset , size_t numBytes ) { const uint8_T * varData = ( const uint8_T * )
mxGetData ( mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T *
) destData , ( const uint8_T * ) & varData [ offset * numBytes ] , numBytes )
; } static void mr_activeBalancing2_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void mr_activeBalancing2_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
{ mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_activeBalancing2_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_activeBalancing2_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_activeBalancing2_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "rtB" , "rtDW" , "rtPrevZCX" , }
; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_activeBalancing2_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & (
rtB ) , sizeof ( rtB ) ) ; { static const char * rtdwDataFieldNames [ 142 ] =
{ "rtDW.mx5vjacu5q" , "rtDW.gu33m3cujr" , "rtDW.ihabibaari" ,
"rtDW.g45xtcsm1y" , "rtDW.mde444qrus" , "rtDW.egfu4zp5ck" , "rtDW.jjpmmqdhaq"
, "rtDW.knijrjnyhh" , "rtDW.curbfhmvfh" , "rtDW.h51d42z1yp" ,
"rtDW.evcbaypssu" , "rtDW.fcr2tgbfvo" , "rtDW.glz3hn24br" , "rtDW.peu253ymia"
, "rtDW.b0muitc2hd" , "rtDW.llaf3ewbkp" , "rtDW.axv0fdx2my" ,
"rtDW.azndzkmkcs" , "rtDW.nthq3z5tt5" , "rtDW.plxwewmbjw" , "rtDW.ftugzjzi0o"
, "rtDW.gipv354qpb" , "rtDW.j1mmhsj1qj" , "rtDW.k4c4pmfnv2" ,
"rtDW.mfqivfq3il" , "rtDW.pxyvizid1y" , "rtDW.feyc5lmf2r" , "rtDW.ebuw4ix1ne"
, "rtDW.jvh5mician" , "rtDW.cdm1pyiexh" , "rtDW.k0umb4nsxj" ,
"rtDW.a1ahum4gsl" , "rtDW.fmvszapqpi" , "rtDW.ko5gsxzsuc" , "rtDW.p3thioyq1j"
, "rtDW.g55jrpbizl" , "rtDW.ojsrsvfc4d" , "rtDW.lldjl4eyzi" ,
"rtDW.gxvtetrs04" , "rtDW.frtlsutffh" , "rtDW.pzgimzosty" , "rtDW.m3sjkfetzr"
, "rtDW.jmxabr1urn" , "rtDW.hrm4dgu33i" , "rtDW.ge34ybq3a0" ,
"rtDW.ed3nvtxxjm" , "rtDW.dsor1ukpll" , "rtDW.cokzwj0i4g" , "rtDW.gnfw0t231h"
, "rtDW.lv22brfstt" , "rtDW.as2ykd4ql3" , "rtDW.kaytcmiwya" ,
"rtDW.dcn3au535t" , "rtDW.jertq5slcs" , "rtDW.l0t1omik1w" , "rtDW.hdetrxmovp"
, "rtDW.d4gcz4s4op" , "rtDW.o0qveok2yn" , "rtDW.jpp24x3j0b" ,
"rtDW.dkr0lmfwa5" , "rtDW.nrpmm2hefl" , "rtDW.audfqsd0mm" , "rtDW.hwrms4izrt"
, "rtDW.gtcdjshroe" , "rtDW.fqhd2sk321" , "rtDW.kxwxa3byt5" ,
"rtDW.fogzt5jbmz" , "rtDW.oq1utabldx" , "rtDW.exu1prz21a" , "rtDW.bs0tfwzjp3"
, "rtDW.msxvlyne10" , "rtDW.owram20lcx" , "rtDW.ktypzgdlxt" ,
"rtDW.otvz1o3ztq" , "rtDW.pkopjswp3e" , "rtDW.e0qedsyqjn" , "rtDW.pkpw1tsasy"
, "rtDW.mx41mp51rp" , "rtDW.jansurp50c" , "rtDW.c4szg1j5wf" ,
"rtDW.izsp05gss2" , "rtDW.b554rpqups" , "rtDW.pbezlulnm5" , "rtDW.oyiznhfz3f"
, "rtDW.djo5beq3n0" , "rtDW.gil4ie50ol" , "rtDW.aarpnpqgmu" ,
"rtDW.cgfl554d0l" , "rtDW.p51wmaigg2" , "rtDW.geb4p4zdgn" , "rtDW.opozmxoahv"
, "rtDW.p3ylutwfna" , "rtDW.fma5ryxgkz" , "rtDW.khxogtuz1l" ,
"rtDW.d4qmht1xff" , "rtDW.hjxqlr4sag" , "rtDW.eg3zr5htps" , "rtDW.gazfgp55bt"
, "rtDW.jkumuiblmb" , "rtDW.nt4ghy3024" , "rtDW.aux30da2zu" ,
"rtDW.aqmi0ximsk" , "rtDW.bf132dfs4i" , "rtDW.n22ezzj533" , "rtDW.egy3i3psvd"
, "rtDW.i5m44h50ql" , "rtDW.axjy40izfe" , "rtDW.jq3vvbxrjf" ,
"rtDW.okvjyaztbz" , "rtDW.mez5whsqc3" , "rtDW.pbjw4010b3" , "rtDW.oyet01vjge"
, "rtDW.bu03oe0pwq" , "rtDW.n1fso1av4u" , "rtDW.orvtgsw01i" ,
"rtDW.i0pn21xe2p" , "rtDW.gljdehuiwg" , "rtDW.mmoscpngve" , "rtDW.icvovv1jq2"
, "rtDW.fwfrplulil" , "rtDW.dxjlf0kpmf" , "rtDW.os5dfkhn1w" ,
"rtDW.iw1ylkptc1" , "rtDW.ggmjvv0lb3" , "rtDW.fbe3y1q2sg" , "rtDW.aslrlvkkcc"
, "rtDW.hekwrhnl5m" , "rtDW.doiwoekzov" , "rtDW.jdnmbiwx3f" ,
"rtDW.aphrz0r2os" , "rtDW.offqujpaki" , "rtDW.bhhlshfa0t" , "rtDW.hxxbbgmykq"
, "rtDW.md1zdgbsoe" , "rtDW.hlvtogm2ca" , "rtDW.ot0jlfqn3i" ,
"rtDW.awhbfmptso" , "rtDW.fdy0jfy1tu" , "rtDW.i2lws3rgth" , "rtDW.oasl5bklsg"
, "rtDW.l0150x51ms" , "rtDW.p4r02ywybb" , } ; mxArray * rtdwData =
mxCreateStructMatrix ( 1 , 1 , 142 , rtdwDataFieldNames ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 0 , ( const void * )
& ( rtDW . mx5vjacu5q ) , sizeof ( rtDW . mx5vjacu5q ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 1 , ( const void * )
& ( rtDW . gu33m3cujr ) , sizeof ( rtDW . gu33m3cujr ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const void * )
& ( rtDW . ihabibaari ) , sizeof ( rtDW . ihabibaari ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const void * )
& ( rtDW . g45xtcsm1y ) , sizeof ( rtDW . g45xtcsm1y ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const void * )
& ( rtDW . mde444qrus ) , sizeof ( rtDW . mde444qrus ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const void * )
& ( rtDW . egfu4zp5ck ) , sizeof ( rtDW . egfu4zp5ck ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const void * )
& ( rtDW . jjpmmqdhaq ) , sizeof ( rtDW . jjpmmqdhaq ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const void * )
& ( rtDW . knijrjnyhh ) , sizeof ( rtDW . knijrjnyhh ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 8 , ( const void * )
& ( rtDW . curbfhmvfh ) , sizeof ( rtDW . curbfhmvfh ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 9 , ( const void * )
& ( rtDW . h51d42z1yp ) , sizeof ( rtDW . h51d42z1yp ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 10 , ( const void * )
& ( rtDW . evcbaypssu ) , sizeof ( rtDW . evcbaypssu ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 11 , ( const void * )
& ( rtDW . fcr2tgbfvo ) , sizeof ( rtDW . fcr2tgbfvo ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 12 , ( const void * )
& ( rtDW . glz3hn24br ) , sizeof ( rtDW . glz3hn24br ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 13 , ( const void * )
& ( rtDW . peu253ymia ) , sizeof ( rtDW . peu253ymia ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 14 , ( const void * )
& ( rtDW . b0muitc2hd ) , sizeof ( rtDW . b0muitc2hd ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 15 , ( const void * )
& ( rtDW . llaf3ewbkp ) , sizeof ( rtDW . llaf3ewbkp ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 16 , ( const void * )
& ( rtDW . axv0fdx2my ) , sizeof ( rtDW . axv0fdx2my ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 17 , ( const void * )
& ( rtDW . azndzkmkcs ) , sizeof ( rtDW . azndzkmkcs ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 18 , ( const void * )
& ( rtDW . nthq3z5tt5 ) , sizeof ( rtDW . nthq3z5tt5 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 19 , ( const void * )
& ( rtDW . plxwewmbjw ) , sizeof ( rtDW . plxwewmbjw ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 20 , ( const void * )
& ( rtDW . ftugzjzi0o ) , sizeof ( rtDW . ftugzjzi0o ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 21 , ( const void * )
& ( rtDW . gipv354qpb ) , sizeof ( rtDW . gipv354qpb ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 22 , ( const void * )
& ( rtDW . j1mmhsj1qj ) , sizeof ( rtDW . j1mmhsj1qj ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 23 , ( const void * )
& ( rtDW . k4c4pmfnv2 ) , sizeof ( rtDW . k4c4pmfnv2 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 24 , ( const void * )
& ( rtDW . mfqivfq3il ) , sizeof ( rtDW . mfqivfq3il ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 25 , ( const void * )
& ( rtDW . pxyvizid1y ) , sizeof ( rtDW . pxyvizid1y ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 26 , ( const void * )
& ( rtDW . feyc5lmf2r ) , sizeof ( rtDW . feyc5lmf2r ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 27 , ( const void * )
& ( rtDW . ebuw4ix1ne ) , sizeof ( rtDW . ebuw4ix1ne ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 28 , ( const void * )
& ( rtDW . jvh5mician ) , sizeof ( rtDW . jvh5mician ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 29 , ( const void * )
& ( rtDW . cdm1pyiexh ) , sizeof ( rtDW . cdm1pyiexh ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 30 , ( const void * )
& ( rtDW . k0umb4nsxj ) , sizeof ( rtDW . k0umb4nsxj ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 31 , ( const void * )
& ( rtDW . a1ahum4gsl ) , sizeof ( rtDW . a1ahum4gsl ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 32 , ( const void * )
& ( rtDW . fmvszapqpi ) , sizeof ( rtDW . fmvszapqpi ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 33 , ( const void * )
& ( rtDW . ko5gsxzsuc ) , sizeof ( rtDW . ko5gsxzsuc ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 34 , ( const void * )
& ( rtDW . p3thioyq1j ) , sizeof ( rtDW . p3thioyq1j ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 35 , ( const void * )
& ( rtDW . g55jrpbizl ) , sizeof ( rtDW . g55jrpbizl ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 36 , ( const void * )
& ( rtDW . ojsrsvfc4d ) , sizeof ( rtDW . ojsrsvfc4d ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 37 , ( const void * )
& ( rtDW . lldjl4eyzi ) , sizeof ( rtDW . lldjl4eyzi ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 38 , ( const void * )
& ( rtDW . gxvtetrs04 ) , sizeof ( rtDW . gxvtetrs04 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 39 , ( const void * )
& ( rtDW . frtlsutffh ) , sizeof ( rtDW . frtlsutffh ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 40 , ( const void * )
& ( rtDW . pzgimzosty ) , sizeof ( rtDW . pzgimzosty ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 41 , ( const void * )
& ( rtDW . m3sjkfetzr ) , sizeof ( rtDW . m3sjkfetzr ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 42 , ( const void * )
& ( rtDW . jmxabr1urn ) , sizeof ( rtDW . jmxabr1urn ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 43 , ( const void * )
& ( rtDW . hrm4dgu33i ) , sizeof ( rtDW . hrm4dgu33i ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 44 , ( const void * )
& ( rtDW . ge34ybq3a0 ) , sizeof ( rtDW . ge34ybq3a0 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 45 , ( const void * )
& ( rtDW . ed3nvtxxjm ) , sizeof ( rtDW . ed3nvtxxjm ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 46 , ( const void * )
& ( rtDW . dsor1ukpll ) , sizeof ( rtDW . dsor1ukpll ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 47 , ( const void * )
& ( rtDW . cokzwj0i4g ) , sizeof ( rtDW . cokzwj0i4g ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 48 , ( const void * )
& ( rtDW . gnfw0t231h ) , sizeof ( rtDW . gnfw0t231h ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 49 , ( const void * )
& ( rtDW . lv22brfstt ) , sizeof ( rtDW . lv22brfstt ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 50 , ( const void * )
& ( rtDW . as2ykd4ql3 ) , sizeof ( rtDW . as2ykd4ql3 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 51 , ( const void * )
& ( rtDW . kaytcmiwya ) , sizeof ( rtDW . kaytcmiwya ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 52 , ( const void * )
& ( rtDW . dcn3au535t ) , sizeof ( rtDW . dcn3au535t ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 53 , ( const void * )
& ( rtDW . jertq5slcs ) , sizeof ( rtDW . jertq5slcs ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 54 , ( const void * )
& ( rtDW . l0t1omik1w ) , sizeof ( rtDW . l0t1omik1w ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 55 , ( const void * )
& ( rtDW . hdetrxmovp ) , sizeof ( rtDW . hdetrxmovp ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 56 , ( const void * )
& ( rtDW . d4gcz4s4op ) , sizeof ( rtDW . d4gcz4s4op ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 57 , ( const void * )
& ( rtDW . o0qveok2yn ) , sizeof ( rtDW . o0qveok2yn ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 58 , ( const void * )
& ( rtDW . jpp24x3j0b ) , sizeof ( rtDW . jpp24x3j0b ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 59 , ( const void * )
& ( rtDW . dkr0lmfwa5 ) , sizeof ( rtDW . dkr0lmfwa5 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 60 , ( const void * )
& ( rtDW . nrpmm2hefl ) , sizeof ( rtDW . nrpmm2hefl ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 61 , ( const void * )
& ( rtDW . audfqsd0mm ) , sizeof ( rtDW . audfqsd0mm ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 62 , ( const void * )
& ( rtDW . hwrms4izrt ) , sizeof ( rtDW . hwrms4izrt ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 63 , ( const void * )
& ( rtDW . gtcdjshroe ) , sizeof ( rtDW . gtcdjshroe ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 64 , ( const void * )
& ( rtDW . fqhd2sk321 ) , sizeof ( rtDW . fqhd2sk321 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 65 , ( const void * )
& ( rtDW . kxwxa3byt5 ) , sizeof ( rtDW . kxwxa3byt5 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 66 , ( const void * )
& ( rtDW . fogzt5jbmz ) , sizeof ( rtDW . fogzt5jbmz ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 67 , ( const void * )
& ( rtDW . oq1utabldx ) , sizeof ( rtDW . oq1utabldx ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 68 , ( const void * )
& ( rtDW . exu1prz21a ) , sizeof ( rtDW . exu1prz21a ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 69 , ( const void * )
& ( rtDW . bs0tfwzjp3 ) , sizeof ( rtDW . bs0tfwzjp3 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 70 , ( const void * )
& ( rtDW . msxvlyne10 ) , sizeof ( rtDW . msxvlyne10 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 71 , ( const void * )
& ( rtDW . owram20lcx ) , sizeof ( rtDW . owram20lcx ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 72 , ( const void * )
& ( rtDW . ktypzgdlxt ) , sizeof ( rtDW . ktypzgdlxt ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 73 , ( const void * )
& ( rtDW . otvz1o3ztq ) , sizeof ( rtDW . otvz1o3ztq ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 74 , ( const void * )
& ( rtDW . pkopjswp3e ) , sizeof ( rtDW . pkopjswp3e ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 75 , ( const void * )
& ( rtDW . e0qedsyqjn ) , sizeof ( rtDW . e0qedsyqjn ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 76 , ( const void * )
& ( rtDW . pkpw1tsasy ) , sizeof ( rtDW . pkpw1tsasy ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 77 , ( const void * )
& ( rtDW . mx41mp51rp ) , sizeof ( rtDW . mx41mp51rp ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 78 , ( const void * )
& ( rtDW . jansurp50c ) , sizeof ( rtDW . jansurp50c ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 79 , ( const void * )
& ( rtDW . c4szg1j5wf ) , sizeof ( rtDW . c4szg1j5wf ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 80 , ( const void * )
& ( rtDW . izsp05gss2 ) , sizeof ( rtDW . izsp05gss2 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 81 , ( const void * )
& ( rtDW . b554rpqups ) , sizeof ( rtDW . b554rpqups ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 82 , ( const void * )
& ( rtDW . pbezlulnm5 ) , sizeof ( rtDW . pbezlulnm5 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 83 , ( const void * )
& ( rtDW . oyiznhfz3f ) , sizeof ( rtDW . oyiznhfz3f ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 84 , ( const void * )
& ( rtDW . djo5beq3n0 ) , sizeof ( rtDW . djo5beq3n0 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 85 , ( const void * )
& ( rtDW . gil4ie50ol ) , sizeof ( rtDW . gil4ie50ol ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 86 , ( const void * )
& ( rtDW . aarpnpqgmu ) , sizeof ( rtDW . aarpnpqgmu ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 87 , ( const void * )
& ( rtDW . cgfl554d0l ) , sizeof ( rtDW . cgfl554d0l ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 88 , ( const void * )
& ( rtDW . p51wmaigg2 ) , sizeof ( rtDW . p51wmaigg2 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 89 , ( const void * )
& ( rtDW . geb4p4zdgn ) , sizeof ( rtDW . geb4p4zdgn ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 90 , ( const void * )
& ( rtDW . opozmxoahv ) , sizeof ( rtDW . opozmxoahv ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 91 , ( const void * )
& ( rtDW . p3ylutwfna ) , sizeof ( rtDW . p3ylutwfna ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 92 , ( const void * )
& ( rtDW . fma5ryxgkz ) , sizeof ( rtDW . fma5ryxgkz ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 93 , ( const void * )
& ( rtDW . khxogtuz1l ) , sizeof ( rtDW . khxogtuz1l ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 94 , ( const void * )
& ( rtDW . d4qmht1xff ) , sizeof ( rtDW . d4qmht1xff ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 95 , ( const void * )
& ( rtDW . hjxqlr4sag ) , sizeof ( rtDW . hjxqlr4sag ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 96 , ( const void * )
& ( rtDW . eg3zr5htps ) , sizeof ( rtDW . eg3zr5htps ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 97 , ( const void * )
& ( rtDW . gazfgp55bt ) , sizeof ( rtDW . gazfgp55bt ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 98 , ( const void * )
& ( rtDW . jkumuiblmb ) , sizeof ( rtDW . jkumuiblmb ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 99 , ( const void * )
& ( rtDW . nt4ghy3024 ) , sizeof ( rtDW . nt4ghy3024 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 100 , ( const void *
) & ( rtDW . aux30da2zu ) , sizeof ( rtDW . aux30da2zu ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 101 , ( const void *
) & ( rtDW . aqmi0ximsk ) , sizeof ( rtDW . aqmi0ximsk ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 102 , ( const void *
) & ( rtDW . bf132dfs4i ) , sizeof ( rtDW . bf132dfs4i ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 103 , ( const void *
) & ( rtDW . n22ezzj533 ) , sizeof ( rtDW . n22ezzj533 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 104 , ( const void *
) & ( rtDW . egy3i3psvd ) , sizeof ( rtDW . egy3i3psvd ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 105 , ( const void *
) & ( rtDW . i5m44h50ql ) , sizeof ( rtDW . i5m44h50ql ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 106 , ( const void *
) & ( rtDW . axjy40izfe ) , sizeof ( rtDW . axjy40izfe ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 107 , ( const void *
) & ( rtDW . jq3vvbxrjf ) , sizeof ( rtDW . jq3vvbxrjf ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 108 , ( const void *
) & ( rtDW . okvjyaztbz ) , sizeof ( rtDW . okvjyaztbz ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 109 , ( const void *
) & ( rtDW . mez5whsqc3 ) , sizeof ( rtDW . mez5whsqc3 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 110 , ( const void *
) & ( rtDW . pbjw4010b3 ) , sizeof ( rtDW . pbjw4010b3 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 111 , ( const void *
) & ( rtDW . oyet01vjge ) , sizeof ( rtDW . oyet01vjge ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 112 , ( const void *
) & ( rtDW . bu03oe0pwq ) , sizeof ( rtDW . bu03oe0pwq ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 113 , ( const void *
) & ( rtDW . n1fso1av4u ) , sizeof ( rtDW . n1fso1av4u ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 114 , ( const void *
) & ( rtDW . orvtgsw01i ) , sizeof ( rtDW . orvtgsw01i ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 115 , ( const void *
) & ( rtDW . i0pn21xe2p ) , sizeof ( rtDW . i0pn21xe2p ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 116 , ( const void *
) & ( rtDW . gljdehuiwg ) , sizeof ( rtDW . gljdehuiwg ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 117 , ( const void *
) & ( rtDW . mmoscpngve ) , sizeof ( rtDW . mmoscpngve ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 118 , ( const void *
) & ( rtDW . icvovv1jq2 ) , sizeof ( rtDW . icvovv1jq2 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 119 , ( const void *
) & ( rtDW . fwfrplulil ) , sizeof ( rtDW . fwfrplulil ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 120 , ( const void *
) & ( rtDW . dxjlf0kpmf ) , sizeof ( rtDW . dxjlf0kpmf ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 121 , ( const void *
) & ( rtDW . os5dfkhn1w ) , sizeof ( rtDW . os5dfkhn1w ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 122 , ( const void *
) & ( rtDW . iw1ylkptc1 ) , sizeof ( rtDW . iw1ylkptc1 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 123 , ( const void *
) & ( rtDW . ggmjvv0lb3 ) , sizeof ( rtDW . ggmjvv0lb3 ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 124 , ( const void *
) & ( rtDW . fbe3y1q2sg ) , sizeof ( rtDW . fbe3y1q2sg ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 125 , ( const void *
) & ( rtDW . aslrlvkkcc ) , sizeof ( rtDW . aslrlvkkcc ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 126 , ( const void *
) & ( rtDW . hekwrhnl5m ) , sizeof ( rtDW . hekwrhnl5m ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 127 , ( const void *
) & ( rtDW . doiwoekzov ) , sizeof ( rtDW . doiwoekzov ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 128 , ( const void *
) & ( rtDW . jdnmbiwx3f ) , sizeof ( rtDW . jdnmbiwx3f ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 129 , ( const void *
) & ( rtDW . aphrz0r2os ) , sizeof ( rtDW . aphrz0r2os ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 130 , ( const void *
) & ( rtDW . offqujpaki ) , sizeof ( rtDW . offqujpaki ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 131 , ( const void *
) & ( rtDW . bhhlshfa0t ) , sizeof ( rtDW . bhhlshfa0t ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 132 , ( const void *
) & ( rtDW . hxxbbgmykq ) , sizeof ( rtDW . hxxbbgmykq ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 133 , ( const void *
) & ( rtDW . md1zdgbsoe ) , sizeof ( rtDW . md1zdgbsoe ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 134 , ( const void *
) & ( rtDW . hlvtogm2ca ) , sizeof ( rtDW . hlvtogm2ca ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 135 , ( const void *
) & ( rtDW . ot0jlfqn3i ) , sizeof ( rtDW . ot0jlfqn3i ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 136 , ( const void *
) & ( rtDW . awhbfmptso ) , sizeof ( rtDW . awhbfmptso ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 137 , ( const void *
) & ( rtDW . fdy0jfy1tu ) , sizeof ( rtDW . fdy0jfy1tu ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 138 , ( const void *
) & ( rtDW . i2lws3rgth ) , sizeof ( rtDW . i2lws3rgth ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 139 , ( const void *
) & ( rtDW . oasl5bklsg ) , sizeof ( rtDW . oasl5bklsg ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 140 , ( const void *
) & ( rtDW . l0150x51ms ) , sizeof ( rtDW . l0150x51ms ) ) ;
mr_activeBalancing2_cacheDataAsMxArray ( rtdwData , 0 , 141 , ( const void *
) & ( rtDW . p4r02ywybb ) , sizeof ( rtDW . p4r02ywybb ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; }
mr_activeBalancing2_cacheDataAsMxArray ( ssDW , 0 , 2 , ( const void * ) & (
rtPrevZCX ) , sizeof ( rtPrevZCX ) ) ; return ssDW ; } void
mr_activeBalancing2_SetDWork ( const mxArray * ssDW ) { ( void ) ssDW ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtB ) , ssDW , 0
, 0 , sizeof ( rtB ) ) ; { const mxArray * rtdwData = mxGetFieldByNumber (
ssDW , 0 , 1 ) ; mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & (
rtDW . mx5vjacu5q ) , rtdwData , 0 , 0 , sizeof ( rtDW . mx5vjacu5q ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . gu33m3cujr
) , rtdwData , 0 , 1 , sizeof ( rtDW . gu33m3cujr ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ihabibaari
) , rtdwData , 0 , 2 , sizeof ( rtDW . ihabibaari ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . g45xtcsm1y
) , rtdwData , 0 , 3 , sizeof ( rtDW . g45xtcsm1y ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . mde444qrus
) , rtdwData , 0 , 4 , sizeof ( rtDW . mde444qrus ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . egfu4zp5ck
) , rtdwData , 0 , 5 , sizeof ( rtDW . egfu4zp5ck ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . jjpmmqdhaq
) , rtdwData , 0 , 6 , sizeof ( rtDW . jjpmmqdhaq ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . knijrjnyhh
) , rtdwData , 0 , 7 , sizeof ( rtDW . knijrjnyhh ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . curbfhmvfh
) , rtdwData , 0 , 8 , sizeof ( rtDW . curbfhmvfh ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . h51d42z1yp
) , rtdwData , 0 , 9 , sizeof ( rtDW . h51d42z1yp ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . evcbaypssu
) , rtdwData , 0 , 10 , sizeof ( rtDW . evcbaypssu ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . fcr2tgbfvo
) , rtdwData , 0 , 11 , sizeof ( rtDW . fcr2tgbfvo ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . glz3hn24br
) , rtdwData , 0 , 12 , sizeof ( rtDW . glz3hn24br ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . peu253ymia
) , rtdwData , 0 , 13 , sizeof ( rtDW . peu253ymia ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . b0muitc2hd
) , rtdwData , 0 , 14 , sizeof ( rtDW . b0muitc2hd ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . llaf3ewbkp
) , rtdwData , 0 , 15 , sizeof ( rtDW . llaf3ewbkp ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . axv0fdx2my
) , rtdwData , 0 , 16 , sizeof ( rtDW . axv0fdx2my ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . azndzkmkcs
) , rtdwData , 0 , 17 , sizeof ( rtDW . azndzkmkcs ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . nthq3z5tt5
) , rtdwData , 0 , 18 , sizeof ( rtDW . nthq3z5tt5 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . plxwewmbjw
) , rtdwData , 0 , 19 , sizeof ( rtDW . plxwewmbjw ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ftugzjzi0o
) , rtdwData , 0 , 20 , sizeof ( rtDW . ftugzjzi0o ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . gipv354qpb
) , rtdwData , 0 , 21 , sizeof ( rtDW . gipv354qpb ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . j1mmhsj1qj
) , rtdwData , 0 , 22 , sizeof ( rtDW . j1mmhsj1qj ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . k4c4pmfnv2
) , rtdwData , 0 , 23 , sizeof ( rtDW . k4c4pmfnv2 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . mfqivfq3il
) , rtdwData , 0 , 24 , sizeof ( rtDW . mfqivfq3il ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . pxyvizid1y
) , rtdwData , 0 , 25 , sizeof ( rtDW . pxyvizid1y ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . feyc5lmf2r
) , rtdwData , 0 , 26 , sizeof ( rtDW . feyc5lmf2r ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ebuw4ix1ne
) , rtdwData , 0 , 27 , sizeof ( rtDW . ebuw4ix1ne ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . jvh5mician
) , rtdwData , 0 , 28 , sizeof ( rtDW . jvh5mician ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . cdm1pyiexh
) , rtdwData , 0 , 29 , sizeof ( rtDW . cdm1pyiexh ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . k0umb4nsxj
) , rtdwData , 0 , 30 , sizeof ( rtDW . k0umb4nsxj ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . a1ahum4gsl
) , rtdwData , 0 , 31 , sizeof ( rtDW . a1ahum4gsl ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . fmvszapqpi
) , rtdwData , 0 , 32 , sizeof ( rtDW . fmvszapqpi ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ko5gsxzsuc
) , rtdwData , 0 , 33 , sizeof ( rtDW . ko5gsxzsuc ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . p3thioyq1j
) , rtdwData , 0 , 34 , sizeof ( rtDW . p3thioyq1j ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . g55jrpbizl
) , rtdwData , 0 , 35 , sizeof ( rtDW . g55jrpbizl ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ojsrsvfc4d
) , rtdwData , 0 , 36 , sizeof ( rtDW . ojsrsvfc4d ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . lldjl4eyzi
) , rtdwData , 0 , 37 , sizeof ( rtDW . lldjl4eyzi ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . gxvtetrs04
) , rtdwData , 0 , 38 , sizeof ( rtDW . gxvtetrs04 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . frtlsutffh
) , rtdwData , 0 , 39 , sizeof ( rtDW . frtlsutffh ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . pzgimzosty
) , rtdwData , 0 , 40 , sizeof ( rtDW . pzgimzosty ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . m3sjkfetzr
) , rtdwData , 0 , 41 , sizeof ( rtDW . m3sjkfetzr ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . jmxabr1urn
) , rtdwData , 0 , 42 , sizeof ( rtDW . jmxabr1urn ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . hrm4dgu33i
) , rtdwData , 0 , 43 , sizeof ( rtDW . hrm4dgu33i ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ge34ybq3a0
) , rtdwData , 0 , 44 , sizeof ( rtDW . ge34ybq3a0 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ed3nvtxxjm
) , rtdwData , 0 , 45 , sizeof ( rtDW . ed3nvtxxjm ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . dsor1ukpll
) , rtdwData , 0 , 46 , sizeof ( rtDW . dsor1ukpll ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . cokzwj0i4g
) , rtdwData , 0 , 47 , sizeof ( rtDW . cokzwj0i4g ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . gnfw0t231h
) , rtdwData , 0 , 48 , sizeof ( rtDW . gnfw0t231h ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . lv22brfstt
) , rtdwData , 0 , 49 , sizeof ( rtDW . lv22brfstt ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . as2ykd4ql3
) , rtdwData , 0 , 50 , sizeof ( rtDW . as2ykd4ql3 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . kaytcmiwya
) , rtdwData , 0 , 51 , sizeof ( rtDW . kaytcmiwya ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . dcn3au535t
) , rtdwData , 0 , 52 , sizeof ( rtDW . dcn3au535t ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . jertq5slcs
) , rtdwData , 0 , 53 , sizeof ( rtDW . jertq5slcs ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . l0t1omik1w
) , rtdwData , 0 , 54 , sizeof ( rtDW . l0t1omik1w ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . hdetrxmovp
) , rtdwData , 0 , 55 , sizeof ( rtDW . hdetrxmovp ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . d4gcz4s4op
) , rtdwData , 0 , 56 , sizeof ( rtDW . d4gcz4s4op ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . o0qveok2yn
) , rtdwData , 0 , 57 , sizeof ( rtDW . o0qveok2yn ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . jpp24x3j0b
) , rtdwData , 0 , 58 , sizeof ( rtDW . jpp24x3j0b ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . dkr0lmfwa5
) , rtdwData , 0 , 59 , sizeof ( rtDW . dkr0lmfwa5 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . nrpmm2hefl
) , rtdwData , 0 , 60 , sizeof ( rtDW . nrpmm2hefl ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . audfqsd0mm
) , rtdwData , 0 , 61 , sizeof ( rtDW . audfqsd0mm ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . hwrms4izrt
) , rtdwData , 0 , 62 , sizeof ( rtDW . hwrms4izrt ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . gtcdjshroe
) , rtdwData , 0 , 63 , sizeof ( rtDW . gtcdjshroe ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . fqhd2sk321
) , rtdwData , 0 , 64 , sizeof ( rtDW . fqhd2sk321 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . kxwxa3byt5
) , rtdwData , 0 , 65 , sizeof ( rtDW . kxwxa3byt5 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . fogzt5jbmz
) , rtdwData , 0 , 66 , sizeof ( rtDW . fogzt5jbmz ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . oq1utabldx
) , rtdwData , 0 , 67 , sizeof ( rtDW . oq1utabldx ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . exu1prz21a
) , rtdwData , 0 , 68 , sizeof ( rtDW . exu1prz21a ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . bs0tfwzjp3
) , rtdwData , 0 , 69 , sizeof ( rtDW . bs0tfwzjp3 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . msxvlyne10
) , rtdwData , 0 , 70 , sizeof ( rtDW . msxvlyne10 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . owram20lcx
) , rtdwData , 0 , 71 , sizeof ( rtDW . owram20lcx ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ktypzgdlxt
) , rtdwData , 0 , 72 , sizeof ( rtDW . ktypzgdlxt ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . otvz1o3ztq
) , rtdwData , 0 , 73 , sizeof ( rtDW . otvz1o3ztq ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . pkopjswp3e
) , rtdwData , 0 , 74 , sizeof ( rtDW . pkopjswp3e ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . e0qedsyqjn
) , rtdwData , 0 , 75 , sizeof ( rtDW . e0qedsyqjn ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . pkpw1tsasy
) , rtdwData , 0 , 76 , sizeof ( rtDW . pkpw1tsasy ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . mx41mp51rp
) , rtdwData , 0 , 77 , sizeof ( rtDW . mx41mp51rp ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . jansurp50c
) , rtdwData , 0 , 78 , sizeof ( rtDW . jansurp50c ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . c4szg1j5wf
) , rtdwData , 0 , 79 , sizeof ( rtDW . c4szg1j5wf ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . izsp05gss2
) , rtdwData , 0 , 80 , sizeof ( rtDW . izsp05gss2 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . b554rpqups
) , rtdwData , 0 , 81 , sizeof ( rtDW . b554rpqups ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . pbezlulnm5
) , rtdwData , 0 , 82 , sizeof ( rtDW . pbezlulnm5 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . oyiznhfz3f
) , rtdwData , 0 , 83 , sizeof ( rtDW . oyiznhfz3f ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . djo5beq3n0
) , rtdwData , 0 , 84 , sizeof ( rtDW . djo5beq3n0 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . gil4ie50ol
) , rtdwData , 0 , 85 , sizeof ( rtDW . gil4ie50ol ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . aarpnpqgmu
) , rtdwData , 0 , 86 , sizeof ( rtDW . aarpnpqgmu ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . cgfl554d0l
) , rtdwData , 0 , 87 , sizeof ( rtDW . cgfl554d0l ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . p51wmaigg2
) , rtdwData , 0 , 88 , sizeof ( rtDW . p51wmaigg2 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . geb4p4zdgn
) , rtdwData , 0 , 89 , sizeof ( rtDW . geb4p4zdgn ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . opozmxoahv
) , rtdwData , 0 , 90 , sizeof ( rtDW . opozmxoahv ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . p3ylutwfna
) , rtdwData , 0 , 91 , sizeof ( rtDW . p3ylutwfna ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . fma5ryxgkz
) , rtdwData , 0 , 92 , sizeof ( rtDW . fma5ryxgkz ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . khxogtuz1l
) , rtdwData , 0 , 93 , sizeof ( rtDW . khxogtuz1l ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . d4qmht1xff
) , rtdwData , 0 , 94 , sizeof ( rtDW . d4qmht1xff ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . hjxqlr4sag
) , rtdwData , 0 , 95 , sizeof ( rtDW . hjxqlr4sag ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . eg3zr5htps
) , rtdwData , 0 , 96 , sizeof ( rtDW . eg3zr5htps ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . gazfgp55bt
) , rtdwData , 0 , 97 , sizeof ( rtDW . gazfgp55bt ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . jkumuiblmb
) , rtdwData , 0 , 98 , sizeof ( rtDW . jkumuiblmb ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . nt4ghy3024
) , rtdwData , 0 , 99 , sizeof ( rtDW . nt4ghy3024 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . aux30da2zu
) , rtdwData , 0 , 100 , sizeof ( rtDW . aux30da2zu ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . aqmi0ximsk
) , rtdwData , 0 , 101 , sizeof ( rtDW . aqmi0ximsk ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . bf132dfs4i
) , rtdwData , 0 , 102 , sizeof ( rtDW . bf132dfs4i ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . n22ezzj533
) , rtdwData , 0 , 103 , sizeof ( rtDW . n22ezzj533 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . egy3i3psvd
) , rtdwData , 0 , 104 , sizeof ( rtDW . egy3i3psvd ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . i5m44h50ql
) , rtdwData , 0 , 105 , sizeof ( rtDW . i5m44h50ql ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . axjy40izfe
) , rtdwData , 0 , 106 , sizeof ( rtDW . axjy40izfe ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . jq3vvbxrjf
) , rtdwData , 0 , 107 , sizeof ( rtDW . jq3vvbxrjf ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . okvjyaztbz
) , rtdwData , 0 , 108 , sizeof ( rtDW . okvjyaztbz ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . mez5whsqc3
) , rtdwData , 0 , 109 , sizeof ( rtDW . mez5whsqc3 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . pbjw4010b3
) , rtdwData , 0 , 110 , sizeof ( rtDW . pbjw4010b3 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . oyet01vjge
) , rtdwData , 0 , 111 , sizeof ( rtDW . oyet01vjge ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . bu03oe0pwq
) , rtdwData , 0 , 112 , sizeof ( rtDW . bu03oe0pwq ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . n1fso1av4u
) , rtdwData , 0 , 113 , sizeof ( rtDW . n1fso1av4u ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . orvtgsw01i
) , rtdwData , 0 , 114 , sizeof ( rtDW . orvtgsw01i ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . i0pn21xe2p
) , rtdwData , 0 , 115 , sizeof ( rtDW . i0pn21xe2p ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . gljdehuiwg
) , rtdwData , 0 , 116 , sizeof ( rtDW . gljdehuiwg ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . mmoscpngve
) , rtdwData , 0 , 117 , sizeof ( rtDW . mmoscpngve ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . icvovv1jq2
) , rtdwData , 0 , 118 , sizeof ( rtDW . icvovv1jq2 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . fwfrplulil
) , rtdwData , 0 , 119 , sizeof ( rtDW . fwfrplulil ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . dxjlf0kpmf
) , rtdwData , 0 , 120 , sizeof ( rtDW . dxjlf0kpmf ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . os5dfkhn1w
) , rtdwData , 0 , 121 , sizeof ( rtDW . os5dfkhn1w ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . iw1ylkptc1
) , rtdwData , 0 , 122 , sizeof ( rtDW . iw1ylkptc1 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ggmjvv0lb3
) , rtdwData , 0 , 123 , sizeof ( rtDW . ggmjvv0lb3 ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . fbe3y1q2sg
) , rtdwData , 0 , 124 , sizeof ( rtDW . fbe3y1q2sg ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . aslrlvkkcc
) , rtdwData , 0 , 125 , sizeof ( rtDW . aslrlvkkcc ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . hekwrhnl5m
) , rtdwData , 0 , 126 , sizeof ( rtDW . hekwrhnl5m ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . doiwoekzov
) , rtdwData , 0 , 127 , sizeof ( rtDW . doiwoekzov ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . jdnmbiwx3f
) , rtdwData , 0 , 128 , sizeof ( rtDW . jdnmbiwx3f ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . aphrz0r2os
) , rtdwData , 0 , 129 , sizeof ( rtDW . aphrz0r2os ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . offqujpaki
) , rtdwData , 0 , 130 , sizeof ( rtDW . offqujpaki ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . bhhlshfa0t
) , rtdwData , 0 , 131 , sizeof ( rtDW . bhhlshfa0t ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . hxxbbgmykq
) , rtdwData , 0 , 132 , sizeof ( rtDW . hxxbbgmykq ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . md1zdgbsoe
) , rtdwData , 0 , 133 , sizeof ( rtDW . md1zdgbsoe ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . hlvtogm2ca
) , rtdwData , 0 , 134 , sizeof ( rtDW . hlvtogm2ca ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . ot0jlfqn3i
) , rtdwData , 0 , 135 , sizeof ( rtDW . ot0jlfqn3i ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . awhbfmptso
) , rtdwData , 0 , 136 , sizeof ( rtDW . awhbfmptso ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . fdy0jfy1tu
) , rtdwData , 0 , 137 , sizeof ( rtDW . fdy0jfy1tu ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . i2lws3rgth
) , rtdwData , 0 , 138 , sizeof ( rtDW . i2lws3rgth ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . oasl5bklsg
) , rtdwData , 0 , 139 , sizeof ( rtDW . oasl5bklsg ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . l0150x51ms
) , rtdwData , 0 , 140 , sizeof ( rtDW . l0150x51ms ) ) ;
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtDW . p4r02ywybb
) , rtdwData , 0 , 141 , sizeof ( rtDW . p4r02ywybb ) ) ; }
mr_activeBalancing2_restoreDataFromMxArray ( ( void * ) & ( rtPrevZCX ) ,
ssDW , 0 , 2 , sizeof ( rtPrevZCX ) ) ; } mxArray *
mr_activeBalancing2_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 4 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 4 ] = { "S-Function" , "Scope" , "Scope" , "S-Function" ,
} ; static const char * blockPath [ 4 ] = {
"activeBalancing2/powergui/EquivalentModel1/State-Space" ,
"activeBalancing2/SOC %" , "activeBalancing2/Voltage" ,
"activeBalancing2/powergui/EquivalentModel1/State-Space" , } ; static const
int reason [ 4 ] = { 0 , 0 , 0 , 2 , } ; for ( subs [ 0 ] = 0 ; subs [ 0 ] <
4 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset = mxCalcSingleSubscript (
data , 2 , subs ) ; mxSetCell ( data , offset , mxCreateString ( blockType [
subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ; offset = mxCalcSingleSubscript ( data , 2
, subs ) ; mxSetCell ( data , offset , mxCreateString ( blockPath [ subs [ 0
] ] ) ) ; subs [ 1 ] = 2 ; offset = mxCalcSingleSubscript ( data , 2 , subs )
; mxSetCell ( data , offset , mxCreateDoubleScalar ( ( double ) reason [ subs
[ 0 ] ] ) ) ; } } return data ; } void MdlInitializeSizes ( void ) {
ssSetNumContStates ( rtS , 26 ) ; ssSetNumPeriodicContStates ( rtS , 0 ) ;
ssSetNumY ( rtS , 0 ) ; ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough ( rtS
, 0 ) ; ssSetNumSampleTimes ( rtS , 8 ) ; ssSetNumBlocks ( rtS , 713 ) ;
ssSetNumBlockIO ( rtS , 297 ) ; ssSetNumBlockParams ( rtS , 6582 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 , 0.0 ) ;
ssSetSampleTime ( rtS , 1 , 0.0 ) ; ssSetSampleTime ( rtS , 2 , - 2.0 ) ;
ssSetSampleTime ( rtS , 3 , - 2.0 ) ; ssSetSampleTime ( rtS , 4 , - 2.0 ) ;
ssSetSampleTime ( rtS , 5 , - 2.0 ) ; ssSetSampleTime ( rtS , 6 , - 2.0 ) ;
ssSetSampleTime ( rtS , 7 , - 2.0 ) ; ssSetOffsetTime ( rtS , 0 , 0.0 ) ;
ssSetOffsetTime ( rtS , 1 , 1.0 ) ; ssSetOffsetTime ( rtS , 2 , 0.0 ) ;
ssSetOffsetTime ( rtS , 3 , 1.0 ) ; ssSetOffsetTime ( rtS , 4 , 2.0 ) ;
ssSetOffsetTime ( rtS , 5 , 3.0 ) ; ssSetOffsetTime ( rtS , 6 , 4.0 ) ;
ssSetOffsetTime ( rtS , 7 , 5.0 ) ; } void raccel_set_checksum ( ) {
ssSetChecksumVal ( rtS , 0 , 2020061266U ) ; ssSetChecksumVal ( rtS , 1 ,
3753598033U ) ; ssSetChecksumVal ( rtS , 2 , 1176490380U ) ; ssSetChecksumVal
( rtS , 3 , 1620534263U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; ( void ) memset ( ( char * ) rtS , 0 ,
sizeof ( SimStruct ) ) ; ( void ) memset ( ( char * ) & mdlInfo , 0 , sizeof
( struct _ssMdlInfo ) ) ; ssSetMdlInfoPtr ( rtS , & mdlInfo ) ;
ssSetExecutionInfo ( rtS , executionInfo ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; } { real_T * x = ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ;
( void ) memset ( ( void * ) x , 0 , sizeof ( X ) ) ; } { void * dwork = (
void * ) & rtDW ; ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork ,
0 , sizeof ( DW ) ) ; } { static DataTypeTransInfo dtInfo ; ( void ) memset (
( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS
, & dtInfo ) ; dtInfo . numDataTypes = 23 ; dtInfo . dataTypeSizes = &
rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = & rtDataTypeNames [ 0 ] ;
dtInfo . BTransTable = & rtBTransTable ; dtInfo . PTransTable = &
rtPTransTable ; dtInfo . dataTypeInfoTable = rtDataTypeInfoTable ; }
activeBalancing2_InitializeDataMapInfo ( ) ; ssSetIsRapidAcceleratorActive (
rtS , true ) ; ssSetRootSS ( rtS , rtS ) ; ssSetVersion ( rtS ,
SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS , "activeBalancing2" ) ;
ssSetPath ( rtS , "activeBalancing2" ) ; ssSetTStart ( rtS , 0.0 ) ;
ssSetTFinal ( rtS , 120.0 ) ; { static RTWLogInfo rt_DataLoggingInfo ;
rt_DataLoggingInfo . loggingInterval = ( NULL ) ; ssSetRTWLogInfo ( rtS , &
rt_DataLoggingInfo ) ; } { { static int_T rt_LoggedStateWidths [ ] = { 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 6 }
; static int_T rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; static int_T
rt_LoggedStateDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 6 } ; static boolean_T
rt_LoggedStateIsVarDims [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static BuiltInDTypeId
rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE } ;
static int_T rt_LoggedStateComplexSignals [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static
RTWPreprocessingFcnPtr rt_LoggingStatePreprocessingFcnPtrs [ ] = { ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) } ; static
const char_T * rt_LoggedStateLabels [ ] = { "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" } ; static const char_T *
rt_LoggedStateBlockNames [ ] = {
"activeBalancing2/Battery1/Model/Current filter" ,
"activeBalancing2/Battery1/Model/int(i)" ,
"activeBalancing2/Battery1/Model/Exp/Integrator2" ,
"activeBalancing2/Battery1/Model/BAL" ,
"activeBalancing2/Battery2/Model/Current filter" ,
"activeBalancing2/Battery2/Model/int(i)" ,
"activeBalancing2/Battery2/Model/Exp/Integrator2" ,
"activeBalancing2/Battery2/Model/BAL" ,
"activeBalancing2/Battery3/Model/Current filter" ,
"activeBalancing2/Battery3/Model/int(i)" ,
"activeBalancing2/Battery3/Model/Exp/Integrator2" ,
"activeBalancing2/Battery3/Model/BAL" ,
"activeBalancing2/Battery4/Model/Current filter" ,
"activeBalancing2/Battery4/Model/int(i)" ,
"activeBalancing2/Battery4/Model/Exp/Integrator2" ,
"activeBalancing2/Battery4/Model/BAL" ,
"activeBalancing2/Battery5/Model/Current filter" ,
"activeBalancing2/Battery5/Model/int(i)" ,
"activeBalancing2/Battery5/Model/Exp/Integrator2" ,
"activeBalancing2/Battery5/Model/BAL" ,
"activeBalancing2/powergui/EquivalentModel1/State-Space" } ; static const
char_T * rt_LoggedStateNames [ ] = { "" , "" , "" , "" , "" , "" , "" , "" ,
"" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" } ; static
boolean_T rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static
RTWLogDataTypeConvert rt_RTWLogDataTypeConvert [ ] = { { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } } ; static int_T
rt_LoggedStateIdxList [ ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 20 } ; static RTWLogSignalInfo
rt_LoggedStateSignalInfo = { 21 , rt_LoggedStateWidths ,
rt_LoggedStateNumDimensions , rt_LoggedStateDimensions ,
rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 21 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . foozkkgumc ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtX . axoluperv2 ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtX . iftoftjjsf ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) & rtX . iwofyqttuz ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) & rtX . jsonadfc25 ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) & rtX . bhkc4j1ohz ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) & rtX . m13n11gqh5 ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) & rtX . cveknlxk0w ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) & rtX . iqfvbswlqx ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtX . aczscrflwb ;
rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) & rtX . a20yshtbnb ;
rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtX . m2tz1exxd4 ;
rt_LoggedStateSignalPtrs [ 12 ] = ( void * ) & rtX . n3r5zcmpoi ;
rt_LoggedStateSignalPtrs [ 13 ] = ( void * ) & rtX . bz3dftuo0x ;
rt_LoggedStateSignalPtrs [ 14 ] = ( void * ) & rtX . e02u4qxaaf ;
rt_LoggedStateSignalPtrs [ 15 ] = ( void * ) & rtX . lkcwi10nsx ;
rt_LoggedStateSignalPtrs [ 16 ] = ( void * ) & rtX . l1c0yrfxl4 ;
rt_LoggedStateSignalPtrs [ 17 ] = ( void * ) & rtX . lgrzwldtuz ;
rt_LoggedStateSignalPtrs [ 18 ] = ( void * ) & rtX . aacuquz0zq ;
rt_LoggedStateSignalPtrs [ 19 ] = ( void * ) & rtX . lnia4pzqrd ;
rt_LoggedStateSignalPtrs [ 20 ] = ( void * ) & rtX . odntevo1ki [ 0 ] ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssJacobianPerturbationBounds jacobianPerturbationBounds ;
ssSetJacobianPerturbationBounds ( rtS , & jacobianPerturbationBounds ) ; } {
static ssSolverInfo slvrInfo ; static struct _ssSFcnModelMethods3 mdlMethods3
; static struct _ssSFcnModelMethods2 mdlMethods2 ; static boolean_T
contStatesDisabled [ 26 ] ; static real_T absTol [ 26 ] = { 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 } ;
static uint8_T absTolControl [ 26 ] = { 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U
, 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U ,
0U , 0U , 0U } ; static real_T contStateJacPerturbBoundMinVec [ 26 ] ; static
real_T contStateJacPerturbBoundMaxVec [ 26 ] ; static uint8_T zcAttributes [
126 ] = { ( ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP )
, ( ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL
) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL )
, ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) } ; static
ssNonContDerivSigInfo nonContDerivSigInfo [ 82 ] = { { 1 * sizeof ( real_T )
, ( char * ) ( & rtB . grdrezphge ) , ( NULL ) } , { 1 * sizeof ( real_T ) ,
( char * ) ( & rtB . jwyopjqrrt ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . dnh3ifiezd ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . cddvon4kch ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . le12ofiyut ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . h0sbflpvzu ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . m0rozdflil ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . jrbeh4gjon ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . babbdjgwl2 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . juwmydw0tr ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . db4zg1qvnr ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . gvzvt5tv3i ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . lm2n4ijyor ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . m40urup0vc ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . l5tc3gqfzb ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . cwzjkwv2ox ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . p0xfzbei1b ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ovwc5iskjn ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ldbnroag1b ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . n2t5rlh5a1 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . azrlqv35vl ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . kiqwsofa1f ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . bklkra2upj ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ir1j5szgpu ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . gkdril5bnk ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ekz0c33q4s ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . aj1fizh15j ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . lbo2irmbzd ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ffmj4w3cmt ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ok2bxp4qq0 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ewvip3v1vs ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . cj3lmhi2x0 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . fvxbq05uoi ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . hd4g4dpfnd ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . lwf12tqfq2 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . dxpca0qb4k ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . pqnqe2hboi ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . hdec1eqbit ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . egc5tqeng4 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . m5lqxlhg5k ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . jtgqzbh1iz ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . leccoparpy ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . pbs4th3eaf ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . cvyse4x1ck ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . jatdb2hgzm ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . dbom2viqze ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ndpfkqx0ft ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . n35vhllexk ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ggsuorkr3o ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . mudvde1asq ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . dixauele0b ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . hqnpeamwdn ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . db3qyyuroe ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ik5rmfzive ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . mil2gvjxva ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ihicpd1xdt ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ixe2myxgue ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . hy1qp5kmnb ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . gfojdvphy5 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . fanfrrdn0p ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ebarhnnaj2 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . n30sif3yf3 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ma2bkws5c2 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . le2uootisz ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . n0hhvlmhsx ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . fzgromwfrh ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ax0agqaio3 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . gytt55q4rf ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ilnbwvckzb ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . jrlz1gdkjb ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . o4wzll3qjg ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . m40orrweos ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . gvvtz2d2av ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . e5s2aj4bft ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . jz1nhvdeap ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . mlf4o50fzo ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . gbl1xcr4zw ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ottjrsvg2b ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . kmc5f3pvgr ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . mypk2tqufk ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . kddmvh240q ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . kjybbipaii ) , ( NULL ) } } ; { int i ; for ( i = 0 ; i <
26 ; ++ i ) { contStateJacPerturbBoundMinVec [ i ] = 0 ;
contStateJacPerturbBoundMaxVec [ i ] = rtGetInf ( ) ; } } ssSetSolverRelTol (
rtS , 0.001 ) ; ssSetStepSize ( rtS , 0.0 ) ; ssSetMinStepSize ( rtS , 0.0 )
; ssSetMaxNumMinSteps ( rtS , - 1 ) ; ssSetMinStepViolatedError ( rtS , 0 ) ;
ssSetMaxStepSize ( rtS , 2.4 ) ; ssSetSolverMaxOrder ( rtS , - 1 ) ;
ssSetSolverRefineFactor ( rtS , 1 ) ; ssSetOutputTimes ( rtS , ( NULL ) ) ;
ssSetNumOutputTimes ( rtS , 0 ) ; ssSetOutputTimesOnly ( rtS , 0 ) ;
ssSetOutputTimesIndex ( rtS , 0 ) ; ssSetZCCacheNeedsReset ( rtS , 1 ) ;
ssSetDerivCacheNeedsReset ( rtS , 0 ) ; ssSetNumNonContDerivSigInfos ( rtS ,
82 ) ; ssSetNonContDerivSigInfos ( rtS , nonContDerivSigInfo ) ;
ssSetSolverInfo ( rtS , & slvrInfo ) ; ssSetSolverName ( rtS , "ode23tb" ) ;
ssSetVariableStepSolver ( rtS , 1 ) ; ssSetSolverConsistencyChecking ( rtS ,
0 ) ; ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ;
ssSetSolverRobustResetMethod ( rtS , 0 ) ; ssSetAbsTolVector ( rtS , absTol )
; ssSetAbsTolControlVector ( rtS , absTolControl ) ;
ssSetSolverAbsTol_Obsolete ( rtS , absTol ) ;
ssSetSolverAbsTolControl_Obsolete ( rtS , absTolControl ) ;
ssSetJacobianPerturbationBoundsMinVec ( rtS , contStateJacPerturbBoundMinVec
) ; ssSetJacobianPerturbationBoundsMaxVec ( rtS ,
contStateJacPerturbBoundMaxVec ) ; ssSetSolverStateProjection ( rtS , 1 ) ; (
void ) memset ( ( void * ) & mdlMethods2 , 0 , sizeof ( mdlMethods2 ) ) ;
ssSetModelMethods2 ( rtS , & mdlMethods2 ) ; ( void ) memset ( ( void * ) &
mdlMethods3 , 0 , sizeof ( mdlMethods3 ) ) ; ssSetModelMethods3 ( rtS , &
mdlMethods3 ) ; ssSetModelProjection ( rtS , MdlProjection ) ;
ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelLogData ( rtS , rt_UpdateTXYLogVars ) ;
ssSetModelLogDataIfInInterval ( rtS , rt_UpdateTXXFYLogVars ) ;
ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetModelDerivatives ( rtS ,
MdlDerivatives ) ; ssSetSolverZcSignalAttrib ( rtS , zcAttributes ) ;
ssSetSolverNumZcSignals ( rtS , 126 ) ; ssSetModelZeroCrossings ( rtS ,
MdlZeroCrossings ) ; ssSetSolverConsecutiveZCsStepRelTol ( rtS ,
2.8421709430404007E-13 ) ; ssSetSolverMaxConsecutiveZCs ( rtS , 1000 ) ;
ssSetSolverConsecutiveZCsError ( rtS , 2 ) ; ssSetSolverMaskedZcDiagnostic (
rtS , 1 ) ; ssSetSolverIgnoredZcDiagnostic ( rtS , 1 ) ;
ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ;
ssSetSolverShapePreserveControl ( rtS , 2 ) ; ssSetTNextTid ( rtS , INT_MIN )
; ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 121 ) ; ssSetContStateDisabled ( rtS ,
contStatesDisabled ) ; ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ; } {
ZCSigState * zc = ( ZCSigState * ) & rtPrevZCX ; ssSetPrevZCSigState ( rtS ,
zc ) ; } { rtPrevZCX . oztcuusllf = UNINITIALIZED_ZCSIG ; rtPrevZCX .
omisk5z2rc = UNINITIALIZED_ZCSIG ; rtPrevZCX . dwwhqwbiro =
UNINITIALIZED_ZCSIG ; rtPrevZCX . lm2mnmnxo1 = UNINITIALIZED_ZCSIG ;
rtPrevZCX . eqomayvlng = UNINITIALIZED_ZCSIG ; } ssSetChecksumVal ( rtS , 0 ,
2020061266U ) ; ssSetChecksumVal ( rtS , 1 , 3753598033U ) ; ssSetChecksumVal
( rtS , 2 , 1176490380U ) ; ssSetChecksumVal ( rtS , 3 , 1620534263U ) ; {
static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE ; static
RTWExtModeInfo rt_ExtModeInfo ; static const sysRanDType * systemRan [ 65 ] ;
gblRTWExtModeInfo = & rt_ExtModeInfo ; ssSetRTWExtModeInfo ( rtS , &
rt_ExtModeInfo ) ; rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo ,
systemRan ) ; systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = &
rtAlwaysEnabled ; systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = &
rtAlwaysEnabled ; systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = &
rtAlwaysEnabled ; systemRan [ 6 ] = & rtAlwaysEnabled ; systemRan [ 7 ] = &
rtAlwaysEnabled ; systemRan [ 8 ] = & rtAlwaysEnabled ; systemRan [ 9 ] = &
rtAlwaysEnabled ; systemRan [ 10 ] = & rtAlwaysEnabled ; systemRan [ 11 ] = &
rtAlwaysEnabled ; systemRan [ 12 ] = & rtAlwaysEnabled ; systemRan [ 13 ] = &
rtAlwaysEnabled ; systemRan [ 14 ] = & rtAlwaysEnabled ; systemRan [ 15 ] = &
rtAlwaysEnabled ; systemRan [ 16 ] = & rtAlwaysEnabled ; systemRan [ 17 ] = &
rtAlwaysEnabled ; systemRan [ 18 ] = & rtAlwaysEnabled ; systemRan [ 19 ] = &
rtAlwaysEnabled ; systemRan [ 20 ] = & rtAlwaysEnabled ; systemRan [ 21 ] = &
rtAlwaysEnabled ; systemRan [ 22 ] = & rtAlwaysEnabled ; systemRan [ 23 ] = &
rtAlwaysEnabled ; systemRan [ 24 ] = & rtAlwaysEnabled ; systemRan [ 25 ] = &
rtAlwaysEnabled ; systemRan [ 26 ] = & rtAlwaysEnabled ; systemRan [ 27 ] = &
rtAlwaysEnabled ; systemRan [ 28 ] = & rtAlwaysEnabled ; systemRan [ 29 ] = &
rtAlwaysEnabled ; systemRan [ 30 ] = & rtAlwaysEnabled ; systemRan [ 31 ] = &
rtAlwaysEnabled ; systemRan [ 32 ] = & rtAlwaysEnabled ; systemRan [ 33 ] = &
rtAlwaysEnabled ; systemRan [ 34 ] = & rtAlwaysEnabled ; systemRan [ 35 ] = &
rtAlwaysEnabled ; systemRan [ 36 ] = & rtAlwaysEnabled ; systemRan [ 37 ] = &
rtAlwaysEnabled ; systemRan [ 38 ] = & rtAlwaysEnabled ; systemRan [ 39 ] = &
rtAlwaysEnabled ; systemRan [ 40 ] = & rtAlwaysEnabled ; systemRan [ 41 ] = &
rtAlwaysEnabled ; systemRan [ 42 ] = & rtAlwaysEnabled ; systemRan [ 43 ] = &
rtAlwaysEnabled ; systemRan [ 44 ] = & rtAlwaysEnabled ; systemRan [ 45 ] = &
rtAlwaysEnabled ; systemRan [ 46 ] = & rtAlwaysEnabled ; systemRan [ 47 ] = &
rtAlwaysEnabled ; systemRan [ 48 ] = & rtAlwaysEnabled ; systemRan [ 49 ] = &
rtAlwaysEnabled ; systemRan [ 50 ] = & rtAlwaysEnabled ; systemRan [ 51 ] = &
rtAlwaysEnabled ; systemRan [ 52 ] = & rtAlwaysEnabled ; systemRan [ 53 ] = &
rtAlwaysEnabled ; systemRan [ 54 ] = & rtAlwaysEnabled ; systemRan [ 55 ] = &
rtAlwaysEnabled ; systemRan [ 56 ] = & rtAlwaysEnabled ; systemRan [ 57 ] = &
rtAlwaysEnabled ; systemRan [ 58 ] = & rtAlwaysEnabled ; systemRan [ 59 ] = &
rtAlwaysEnabled ; systemRan [ 60 ] = & rtAlwaysEnabled ; systemRan [ 61 ] = &
rtAlwaysEnabled ; systemRan [ 62 ] = & rtAlwaysEnabled ; systemRan [ 63 ] = &
rtAlwaysEnabled ; systemRan [ 64 ] = & rtAlwaysEnabled ;
rteiSetModelMappingInfoPtr ( ssGetRTWExtModeInfo ( rtS ) , &
ssGetModelMappingInfo ( rtS ) ) ; rteiSetChecksumsPtr ( ssGetRTWExtModeInfo (
rtS ) , ssGetChecksums ( rtS ) ) ; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS )
, ssGetTPtr ( rtS ) ) ; } slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_activeBalancing2_GetSimStateDisallowedBlocks ) ;
slsaGetWorkFcnForSimTargetOP ( rtS , mr_activeBalancing2_GetDWork ) ;
slsaSetWorkFcnForSimTargetOP ( rtS , mr_activeBalancing2_SetDWork ) ; rtP .
inti_LowerSat = rtMinusInf ; rtP . Saturation_LowerSat = rtMinusInf ; rtP .
inti_LowerSat_lz3gh0icex = rtMinusInf ; rtP . Saturation_LowerSat_kwi433xk5g
= rtMinusInf ; rtP . inti_LowerSat_cwekkzbyq1 = rtMinusInf ; rtP .
Saturation_LowerSat_o0i20janpw = rtMinusInf ; rtP . inti_LowerSat_nb1wwuftgl
= rtMinusInf ; rtP . Saturation_LowerSat_g1ovkjgj1x = rtMinusInf ; rtP .
inti_LowerSat_hzpmw3xl5s = rtMinusInf ; rtP . Saturation_LowerSat_haspwmkdbs
= rtMinusInf ; rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if (
ssGetErrorStatus ( rtS ) ) { return rtS ; } ssSetNumSFunctions ( rtS , 1 ) ;
{ static SimStruct childSFunctions [ 1 ] ; static SimStruct *
childSFunctionPtrs [ 1 ] ; ( void ) memset ( ( void * ) & childSFunctions [ 0
] , 0 , sizeof ( childSFunctions ) ) ; ssSetSFunctions ( rtS , &
childSFunctionPtrs [ 0 ] ) ; ssSetSFunction ( rtS , 0 , & childSFunctions [ 0
] ) ; { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; static time_T
sfcnPeriod [ 1 ] ; static time_T sfcnOffset [ 1 ] ; static int_T sfcnTsMap [
1 ] ; ( void ) memset ( ( void * ) sfcnPeriod , 0 , sizeof ( time_T ) * 1 ) ;
( void ) memset ( ( void * ) sfcnOffset , 0 , sizeof ( time_T ) * 1 ) ;
ssSetSampleTimePtr ( rts , & sfcnPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rts ,
& sfcnOffset [ 0 ] ) ; ssSetSampleTimeTaskIDPtr ( rts , sfcnTsMap ) ; {
static struct _ssBlkInfo2 _blkInfo2 ; struct _ssBlkInfo2 * blkInfo2 = &
_blkInfo2 ; ssSetBlkInfo2Ptr ( rts , blkInfo2 ) ; } { static struct
_ssPortInfo2 _portInfo2 ; struct _ssPortInfo2 * portInfo2 = & _portInfo2 ;
_ssSetBlkInfo2PortInfo2Ptr ( rts , portInfo2 ) ; } ssSetMdlInfoPtr ( rts ,
ssGetMdlInfoPtr ( rtS ) ) ; { static struct _ssSFcnModelMethods2 methods2 ;
ssSetModelMethods2 ( rts , & methods2 ) ; } { static struct
_ssSFcnModelMethods3 methods3 ; ssSetModelMethods3 ( rts , & methods3 ) ; } {
static struct _ssSFcnModelMethods4 methods4 ; ssSetModelMethods4 ( rts , &
methods4 ) ; } { static struct _ssStatesInfo2 statesInfo2 ; static
ssPeriodicStatesInfo periodicStatesInfo ; static ssJacobianPerturbationBounds
jacPerturbationBounds ; ssSetStatesInfo2 ( rts , & statesInfo2 ) ;
ssSetPeriodicStatesInfo ( rts , & periodicStatesInfo ) ;
ssSetJacobianPerturbationBounds ( rts , & jacPerturbationBounds ) ;
ssSetAbsTolVector ( rts , ssGetAbsTolVector ( rtS ) + 20 ) ;
ssSetAbsTolControlVector ( rts , ssGetAbsTolControlVector ( rtS ) + 20 ) ; }
{ static struct _ssPortInputs inputPortInfo [ 2 ] ; _ssSetNumInputPorts ( rts
, 2 ) ; ssSetPortInfoForInputs ( rts , & inputPortInfo [ 0 ] ) ; { static
struct _ssInPortUnit inputPortUnits [ 2 ] ; _ssSetPortInfo2ForInputUnits (
rts , & inputPortUnits [ 0 ] ) ; } ssSetInputPortUnit ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 1 , 0 ) ; { static struct _ssInPortCoSimAttribute
inputPortCoSimAttribute [ 2 ] ; _ssSetPortInfo2ForInputCoSimAttribute ( rts ,
& inputPortCoSimAttribute [ 0 ] ) ; } ssSetInputPortIsContinuousQuantity (
rts , 0 , 0 ) ; ssSetInputPortIsContinuousQuantity ( rts , 1 , 0 ) ; { static
real_T const * sfcnUPtrs [ 5 ] ; sfcnUPtrs [ 0 ] = & rtB . luoecyht3u ;
sfcnUPtrs [ 1 ] = & rtB . pfiy5maj4o ; sfcnUPtrs [ 2 ] = & rtB . aq2lacmksf ;
sfcnUPtrs [ 3 ] = & rtB . huhl4ltvhz ; sfcnUPtrs [ 4 ] = & rtB . kht02mkzqz ;
ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidth ( rts , 0
, 5 ) ; } { static real_T const * sfcnUPtrs [ 24 ] ; sfcnUPtrs [ 0 ] = & rtB
. jrbeh4gjon ; sfcnUPtrs [ 1 ] = & rtB . db4zg1qvnr ; sfcnUPtrs [ 2 ] = & rtB
. juwmydw0tr ; sfcnUPtrs [ 3 ] = & rtB . babbdjgwl2 ; sfcnUPtrs [ 4 ] = & rtB
. m0rozdflil ; sfcnUPtrs [ 5 ] = & rtB . h0sbflpvzu ; sfcnUPtrs [ 6 ] = & rtB
. le12ofiyut ; sfcnUPtrs [ 7 ] = & rtB . cddvon4kch ; sfcnUPtrs [ 8 ] = & rtB
. dnh3ifiezd ; sfcnUPtrs [ 9 ] = & rtB . jwyopjqrrt ; sfcnUPtrs [ 10 ] = &
rtB . grdrezphge ; sfcnUPtrs [ 11 ] = & rtB . gvzvt5tv3i ; sfcnUPtrs [ 12 ] =
& rtB . grnwe52eh1 ; sfcnUPtrs [ 13 ] = & rtB . cckn1bvi00 ; sfcnUPtrs [ 14 ]
= & rtB . jsgmo5wnpv ; sfcnUPtrs [ 15 ] = & rtB . nfqfvnlxj5 ; sfcnUPtrs [ 16
] = & rtB . ajs4brrkkk ; sfcnUPtrs [ 17 ] = & rtB . kmzuanhyxk ; sfcnUPtrs [
18 ] = & rtB . epnsbymmm2 ; sfcnUPtrs [ 19 ] = & rtB . jffgurm1tz ; sfcnUPtrs
[ 20 ] = & rtB . ef3o0lqjl4 ; sfcnUPtrs [ 21 ] = & rtB . hpvgxobeuc ;
sfcnUPtrs [ 22 ] = & rtB . e0jfdwewz4 ; sfcnUPtrs [ 23 ] = & rtB . hdoahn5d4v
; ssSetInputPortSignalPtrs ( rts , 1 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] )
; _ssSetInputPortNumDimensions ( rts , 1 , 1 ) ; ssSetInputPortWidth ( rts ,
1 , 24 ) ; } } { static struct _ssPortOutputs outputPortInfo [ 2 ] ;
ssSetPortInfoForOutputs ( rts , & outputPortInfo [ 0 ] ) ;
_ssSetNumOutputPorts ( rts , 2 ) ; { static struct _ssOutPortUnit
outputPortUnits [ 2 ] ; _ssSetPortInfo2ForOutputUnits ( rts , &
outputPortUnits [ 0 ] ) ; } ssSetOutputPortUnit ( rts , 0 , 0 ) ;
ssSetOutputPortUnit ( rts , 1 , 0 ) ; { static struct
_ssOutPortCoSimAttribute outputPortCoSimAttribute [ 2 ] ;
_ssSetPortInfo2ForOutputCoSimAttribute ( rts , & outputPortCoSimAttribute [ 0
] ) ; } ssSetOutputPortIsContinuousQuantity ( rts , 0 , 0 ) ;
ssSetOutputPortIsContinuousQuantity ( rts , 1 , 0 ) ; {
_ssSetOutputPortNumDimensions ( rts , 0 , 1 ) ; ssSetOutputPortWidth ( rts ,
0 , 5 ) ; ssSetOutputPortSignal ( rts , 0 , ( ( real_T * ) rtB . e0hcimvo4b )
) ; } { _ssSetOutputPortNumDimensions ( rts , 1 , 1 ) ; ssSetOutputPortWidth
( rts , 1 , 48 ) ; ssSetOutputPortSignal ( rts , 1 , ( ( real_T * ) rtB .
absenqpioz ) ) ; } } ssSetContStates ( rts , & rtX . odntevo1ki [ 0 ] ) ;
ssSetContStateDisabled ( rts , & ( ( XDis * ) ssGetContStateDisabled ( rtS )
) -> odntevo1ki [ 0 ] ) ; { real_T * minVec = & ( ( CXPtMin * )
ssGetJacobianPerturbationBoundsMinVec ( rtS ) ) -> odntevo1ki [ 0 ] ; real_T
* maxVec = & ( ( CXPtMax * ) ssGetJacobianPerturbationBoundsMaxVec ( rtS ) )
-> odntevo1ki [ 0 ] ; ssSetJacobianPerturbationBoundsMinVec ( rts , minVec )
; ssSetJacobianPerturbationBoundsMaxVec ( rts , maxVec ) ; } ssSetModelName (
rts , "State-Space" ) ; ssSetPath ( rts ,
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) ; if (
ssGetRTModel ( rtS ) == ( NULL ) ) { ssSetParentSS ( rts , rtS ) ;
ssSetRootSS ( rts , ssGetRootSS ( rtS ) ) ; } else { ssSetRTModel ( rts ,
ssGetRTModel ( rtS ) ) ; ssSetParentSS ( rts , ( NULL ) ) ; ssSetRootSS ( rts
, rts ) ; } ssSetVersion ( rts , SIMSTRUCT_VERSION_LEVEL2 ) ; { static
mxArray * sfcnParams [ 10 ] ; ssSetSFcnParamsCount ( rts , 10 ) ;
ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ; ssSetSFcnParam ( rts , 0 ,
( mxArray * ) rtP . StateSpace_P1_Size ) ; ssSetSFcnParam ( rts , 1 , (
mxArray * ) rtP . StateSpace_P2_Size ) ; ssSetSFcnParam ( rts , 2 , ( mxArray
* ) rtP . StateSpace_P3_Size ) ; ssSetSFcnParam ( rts , 3 , ( mxArray * ) rtP
. StateSpace_P4_Size ) ; ssSetSFcnParam ( rts , 4 , ( mxArray * ) rtP .
StateSpace_P5_Size ) ; ssSetSFcnParam ( rts , 5 , ( mxArray * ) rtP .
StateSpace_P6_Size ) ; ssSetSFcnParam ( rts , 6 , ( mxArray * ) rtP .
StateSpace_P7_Size ) ; ssSetSFcnParam ( rts , 7 , ( mxArray * ) rtP .
StateSpace_P8_Size ) ; ssSetSFcnParam ( rts , 8 , ( mxArray * ) rtP .
StateSpace_P9_Size ) ; ssSetSFcnParam ( rts , 9 , ( mxArray * ) rtP .
StateSpace_P10_Size ) ; } ssSetRWork ( rts , ( real_T * ) & rtDW . p3thioyq1j
[ 0 ] ) ; ssSetIWork ( rts , ( int_T * ) & rtDW . pzgimzosty [ 0 ] ) ;
ssSetPWork ( rts , ( void * * ) & rtDW . grbdzf5eku [ 0 ] ) ; { static struct
_ssDWorkRecord dWorkRecord [ 4 ] ; static struct _ssDWorkAuxRecord
dWorkAuxRecord [ 4 ] ; ssSetSFcnDWork ( rts , dWorkRecord ) ;
ssSetSFcnDWorkAux ( rts , dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 4 ) ;
ssSetDWorkWidth ( rts , 0 , 25 ) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER
) ; ssSetDWorkComplexSignal ( rts , 0 , 0 ) ; ssSetDWork ( rts , 0 , & rtDW .
kaytcmiwya [ 0 ] ) ; ssSetDWorkWidth ( rts , 1 , 2 ) ; ssSetDWorkDataType (
rts , 1 , SS_DOUBLE ) ; ssSetDWorkComplexSignal ( rts , 1 , 0 ) ; ssSetDWork
( rts , 1 , & rtDW . p3thioyq1j [ 0 ] ) ; ssSetDWorkWidth ( rts , 2 , 23 ) ;
ssSetDWorkDataType ( rts , 2 , SS_INTEGER ) ; ssSetDWorkComplexSignal ( rts ,
2 , 0 ) ; ssSetDWork ( rts , 2 , & rtDW . pzgimzosty [ 0 ] ) ;
ssSetDWorkWidth ( rts , 3 , 22 ) ; ssSetDWorkDataType ( rts , 3 , SS_POINTER
) ; ssSetDWorkComplexSignal ( rts , 3 , 0 ) ; ssSetDWork ( rts , 3 , & rtDW .
grbdzf5eku [ 0 ] ) ; } ssSetModeVector ( rts , ( int_T * ) & rtDW .
kaytcmiwya [ 0 ] ) ; sfun_spid_contc ( rts ) ; sfcnInitializeSizes ( rts ) ;
sfcnInitializeSampleTimes ( rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ;
ssSetOffsetTime ( rts , 0 , 0.0 ) ; sfcnTsMap [ 0 ] = 0 ;
ssSetNumNonsampledZCs ( rts , 25 ) ; _ssSetInputPortConnected ( rts , 0 , 1 )
; _ssSetInputPortConnected ( rts , 1 , 1 ) ; _ssSetOutputPortConnected ( rts
, 0 , 1 ) ; _ssSetOutputPortConnected ( rts , 1 , 1 ) ;
_ssSetOutputPortBeingMerged ( rts , 0 , 0 ) ; _ssSetOutputPortBeingMerged (
rts , 1 , 0 ) ; ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ;
ssSetInputPortBufferDstPort ( rts , 1 , - 1 ) ; } } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 8 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID8 ( tid ) ; }
