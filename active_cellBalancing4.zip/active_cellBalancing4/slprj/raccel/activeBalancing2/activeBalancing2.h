#ifndef RTW_HEADER_activeBalancing2_h_
#define RTW_HEADER_activeBalancing2_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap_simtarget.h"
#ifndef activeBalancing2_COMMON_INCLUDES_
#define activeBalancing2_COMMON_INCLUDES_
#include <stdlib.h>
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "activeBalancing2_types.h"
#include "multiword_types.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "rt_zcfcn.h"
#include "mwmathutil.h"
#include "rt_defines.h"
#define MODEL_NAME activeBalancing2
#define NSAMPLE_TIMES (9) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (297) 
#define NUM_ZC_EVENTS (5) 
#ifndef NCSTATES
#define NCSTATES (26)   
#elif NCSTATES != 26
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T odhgoorqbc [ 2 ] ; real_T nbuwrhuier [ 101 ] ; }
g4qsegj2g0 ; typedef struct { real_T kjybbipaii ; real_T kddmvh240q ; real_T
o04pwljhiy ; real_T jjv3khbcgz ; real_T mypk2tqufk ; real_T exs5fmp5lc ;
real_T d0ekxmir1r ; real_T cuhexdvcd3 ; real_T ocwszegfxg ; real_T h3wghvdhvb
; real_T mlf4o50fzo ; real_T e5s2aj4bft ; real_T ocazt2vdhl ; real_T
m40orrweos ; real_T jymoxqqazt ; real_T ohbzci5slc ; real_T gly2zbjwjb ;
real_T engb4yawhy ; real_T i5byuauteo ; real_T lkmpaypb2p ; real_T c3jgwjjxsi
; real_T drwy5mjekt ; real_T luoecyht3u ; real_T ilnbwvckzb ; real_T
gytt55q4rf ; real_T jzbhnekpdw ; real_T habvcjn5vp ; real_T ax0agqaio3 ;
real_T expk2fcvrk ; real_T kq4wgxleiz ; real_T ftwzojqrpo ; real_T ehiwj5javn
; real_T a3dofhbrxy ; real_T ma2bkws5c2 ; real_T ebarhnnaj2 ; real_T
ccww5ibchs ; real_T gfojdvphy5 ; real_T ch24s33jrc ; real_T mszxp2nb10 ;
real_T hrkgmangdo ; real_T f3w2xtsvho ; real_T pcyqjx4sd2 ; real_T cxeawbkrpo
; real_T ag14fyi5we ; real_T gdlqjdwsgs ; real_T pfiy5maj4o ; real_T
ihicpd1xdt ; real_T mil2gvjxva ; real_T d1gujx31mw ; real_T pw25npqcl5 ;
real_T ik5rmfzive ; real_T nqrbrzc3qp ; real_T chktlyn3xt ; real_T p55huzvwwq
; real_T ncsmjyn2oi ; real_T lpwkyiqyni ; real_T mudvde1asq ; real_T
n35vhllexk ; real_T m5mcuoxuhb ; real_T dbom2viqze ; real_T euguupc5q0 ;
real_T oa1h22e1nc ; real_T hby04c2n1x ; real_T fqmyfgc0km ; real_T ekirprgoht
; real_T bbekmjhgcu ; real_T grb5xsoeik ; real_T nyjzof0rx3 ; real_T
aq2lacmksf ; real_T pbs4th3eaf ; real_T leccoparpy ; real_T ogcju0kfgh ;
real_T c4wkrk0zxw ; real_T jtgqzbh1iz ; real_T ctwhtsiqht ; real_T fdxkmdm50j
; real_T cgevkfqtmb ; real_T py4io1p2ai ; real_T e2fmskpokg ; real_T
pqnqe2hboi ; real_T lwf12tqfq2 ; real_T ahonmvrnyx ; real_T fvxbq05uoi ;
real_T nk05l4h0y2 ; real_T pm301io1ny ; real_T gey35a0elw ; real_T ac3qvilnfk
; real_T ejxcm2rvyf ; real_T gc2gnhaysc ; real_T btlvzhj54h ; real_T
bxllmuyk2m ; real_T huhl4ltvhz ; real_T ok2bxp4qq0 ; real_T ffmj4w3cmt ;
real_T lqzzl3sci3 ; real_T lwj3vtbuti ; real_T lbo2irmbzd ; real_T lirqj0t5wl
; real_T n1240az2ry ; real_T fomxtscak4 ; real_T eu0tsijyvf ; real_T
pr00fiymmv ; real_T ir1j5szgpu ; real_T kiqwsofa1f ; real_T dg5blmqnoc ;
real_T n2t5rlh5a1 ; real_T kme0uunwwt ; real_T n0aabzszil ; real_T ay2k2e2iso
; real_T c0ny2m5ibm ; real_T kxsazgkodr ; real_T eal3yj23jh ; real_T
a0auqpldt3 ; real_T krcxrj0fwb ; real_T kht02mkzqz ; real_T e0hcimvo4b [ 5 ]
; real_T absenqpioz [ 48 ] ; real_T lm0gtrxle5 ; real_T hn4ssoozf0 ; real_T
ej54wy1bqz ; real_T d2s5el1uur ; real_T clgffaez3j ; real_T ijlr2pyucw ;
real_T lzsrkuhyhd ; real_T pcwr2c4ky1 ; real_T mvut4g1kur ; real_T ci24bcb2ae
; real_T g0dxdurozf ; real_T b2v2matgmh ; real_T mvmrxossef ; real_T
babnbnweud ; real_T mc4wzz2sor ; real_T ndew4yws5j ; real_T pnwi4fjn00 ;
real_T e2rllfvmiw ; real_T nvas3hhzkc ; real_T p00h0g1otp ; real_T mjehla4ytu
; real_T pkqxjtkxkb ; real_T hrmd1scdop ; real_T oummy1cytb ; real_T
heo3elq2ut ; real_T gpvrv2cxlg ; real_T fdbodvkrba ; real_T phw53k4pue ;
real_T ercy54k5it ; real_T ie2kjjwcmg ; real_T m00kcxurwn ; real_T expbt1v2tz
; real_T ekjp04xkv2 ; real_T p0xfzbei1b ; real_T bwtepwli4m ; real_T
oslkgg532a ; real_T efpo04tyla ; real_T hni1tcmitz ; real_T civdr4g0u0 ;
real_T cwzjkwv2ox ; real_T nndxmuz5qy ; real_T kofeg0zb1z ; real_T m3dolrlfxz
; real_T mdtzkyg1bb ; real_T fqdwuj2k1s ; real_T l5tc3gqfzb ; real_T
m113skf5al ; real_T gbknmusepz ; real_T gxyxfqaxjb ; real_T odzmgjgd13 ;
real_T fi2b3dhkb3 ; real_T m40urup0vc ; real_T gbpkktvpuo ; real_T pyxgvfzagh
; real_T k5sv02vyqu ; real_T ne45ydwxry ; real_T gssybcpcse ; real_T
lm2n4ijyor ; real_T oxjq4swpla ; real_T hj3gx0gkev ; real_T oncblw0ccg ;
real_T lmx1f3qcpw ; real_T gvzvt5tv3i ; real_T db4zg1qvnr ; real_T juwmydw0tr
; real_T babbdjgwl2 ; real_T jrbeh4gjon ; real_T m0rozdflil ; real_T
h0sbflpvzu ; real_T le12ofiyut ; real_T cddvon4kch ; real_T dnh3ifiezd ;
real_T jwyopjqrrt ; real_T grdrezphge ; real_T grnwe52eh1 ; real_T cckn1bvi00
; real_T jsgmo5wnpv ; real_T nfqfvnlxj5 ; real_T ajs4brrkkk ; real_T
kmzuanhyxk ; real_T epnsbymmm2 ; real_T jffgurm1tz ; real_T ef3o0lqjl4 ;
real_T hpvgxobeuc ; real_T e0jfdwewz4 ; real_T hdoahn5d4v ; real_T lfs2dofdda
[ 2 ] ; real_T jxwilkiy2q ; real_T klne3bbc2d [ 2 ] ; real_T ibr3y1gjec ;
real_T f1qegg10im [ 2 ] ; real_T jfxa2yvvgk ; real_T a5y3jy0hyc [ 2 ] ;
real_T btdu3f30fd ; real_T pvnl3mgpar [ 2 ] ; real_T bpvwc2wtxs ; real_T
mrmctl4ouh [ 2 ] ; real_T fh1zk0jwdl ; real_T bkczs0rgig ; real_T n4uk00kdia
; real_T gqznk4ohus ; real_T c5ubn1fw3x [ 4 ] ; real_T mkps5lmqxp [ 4 ] ;
real_T ljcv0f20dx [ 4 ] ; real_T odqk34pxv4 [ 4 ] ; real_T h524nvoxyr ;
real_T mqsdawspxk ; real_T otljw5bfqz ; real_T ooxivauy2x [ 4 ] ; real_T
ftuq1tkirb [ 4 ] ; real_T p0apn1tlxl [ 4 ] ; real_T igqicy0x3l [ 4 ] ; real_T
bsptkj545k ; real_T ienzqz0wrj ; real_T nxkj21olit ; real_T eiglycnzan [ 4 ]
; real_T meyjept3hg [ 4 ] ; real_T jhubv1l5zc [ 4 ] ; real_T oypuqwf0gd [ 4 ]
; real_T fzjqlg4y3i ; real_T b133p02glv ; real_T orsju1bbcs ; real_T
mtmk2ehsha [ 4 ] ; real_T ad1xsvu0e2 [ 4 ] ; real_T i4xsfrvnpt [ 4 ] ; real_T
fhqvahxlzh [ 4 ] ; real_T l40n3fusaj ; real_T okwsnxfcwm ; real_T hzuw02gvc4
; real_T hhvpdaqnq4 [ 4 ] ; real_T c4dz3ztpxj [ 4 ] ; real_T h40smwlveg [ 4 ]
; real_T mvyppbw32h [ 4 ] ; boolean_T kmc5f3pvgr ; boolean_T ottjrsvg2b ;
boolean_T gbl1xcr4zw ; boolean_T jz1nhvdeap ; boolean_T gvvtz2d2av ;
boolean_T o4wzll3qjg ; boolean_T jrlz1gdkjb ; boolean_T fzgromwfrh ;
boolean_T n0hhvlmhsx ; boolean_T le2uootisz ; boolean_T n30sif3yf3 ;
boolean_T fanfrrdn0p ; boolean_T hy1qp5kmnb ; boolean_T ixe2myxgue ;
boolean_T db3qyyuroe ; boolean_T hqnpeamwdn ; boolean_T dixauele0b ;
boolean_T ggsuorkr3o ; boolean_T ndpfkqx0ft ; boolean_T jatdb2hgzm ;
boolean_T cvyse4x1ck ; boolean_T m5lqxlhg5k ; boolean_T egc5tqeng4 ;
boolean_T hdec1eqbit ; boolean_T dxpca0qb4k ; boolean_T hd4g4dpfnd ;
boolean_T cj3lmhi2x0 ; boolean_T ewvip3v1vs ; boolean_T aj1fizh15j ;
boolean_T ekz0c33q4s ; boolean_T gkdril5bnk ; boolean_T bklkra2upj ;
boolean_T azrlqv35vl ; boolean_T ldbnroag1b ; boolean_T ovwc5iskjn ;
g4qsegj2g0 o1zcbbtrng ; g4qsegj2g0 dieezpzkpy ; g4qsegj2g0 dc2alimajs ;
g4qsegj2g0 cq21slkg0n ; g4qsegj2g0 g3klpnnfu2 ; g4qsegj2g0 ph0zzilf0u ; } B ;
typedef struct { real_T mx5vjacu5q ; real_T gu33m3cujr ; real_T ihabibaari ;
real_T g45xtcsm1y ; real_T mde444qrus ; real_T egfu4zp5ck ; real_T jjpmmqdhaq
; real_T knijrjnyhh ; real_T curbfhmvfh ; real_T h51d42z1yp ; real_T
evcbaypssu ; real_T fcr2tgbfvo ; real_T glz3hn24br ; real_T peu253ymia ;
real_T b0muitc2hd ; real_T llaf3ewbkp ; real_T axv0fdx2my ; real_T azndzkmkcs
; real_T nthq3z5tt5 ; real_T plxwewmbjw ; real_T ftugzjzi0o ; real_T
gipv354qpb ; real_T j1mmhsj1qj ; real_T k4c4pmfnv2 ; real_T mfqivfq3il ;
real_T pxyvizid1y ; real_T feyc5lmf2r ; real_T ebuw4ix1ne ; uint64_T
jvh5mician ; uint64_T cdm1pyiexh ; uint64_T k0umb4nsxj ; uint64_T a1ahum4gsl
; uint64_T fmvszapqpi ; uint64_T ko5gsxzsuc ; real_T p3thioyq1j [ 2 ] ; void
* grbdzf5eku [ 22 ] ; struct { void * LoggedData [ 5 ] ; } iewdw05cht ;
struct { void * AQHandles ; } dbblrjj2tk ; struct { void * AQHandles ; }
l22qnqwzjn ; struct { void * AQHandles ; } fo3wh2yatx ; struct { void *
AQHandles ; } k2ffp3ntfr ; struct { void * AQHandles ; } nyfzlmf145 ; struct
{ void * AQHandles ; } h04wi2qgv5 ; struct { void * AQHandles ; } jgsevaes2d
; struct { void * AQHandles ; } j2pvryuk2u ; struct { void * AQHandles ; }
hqpvabyibc ; struct { void * LoggedData [ 5 ] ; } nwagpl0vbs ; int_T
g55jrpbizl ; int_T ojsrsvfc4d ; int_T lldjl4eyzi ; int_T gxvtetrs04 ; int_T
frtlsutffh ; int_T pzgimzosty [ 23 ] ; int_T m3sjkfetzr ; int_T jmxabr1urn ;
int_T hrm4dgu33i ; int_T ge34ybq3a0 ; int_T ed3nvtxxjm ; int_T dsor1ukpll ;
int_T cokzwj0i4g ; int_T gnfw0t231h ; int_T lv22brfstt ; int_T as2ykd4ql3 ;
int_T kaytcmiwya [ 25 ] ; int_T dcn3au535t ; int_T jertq5slcs ; int_T
l0t1omik1w ; int_T hdetrxmovp ; int_T d4gcz4s4op ; int_T o0qveok2yn ; int_T
jpp24x3j0b ; int_T dkr0lmfwa5 ; int_T nrpmm2hefl ; int_T audfqsd0mm ; int_T
hwrms4izrt ; int_T gtcdjshroe ; int_T fqhd2sk321 ; int_T kxwxa3byt5 ; int_T
fogzt5jbmz ; int_T oq1utabldx ; boolean_T exu1prz21a ; boolean_T bs0tfwzjp3 ;
boolean_T msxvlyne10 ; boolean_T owram20lcx ; boolean_T ktypzgdlxt ;
boolean_T otvz1o3ztq ; boolean_T pkopjswp3e ; boolean_T e0qedsyqjn ;
boolean_T pkpw1tsasy ; boolean_T mx41mp51rp ; boolean_T jansurp50c ;
boolean_T c4szg1j5wf ; boolean_T izsp05gss2 ; boolean_T b554rpqups ;
boolean_T pbezlulnm5 ; boolean_T oyiznhfz3f ; boolean_T djo5beq3n0 ;
boolean_T gil4ie50ol ; boolean_T aarpnpqgmu ; boolean_T cgfl554d0l ;
boolean_T p51wmaigg2 ; boolean_T geb4p4zdgn ; boolean_T opozmxoahv ;
boolean_T p3ylutwfna ; boolean_T fma5ryxgkz ; boolean_T khxogtuz1l ;
boolean_T d4qmht1xff ; boolean_T hjxqlr4sag ; boolean_T eg3zr5htps ;
boolean_T gazfgp55bt ; boolean_T jkumuiblmb ; boolean_T nt4ghy3024 ;
boolean_T aux30da2zu ; boolean_T aqmi0ximsk ; boolean_T bf132dfs4i ;
boolean_T n22ezzj533 ; boolean_T egy3i3psvd ; boolean_T i5m44h50ql ;
boolean_T axjy40izfe ; boolean_T jq3vvbxrjf ; boolean_T okvjyaztbz ;
boolean_T mez5whsqc3 ; boolean_T pbjw4010b3 ; boolean_T oyet01vjge ;
boolean_T bu03oe0pwq ; boolean_T n1fso1av4u ; boolean_T orvtgsw01i ;
boolean_T i0pn21xe2p ; boolean_T gljdehuiwg ; boolean_T mmoscpngve ;
boolean_T icvovv1jq2 ; boolean_T fwfrplulil ; boolean_T dxjlf0kpmf ;
boolean_T os5dfkhn1w ; boolean_T iw1ylkptc1 ; boolean_T ggmjvv0lb3 ;
boolean_T fbe3y1q2sg ; boolean_T aslrlvkkcc ; boolean_T hekwrhnl5m ;
boolean_T doiwoekzov ; boolean_T jdnmbiwx3f ; boolean_T aphrz0r2os ;
boolean_T offqujpaki ; boolean_T bhhlshfa0t ; boolean_T hxxbbgmykq ;
boolean_T md1zdgbsoe ; boolean_T hlvtogm2ca ; boolean_T ot0jlfqn3i ;
boolean_T awhbfmptso ; boolean_T fdy0jfy1tu ; boolean_T i2lws3rgth ;
boolean_T oasl5bklsg ; boolean_T l0150x51ms ; boolean_T p4r02ywybb ; } DW ;
typedef struct { real_T foozkkgumc ; real_T axoluperv2 ; real_T iftoftjjsf ;
real_T iwofyqttuz ; real_T jsonadfc25 ; real_T bhkc4j1ohz ; real_T m13n11gqh5
; real_T cveknlxk0w ; real_T iqfvbswlqx ; real_T aczscrflwb ; real_T
a20yshtbnb ; real_T m2tz1exxd4 ; real_T n3r5zcmpoi ; real_T bz3dftuo0x ;
real_T e02u4qxaaf ; real_T lkcwi10nsx ; real_T l1c0yrfxl4 ; real_T lgrzwldtuz
; real_T aacuquz0zq ; real_T lnia4pzqrd ; real_T odntevo1ki [ 6 ] ; } X ;
typedef struct { real_T foozkkgumc ; real_T axoluperv2 ; real_T iftoftjjsf ;
real_T iwofyqttuz ; real_T jsonadfc25 ; real_T bhkc4j1ohz ; real_T m13n11gqh5
; real_T cveknlxk0w ; real_T iqfvbswlqx ; real_T aczscrflwb ; real_T
a20yshtbnb ; real_T m2tz1exxd4 ; real_T n3r5zcmpoi ; real_T bz3dftuo0x ;
real_T e02u4qxaaf ; real_T lkcwi10nsx ; real_T l1c0yrfxl4 ; real_T lgrzwldtuz
; real_T aacuquz0zq ; real_T lnia4pzqrd ; real_T odntevo1ki [ 6 ] ; } XDot ;
typedef struct { boolean_T foozkkgumc ; boolean_T axoluperv2 ; boolean_T
iftoftjjsf ; boolean_T iwofyqttuz ; boolean_T jsonadfc25 ; boolean_T
bhkc4j1ohz ; boolean_T m13n11gqh5 ; boolean_T cveknlxk0w ; boolean_T
iqfvbswlqx ; boolean_T aczscrflwb ; boolean_T a20yshtbnb ; boolean_T
m2tz1exxd4 ; boolean_T n3r5zcmpoi ; boolean_T bz3dftuo0x ; boolean_T
e02u4qxaaf ; boolean_T lkcwi10nsx ; boolean_T l1c0yrfxl4 ; boolean_T
lgrzwldtuz ; boolean_T aacuquz0zq ; boolean_T lnia4pzqrd ; boolean_T
odntevo1ki [ 6 ] ; } XDis ; typedef struct { real_T foozkkgumc ; real_T
axoluperv2 ; real_T iftoftjjsf ; real_T iwofyqttuz ; real_T jsonadfc25 ;
real_T bhkc4j1ohz ; real_T m13n11gqh5 ; real_T cveknlxk0w ; real_T iqfvbswlqx
; real_T aczscrflwb ; real_T a20yshtbnb ; real_T m2tz1exxd4 ; real_T
n3r5zcmpoi ; real_T bz3dftuo0x ; real_T e02u4qxaaf ; real_T lkcwi10nsx ;
real_T l1c0yrfxl4 ; real_T lgrzwldtuz ; real_T aacuquz0zq ; real_T lnia4pzqrd
; real_T odntevo1ki [ 6 ] ; } CStateAbsTol ; typedef struct { real_T
foozkkgumc ; real_T axoluperv2 ; real_T iftoftjjsf ; real_T iwofyqttuz ;
real_T jsonadfc25 ; real_T bhkc4j1ohz ; real_T m13n11gqh5 ; real_T cveknlxk0w
; real_T iqfvbswlqx ; real_T aczscrflwb ; real_T a20yshtbnb ; real_T
m2tz1exxd4 ; real_T n3r5zcmpoi ; real_T bz3dftuo0x ; real_T e02u4qxaaf ;
real_T lkcwi10nsx ; real_T l1c0yrfxl4 ; real_T lgrzwldtuz ; real_T aacuquz0zq
; real_T lnia4pzqrd ; real_T odntevo1ki [ 6 ] ; } CXPtMin ; typedef struct {
real_T foozkkgumc ; real_T axoluperv2 ; real_T iftoftjjsf ; real_T iwofyqttuz
; real_T jsonadfc25 ; real_T bhkc4j1ohz ; real_T m13n11gqh5 ; real_T
cveknlxk0w ; real_T iqfvbswlqx ; real_T aczscrflwb ; real_T a20yshtbnb ;
real_T m2tz1exxd4 ; real_T n3r5zcmpoi ; real_T bz3dftuo0x ; real_T e02u4qxaaf
; real_T lkcwi10nsx ; real_T l1c0yrfxl4 ; real_T lgrzwldtuz ; real_T
aacuquz0zq ; real_T lnia4pzqrd ; real_T odntevo1ki [ 6 ] ; } CXPtMax ;
typedef struct { real_T lv1ldnbijf ; real_T mbofajbbh4 ; real_T mxtfujwshi ;
real_T o5nrgmy4nz ; real_T dpdbl2hz4o ; real_T bkmypk1tls ; real_T fb1hqmnssy
; real_T lokiv24w4v ; real_T ki3plwbnao ; real_T fqlrimlatx ; real_T
m0mytkt4p5 ; real_T agiqfpoa25 ; real_T kr1o5ks5dg ; real_T oqqii3frkp ;
real_T mquwzfkrsr ; real_T apedymnbja ; real_T g5aaqhxlym ; real_T hqdiuv1g0m
; real_T efcgqgintq ; real_T pevep1w4d0 ; real_T mab5xkr5sd ; real_T
lt5x5ywv3t ; real_T pybraqgztd ; real_T e1xpqp5l3u ; real_T c4zh0k0bej ;
real_T aozqeb31jh ; real_T labtuntw2t ; real_T mvharsolbx ; real_T jukadkkdms
; real_T lkbvthqtea ; real_T nwhr2t5dlx ; real_T ndwe0wixxl ; real_T
oa4weauol3 ; real_T kzmepttb1m ; real_T kdifkciuuy ; real_T eh5cr0zpfu ;
real_T nsv0ssbqyn ; real_T iyiqllgstj ; real_T ez043ntvvt ; real_T b55vsxgh4h
; real_T m3s1nxr3fn ; real_T ns5spo4pzq ; real_T akwa0mqavd ; real_T
nf0pfx4osx ; real_T ow1nryaayc ; real_T e4t4jcks4u ; real_T clmkc3nlqs ;
real_T gmm22ho0aa ; real_T ls4enu1ia3 ; real_T fajzq5dgay ; real_T o0l3c1xpkx
; real_T ne4mvfzecv ; real_T g0fmbdqnmd ; real_T gluy4g0la2 ; real_T
nyquoq334g ; real_T i401ozk4hx ; real_T dwrykibtsx ; real_T fm5tv2ceml ;
real_T mo3qp40mxa ; real_T nniraww0ei ; real_T igluv5v0xe ; real_T jrqtd32djq
; real_T hyftmg40ml ; real_T epeqai5nl0 ; real_T i1d11fku1s ; real_T
l00pjbeskf ; real_T c4qkchwurf ; real_T f1ch1zsae5 ; real_T pe44n104x3 ;
real_T iygiqxkdmd ; real_T ksddoqclas ; real_T dzwzucqogj ; real_T durrtkxsj3
; real_T bqujeoiiyh ; real_T csh4qv0sky ; real_T cyaaehthyd [ 25 ] ; real_T
o240grp02d ; real_T oqmvo2cu14 ; real_T komcu0xtcs ; real_T b214vo0xpz ;
real_T fuig2kilyn ; real_T o1xlxw0vrj ; real_T ltrxsgne22 ; real_T orm2g5z1gx
; real_T d3hdyujfc4 ; real_T bm4n5kngen ; real_T apymty03ju ; real_T
gstktqd5i3 ; real_T cuewc354vy ; real_T kmhgfqqcl3 ; real_T hfconau3ej ;
real_T nc25b1z01a ; real_T mb04eqwxow ; real_T gx3vhtzm3j ; real_T c1kz5znm0i
; real_T ghxapd0dwh ; real_T onkswacg1y ; real_T nzvmf3uvos ; real_T
ifaulpvrbp ; real_T dq1z1zxhuc ; real_T kend2ejss5 ; real_T jed2c0xquo ; }
ZCV ; typedef struct { ZCSigState oztcuusllf ; ZCSigState omisk5z2rc ;
ZCSigState dwwhqwbiro ; ZCSigState lm2mnmnxo1 ; ZCSigState eqomayvlng ; }
PrevZCX ; typedef struct { rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ;
struct P_ { real_T Battery1_BatType ; real_T Battery2_BatType ; real_T
Battery3_BatType ; real_T Battery4_BatType ; real_T Battery5_BatType ; real_T
PWM_Period ; real_T PWM1_Period ; real_T PWM2_Period ; real_T PWM3_Period ;
real_T PWM4_Period ; real_T PWM5_Period ; real_T OutputSamplePoints_Value [
101 ] ; real_T OutputSamplePoints_Value_bs0he10brt [ 101 ] ; real_T
OutputSamplePoints_Value_mmzz2j1vii [ 101 ] ; real_T
OutputSamplePoints_Value_h5oozv5nnj [ 101 ] ; real_T
OutputSamplePoints_Value_mkqnjleygm [ 101 ] ; real_T
OutputSamplePoints_Value_k42vy4v1xv [ 101 ] ; real_T Constant_Value ; real_T
Constant_Value_efypwvyyax ; real_T Constant_Value_ogegtmkzv0 ; real_T
Constant_Value_pbqzqfbpnm ; real_T Constant_Value_hu3rmuppbn ; real_T
Constant_Value_h5irp45zuu ; real_T Constant_Value_bksqnhysc0 ; real_T
Constant_Value_owtewy0ssm ; real_T Constant_Value_k5pwul1wle ; real_T
Constant_Value_kedzfrfegv ; real_T Constant_Value_opaksbgo21 ; real_T
Constant_Value_pp4lg2cwxs ; real_T Constant_Value_epq2rsx4ba ; real_T
Constant_Value_h45zreb2fb ; real_T Constant_Value_khiqevv1tc ; real_T
itinit1_InitialCondition ; real_T R2_Gain ; real_T Currentfilter_A ; real_T
Currentfilter_C ; real_T itinit_InitialCondition ; real_T inti_UpperSat ;
real_T inti_LowerSat ; real_T Gain_Gain ; real_T R3_Gain ; real_T
Integrator2_IC ; real_T Saturation_UpperSat ; real_T Saturation_LowerSat ;
real_T BAL_A ; real_T BAL_C ; real_T R1_Gain ; real_T
itinit1_InitialCondition_l3j5mkh0dv ; real_T R2_Gain_jrqfqsl4vo ; real_T
Currentfilter_A_hazdhojaym ; real_T Currentfilter_C_ldprzne4qv ; real_T
itinit_InitialCondition_pv4h4vt0ps ; real_T inti_UpperSat_itldayqrxp ; real_T
inti_LowerSat_lz3gh0icex ; real_T Gain_Gain_ozvwrv1fuy ; real_T
R3_Gain_dgx1dntlxw ; real_T Integrator2_IC_finfcihmmt ; real_T
Saturation_UpperSat_lxx4j3fnoa ; real_T Saturation_LowerSat_kwi433xk5g ;
real_T BAL_A_cudqa1u03y ; real_T BAL_C_pnvzkp4ayj ; real_T R1_Gain_k1h1x1zryv
; real_T itinit1_InitialCondition_go30gfvhlp ; real_T R2_Gain_fij43s2whq ;
real_T Currentfilter_A_pyl0ygpghg ; real_T Currentfilter_C_hx4sknoziy ;
real_T itinit_InitialCondition_nf4pvnucgc ; real_T inti_UpperSat_nowwhgaxwk ;
real_T inti_LowerSat_cwekkzbyq1 ; real_T Gain_Gain_jbuudt1ftk ; real_T
R3_Gain_de1tgv0zzw ; real_T Integrator2_IC_kqbwod02j2 ; real_T
Saturation_UpperSat_blj3ug4rzx ; real_T Saturation_LowerSat_o0i20janpw ;
real_T BAL_A_n35zxahhei ; real_T BAL_C_ix2bm3qtha ; real_T R1_Gain_elo0441xsu
; real_T itinit1_InitialCondition_ia2mtm2bdv ; real_T R2_Gain_akgkexbqnd ;
real_T Currentfilter_A_bsszjj1hem ; real_T Currentfilter_C_muylregegy ;
real_T itinit_InitialCondition_atlhsczubb ; real_T inti_UpperSat_itde10ibkj ;
real_T inti_LowerSat_nb1wwuftgl ; real_T Gain_Gain_l5lbde12wy ; real_T
R3_Gain_nk0ujvzftk ; real_T Integrator2_IC_gtek0x1of0 ; real_T
Saturation_UpperSat_c0l2pkijii ; real_T Saturation_LowerSat_g1ovkjgj1x ;
real_T BAL_A_jgidwk4hmh ; real_T BAL_C_hfghx3gysd ; real_T R1_Gain_ay3u4mrv4p
; real_T itinit1_InitialCondition_po45v3mmic ; real_T R2_Gain_axv50jbqfg ;
real_T Currentfilter_A_o3r40a2fs0 ; real_T Currentfilter_C_e5mev0pk52 ;
real_T itinit_InitialCondition_mh2yj0opxq ; real_T inti_UpperSat_ff0nysnmjy ;
real_T inti_LowerSat_hzpmw3xl5s ; real_T Gain_Gain_a4qiy5rws3 ; real_T
R3_Gain_hslbhc5rsq ; real_T Integrator2_IC_iw5ohpmyuz ; real_T
Saturation_UpperSat_dr1jmbb0we ; real_T Saturation_LowerSat_haspwmkdbs ;
real_T BAL_A_oad34lr4nf ; real_T BAL_C_cq3wtorxkj ; real_T R1_Gain_bdgjwewy0w
; real_T StateSpace_P1_Size [ 2 ] ; real_T StateSpace_P1 [ 2660 ] ; real_T
StateSpace_P2_Size [ 2 ] ; real_T StateSpace_P2 [ 4 ] ; real_T
StateSpace_P3_Size [ 2 ] ; real_T StateSpace_P3 [ 6 ] ; real_T
StateSpace_P4_Size [ 2 ] ; real_T StateSpace_P4 [ 2964 ] ; real_T
StateSpace_P5_Size [ 2 ] ; real_T StateSpace_P5 [ 48 ] ; real_T
StateSpace_P6_Size [ 2 ] ; real_T StateSpace_P6 [ 24 ] ; real_T
StateSpace_P7_Size [ 2 ] ; real_T StateSpace_P7 [ 24 ] ; real_T
StateSpace_P8_Size [ 2 ] ; real_T StateSpace_P8 [ 24 ] ; real_T
StateSpace_P9_Size [ 2 ] ; real_T StateSpace_P9 ; real_T StateSpace_P10_Size
[ 2 ] ; real_T StateSpace_P10 ; real_T R4_Gain ; real_T
Saturation_UpperSat_aqwzuangfk ; real_T Saturation_LowerSat_bcd3czsgyq ;
real_T R4_Gain_ckkisgzyfx ; real_T Saturation_UpperSat_i3x3oscagf ; real_T
Saturation_LowerSat_gnz45aadu0 ; real_T R4_Gain_dz5jfuhlfd ; real_T
Saturation_UpperSat_pcz043fnep ; real_T Saturation_LowerSat_b05y2t0vvl ;
real_T R4_Gain_nfptou1h22 ; real_T Saturation_UpperSat_luxvjfmfd3 ; real_T
Saturation_LowerSat_mqcesji40p ; real_T R4_Gain_e51nv5aiyc ; real_T
Saturation_UpperSat_p4wbgcsokm ; real_T Saturation_LowerSat_gdbbvpyvzg ;
real_T donotdeletethisgain_Gain ; real_T R_Gain ; real_T
donotdeletethisgain_Gain_o42imifl5k ; real_T R_Gain_g4gmpqe5wx ; real_T
donotdeletethisgain_Gain_fjipbfzkks ; real_T R_Gain_biqz0al5hr ; real_T
donotdeletethisgain_Gain_ave45anr4u ; real_T R_Gain_bq04dmcpzt ; real_T
donotdeletethisgain_Gain_dywzmacz1o ; real_T R_Gain_cwdppwgit4 ; real_T
Gain4_Gain ; real_T Gain1_Gain ; real_T Gain2_Gain ; real_T
Gain4_Gain_kh00znyazs ; real_T Gain1_Gain_og11bwmhu2 ; real_T
Gain2_Gain_m4x3vq3y1f ; real_T Gain4_Gain_fstjjgzlds ; real_T
Gain1_Gain_anymdqpqln ; real_T Gain2_Gain_jptbha03po ; real_T
Gain4_Gain_n2oajsg4xg ; real_T Gain1_Gain_baecfd2g1g ; real_T
Gain2_Gain_fe3eihrk0b ; real_T Gain4_Gain_j4eqtusam3 ; real_T
Gain1_Gain_dq4vkdpk0h ; real_T Gain2_Gain_of2pa5ka31 ; real_T
Constant_Value_jorngiczgp ; real_T Constant1_Value ; real_T Constant12_Value
; real_T Constant9_Value ; real_T Constant1_Value_ks0gbwvaxk ; real_T
Constant2_Value ; real_T Constant3_Value ; real_T Constant4_Value ; real_T
Constant_Value_fzmb45jy2r ; real_T Constant1_Value_jelmmtr1rj ; real_T
Constant12_Value_df3z3yuypl ; real_T Constant9_Value_bfo0fnc5l1 ; real_T
Constant1_Value_jxqfbvs00y ; real_T Constant2_Value_nbkvr3eqsy ; real_T
Constant3_Value_k030zkojhy ; real_T Constant4_Value_p1xz0cpgth ; real_T
Constant_Value_kiu123temw ; real_T Constant1_Value_jj3f5fu3xp ; real_T
Constant12_Value_ktnzmkcekm ; real_T Constant9_Value_nhyzz1ckmw ; real_T
Constant1_Value_gbfcrdkgqa ; real_T Constant2_Value_gnk2tjoo5o ; real_T
Constant3_Value_hat1prtoip ; real_T Constant4_Value_cmgjzabbd1 ; real_T
Constant_Value_em2zyolrnm ; real_T Constant1_Value_myhrse5szs ; real_T
Constant12_Value_jkrk5dvljw ; real_T Constant9_Value_ffsooduwum ; real_T
Constant1_Value_am3al2n15v ; real_T Constant2_Value_odhbgl2n1s ; real_T
Constant3_Value_mujtf1guv4 ; real_T Constant4_Value_ohbtynzx54 ; real_T
Constant_Value_pfu1thap3i ; real_T Constant1_Value_h1thd4w1zg ; real_T
Constant12_Value_oujd2whfki ; real_T Constant9_Value_bcezbzp4a1 ; real_T
Constant1_Value_ny1xdqiske ; real_T Constant2_Value_ppmjeluned ; real_T
Constant3_Value_kuyjih2run ; real_T Constant4_Value_om2zghpbx3 ; real_T
Constant1_Value_kwlajmttwi ; real_T Constant2_Value_e4jyxae25b ; real_T
Constant3_Value_bkb3mktfvw ; real_T Constant6_Value ; real_T Constant7_Value
; real_T Constant8_Value ; real_T Constant9_Value_crabpzohh2 ; real_T
gate_Value ; real_T gate_Value_ghlgnnffhp ; real_T gate_Value_e2pzllcxv0 ;
real_T gate_Value_odvaswnitz ; real_T gate_Value_hrisjp3q0m ; real_T
gate_Value_gy4tkqzmme ; real_T gate_Value_hu4hogb4lk ; real_T
gate_Value_hob43axlzj ; real_T gate_Value_o02a13bzdb ; real_T
gate_Value_awsbj1udfy ; real_T gate_Value_lcm302k1d0 ; real_T
gate_Value_hzvnhzjbik ; } ; extern const char * RT_MEMORY_ALLOCATION_ERROR ;
extern B rtB ; extern X rtX ; extern DW rtDW ; extern PrevZCX rtPrevZCX ;
extern P rtP ; extern mxArray * mr_activeBalancing2_GetDWork ( ) ; extern
void mr_activeBalancing2_SetDWork ( const mxArray * ssDW ) ; extern mxArray *
mr_activeBalancing2_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * activeBalancing2_GetCAPIStaticMap ( void ) ;
extern SimStruct * const rtS ; extern const int_T gblNumToFiles ; extern
const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ; extern
rtInportTUtable * gblInportTUtables ; extern const char * gblInportFileName ;
extern const int_T gblNumRootInportBlks ; extern const int_T
gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ; extern
const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [ ] ;
extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
