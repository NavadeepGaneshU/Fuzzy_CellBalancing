#ifndef RTW_HEADER_activeBalancing2_capi_h
#define RTW_HEADER_activeBalancing2_capi_h
#include "activeBalancing2.h"
extern void activeBalancing2_InitializeDataMapInfo ( void ) ;
#endif
