#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "activeBalancing2_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#ifndef SS_INT64
#define SS_INT64  21
#endif
#ifndef SS_UINT64
#define SS_UINT64  22
#endif
#else
#include "builtin_typeid_types.h"
#include "activeBalancing2.h"
#include "activeBalancing2_capi.h"
#include "activeBalancing2_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 41 , TARGET_STRING
( "activeBalancing2/Fuzzy Logic  Controller 12_34" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 1 , 45 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 1_2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 2 , 49 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 23_45" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 3 , 53 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 2_3" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 4 , 57 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 3_4" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 5 , 61 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 4_5" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 6 , 0 , TARGET_STRING ( "activeBalancing2/aSOC CellPack"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 7 , 0 , TARGET_STRING (
"activeBalancing2/Add11" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 8
, 0 , TARGET_STRING ( "activeBalancing2/Add4" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 9 , 0 , TARGET_STRING ( "activeBalancing2/Add5" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 10 , 0 , TARGET_STRING (
"activeBalancing2/Add6" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 11
, 0 , TARGET_STRING ( "activeBalancing2/Add7" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 12 , 0 , TARGET_STRING ( "activeBalancing2/Add9" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 13 , 41 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 12_34/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 14 , 43 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 12_34/Evaluate Rule Consequents" )
, TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 15 , 45 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 1_2/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 16 , 47 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 1_2/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 17 , 49 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 23_45/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 18 , 51 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 23_45/Evaluate Rule Consequents" )
, TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 19 , 53 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 2_3/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 20 , 55 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 2_3/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 21 , 57 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 3_4/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 22 , 59 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 3_4/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 23 , 61 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 4_5/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 24 , 63 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 4_5/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 25 , 0 , TARGET_STRING (
"activeBalancing2/PWM/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 26 , 0 , TARGET_STRING (
"activeBalancing2/PWM1/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 27 , 0 , TARGET_STRING (
"activeBalancing2/PWM2/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 28 , 0 , TARGET_STRING (
"activeBalancing2/PWM3/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 29 , 0 , TARGET_STRING (
"activeBalancing2/PWM4/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 30 , 0 , TARGET_STRING (
"activeBalancing2/PWM5/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 31 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 32 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 33 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 34 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 35 , 0 , TARGET_STRING ( "activeBalancing2/Battery1/Model/Fcn6" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 36 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 37 , 0 , TARGET_STRING ( "activeBalancing2/Battery1/Model/Gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 38 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 39 , 0 , TARGET_STRING ( "activeBalancing2/Battery1/Model/R1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 40 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 41 , 0 , TARGET_STRING ( "activeBalancing2/Battery1/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 42 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 43 , 0 , TARGET_STRING ( "activeBalancing2/Battery1/Model/int(i)" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 44 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 45 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 46 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 47 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 48 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 49 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 50 , 0 , TARGET_STRING ( "activeBalancing2/Battery1/Model/Add3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 51 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 52 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 53 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 54 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 55 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 56 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 57 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 58 , 0 , TARGET_STRING ( "activeBalancing2/Battery2/Model/Fcn6" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 59 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 60 , 0 , TARGET_STRING ( "activeBalancing2/Battery2/Model/Gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 61 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 62 , 0 , TARGET_STRING ( "activeBalancing2/Battery2/Model/R1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 63 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 64 , 0 , TARGET_STRING ( "activeBalancing2/Battery2/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 65 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 66 , 0 , TARGET_STRING ( "activeBalancing2/Battery2/Model/int(i)" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 67 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 68 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 69 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 70 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 71 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 72 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 73 , 0 , TARGET_STRING ( "activeBalancing2/Battery2/Model/Add3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 74 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 75 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 76 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 77 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 78 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 79 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 80 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 81 , 0 , TARGET_STRING ( "activeBalancing2/Battery3/Model/Fcn6" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 82 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 83 , 0 , TARGET_STRING ( "activeBalancing2/Battery3/Model/Gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 84 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 85 , 0 , TARGET_STRING ( "activeBalancing2/Battery3/Model/R1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 86 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 87 , 0 , TARGET_STRING ( "activeBalancing2/Battery3/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 88 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 89 , 0 , TARGET_STRING ( "activeBalancing2/Battery3/Model/int(i)" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 90 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 91 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 92 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 93 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 94 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 95 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 96 , 0 , TARGET_STRING ( "activeBalancing2/Battery3/Model/Add3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 97 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 98 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 99 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 100 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 101 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 102 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 103 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 104 , 0 , TARGET_STRING ( "activeBalancing2/Battery4/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 105 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 106 , 0 , TARGET_STRING ( "activeBalancing2/Battery4/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 107 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 108 , 0 , TARGET_STRING ( "activeBalancing2/Battery4/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 109 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 110 , 0 , TARGET_STRING ( "activeBalancing2/Battery4/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 111 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 112 , 0 , TARGET_STRING ( "activeBalancing2/Battery4/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 113 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 114 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 115 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 116 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 117 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 118 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 119 , 0 , TARGET_STRING ( "activeBalancing2/Battery4/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 120 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 121 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 122 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 123 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 124 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 125 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 126 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 127 , 0 , TARGET_STRING ( "activeBalancing2/Battery5/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 128 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 129 , 0 , TARGET_STRING ( "activeBalancing2/Battery5/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 130 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 131 , 0 , TARGET_STRING ( "activeBalancing2/Battery5/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 132 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 133 , 0 , TARGET_STRING ( "activeBalancing2/Battery5/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 134 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 135 , 0 , TARGET_STRING ( "activeBalancing2/Battery5/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 136 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 137 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 138 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 139 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 140 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 141 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 142 , 0 , TARGET_STRING ( "activeBalancing2/Battery5/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 143 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 144 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 145 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 146 , 0 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"" ) , 0 , 0 , 2 , 0 , 0 } , { 147 , 0 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"" ) , 1 , 0 , 3 , 0 , 0 } , { 148 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 149 , 2 , TARGET_STRING (
"activeBalancing2/Battery1/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 150 , 4 , TARGET_STRING (
"activeBalancing2/Battery1/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 151 , 3 , TARGET_STRING (
"activeBalancing2/Battery1/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 152 , 1 , TARGET_STRING (
"activeBalancing2/Battery1/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 153 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 154 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 155 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 156 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 157 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 158 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 159 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 160 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 161 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 162 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 163 , 6 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 164 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 165 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 166 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 167 , 7 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 168 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 169 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 170 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 171 , 8 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 172 , 0 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 173 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 174 , 10 , TARGET_STRING (
"activeBalancing2/Battery2/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 175 , 12 , TARGET_STRING (
"activeBalancing2/Battery2/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 176 , 11 , TARGET_STRING (
"activeBalancing2/Battery2/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 177 , 9 , TARGET_STRING (
"activeBalancing2/Battery2/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 178 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 179 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 180 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 181 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 182 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 183 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 184 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 185 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 186 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 187 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 188 , 14 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 189 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 190 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 191 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 192 , 15 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 193 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 194 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 195 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 196 , 16 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 197 , 0 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 198 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 199 , 18 , TARGET_STRING (
"activeBalancing2/Battery3/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 200 , 20 , TARGET_STRING (
"activeBalancing2/Battery3/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 201 , 19 , TARGET_STRING (
"activeBalancing2/Battery3/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 202 , 17 , TARGET_STRING (
"activeBalancing2/Battery3/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 203 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 204 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 205 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 206 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 207 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 208 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 209 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 210 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 211 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 212 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 213 , 22 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 214 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 215 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 216 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 217 , 23 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 218 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 219 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 220 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 221 , 24 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 222 , 0 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 223 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 224 , 26 , TARGET_STRING (
"activeBalancing2/Battery4/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 225 , 28 , TARGET_STRING (
"activeBalancing2/Battery4/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 226 , 27 , TARGET_STRING (
"activeBalancing2/Battery4/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 227 , 25 , TARGET_STRING (
"activeBalancing2/Battery4/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 228 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 229 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 230 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 231 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 232 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 233 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 234 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 235 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 236 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 237 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 238 , 30 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 239 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 240 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 241 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 242 , 31 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 243 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 244 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 245 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 246 , 32 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 247 , 0 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 248 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 249 , 34 , TARGET_STRING (
"activeBalancing2/Battery5/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 250 , 36 , TARGET_STRING (
"activeBalancing2/Battery5/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 251 , 35 , TARGET_STRING (
"activeBalancing2/Battery5/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 252 , 33 , TARGET_STRING (
"activeBalancing2/Battery5/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 253 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 254 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 255 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 256 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 257 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 258 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 259 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 260 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 261 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 262 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 263 , 38 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 264 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 265 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 266 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 267 , 39 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 268 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 269 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 270 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 271 , 40 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 272 , 0 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 273 , 0 , TARGET_STRING (
"activeBalancing2/M1/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 274 , 0 , TARGET_STRING (
"activeBalancing2/M10/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 275 , 0 , TARGET_STRING (
"activeBalancing2/M10/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 276 , 0 , TARGET_STRING (
"activeBalancing2/M11/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 277 , 0 , TARGET_STRING (
"activeBalancing2/M12/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 278 , 0 , TARGET_STRING (
"activeBalancing2/M12/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 279 , 0 , TARGET_STRING (
"activeBalancing2/M2/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 280 , 0 , TARGET_STRING (
"activeBalancing2/M2/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 281 , 0 , TARGET_STRING (
"activeBalancing2/M3/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 282 , 0 , TARGET_STRING (
"activeBalancing2/M4/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 283 , 0 , TARGET_STRING (
"activeBalancing2/M4/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 284 , 0 , TARGET_STRING (
"activeBalancing2/M5/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 285 , 0 , TARGET_STRING (
"activeBalancing2/M6/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 286 , 0 , TARGET_STRING (
"activeBalancing2/M6/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 287 , 0 , TARGET_STRING (
"activeBalancing2/M7/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 288 , 0 , TARGET_STRING (
"activeBalancing2/M8/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 289 , 0 , TARGET_STRING (
"activeBalancing2/M8/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 290 , 0 , TARGET_STRING (
"activeBalancing2/M9/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static
const rtwCAPI_BlockParameters rtBlockParameters [ ] = { { 291 , TARGET_STRING
( "activeBalancing2/Battery1" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } ,
{ 292 , TARGET_STRING ( "activeBalancing2/Battery2" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 293 , TARGET_STRING (
"activeBalancing2/Battery3" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } , {
294 , TARGET_STRING ( "activeBalancing2/Battery4" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 295 , TARGET_STRING (
"activeBalancing2/Battery5" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } , {
296 , TARGET_STRING ( "activeBalancing2/PWM" ) , TARGET_STRING ( "Period" ) ,
0 , 0 , 0 } , { 297 , TARGET_STRING ( "activeBalancing2/PWM1" ) ,
TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 298 , TARGET_STRING (
"activeBalancing2/PWM2" ) , TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 299
, TARGET_STRING ( "activeBalancing2/PWM3" ) , TARGET_STRING ( "Period" ) , 0
, 0 , 0 } , { 300 , TARGET_STRING ( "activeBalancing2/PWM4" ) , TARGET_STRING
( "Period" ) , 0 , 0 , 0 } , { 301 , TARGET_STRING ( "activeBalancing2/PWM5"
) , TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 302 , TARGET_STRING (
"activeBalancing2/Constant1" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
303 , TARGET_STRING ( "activeBalancing2/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 304 , TARGET_STRING (
"activeBalancing2/Constant3" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
305 , TARGET_STRING ( "activeBalancing2/Constant6" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 306 , TARGET_STRING (
"activeBalancing2/Constant7" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
307 , TARGET_STRING ( "activeBalancing2/Constant8" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 308 , TARGET_STRING (
"activeBalancing2/Constant9" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
309 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 12_34/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 310 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 1_2/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 311 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 23_45/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 312 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 2_3/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 313 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 3_4/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 314 , TARGET_STRING (
"activeBalancing2/Fuzzy Logic  Controller 4_5/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 315 , TARGET_STRING (
"activeBalancing2/Battery1/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 316 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 317 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 318 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 319 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 320 , TARGET_STRING ( "activeBalancing2/Battery1/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 321 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 322 , TARGET_STRING ( "activeBalancing2/Battery1/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 323 , TARGET_STRING (
"activeBalancing2/Battery1/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 324 , TARGET_STRING ( "activeBalancing2/Battery1/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 325 , TARGET_STRING (
"activeBalancing2/Battery1/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 326 , TARGET_STRING ( "activeBalancing2/Battery1/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 327 , TARGET_STRING (
"activeBalancing2/Battery1/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 328 , TARGET_STRING (
"activeBalancing2/Battery1/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 329 , TARGET_STRING (
"activeBalancing2/Battery1/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 330 , TARGET_STRING (
"activeBalancing2/Battery1/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 331 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 332 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 333 , TARGET_STRING (
"activeBalancing2/Battery1/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 334 , TARGET_STRING ( "activeBalancing2/Battery1/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 335 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 336 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 337 , TARGET_STRING (
"activeBalancing2/Battery2/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 338 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 339 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 340 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 341 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 342 , TARGET_STRING ( "activeBalancing2/Battery2/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 343 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 344 , TARGET_STRING ( "activeBalancing2/Battery2/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 345 , TARGET_STRING (
"activeBalancing2/Battery2/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 346 , TARGET_STRING ( "activeBalancing2/Battery2/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 347 , TARGET_STRING (
"activeBalancing2/Battery2/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 348 , TARGET_STRING ( "activeBalancing2/Battery2/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 349 , TARGET_STRING (
"activeBalancing2/Battery2/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 350 , TARGET_STRING (
"activeBalancing2/Battery2/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 351 , TARGET_STRING (
"activeBalancing2/Battery2/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 352 , TARGET_STRING (
"activeBalancing2/Battery2/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 353 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 354 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 355 , TARGET_STRING (
"activeBalancing2/Battery2/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 356 , TARGET_STRING ( "activeBalancing2/Battery2/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 357 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 358 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 359 , TARGET_STRING (
"activeBalancing2/Battery3/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 360 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 361 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 362 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 363 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 364 , TARGET_STRING ( "activeBalancing2/Battery3/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 365 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 366 , TARGET_STRING ( "activeBalancing2/Battery3/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 367 , TARGET_STRING (
"activeBalancing2/Battery3/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 368 , TARGET_STRING ( "activeBalancing2/Battery3/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 369 , TARGET_STRING (
"activeBalancing2/Battery3/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 370 , TARGET_STRING ( "activeBalancing2/Battery3/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 371 , TARGET_STRING (
"activeBalancing2/Battery3/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 372 , TARGET_STRING (
"activeBalancing2/Battery3/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 373 , TARGET_STRING (
"activeBalancing2/Battery3/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 374 , TARGET_STRING (
"activeBalancing2/Battery3/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 375 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 376 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 377 , TARGET_STRING (
"activeBalancing2/Battery3/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 378 , TARGET_STRING ( "activeBalancing2/Battery3/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 379 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 380 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 381 , TARGET_STRING (
"activeBalancing2/Battery4/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 382 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 383 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 384 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 385 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 386 , TARGET_STRING ( "activeBalancing2/Battery4/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 387 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 388 , TARGET_STRING ( "activeBalancing2/Battery4/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 389 , TARGET_STRING (
"activeBalancing2/Battery4/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 390 , TARGET_STRING ( "activeBalancing2/Battery4/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 391 , TARGET_STRING (
"activeBalancing2/Battery4/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 392 , TARGET_STRING ( "activeBalancing2/Battery4/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 393 , TARGET_STRING (
"activeBalancing2/Battery4/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 394 , TARGET_STRING (
"activeBalancing2/Battery4/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 395 , TARGET_STRING (
"activeBalancing2/Battery4/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 396 , TARGET_STRING (
"activeBalancing2/Battery4/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 397 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 398 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 399 , TARGET_STRING (
"activeBalancing2/Battery4/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 400 , TARGET_STRING ( "activeBalancing2/Battery4/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 401 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 402 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 403 , TARGET_STRING (
"activeBalancing2/Battery5/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 404 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 405 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 406 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 407 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 408 , TARGET_STRING ( "activeBalancing2/Battery5/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 409 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 410 , TARGET_STRING ( "activeBalancing2/Battery5/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 411 , TARGET_STRING (
"activeBalancing2/Battery5/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 412 , TARGET_STRING ( "activeBalancing2/Battery5/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 413 , TARGET_STRING (
"activeBalancing2/Battery5/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 414 , TARGET_STRING ( "activeBalancing2/Battery5/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 415 , TARGET_STRING (
"activeBalancing2/Battery5/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 416 , TARGET_STRING (
"activeBalancing2/Battery5/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 417 , TARGET_STRING (
"activeBalancing2/Battery5/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 418 , TARGET_STRING (
"activeBalancing2/Battery5/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 419 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 420 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 421 , TARGET_STRING (
"activeBalancing2/Battery5/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 422 , TARGET_STRING ( "activeBalancing2/Battery5/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 423 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 424 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 425 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P1" ) , 0 , 6 , 0 } , { 426 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P2" ) , 0 , 7 , 0 } , { 427 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P3" ) , 0 , 8 , 0 } , { 428 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P4" ) , 0 , 9 , 0 } , { 429 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P5" ) , 0 , 10 , 0 } , { 430 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P6" ) , 0 , 11 , 0 } , { 431 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P7" ) , 0 , 12 , 0 } , { 432 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P8" ) , 0 , 11 , 0 } , { 433 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P9" ) , 0 , 0 , 0 } , { 434 , TARGET_STRING (
"activeBalancing2/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P10" ) , 0 , 0 , 0 } , { 435 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 436 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 437 , TARGET_STRING (
"activeBalancing2/Battery1/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 438 , TARGET_STRING (
"activeBalancing2/Battery1/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 439 , TARGET_STRING (
"activeBalancing2/Battery1/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 440 , TARGET_STRING (
"activeBalancing2/Battery1/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 441 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 442 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 443 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 444 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 445 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 446 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 447 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 448 , TARGET_STRING (
"activeBalancing2/Battery2/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 449 , TARGET_STRING (
"activeBalancing2/Battery2/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 450 , TARGET_STRING (
"activeBalancing2/Battery2/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 451 , TARGET_STRING (
"activeBalancing2/Battery2/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 452 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 453 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 454 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 455 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 456 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 457 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 458 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 459 , TARGET_STRING (
"activeBalancing2/Battery3/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 460 , TARGET_STRING (
"activeBalancing2/Battery3/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 461 , TARGET_STRING (
"activeBalancing2/Battery3/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 462 , TARGET_STRING (
"activeBalancing2/Battery3/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 463 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 464 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 465 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 466 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 467 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 468 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 469 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 470 , TARGET_STRING (
"activeBalancing2/Battery4/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 471 , TARGET_STRING (
"activeBalancing2/Battery4/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 472 , TARGET_STRING (
"activeBalancing2/Battery4/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 473 , TARGET_STRING (
"activeBalancing2/Battery4/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 474 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 475 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 476 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 477 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 478 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 479 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 480 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 481 , TARGET_STRING (
"activeBalancing2/Battery5/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 482 , TARGET_STRING (
"activeBalancing2/Battery5/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 483 , TARGET_STRING (
"activeBalancing2/Battery5/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 484 , TARGET_STRING (
"activeBalancing2/Battery5/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 485 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 486 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 487 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 488 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 489 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 490 , TARGET_STRING (
"activeBalancing2/M1/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 491 , TARGET_STRING ( "activeBalancing2/M10/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 492 , TARGET_STRING (
"activeBalancing2/M11/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 493 , TARGET_STRING ( "activeBalancing2/M12/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 494 , TARGET_STRING (
"activeBalancing2/M2/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 495 , TARGET_STRING ( "activeBalancing2/M3/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 496 , TARGET_STRING (
"activeBalancing2/M4/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 497 , TARGET_STRING ( "activeBalancing2/M5/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 498 , TARGET_STRING (
"activeBalancing2/M6/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 499 , TARGET_STRING ( "activeBalancing2/M7/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 500 , TARGET_STRING (
"activeBalancing2/M8/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 501 , TARGET_STRING ( "activeBalancing2/M9/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 502 , TARGET_STRING (
"activeBalancing2/Battery1/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 503 , TARGET_STRING (
"activeBalancing2/Battery2/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 504 , TARGET_STRING (
"activeBalancing2/Battery3/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 505 , TARGET_STRING (
"activeBalancing2/Battery4/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 506 , TARGET_STRING (
"activeBalancing2/Battery5/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 } } ; static int_T rt_LoggedStateIdxList [ ] = { - 1 } ; static const
rtwCAPI_Signals rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 , 0 , 0 } } ; static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0 , 0 ,
( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_ModelParameters rtModelParameters [ ] = { { 0 , ( NULL ) , 0 , 0 , 0
} } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . fh1zk0jwdl , & rtB . bpvwc2wtxs ,
& rtB . btdu3f30fd , & rtB . jfxa2yvvgk , & rtB . ibr3y1gjec , & rtB .
jxwilkiy2q , & rtB . pkqxjtkxkb , & rtB . mjehla4ytu , & rtB . lzsrkuhyhd , &
rtB . g0dxdurozf , & rtB . e2rllfvmiw , & rtB . nvas3hhzkc , & rtB .
p00h0g1otp , & rtB . fh1zk0jwdl , & rtB . ph0zzilf0u . nbuwrhuier [ 0 ] , &
rtB . bpvwc2wtxs , & rtB . g3klpnnfu2 . nbuwrhuier [ 0 ] , & rtB . btdu3f30fd
, & rtB . cq21slkg0n . nbuwrhuier [ 0 ] , & rtB . jfxa2yvvgk , & rtB .
dc2alimajs . nbuwrhuier [ 0 ] , & rtB . ibr3y1gjec , & rtB . dieezpzkpy .
nbuwrhuier [ 0 ] , & rtB . jxwilkiy2q , & rtB . o1zcbbtrng . nbuwrhuier [ 0 ]
, & rtB . juwmydw0tr , & rtB . jrbeh4gjon , & rtB . h0sbflpvzu , & rtB .
cddvon4kch , & rtB . jwyopjqrrt , & rtB . gvzvt5tv3i , & rtB . m00kcxurwn , &
rtB . m40orrweos , & rtB . mypk2tqufk , & rtB . mvut4g1kur , & rtB .
e5s2aj4bft , & rtB . o04pwljhiy , & rtB . cuhexdvcd3 , & rtB . hni1tcmitz , &
rtB . drwy5mjekt , & rtB . kddmvh240q , & rtB . mlf4o50fzo , & rtB .
pcwr2c4ky1 , & rtB . d0ekxmir1r , & rtB . exs5fmp5lc , & rtB . kjybbipaii , &
rtB . gbl1xcr4zw , & rtB . ci24bcb2ae , & rtB . expbt1v2tz , & rtB .
i5byuauteo , & rtB . lkmpaypb2p , & rtB . h3wghvdhvb , & rtB . c3jgwjjxsi , &
rtB . jjv3khbcgz , & rtB . hrmd1scdop , & rtB . gfojdvphy5 , & rtB .
ax0agqaio3 , & rtB . hn4ssoozf0 , & rtB . ebarhnnaj2 , & rtB . jzbhnekpdw , &
rtB . ftwzojqrpo , & rtB . mdtzkyg1bb , & rtB . gdlqjdwsgs , & rtB .
gytt55q4rf , & rtB . ma2bkws5c2 , & rtB . lm0gtrxle5 , & rtB . kq4wgxleiz , &
rtB . expk2fcvrk , & rtB . ilnbwvckzb , & rtB . le2uootisz , & rtB .
ej54wy1bqz , & rtB . oummy1cytb , & rtB . pcyqjx4sd2 , & rtB . cxeawbkrpo , &
rtB . a3dofhbrxy , & rtB . ag14fyi5we , & rtB . habvcjn5vp , & rtB .
heo3elq2ut , & rtB . dbom2viqze , & rtB . ik5rmfzive , & rtB . clgffaez3j , &
rtB . n35vhllexk , & rtB . d1gujx31mw , & rtB . p55huzvwwq , & rtB .
odzmgjgd13 , & rtB . nyjzof0rx3 , & rtB . mil2gvjxva , & rtB . mudvde1asq , &
rtB . d2s5el1uur , & rtB . chktlyn3xt , & rtB . nqrbrzc3qp , & rtB .
ihicpd1xdt , & rtB . dixauele0b , & rtB . ijlr2pyucw , & rtB . gpvrv2cxlg , &
rtB . ekirprgoht , & rtB . bbekmjhgcu , & rtB . lpwkyiqyni , & rtB .
grb5xsoeik , & rtB . pw25npqcl5 , & rtB . fdbodvkrba , & rtB . fvxbq05uoi , &
rtB . jtgqzbh1iz , & rtB . mvmrxossef , & rtB . lwf12tqfq2 , & rtB .
ogcju0kfgh , & rtB . cgevkfqtmb , & rtB . ne45ydwxry , & rtB . bxllmuyk2m , &
rtB . leccoparpy , & rtB . pqnqe2hboi , & rtB . b2v2matgmh , & rtB .
fdxkmdm50j , & rtB . ctwhtsiqht , & rtB . pbs4th3eaf , & rtB . hdec1eqbit , &
rtB . babnbnweud , & rtB . phw53k4pue , & rtB . ejxcm2rvyf , & rtB .
gc2gnhaysc , & rtB . e2fmskpokg , & rtB . btlvzhj54h , & rtB . c4wkrk0zxw , &
rtB . ercy54k5it , & rtB . n2t5rlh5a1 , & rtB . lbo2irmbzd , & rtB .
ndew4yws5j , & rtB . kiqwsofa1f , & rtB . lqzzl3sci3 , & rtB . fomxtscak4 , &
rtB . lmx1f3qcpw , & rtB . krcxrj0fwb , & rtB . ffmj4w3cmt , & rtB .
ir1j5szgpu , & rtB . mc4wzz2sor , & rtB . n1240az2ry , & rtB . lirqj0t5wl , &
rtB . ok2bxp4qq0 , & rtB . gkdril5bnk , & rtB . pnwi4fjn00 , & rtB .
ie2kjjwcmg , & rtB . kxsazgkodr , & rtB . eal3yj23jh , & rtB . pr00fiymmv , &
rtB . a0auqpldt3 , & rtB . lwj3vtbuti , & rtB . e0hcimvo4b [ 0 ] , & rtB .
absenqpioz [ 0 ] , & rtB . jymoxqqazt , & rtB . h40smwlveg [ 0 ] , & rtB .
hhvpdaqnq4 [ 0 ] , & rtB . c4dz3ztpxj [ 0 ] , & rtB . mvyppbw32h [ 0 ] , &
rtB . ekjp04xkv2 , & rtB . efpo04tyla , & rtB . p0xfzbei1b , & rtB .
ohbzci5slc , & rtB . engb4yawhy , & rtB . oslkgg532a , & rtB . gly2zbjwjb , &
rtB . bwtepwli4m , & rtB . o4wzll3qjg , & rtB . jrlz1gdkjb , & rtB .
hzuw02gvc4 , & rtB . luoecyht3u , & rtB . kmc5f3pvgr , & rtB . ottjrsvg2b , &
rtB . okwsnxfcwm , & rtB . ocwszegfxg , & rtB . jz1nhvdeap , & rtB .
gvvtz2d2av , & rtB . l40n3fusaj , & rtB . ocazt2vdhl , & rtB . ch24s33jrc , &
rtB . i4xsfrvnpt [ 0 ] , & rtB . mtmk2ehsha [ 0 ] , & rtB . ad1xsvu0e2 [ 0 ]
, & rtB . fhqvahxlzh [ 0 ] , & rtB . civdr4g0u0 , & rtB . m3dolrlfxz , & rtB
. cwzjkwv2ox , & rtB . mszxp2nb10 , & rtB . f3w2xtsvho , & rtB . kofeg0zb1z ,
& rtB . hrkgmangdo , & rtB . nndxmuz5qy , & rtB . hy1qp5kmnb , & rtB .
ixe2myxgue , & rtB . orsju1bbcs , & rtB . pfiy5maj4o , & rtB . fzgromwfrh , &
rtB . n0hhvlmhsx , & rtB . b133p02glv , & rtB . ehiwj5javn , & rtB .
n30sif3yf3 , & rtB . fanfrrdn0p , & rtB . fzjqlg4y3i , & rtB . ccww5ibchs , &
rtB . euguupc5q0 , & rtB . jhubv1l5zc [ 0 ] , & rtB . eiglycnzan [ 0 ] , &
rtB . meyjept3hg [ 0 ] , & rtB . oypuqwf0gd [ 0 ] , & rtB . fqdwuj2k1s , &
rtB . gxyxfqaxjb , & rtB . l5tc3gqfzb , & rtB . oa1h22e1nc , & rtB .
fqmyfgc0km , & rtB . gbknmusepz , & rtB . hby04c2n1x , & rtB . m113skf5al , &
rtB . jatdb2hgzm , & rtB . cvyse4x1ck , & rtB . nxkj21olit , & rtB .
aq2lacmksf , & rtB . db3qyyuroe , & rtB . hqnpeamwdn , & rtB . ienzqz0wrj , &
rtB . ncsmjyn2oi , & rtB . ggsuorkr3o , & rtB . ndpfkqx0ft , & rtB .
bsptkj545k , & rtB . m5mcuoxuhb , & rtB . nk05l4h0y2 , & rtB . p0apn1tlxl [ 0
] , & rtB . ooxivauy2x [ 0 ] , & rtB . ftuq1tkirb [ 0 ] , & rtB . igqicy0x3l
[ 0 ] , & rtB . fi2b3dhkb3 , & rtB . k5sv02vyqu , & rtB . m40urup0vc , & rtB
. pm301io1ny , & rtB . ac3qvilnfk , & rtB . pyxgvfzagh , & rtB . gey35a0elw ,
& rtB . gbpkktvpuo , & rtB . cj3lmhi2x0 , & rtB . ewvip3v1vs , & rtB .
otljw5bfqz , & rtB . huhl4ltvhz , & rtB . m5lqxlhg5k , & rtB . egc5tqeng4 , &
rtB . mqsdawspxk , & rtB . py4io1p2ai , & rtB . dxpca0qb4k , & rtB .
hd4g4dpfnd , & rtB . h524nvoxyr , & rtB . ahonmvrnyx , & rtB . kme0uunwwt , &
rtB . ljcv0f20dx [ 0 ] , & rtB . c5ubn1fw3x [ 0 ] , & rtB . mkps5lmqxp [ 0 ]
, & rtB . odqk34pxv4 [ 0 ] , & rtB . gssybcpcse , & rtB . oncblw0ccg , & rtB
. lm2n4ijyor , & rtB . n0aabzszil , & rtB . c0ny2m5ibm , & rtB . hj3gx0gkev ,
& rtB . ay2k2e2iso , & rtB . oxjq4swpla , & rtB . ldbnroag1b , & rtB .
ovwc5iskjn , & rtB . gqznk4ohus , & rtB . kht02mkzqz , & rtB . aj1fizh15j , &
rtB . ekz0c33q4s , & rtB . n4uk00kdia , & rtB . eu0tsijyvf , & rtB .
bklkra2upj , & rtB . azrlqv35vl , & rtB . bkczs0rgig , & rtB . dg5blmqnoc , &
rtB . grnwe52eh1 , & rtB . cckn1bvi00 , & rtB . db4zg1qvnr , & rtB .
jsgmo5wnpv , & rtB . nfqfvnlxj5 , & rtB . babbdjgwl2 , & rtB . ajs4brrkkk , &
rtB . m0rozdflil , & rtB . kmzuanhyxk , & rtB . epnsbymmm2 , & rtB .
le12ofiyut , & rtB . jffgurm1tz , & rtB . ef3o0lqjl4 , & rtB . dnh3ifiezd , &
rtB . hpvgxobeuc , & rtB . e0jfdwewz4 , & rtB . grdrezphge , & rtB .
hdoahn5d4v , & rtP . Battery1_BatType , & rtP . Battery2_BatType , & rtP .
Battery3_BatType , & rtP . Battery4_BatType , & rtP . Battery5_BatType , &
rtP . PWM_Period , & rtP . PWM1_Period , & rtP . PWM2_Period , & rtP .
PWM3_Period , & rtP . PWM4_Period , & rtP . PWM5_Period , & rtP .
Constant1_Value_kwlajmttwi , & rtP . Constant2_Value_e4jyxae25b , & rtP .
Constant3_Value_bkb3mktfvw , & rtP . Constant6_Value , & rtP .
Constant7_Value , & rtP . Constant8_Value , & rtP .
Constant9_Value_crabpzohh2 , & rtP . OutputSamplePoints_Value [ 0 ] , & rtP .
OutputSamplePoints_Value_bs0he10brt [ 0 ] , & rtP .
OutputSamplePoints_Value_mmzz2j1vii [ 0 ] , & rtP .
OutputSamplePoints_Value_h5oozv5nnj [ 0 ] , & rtP .
OutputSamplePoints_Value_mkqnjleygm [ 0 ] , & rtP .
OutputSamplePoints_Value_k42vy4v1xv [ 0 ] , & rtP .
donotdeletethisgain_Gain_dywzmacz1o , & rtP . Constant_Value_jorngiczgp , &
rtP . Constant1_Value , & rtP . Constant12_Value , & rtP . Constant9_Value ,
& rtP . Gain_Gain , & rtP . Gain2_Gain , & rtP . R_Gain_cwdppwgit4 , & rtP .
R1_Gain , & rtP . R2_Gain , & rtP . R3_Gain , & rtP . R4_Gain_dz5jfuhlfd , &
rtP . inti_UpperSat , & rtP . inti_LowerSat , & rtP . itinit_InitialCondition
, & rtP . itinit1_InitialCondition , & rtP . Saturation_UpperSat_pcz043fnep ,
& rtP . Saturation_LowerSat_b05y2t0vvl , & rtP . BAL_A , & rtP . BAL_C , &
rtP . Currentfilter_A , & rtP . Currentfilter_C , & rtP .
donotdeletethisgain_Gain , & rtP . Constant_Value_fzmb45jy2r , & rtP .
Constant1_Value_jelmmtr1rj , & rtP . Constant12_Value_df3z3yuypl , & rtP .
Constant9_Value_bfo0fnc5l1 , & rtP . Gain_Gain_ozvwrv1fuy , & rtP .
Gain2_Gain_m4x3vq3y1f , & rtP . R_Gain , & rtP . R1_Gain_k1h1x1zryv , & rtP .
R2_Gain_jrqfqsl4vo , & rtP . R3_Gain_dgx1dntlxw , & rtP . R4_Gain , & rtP .
inti_UpperSat_itldayqrxp , & rtP . inti_LowerSat_lz3gh0icex , & rtP .
itinit_InitialCondition_pv4h4vt0ps , & rtP .
itinit1_InitialCondition_l3j5mkh0dv , & rtP . Saturation_UpperSat_aqwzuangfk
, & rtP . Saturation_LowerSat_bcd3czsgyq , & rtP . BAL_A_cudqa1u03y , & rtP .
BAL_C_pnvzkp4ayj , & rtP . Currentfilter_A_hazdhojaym , & rtP .
Currentfilter_C_ldprzne4qv , & rtP . donotdeletethisgain_Gain_o42imifl5k , &
rtP . Constant_Value_kiu123temw , & rtP . Constant1_Value_jj3f5fu3xp , & rtP
. Constant12_Value_ktnzmkcekm , & rtP . Constant9_Value_nhyzz1ckmw , & rtP .
Gain_Gain_jbuudt1ftk , & rtP . Gain2_Gain_jptbha03po , & rtP .
R_Gain_g4gmpqe5wx , & rtP . R1_Gain_elo0441xsu , & rtP . R2_Gain_fij43s2whq ,
& rtP . R3_Gain_de1tgv0zzw , & rtP . R4_Gain_ckkisgzyfx , & rtP .
inti_UpperSat_nowwhgaxwk , & rtP . inti_LowerSat_cwekkzbyq1 , & rtP .
itinit_InitialCondition_nf4pvnucgc , & rtP .
itinit1_InitialCondition_go30gfvhlp , & rtP . Saturation_UpperSat_i3x3oscagf
, & rtP . Saturation_LowerSat_gnz45aadu0 , & rtP . BAL_A_n35zxahhei , & rtP .
BAL_C_ix2bm3qtha , & rtP . Currentfilter_A_pyl0ygpghg , & rtP .
Currentfilter_C_hx4sknoziy , & rtP . donotdeletethisgain_Gain_fjipbfzkks , &
rtP . Constant_Value_em2zyolrnm , & rtP . Constant1_Value_myhrse5szs , & rtP
. Constant12_Value_jkrk5dvljw , & rtP . Constant9_Value_ffsooduwum , & rtP .
Gain_Gain_l5lbde12wy , & rtP . Gain2_Gain_fe3eihrk0b , & rtP .
R_Gain_biqz0al5hr , & rtP . R1_Gain_ay3u4mrv4p , & rtP . R2_Gain_akgkexbqnd ,
& rtP . R3_Gain_nk0ujvzftk , & rtP . R4_Gain_nfptou1h22 , & rtP .
inti_UpperSat_itde10ibkj , & rtP . inti_LowerSat_nb1wwuftgl , & rtP .
itinit_InitialCondition_atlhsczubb , & rtP .
itinit1_InitialCondition_ia2mtm2bdv , & rtP . Saturation_UpperSat_luxvjfmfd3
, & rtP . Saturation_LowerSat_mqcesji40p , & rtP . BAL_A_jgidwk4hmh , & rtP .
BAL_C_hfghx3gysd , & rtP . Currentfilter_A_bsszjj1hem , & rtP .
Currentfilter_C_muylregegy , & rtP . donotdeletethisgain_Gain_ave45anr4u , &
rtP . Constant_Value_pfu1thap3i , & rtP . Constant1_Value_h1thd4w1zg , & rtP
. Constant12_Value_oujd2whfki , & rtP . Constant9_Value_bcezbzp4a1 , & rtP .
Gain_Gain_a4qiy5rws3 , & rtP . Gain2_Gain_of2pa5ka31 , & rtP .
R_Gain_bq04dmcpzt , & rtP . R1_Gain_bdgjwewy0w , & rtP . R2_Gain_axv50jbqfg ,
& rtP . R3_Gain_hslbhc5rsq , & rtP . R4_Gain_e51nv5aiyc , & rtP .
inti_UpperSat_ff0nysnmjy , & rtP . inti_LowerSat_hzpmw3xl5s , & rtP .
itinit_InitialCondition_mh2yj0opxq , & rtP .
itinit1_InitialCondition_po45v3mmic , & rtP . Saturation_UpperSat_p4wbgcsokm
, & rtP . Saturation_LowerSat_gdbbvpyvzg , & rtP . BAL_A_oad34lr4nf , & rtP .
BAL_C_cq3wtorxkj , & rtP . Currentfilter_A_o3r40a2fs0 , & rtP .
Currentfilter_C_e5mev0pk52 , & rtP . StateSpace_P1 [ 0 ] , & rtP .
StateSpace_P2 [ 0 ] , & rtP . StateSpace_P3 [ 0 ] , & rtP . StateSpace_P4 [ 0
] , & rtP . StateSpace_P5 [ 0 ] , & rtP . StateSpace_P6 [ 0 ] , & rtP .
StateSpace_P7 [ 0 ] , & rtP . StateSpace_P8 [ 0 ] , & rtP . StateSpace_P9 , &
rtP . StateSpace_P10 , & rtP . Constant_Value , & rtP .
Constant_Value_efypwvyyax , & rtP . Constant1_Value_ks0gbwvaxk , & rtP .
Constant2_Value , & rtP . Constant3_Value , & rtP . Constant4_Value , & rtP .
Gain1_Gain , & rtP . Gain4_Gain , & rtP . Integrator2_IC , & rtP .
Saturation_UpperSat , & rtP . Saturation_LowerSat , & rtP .
Constant_Value_pbqzqfbpnm , & rtP . Constant_Value_hu3rmuppbn , & rtP .
Constant1_Value_jxqfbvs00y , & rtP . Constant2_Value_nbkvr3eqsy , & rtP .
Constant3_Value_k030zkojhy , & rtP . Constant4_Value_p1xz0cpgth , & rtP .
Gain1_Gain_og11bwmhu2 , & rtP . Gain4_Gain_kh00znyazs , & rtP .
Integrator2_IC_finfcihmmt , & rtP . Saturation_UpperSat_lxx4j3fnoa , & rtP .
Saturation_LowerSat_kwi433xk5g , & rtP . Constant_Value_bksqnhysc0 , & rtP .
Constant_Value_owtewy0ssm , & rtP . Constant1_Value_gbfcrdkgqa , & rtP .
Constant2_Value_gnk2tjoo5o , & rtP . Constant3_Value_hat1prtoip , & rtP .
Constant4_Value_cmgjzabbd1 , & rtP . Gain1_Gain_anymdqpqln , & rtP .
Gain4_Gain_fstjjgzlds , & rtP . Integrator2_IC_kqbwod02j2 , & rtP .
Saturation_UpperSat_blj3ug4rzx , & rtP . Saturation_LowerSat_o0i20janpw , &
rtP . Constant_Value_kedzfrfegv , & rtP . Constant_Value_opaksbgo21 , & rtP .
Constant1_Value_am3al2n15v , & rtP . Constant2_Value_odhbgl2n1s , & rtP .
Constant3_Value_mujtf1guv4 , & rtP . Constant4_Value_ohbtynzx54 , & rtP .
Gain1_Gain_baecfd2g1g , & rtP . Gain4_Gain_n2oajsg4xg , & rtP .
Integrator2_IC_gtek0x1of0 , & rtP . Saturation_UpperSat_c0l2pkijii , & rtP .
Saturation_LowerSat_g1ovkjgj1x , & rtP . Constant_Value_epq2rsx4ba , & rtP .
Constant_Value_h45zreb2fb , & rtP . Constant1_Value_ny1xdqiske , & rtP .
Constant2_Value_ppmjeluned , & rtP . Constant3_Value_kuyjih2run , & rtP .
Constant4_Value_om2zghpbx3 , & rtP . Gain1_Gain_dq4vkdpk0h , & rtP .
Gain4_Gain_j4eqtusam3 , & rtP . Integrator2_IC_iw5ohpmyuz , & rtP .
Saturation_UpperSat_dr1jmbb0we , & rtP . Saturation_LowerSat_haspwmkdbs , &
rtP . gate_Value , & rtP . gate_Value_ghlgnnffhp , & rtP .
gate_Value_e2pzllcxv0 , & rtP . gate_Value_odvaswnitz , & rtP .
gate_Value_hrisjp3q0m , & rtP . gate_Value_gy4tkqzmme , & rtP .
gate_Value_hu4hogb4lk , & rtP . gate_Value_hob43axlzj , & rtP .
gate_Value_o02a13bzdb , & rtP . gate_Value_awsbj1udfy , & rtP .
gate_Value_lcm302k1d0 , & rtP . gate_Value_hzvnhzjbik , & rtP .
Constant_Value_ogegtmkzv0 , & rtP . Constant_Value_h5irp45zuu , & rtP .
Constant_Value_k5pwul1wle , & rtP . Constant_Value_pp4lg2cwxs , & rtP .
Constant_Value_khiqevv1tc , } ; static int32_T * rtVarDimsAddrMap [ ] = { (
NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 , 0 } , {
"unsigned char" , "boolean_T" , 0 , 0 , sizeof ( boolean_T ) , SS_BOOLEAN , 0
, 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 2 , 2 , 0 } , {
rtwCAPI_VECTOR , 4 , 2 , 0 } , { rtwCAPI_VECTOR , 6 , 2 , 0 } , {
rtwCAPI_VECTOR , 8 , 2 , 0 } , { rtwCAPI_VECTOR , 10 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 12 , 2 , 0 } , { rtwCAPI_VECTOR , 14 , 2 , 0 } , {
rtwCAPI_VECTOR , 16 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 18 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 20 , 2 , 0 } , { rtwCAPI_VECTOR , 22 , 2 , 0 } , {
rtwCAPI_VECTOR , 24 , 2 , 0 } } ; static const uint_T rtDimensionArray [ ] =
{ 1 , 1 , 101 , 1 , 5 , 1 , 48 , 1 , 4 , 1 , 1 , 101 , 76 , 35 , 1 , 4 , 6 ,
1 , 76 , 39 , 2 , 24 , 1 , 24 , 24 , 1 } ; static const real_T
rtcapiStoredFloats [ ] = { 0.0 , 1.0 } ; static const rtwCAPI_FixPtMap
rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) , rtwCAPI_FIX_RESERVED , 0 , 0 , 0 }
, } ; static const rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const
void * ) & rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [
0 ] , 0 , 0 } , { ( const void * ) & rtcapiStoredFloats [ 0 ] , ( const void
* ) & rtcapiStoredFloats [ 1 ] , 1 , 0 } , { ( NULL ) , ( NULL ) , 8 , 0 } }
; static rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 291
, rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 216 ,
rtModelParameters , 0 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 2020061266U , 3753598033U , 1176490380U , 1620534263U } , ( NULL ) , 0 ,
0 , rt_LoggedStateIdxList } ; const rtwCAPI_ModelMappingStaticInfo *
activeBalancing2_GetCAPIStaticMap ( void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void activeBalancing2_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion ( (
* rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void activeBalancing2_host_InitializeDataMapInfo (
activeBalancing2_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
