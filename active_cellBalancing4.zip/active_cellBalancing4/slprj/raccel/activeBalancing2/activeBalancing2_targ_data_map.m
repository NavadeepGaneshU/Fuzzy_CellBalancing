  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtP)
    ;%
      section.nData     = 226;
      section.data(226)  = dumData; %prealloc
      
	  ;% rtP.Battery1_BatType
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtP.Battery2_BatType
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtP.Battery3_BatType
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtP.Battery4_BatType
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtP.Battery5_BatType
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtP.PWM_Period
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtP.PWM1_Period
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtP.PWM2_Period
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtP.PWM3_Period
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtP.PWM4_Period
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtP.PWM5_Period
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtP.OutputSamplePoints_Value
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtP.OutputSamplePoints_Value_bs0he10brt
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 112;
	
	  ;% rtP.OutputSamplePoints_Value_mmzz2j1vii
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 213;
	
	  ;% rtP.OutputSamplePoints_Value_h5oozv5nnj
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 314;
	
	  ;% rtP.OutputSamplePoints_Value_mkqnjleygm
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 415;
	
	  ;% rtP.OutputSamplePoints_Value_k42vy4v1xv
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 516;
	
	  ;% rtP.Constant_Value
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 617;
	
	  ;% rtP.Constant_Value_efypwvyyax
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 618;
	
	  ;% rtP.Constant_Value_ogegtmkzv0
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 619;
	
	  ;% rtP.Constant_Value_pbqzqfbpnm
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 620;
	
	  ;% rtP.Constant_Value_hu3rmuppbn
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 621;
	
	  ;% rtP.Constant_Value_h5irp45zuu
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 622;
	
	  ;% rtP.Constant_Value_bksqnhysc0
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 623;
	
	  ;% rtP.Constant_Value_owtewy0ssm
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 624;
	
	  ;% rtP.Constant_Value_k5pwul1wle
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 625;
	
	  ;% rtP.Constant_Value_kedzfrfegv
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 626;
	
	  ;% rtP.Constant_Value_opaksbgo21
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 627;
	
	  ;% rtP.Constant_Value_pp4lg2cwxs
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 628;
	
	  ;% rtP.Constant_Value_epq2rsx4ba
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 629;
	
	  ;% rtP.Constant_Value_h45zreb2fb
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 630;
	
	  ;% rtP.Constant_Value_khiqevv1tc
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 631;
	
	  ;% rtP.itinit1_InitialCondition
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 632;
	
	  ;% rtP.R2_Gain
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 633;
	
	  ;% rtP.Currentfilter_A
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 634;
	
	  ;% rtP.Currentfilter_C
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 635;
	
	  ;% rtP.itinit_InitialCondition
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 636;
	
	  ;% rtP.inti_UpperSat
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 637;
	
	  ;% rtP.inti_LowerSat
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 638;
	
	  ;% rtP.Gain_Gain
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 639;
	
	  ;% rtP.R3_Gain
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 640;
	
	  ;% rtP.Integrator2_IC
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 641;
	
	  ;% rtP.Saturation_UpperSat
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 642;
	
	  ;% rtP.Saturation_LowerSat
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 643;
	
	  ;% rtP.BAL_A
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 644;
	
	  ;% rtP.BAL_C
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 645;
	
	  ;% rtP.R1_Gain
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 646;
	
	  ;% rtP.itinit1_InitialCondition_l3j5mkh0dv
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 647;
	
	  ;% rtP.R2_Gain_jrqfqsl4vo
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 648;
	
	  ;% rtP.Currentfilter_A_hazdhojaym
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 649;
	
	  ;% rtP.Currentfilter_C_ldprzne4qv
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 650;
	
	  ;% rtP.itinit_InitialCondition_pv4h4vt0ps
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 651;
	
	  ;% rtP.inti_UpperSat_itldayqrxp
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 652;
	
	  ;% rtP.inti_LowerSat_lz3gh0icex
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 653;
	
	  ;% rtP.Gain_Gain_ozvwrv1fuy
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 654;
	
	  ;% rtP.R3_Gain_dgx1dntlxw
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 655;
	
	  ;% rtP.Integrator2_IC_finfcihmmt
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 656;
	
	  ;% rtP.Saturation_UpperSat_lxx4j3fnoa
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 657;
	
	  ;% rtP.Saturation_LowerSat_kwi433xk5g
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 658;
	
	  ;% rtP.BAL_A_cudqa1u03y
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 659;
	
	  ;% rtP.BAL_C_pnvzkp4ayj
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 660;
	
	  ;% rtP.R1_Gain_k1h1x1zryv
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 661;
	
	  ;% rtP.itinit1_InitialCondition_go30gfvhlp
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 662;
	
	  ;% rtP.R2_Gain_fij43s2whq
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 663;
	
	  ;% rtP.Currentfilter_A_pyl0ygpghg
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 664;
	
	  ;% rtP.Currentfilter_C_hx4sknoziy
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 665;
	
	  ;% rtP.itinit_InitialCondition_nf4pvnucgc
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 666;
	
	  ;% rtP.inti_UpperSat_nowwhgaxwk
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 667;
	
	  ;% rtP.inti_LowerSat_cwekkzbyq1
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 668;
	
	  ;% rtP.Gain_Gain_jbuudt1ftk
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 669;
	
	  ;% rtP.R3_Gain_de1tgv0zzw
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 670;
	
	  ;% rtP.Integrator2_IC_kqbwod02j2
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 671;
	
	  ;% rtP.Saturation_UpperSat_blj3ug4rzx
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 672;
	
	  ;% rtP.Saturation_LowerSat_o0i20janpw
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 673;
	
	  ;% rtP.BAL_A_n35zxahhei
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 674;
	
	  ;% rtP.BAL_C_ix2bm3qtha
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 675;
	
	  ;% rtP.R1_Gain_elo0441xsu
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 676;
	
	  ;% rtP.itinit1_InitialCondition_ia2mtm2bdv
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 677;
	
	  ;% rtP.R2_Gain_akgkexbqnd
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 678;
	
	  ;% rtP.Currentfilter_A_bsszjj1hem
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 679;
	
	  ;% rtP.Currentfilter_C_muylregegy
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 680;
	
	  ;% rtP.itinit_InitialCondition_atlhsczubb
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 681;
	
	  ;% rtP.inti_UpperSat_itde10ibkj
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 682;
	
	  ;% rtP.inti_LowerSat_nb1wwuftgl
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 683;
	
	  ;% rtP.Gain_Gain_l5lbde12wy
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 684;
	
	  ;% rtP.R3_Gain_nk0ujvzftk
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 685;
	
	  ;% rtP.Integrator2_IC_gtek0x1of0
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 686;
	
	  ;% rtP.Saturation_UpperSat_c0l2pkijii
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 687;
	
	  ;% rtP.Saturation_LowerSat_g1ovkjgj1x
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 688;
	
	  ;% rtP.BAL_A_jgidwk4hmh
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 689;
	
	  ;% rtP.BAL_C_hfghx3gysd
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 690;
	
	  ;% rtP.R1_Gain_ay3u4mrv4p
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 691;
	
	  ;% rtP.itinit1_InitialCondition_po45v3mmic
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 692;
	
	  ;% rtP.R2_Gain_axv50jbqfg
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 693;
	
	  ;% rtP.Currentfilter_A_o3r40a2fs0
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 694;
	
	  ;% rtP.Currentfilter_C_e5mev0pk52
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 695;
	
	  ;% rtP.itinit_InitialCondition_mh2yj0opxq
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 696;
	
	  ;% rtP.inti_UpperSat_ff0nysnmjy
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 697;
	
	  ;% rtP.inti_LowerSat_hzpmw3xl5s
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 698;
	
	  ;% rtP.Gain_Gain_a4qiy5rws3
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 699;
	
	  ;% rtP.R3_Gain_hslbhc5rsq
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 700;
	
	  ;% rtP.Integrator2_IC_iw5ohpmyuz
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 701;
	
	  ;% rtP.Saturation_UpperSat_dr1jmbb0we
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 702;
	
	  ;% rtP.Saturation_LowerSat_haspwmkdbs
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 703;
	
	  ;% rtP.BAL_A_oad34lr4nf
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 704;
	
	  ;% rtP.BAL_C_cq3wtorxkj
	  section.data(106).logicalSrcIdx = 105;
	  section.data(106).dtTransOffset = 705;
	
	  ;% rtP.R1_Gain_bdgjwewy0w
	  section.data(107).logicalSrcIdx = 106;
	  section.data(107).dtTransOffset = 706;
	
	  ;% rtP.StateSpace_P1_Size
	  section.data(108).logicalSrcIdx = 107;
	  section.data(108).dtTransOffset = 707;
	
	  ;% rtP.StateSpace_P1
	  section.data(109).logicalSrcIdx = 108;
	  section.data(109).dtTransOffset = 709;
	
	  ;% rtP.StateSpace_P2_Size
	  section.data(110).logicalSrcIdx = 109;
	  section.data(110).dtTransOffset = 3369;
	
	  ;% rtP.StateSpace_P2
	  section.data(111).logicalSrcIdx = 110;
	  section.data(111).dtTransOffset = 3371;
	
	  ;% rtP.StateSpace_P3_Size
	  section.data(112).logicalSrcIdx = 111;
	  section.data(112).dtTransOffset = 3375;
	
	  ;% rtP.StateSpace_P3
	  section.data(113).logicalSrcIdx = 112;
	  section.data(113).dtTransOffset = 3377;
	
	  ;% rtP.StateSpace_P4_Size
	  section.data(114).logicalSrcIdx = 113;
	  section.data(114).dtTransOffset = 3383;
	
	  ;% rtP.StateSpace_P4
	  section.data(115).logicalSrcIdx = 114;
	  section.data(115).dtTransOffset = 3385;
	
	  ;% rtP.StateSpace_P5_Size
	  section.data(116).logicalSrcIdx = 115;
	  section.data(116).dtTransOffset = 6349;
	
	  ;% rtP.StateSpace_P5
	  section.data(117).logicalSrcIdx = 116;
	  section.data(117).dtTransOffset = 6351;
	
	  ;% rtP.StateSpace_P6_Size
	  section.data(118).logicalSrcIdx = 117;
	  section.data(118).dtTransOffset = 6399;
	
	  ;% rtP.StateSpace_P6
	  section.data(119).logicalSrcIdx = 118;
	  section.data(119).dtTransOffset = 6401;
	
	  ;% rtP.StateSpace_P7_Size
	  section.data(120).logicalSrcIdx = 119;
	  section.data(120).dtTransOffset = 6425;
	
	  ;% rtP.StateSpace_P7
	  section.data(121).logicalSrcIdx = 120;
	  section.data(121).dtTransOffset = 6427;
	
	  ;% rtP.StateSpace_P8_Size
	  section.data(122).logicalSrcIdx = 121;
	  section.data(122).dtTransOffset = 6451;
	
	  ;% rtP.StateSpace_P8
	  section.data(123).logicalSrcIdx = 122;
	  section.data(123).dtTransOffset = 6453;
	
	  ;% rtP.StateSpace_P9_Size
	  section.data(124).logicalSrcIdx = 123;
	  section.data(124).dtTransOffset = 6477;
	
	  ;% rtP.StateSpace_P9
	  section.data(125).logicalSrcIdx = 124;
	  section.data(125).dtTransOffset = 6479;
	
	  ;% rtP.StateSpace_P10_Size
	  section.data(126).logicalSrcIdx = 125;
	  section.data(126).dtTransOffset = 6480;
	
	  ;% rtP.StateSpace_P10
	  section.data(127).logicalSrcIdx = 126;
	  section.data(127).dtTransOffset = 6482;
	
	  ;% rtP.R4_Gain
	  section.data(128).logicalSrcIdx = 127;
	  section.data(128).dtTransOffset = 6483;
	
	  ;% rtP.Saturation_UpperSat_aqwzuangfk
	  section.data(129).logicalSrcIdx = 128;
	  section.data(129).dtTransOffset = 6484;
	
	  ;% rtP.Saturation_LowerSat_bcd3czsgyq
	  section.data(130).logicalSrcIdx = 129;
	  section.data(130).dtTransOffset = 6485;
	
	  ;% rtP.R4_Gain_ckkisgzyfx
	  section.data(131).logicalSrcIdx = 130;
	  section.data(131).dtTransOffset = 6486;
	
	  ;% rtP.Saturation_UpperSat_i3x3oscagf
	  section.data(132).logicalSrcIdx = 131;
	  section.data(132).dtTransOffset = 6487;
	
	  ;% rtP.Saturation_LowerSat_gnz45aadu0
	  section.data(133).logicalSrcIdx = 132;
	  section.data(133).dtTransOffset = 6488;
	
	  ;% rtP.R4_Gain_dz5jfuhlfd
	  section.data(134).logicalSrcIdx = 133;
	  section.data(134).dtTransOffset = 6489;
	
	  ;% rtP.Saturation_UpperSat_pcz043fnep
	  section.data(135).logicalSrcIdx = 134;
	  section.data(135).dtTransOffset = 6490;
	
	  ;% rtP.Saturation_LowerSat_b05y2t0vvl
	  section.data(136).logicalSrcIdx = 135;
	  section.data(136).dtTransOffset = 6491;
	
	  ;% rtP.R4_Gain_nfptou1h22
	  section.data(137).logicalSrcIdx = 136;
	  section.data(137).dtTransOffset = 6492;
	
	  ;% rtP.Saturation_UpperSat_luxvjfmfd3
	  section.data(138).logicalSrcIdx = 137;
	  section.data(138).dtTransOffset = 6493;
	
	  ;% rtP.Saturation_LowerSat_mqcesji40p
	  section.data(139).logicalSrcIdx = 138;
	  section.data(139).dtTransOffset = 6494;
	
	  ;% rtP.R4_Gain_e51nv5aiyc
	  section.data(140).logicalSrcIdx = 139;
	  section.data(140).dtTransOffset = 6495;
	
	  ;% rtP.Saturation_UpperSat_p4wbgcsokm
	  section.data(141).logicalSrcIdx = 140;
	  section.data(141).dtTransOffset = 6496;
	
	  ;% rtP.Saturation_LowerSat_gdbbvpyvzg
	  section.data(142).logicalSrcIdx = 141;
	  section.data(142).dtTransOffset = 6497;
	
	  ;% rtP.donotdeletethisgain_Gain
	  section.data(143).logicalSrcIdx = 142;
	  section.data(143).dtTransOffset = 6498;
	
	  ;% rtP.R_Gain
	  section.data(144).logicalSrcIdx = 143;
	  section.data(144).dtTransOffset = 6499;
	
	  ;% rtP.donotdeletethisgain_Gain_o42imifl5k
	  section.data(145).logicalSrcIdx = 144;
	  section.data(145).dtTransOffset = 6500;
	
	  ;% rtP.R_Gain_g4gmpqe5wx
	  section.data(146).logicalSrcIdx = 145;
	  section.data(146).dtTransOffset = 6501;
	
	  ;% rtP.donotdeletethisgain_Gain_fjipbfzkks
	  section.data(147).logicalSrcIdx = 146;
	  section.data(147).dtTransOffset = 6502;
	
	  ;% rtP.R_Gain_biqz0al5hr
	  section.data(148).logicalSrcIdx = 147;
	  section.data(148).dtTransOffset = 6503;
	
	  ;% rtP.donotdeletethisgain_Gain_ave45anr4u
	  section.data(149).logicalSrcIdx = 148;
	  section.data(149).dtTransOffset = 6504;
	
	  ;% rtP.R_Gain_bq04dmcpzt
	  section.data(150).logicalSrcIdx = 149;
	  section.data(150).dtTransOffset = 6505;
	
	  ;% rtP.donotdeletethisgain_Gain_dywzmacz1o
	  section.data(151).logicalSrcIdx = 150;
	  section.data(151).dtTransOffset = 6506;
	
	  ;% rtP.R_Gain_cwdppwgit4
	  section.data(152).logicalSrcIdx = 151;
	  section.data(152).dtTransOffset = 6507;
	
	  ;% rtP.Gain4_Gain
	  section.data(153).logicalSrcIdx = 152;
	  section.data(153).dtTransOffset = 6508;
	
	  ;% rtP.Gain1_Gain
	  section.data(154).logicalSrcIdx = 153;
	  section.data(154).dtTransOffset = 6509;
	
	  ;% rtP.Gain2_Gain
	  section.data(155).logicalSrcIdx = 154;
	  section.data(155).dtTransOffset = 6510;
	
	  ;% rtP.Gain4_Gain_kh00znyazs
	  section.data(156).logicalSrcIdx = 155;
	  section.data(156).dtTransOffset = 6511;
	
	  ;% rtP.Gain1_Gain_og11bwmhu2
	  section.data(157).logicalSrcIdx = 156;
	  section.data(157).dtTransOffset = 6512;
	
	  ;% rtP.Gain2_Gain_m4x3vq3y1f
	  section.data(158).logicalSrcIdx = 157;
	  section.data(158).dtTransOffset = 6513;
	
	  ;% rtP.Gain4_Gain_fstjjgzlds
	  section.data(159).logicalSrcIdx = 158;
	  section.data(159).dtTransOffset = 6514;
	
	  ;% rtP.Gain1_Gain_anymdqpqln
	  section.data(160).logicalSrcIdx = 159;
	  section.data(160).dtTransOffset = 6515;
	
	  ;% rtP.Gain2_Gain_jptbha03po
	  section.data(161).logicalSrcIdx = 160;
	  section.data(161).dtTransOffset = 6516;
	
	  ;% rtP.Gain4_Gain_n2oajsg4xg
	  section.data(162).logicalSrcIdx = 161;
	  section.data(162).dtTransOffset = 6517;
	
	  ;% rtP.Gain1_Gain_baecfd2g1g
	  section.data(163).logicalSrcIdx = 162;
	  section.data(163).dtTransOffset = 6518;
	
	  ;% rtP.Gain2_Gain_fe3eihrk0b
	  section.data(164).logicalSrcIdx = 163;
	  section.data(164).dtTransOffset = 6519;
	
	  ;% rtP.Gain4_Gain_j4eqtusam3
	  section.data(165).logicalSrcIdx = 164;
	  section.data(165).dtTransOffset = 6520;
	
	  ;% rtP.Gain1_Gain_dq4vkdpk0h
	  section.data(166).logicalSrcIdx = 165;
	  section.data(166).dtTransOffset = 6521;
	
	  ;% rtP.Gain2_Gain_of2pa5ka31
	  section.data(167).logicalSrcIdx = 166;
	  section.data(167).dtTransOffset = 6522;
	
	  ;% rtP.Constant_Value_jorngiczgp
	  section.data(168).logicalSrcIdx = 167;
	  section.data(168).dtTransOffset = 6523;
	
	  ;% rtP.Constant1_Value
	  section.data(169).logicalSrcIdx = 168;
	  section.data(169).dtTransOffset = 6524;
	
	  ;% rtP.Constant12_Value
	  section.data(170).logicalSrcIdx = 169;
	  section.data(170).dtTransOffset = 6525;
	
	  ;% rtP.Constant9_Value
	  section.data(171).logicalSrcIdx = 170;
	  section.data(171).dtTransOffset = 6526;
	
	  ;% rtP.Constant1_Value_ks0gbwvaxk
	  section.data(172).logicalSrcIdx = 171;
	  section.data(172).dtTransOffset = 6527;
	
	  ;% rtP.Constant2_Value
	  section.data(173).logicalSrcIdx = 172;
	  section.data(173).dtTransOffset = 6528;
	
	  ;% rtP.Constant3_Value
	  section.data(174).logicalSrcIdx = 173;
	  section.data(174).dtTransOffset = 6529;
	
	  ;% rtP.Constant4_Value
	  section.data(175).logicalSrcIdx = 174;
	  section.data(175).dtTransOffset = 6530;
	
	  ;% rtP.Constant_Value_fzmb45jy2r
	  section.data(176).logicalSrcIdx = 175;
	  section.data(176).dtTransOffset = 6531;
	
	  ;% rtP.Constant1_Value_jelmmtr1rj
	  section.data(177).logicalSrcIdx = 176;
	  section.data(177).dtTransOffset = 6532;
	
	  ;% rtP.Constant12_Value_df3z3yuypl
	  section.data(178).logicalSrcIdx = 177;
	  section.data(178).dtTransOffset = 6533;
	
	  ;% rtP.Constant9_Value_bfo0fnc5l1
	  section.data(179).logicalSrcIdx = 178;
	  section.data(179).dtTransOffset = 6534;
	
	  ;% rtP.Constant1_Value_jxqfbvs00y
	  section.data(180).logicalSrcIdx = 179;
	  section.data(180).dtTransOffset = 6535;
	
	  ;% rtP.Constant2_Value_nbkvr3eqsy
	  section.data(181).logicalSrcIdx = 180;
	  section.data(181).dtTransOffset = 6536;
	
	  ;% rtP.Constant3_Value_k030zkojhy
	  section.data(182).logicalSrcIdx = 181;
	  section.data(182).dtTransOffset = 6537;
	
	  ;% rtP.Constant4_Value_p1xz0cpgth
	  section.data(183).logicalSrcIdx = 182;
	  section.data(183).dtTransOffset = 6538;
	
	  ;% rtP.Constant_Value_kiu123temw
	  section.data(184).logicalSrcIdx = 183;
	  section.data(184).dtTransOffset = 6539;
	
	  ;% rtP.Constant1_Value_jj3f5fu3xp
	  section.data(185).logicalSrcIdx = 184;
	  section.data(185).dtTransOffset = 6540;
	
	  ;% rtP.Constant12_Value_ktnzmkcekm
	  section.data(186).logicalSrcIdx = 185;
	  section.data(186).dtTransOffset = 6541;
	
	  ;% rtP.Constant9_Value_nhyzz1ckmw
	  section.data(187).logicalSrcIdx = 186;
	  section.data(187).dtTransOffset = 6542;
	
	  ;% rtP.Constant1_Value_gbfcrdkgqa
	  section.data(188).logicalSrcIdx = 187;
	  section.data(188).dtTransOffset = 6543;
	
	  ;% rtP.Constant2_Value_gnk2tjoo5o
	  section.data(189).logicalSrcIdx = 188;
	  section.data(189).dtTransOffset = 6544;
	
	  ;% rtP.Constant3_Value_hat1prtoip
	  section.data(190).logicalSrcIdx = 189;
	  section.data(190).dtTransOffset = 6545;
	
	  ;% rtP.Constant4_Value_cmgjzabbd1
	  section.data(191).logicalSrcIdx = 190;
	  section.data(191).dtTransOffset = 6546;
	
	  ;% rtP.Constant_Value_em2zyolrnm
	  section.data(192).logicalSrcIdx = 191;
	  section.data(192).dtTransOffset = 6547;
	
	  ;% rtP.Constant1_Value_myhrse5szs
	  section.data(193).logicalSrcIdx = 192;
	  section.data(193).dtTransOffset = 6548;
	
	  ;% rtP.Constant12_Value_jkrk5dvljw
	  section.data(194).logicalSrcIdx = 193;
	  section.data(194).dtTransOffset = 6549;
	
	  ;% rtP.Constant9_Value_ffsooduwum
	  section.data(195).logicalSrcIdx = 194;
	  section.data(195).dtTransOffset = 6550;
	
	  ;% rtP.Constant1_Value_am3al2n15v
	  section.data(196).logicalSrcIdx = 195;
	  section.data(196).dtTransOffset = 6551;
	
	  ;% rtP.Constant2_Value_odhbgl2n1s
	  section.data(197).logicalSrcIdx = 196;
	  section.data(197).dtTransOffset = 6552;
	
	  ;% rtP.Constant3_Value_mujtf1guv4
	  section.data(198).logicalSrcIdx = 197;
	  section.data(198).dtTransOffset = 6553;
	
	  ;% rtP.Constant4_Value_ohbtynzx54
	  section.data(199).logicalSrcIdx = 198;
	  section.data(199).dtTransOffset = 6554;
	
	  ;% rtP.Constant_Value_pfu1thap3i
	  section.data(200).logicalSrcIdx = 199;
	  section.data(200).dtTransOffset = 6555;
	
	  ;% rtP.Constant1_Value_h1thd4w1zg
	  section.data(201).logicalSrcIdx = 200;
	  section.data(201).dtTransOffset = 6556;
	
	  ;% rtP.Constant12_Value_oujd2whfki
	  section.data(202).logicalSrcIdx = 201;
	  section.data(202).dtTransOffset = 6557;
	
	  ;% rtP.Constant9_Value_bcezbzp4a1
	  section.data(203).logicalSrcIdx = 202;
	  section.data(203).dtTransOffset = 6558;
	
	  ;% rtP.Constant1_Value_ny1xdqiske
	  section.data(204).logicalSrcIdx = 203;
	  section.data(204).dtTransOffset = 6559;
	
	  ;% rtP.Constant2_Value_ppmjeluned
	  section.data(205).logicalSrcIdx = 204;
	  section.data(205).dtTransOffset = 6560;
	
	  ;% rtP.Constant3_Value_kuyjih2run
	  section.data(206).logicalSrcIdx = 205;
	  section.data(206).dtTransOffset = 6561;
	
	  ;% rtP.Constant4_Value_om2zghpbx3
	  section.data(207).logicalSrcIdx = 206;
	  section.data(207).dtTransOffset = 6562;
	
	  ;% rtP.Constant1_Value_kwlajmttwi
	  section.data(208).logicalSrcIdx = 207;
	  section.data(208).dtTransOffset = 6563;
	
	  ;% rtP.Constant2_Value_e4jyxae25b
	  section.data(209).logicalSrcIdx = 208;
	  section.data(209).dtTransOffset = 6564;
	
	  ;% rtP.Constant3_Value_bkb3mktfvw
	  section.data(210).logicalSrcIdx = 209;
	  section.data(210).dtTransOffset = 6565;
	
	  ;% rtP.Constant6_Value
	  section.data(211).logicalSrcIdx = 210;
	  section.data(211).dtTransOffset = 6566;
	
	  ;% rtP.Constant7_Value
	  section.data(212).logicalSrcIdx = 211;
	  section.data(212).dtTransOffset = 6567;
	
	  ;% rtP.Constant8_Value
	  section.data(213).logicalSrcIdx = 212;
	  section.data(213).dtTransOffset = 6568;
	
	  ;% rtP.Constant9_Value_crabpzohh2
	  section.data(214).logicalSrcIdx = 213;
	  section.data(214).dtTransOffset = 6569;
	
	  ;% rtP.gate_Value
	  section.data(215).logicalSrcIdx = 214;
	  section.data(215).dtTransOffset = 6570;
	
	  ;% rtP.gate_Value_ghlgnnffhp
	  section.data(216).logicalSrcIdx = 215;
	  section.data(216).dtTransOffset = 6571;
	
	  ;% rtP.gate_Value_e2pzllcxv0
	  section.data(217).logicalSrcIdx = 216;
	  section.data(217).dtTransOffset = 6572;
	
	  ;% rtP.gate_Value_odvaswnitz
	  section.data(218).logicalSrcIdx = 217;
	  section.data(218).dtTransOffset = 6573;
	
	  ;% rtP.gate_Value_hrisjp3q0m
	  section.data(219).logicalSrcIdx = 218;
	  section.data(219).dtTransOffset = 6574;
	
	  ;% rtP.gate_Value_gy4tkqzmme
	  section.data(220).logicalSrcIdx = 219;
	  section.data(220).dtTransOffset = 6575;
	
	  ;% rtP.gate_Value_hu4hogb4lk
	  section.data(221).logicalSrcIdx = 220;
	  section.data(221).dtTransOffset = 6576;
	
	  ;% rtP.gate_Value_hob43axlzj
	  section.data(222).logicalSrcIdx = 221;
	  section.data(222).dtTransOffset = 6577;
	
	  ;% rtP.gate_Value_o02a13bzdb
	  section.data(223).logicalSrcIdx = 222;
	  section.data(223).dtTransOffset = 6578;
	
	  ;% rtP.gate_Value_awsbj1udfy
	  section.data(224).logicalSrcIdx = 223;
	  section.data(224).dtTransOffset = 6579;
	
	  ;% rtP.gate_Value_lcm302k1d0
	  section.data(225).logicalSrcIdx = 224;
	  section.data(225).dtTransOffset = 6580;
	
	  ;% rtP.gate_Value_hzvnhzjbik
	  section.data(226).logicalSrcIdx = 225;
	  section.data(226).dtTransOffset = 6581;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 8;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtB)
    ;%
      section.nData     = 250;
      section.data(250)  = dumData; %prealloc
      
	  ;% rtB.kjybbipaii
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.kddmvh240q
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.o04pwljhiy
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtB.jjv3khbcgz
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtB.mypk2tqufk
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtB.exs5fmp5lc
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtB.d0ekxmir1r
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtB.cuhexdvcd3
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtB.ocwszegfxg
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtB.h3wghvdhvb
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtB.mlf4o50fzo
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtB.e5s2aj4bft
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtB.ocazt2vdhl
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtB.m40orrweos
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtB.jymoxqqazt
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtB.ohbzci5slc
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtB.gly2zbjwjb
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtB.engb4yawhy
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtB.i5byuauteo
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtB.lkmpaypb2p
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtB.c3jgwjjxsi
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtB.drwy5mjekt
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtB.luoecyht3u
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtB.ilnbwvckzb
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtB.gytt55q4rf
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtB.jzbhnekpdw
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtB.habvcjn5vp
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtB.ax0agqaio3
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtB.expk2fcvrk
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtB.kq4wgxleiz
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtB.ftwzojqrpo
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtB.ehiwj5javn
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtB.a3dofhbrxy
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtB.ma2bkws5c2
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtB.ebarhnnaj2
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 34;
	
	  ;% rtB.ccww5ibchs
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 35;
	
	  ;% rtB.gfojdvphy5
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 36;
	
	  ;% rtB.ch24s33jrc
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 37;
	
	  ;% rtB.mszxp2nb10
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 38;
	
	  ;% rtB.hrkgmangdo
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 39;
	
	  ;% rtB.f3w2xtsvho
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 40;
	
	  ;% rtB.pcyqjx4sd2
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 41;
	
	  ;% rtB.cxeawbkrpo
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 42;
	
	  ;% rtB.ag14fyi5we
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 43;
	
	  ;% rtB.gdlqjdwsgs
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 44;
	
	  ;% rtB.pfiy5maj4o
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 45;
	
	  ;% rtB.ihicpd1xdt
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 46;
	
	  ;% rtB.mil2gvjxva
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 47;
	
	  ;% rtB.d1gujx31mw
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 48;
	
	  ;% rtB.pw25npqcl5
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 49;
	
	  ;% rtB.ik5rmfzive
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 50;
	
	  ;% rtB.nqrbrzc3qp
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 51;
	
	  ;% rtB.chktlyn3xt
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 52;
	
	  ;% rtB.p55huzvwwq
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 53;
	
	  ;% rtB.ncsmjyn2oi
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 54;
	
	  ;% rtB.lpwkyiqyni
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 55;
	
	  ;% rtB.mudvde1asq
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 56;
	
	  ;% rtB.n35vhllexk
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 57;
	
	  ;% rtB.m5mcuoxuhb
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 58;
	
	  ;% rtB.dbom2viqze
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 59;
	
	  ;% rtB.euguupc5q0
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 60;
	
	  ;% rtB.oa1h22e1nc
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 61;
	
	  ;% rtB.hby04c2n1x
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 62;
	
	  ;% rtB.fqmyfgc0km
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 63;
	
	  ;% rtB.ekirprgoht
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 64;
	
	  ;% rtB.bbekmjhgcu
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 65;
	
	  ;% rtB.grb5xsoeik
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 66;
	
	  ;% rtB.nyjzof0rx3
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 67;
	
	  ;% rtB.aq2lacmksf
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 68;
	
	  ;% rtB.pbs4th3eaf
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 69;
	
	  ;% rtB.leccoparpy
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 70;
	
	  ;% rtB.ogcju0kfgh
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 71;
	
	  ;% rtB.c4wkrk0zxw
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 72;
	
	  ;% rtB.jtgqzbh1iz
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 73;
	
	  ;% rtB.ctwhtsiqht
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 74;
	
	  ;% rtB.fdxkmdm50j
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 75;
	
	  ;% rtB.cgevkfqtmb
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 76;
	
	  ;% rtB.py4io1p2ai
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 77;
	
	  ;% rtB.e2fmskpokg
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 78;
	
	  ;% rtB.pqnqe2hboi
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 79;
	
	  ;% rtB.lwf12tqfq2
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 80;
	
	  ;% rtB.ahonmvrnyx
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 81;
	
	  ;% rtB.fvxbq05uoi
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 82;
	
	  ;% rtB.nk05l4h0y2
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 83;
	
	  ;% rtB.pm301io1ny
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 84;
	
	  ;% rtB.gey35a0elw
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 85;
	
	  ;% rtB.ac3qvilnfk
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 86;
	
	  ;% rtB.ejxcm2rvyf
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 87;
	
	  ;% rtB.gc2gnhaysc
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 88;
	
	  ;% rtB.btlvzhj54h
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 89;
	
	  ;% rtB.bxllmuyk2m
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 90;
	
	  ;% rtB.huhl4ltvhz
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 91;
	
	  ;% rtB.ok2bxp4qq0
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 92;
	
	  ;% rtB.ffmj4w3cmt
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 93;
	
	  ;% rtB.lqzzl3sci3
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 94;
	
	  ;% rtB.lwj3vtbuti
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 95;
	
	  ;% rtB.lbo2irmbzd
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 96;
	
	  ;% rtB.lirqj0t5wl
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 97;
	
	  ;% rtB.n1240az2ry
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 98;
	
	  ;% rtB.fomxtscak4
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 99;
	
	  ;% rtB.eu0tsijyvf
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 100;
	
	  ;% rtB.pr00fiymmv
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 101;
	
	  ;% rtB.ir1j5szgpu
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 102;
	
	  ;% rtB.kiqwsofa1f
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 103;
	
	  ;% rtB.dg5blmqnoc
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 104;
	
	  ;% rtB.n2t5rlh5a1
	  section.data(106).logicalSrcIdx = 105;
	  section.data(106).dtTransOffset = 105;
	
	  ;% rtB.kme0uunwwt
	  section.data(107).logicalSrcIdx = 106;
	  section.data(107).dtTransOffset = 106;
	
	  ;% rtB.n0aabzszil
	  section.data(108).logicalSrcIdx = 107;
	  section.data(108).dtTransOffset = 107;
	
	  ;% rtB.ay2k2e2iso
	  section.data(109).logicalSrcIdx = 108;
	  section.data(109).dtTransOffset = 108;
	
	  ;% rtB.c0ny2m5ibm
	  section.data(110).logicalSrcIdx = 109;
	  section.data(110).dtTransOffset = 109;
	
	  ;% rtB.kxsazgkodr
	  section.data(111).logicalSrcIdx = 110;
	  section.data(111).dtTransOffset = 110;
	
	  ;% rtB.eal3yj23jh
	  section.data(112).logicalSrcIdx = 111;
	  section.data(112).dtTransOffset = 111;
	
	  ;% rtB.a0auqpldt3
	  section.data(113).logicalSrcIdx = 112;
	  section.data(113).dtTransOffset = 112;
	
	  ;% rtB.krcxrj0fwb
	  section.data(114).logicalSrcIdx = 113;
	  section.data(114).dtTransOffset = 113;
	
	  ;% rtB.kht02mkzqz
	  section.data(115).logicalSrcIdx = 114;
	  section.data(115).dtTransOffset = 114;
	
	  ;% rtB.e0hcimvo4b
	  section.data(116).logicalSrcIdx = 115;
	  section.data(116).dtTransOffset = 115;
	
	  ;% rtB.absenqpioz
	  section.data(117).logicalSrcIdx = 116;
	  section.data(117).dtTransOffset = 120;
	
	  ;% rtB.lm0gtrxle5
	  section.data(118).logicalSrcIdx = 117;
	  section.data(118).dtTransOffset = 168;
	
	  ;% rtB.hn4ssoozf0
	  section.data(119).logicalSrcIdx = 118;
	  section.data(119).dtTransOffset = 169;
	
	  ;% rtB.ej54wy1bqz
	  section.data(120).logicalSrcIdx = 119;
	  section.data(120).dtTransOffset = 170;
	
	  ;% rtB.d2s5el1uur
	  section.data(121).logicalSrcIdx = 120;
	  section.data(121).dtTransOffset = 171;
	
	  ;% rtB.clgffaez3j
	  section.data(122).logicalSrcIdx = 121;
	  section.data(122).dtTransOffset = 172;
	
	  ;% rtB.ijlr2pyucw
	  section.data(123).logicalSrcIdx = 122;
	  section.data(123).dtTransOffset = 173;
	
	  ;% rtB.lzsrkuhyhd
	  section.data(124).logicalSrcIdx = 123;
	  section.data(124).dtTransOffset = 174;
	
	  ;% rtB.pcwr2c4ky1
	  section.data(125).logicalSrcIdx = 124;
	  section.data(125).dtTransOffset = 175;
	
	  ;% rtB.mvut4g1kur
	  section.data(126).logicalSrcIdx = 125;
	  section.data(126).dtTransOffset = 176;
	
	  ;% rtB.ci24bcb2ae
	  section.data(127).logicalSrcIdx = 126;
	  section.data(127).dtTransOffset = 177;
	
	  ;% rtB.g0dxdurozf
	  section.data(128).logicalSrcIdx = 127;
	  section.data(128).dtTransOffset = 178;
	
	  ;% rtB.b2v2matgmh
	  section.data(129).logicalSrcIdx = 128;
	  section.data(129).dtTransOffset = 179;
	
	  ;% rtB.mvmrxossef
	  section.data(130).logicalSrcIdx = 129;
	  section.data(130).dtTransOffset = 180;
	
	  ;% rtB.babnbnweud
	  section.data(131).logicalSrcIdx = 130;
	  section.data(131).dtTransOffset = 181;
	
	  ;% rtB.mc4wzz2sor
	  section.data(132).logicalSrcIdx = 131;
	  section.data(132).dtTransOffset = 182;
	
	  ;% rtB.ndew4yws5j
	  section.data(133).logicalSrcIdx = 132;
	  section.data(133).dtTransOffset = 183;
	
	  ;% rtB.pnwi4fjn00
	  section.data(134).logicalSrcIdx = 133;
	  section.data(134).dtTransOffset = 184;
	
	  ;% rtB.e2rllfvmiw
	  section.data(135).logicalSrcIdx = 134;
	  section.data(135).dtTransOffset = 185;
	
	  ;% rtB.nvas3hhzkc
	  section.data(136).logicalSrcIdx = 135;
	  section.data(136).dtTransOffset = 186;
	
	  ;% rtB.p00h0g1otp
	  section.data(137).logicalSrcIdx = 136;
	  section.data(137).dtTransOffset = 187;
	
	  ;% rtB.mjehla4ytu
	  section.data(138).logicalSrcIdx = 137;
	  section.data(138).dtTransOffset = 188;
	
	  ;% rtB.pkqxjtkxkb
	  section.data(139).logicalSrcIdx = 138;
	  section.data(139).dtTransOffset = 189;
	
	  ;% rtB.hrmd1scdop
	  section.data(140).logicalSrcIdx = 139;
	  section.data(140).dtTransOffset = 190;
	
	  ;% rtB.oummy1cytb
	  section.data(141).logicalSrcIdx = 140;
	  section.data(141).dtTransOffset = 191;
	
	  ;% rtB.heo3elq2ut
	  section.data(142).logicalSrcIdx = 141;
	  section.data(142).dtTransOffset = 192;
	
	  ;% rtB.gpvrv2cxlg
	  section.data(143).logicalSrcIdx = 142;
	  section.data(143).dtTransOffset = 193;
	
	  ;% rtB.fdbodvkrba
	  section.data(144).logicalSrcIdx = 143;
	  section.data(144).dtTransOffset = 194;
	
	  ;% rtB.phw53k4pue
	  section.data(145).logicalSrcIdx = 144;
	  section.data(145).dtTransOffset = 195;
	
	  ;% rtB.ercy54k5it
	  section.data(146).logicalSrcIdx = 145;
	  section.data(146).dtTransOffset = 196;
	
	  ;% rtB.ie2kjjwcmg
	  section.data(147).logicalSrcIdx = 146;
	  section.data(147).dtTransOffset = 197;
	
	  ;% rtB.m00kcxurwn
	  section.data(148).logicalSrcIdx = 147;
	  section.data(148).dtTransOffset = 198;
	
	  ;% rtB.expbt1v2tz
	  section.data(149).logicalSrcIdx = 148;
	  section.data(149).dtTransOffset = 199;
	
	  ;% rtB.ekjp04xkv2
	  section.data(150).logicalSrcIdx = 149;
	  section.data(150).dtTransOffset = 200;
	
	  ;% rtB.p0xfzbei1b
	  section.data(151).logicalSrcIdx = 150;
	  section.data(151).dtTransOffset = 201;
	
	  ;% rtB.bwtepwli4m
	  section.data(152).logicalSrcIdx = 151;
	  section.data(152).dtTransOffset = 202;
	
	  ;% rtB.oslkgg532a
	  section.data(153).logicalSrcIdx = 152;
	  section.data(153).dtTransOffset = 203;
	
	  ;% rtB.efpo04tyla
	  section.data(154).logicalSrcIdx = 153;
	  section.data(154).dtTransOffset = 204;
	
	  ;% rtB.hni1tcmitz
	  section.data(155).logicalSrcIdx = 154;
	  section.data(155).dtTransOffset = 205;
	
	  ;% rtB.civdr4g0u0
	  section.data(156).logicalSrcIdx = 155;
	  section.data(156).dtTransOffset = 206;
	
	  ;% rtB.cwzjkwv2ox
	  section.data(157).logicalSrcIdx = 156;
	  section.data(157).dtTransOffset = 207;
	
	  ;% rtB.nndxmuz5qy
	  section.data(158).logicalSrcIdx = 157;
	  section.data(158).dtTransOffset = 208;
	
	  ;% rtB.kofeg0zb1z
	  section.data(159).logicalSrcIdx = 158;
	  section.data(159).dtTransOffset = 209;
	
	  ;% rtB.m3dolrlfxz
	  section.data(160).logicalSrcIdx = 159;
	  section.data(160).dtTransOffset = 210;
	
	  ;% rtB.mdtzkyg1bb
	  section.data(161).logicalSrcIdx = 160;
	  section.data(161).dtTransOffset = 211;
	
	  ;% rtB.fqdwuj2k1s
	  section.data(162).logicalSrcIdx = 161;
	  section.data(162).dtTransOffset = 212;
	
	  ;% rtB.l5tc3gqfzb
	  section.data(163).logicalSrcIdx = 162;
	  section.data(163).dtTransOffset = 213;
	
	  ;% rtB.m113skf5al
	  section.data(164).logicalSrcIdx = 163;
	  section.data(164).dtTransOffset = 214;
	
	  ;% rtB.gbknmusepz
	  section.data(165).logicalSrcIdx = 164;
	  section.data(165).dtTransOffset = 215;
	
	  ;% rtB.gxyxfqaxjb
	  section.data(166).logicalSrcIdx = 165;
	  section.data(166).dtTransOffset = 216;
	
	  ;% rtB.odzmgjgd13
	  section.data(167).logicalSrcIdx = 166;
	  section.data(167).dtTransOffset = 217;
	
	  ;% rtB.fi2b3dhkb3
	  section.data(168).logicalSrcIdx = 167;
	  section.data(168).dtTransOffset = 218;
	
	  ;% rtB.m40urup0vc
	  section.data(169).logicalSrcIdx = 168;
	  section.data(169).dtTransOffset = 219;
	
	  ;% rtB.gbpkktvpuo
	  section.data(170).logicalSrcIdx = 169;
	  section.data(170).dtTransOffset = 220;
	
	  ;% rtB.pyxgvfzagh
	  section.data(171).logicalSrcIdx = 170;
	  section.data(171).dtTransOffset = 221;
	
	  ;% rtB.k5sv02vyqu
	  section.data(172).logicalSrcIdx = 171;
	  section.data(172).dtTransOffset = 222;
	
	  ;% rtB.ne45ydwxry
	  section.data(173).logicalSrcIdx = 172;
	  section.data(173).dtTransOffset = 223;
	
	  ;% rtB.gssybcpcse
	  section.data(174).logicalSrcIdx = 173;
	  section.data(174).dtTransOffset = 224;
	
	  ;% rtB.lm2n4ijyor
	  section.data(175).logicalSrcIdx = 174;
	  section.data(175).dtTransOffset = 225;
	
	  ;% rtB.oxjq4swpla
	  section.data(176).logicalSrcIdx = 175;
	  section.data(176).dtTransOffset = 226;
	
	  ;% rtB.hj3gx0gkev
	  section.data(177).logicalSrcIdx = 176;
	  section.data(177).dtTransOffset = 227;
	
	  ;% rtB.oncblw0ccg
	  section.data(178).logicalSrcIdx = 177;
	  section.data(178).dtTransOffset = 228;
	
	  ;% rtB.lmx1f3qcpw
	  section.data(179).logicalSrcIdx = 178;
	  section.data(179).dtTransOffset = 229;
	
	  ;% rtB.gvzvt5tv3i
	  section.data(180).logicalSrcIdx = 179;
	  section.data(180).dtTransOffset = 230;
	
	  ;% rtB.db4zg1qvnr
	  section.data(181).logicalSrcIdx = 180;
	  section.data(181).dtTransOffset = 231;
	
	  ;% rtB.juwmydw0tr
	  section.data(182).logicalSrcIdx = 181;
	  section.data(182).dtTransOffset = 232;
	
	  ;% rtB.babbdjgwl2
	  section.data(183).logicalSrcIdx = 182;
	  section.data(183).dtTransOffset = 233;
	
	  ;% rtB.jrbeh4gjon
	  section.data(184).logicalSrcIdx = 183;
	  section.data(184).dtTransOffset = 234;
	
	  ;% rtB.m0rozdflil
	  section.data(185).logicalSrcIdx = 184;
	  section.data(185).dtTransOffset = 235;
	
	  ;% rtB.h0sbflpvzu
	  section.data(186).logicalSrcIdx = 185;
	  section.data(186).dtTransOffset = 236;
	
	  ;% rtB.le12ofiyut
	  section.data(187).logicalSrcIdx = 186;
	  section.data(187).dtTransOffset = 237;
	
	  ;% rtB.cddvon4kch
	  section.data(188).logicalSrcIdx = 187;
	  section.data(188).dtTransOffset = 238;
	
	  ;% rtB.dnh3ifiezd
	  section.data(189).logicalSrcIdx = 188;
	  section.data(189).dtTransOffset = 239;
	
	  ;% rtB.jwyopjqrrt
	  section.data(190).logicalSrcIdx = 189;
	  section.data(190).dtTransOffset = 240;
	
	  ;% rtB.grdrezphge
	  section.data(191).logicalSrcIdx = 190;
	  section.data(191).dtTransOffset = 241;
	
	  ;% rtB.grnwe52eh1
	  section.data(192).logicalSrcIdx = 191;
	  section.data(192).dtTransOffset = 242;
	
	  ;% rtB.cckn1bvi00
	  section.data(193).logicalSrcIdx = 192;
	  section.data(193).dtTransOffset = 243;
	
	  ;% rtB.jsgmo5wnpv
	  section.data(194).logicalSrcIdx = 193;
	  section.data(194).dtTransOffset = 244;
	
	  ;% rtB.nfqfvnlxj5
	  section.data(195).logicalSrcIdx = 194;
	  section.data(195).dtTransOffset = 245;
	
	  ;% rtB.ajs4brrkkk
	  section.data(196).logicalSrcIdx = 195;
	  section.data(196).dtTransOffset = 246;
	
	  ;% rtB.kmzuanhyxk
	  section.data(197).logicalSrcIdx = 196;
	  section.data(197).dtTransOffset = 247;
	
	  ;% rtB.epnsbymmm2
	  section.data(198).logicalSrcIdx = 197;
	  section.data(198).dtTransOffset = 248;
	
	  ;% rtB.jffgurm1tz
	  section.data(199).logicalSrcIdx = 198;
	  section.data(199).dtTransOffset = 249;
	
	  ;% rtB.ef3o0lqjl4
	  section.data(200).logicalSrcIdx = 199;
	  section.data(200).dtTransOffset = 250;
	
	  ;% rtB.hpvgxobeuc
	  section.data(201).logicalSrcIdx = 200;
	  section.data(201).dtTransOffset = 251;
	
	  ;% rtB.e0jfdwewz4
	  section.data(202).logicalSrcIdx = 201;
	  section.data(202).dtTransOffset = 252;
	
	  ;% rtB.hdoahn5d4v
	  section.data(203).logicalSrcIdx = 202;
	  section.data(203).dtTransOffset = 253;
	
	  ;% rtB.lfs2dofdda
	  section.data(204).logicalSrcIdx = 203;
	  section.data(204).dtTransOffset = 254;
	
	  ;% rtB.jxwilkiy2q
	  section.data(205).logicalSrcIdx = 204;
	  section.data(205).dtTransOffset = 256;
	
	  ;% rtB.klne3bbc2d
	  section.data(206).logicalSrcIdx = 205;
	  section.data(206).dtTransOffset = 257;
	
	  ;% rtB.ibr3y1gjec
	  section.data(207).logicalSrcIdx = 206;
	  section.data(207).dtTransOffset = 259;
	
	  ;% rtB.f1qegg10im
	  section.data(208).logicalSrcIdx = 207;
	  section.data(208).dtTransOffset = 260;
	
	  ;% rtB.jfxa2yvvgk
	  section.data(209).logicalSrcIdx = 208;
	  section.data(209).dtTransOffset = 262;
	
	  ;% rtB.a5y3jy0hyc
	  section.data(210).logicalSrcIdx = 209;
	  section.data(210).dtTransOffset = 263;
	
	  ;% rtB.btdu3f30fd
	  section.data(211).logicalSrcIdx = 210;
	  section.data(211).dtTransOffset = 265;
	
	  ;% rtB.pvnl3mgpar
	  section.data(212).logicalSrcIdx = 211;
	  section.data(212).dtTransOffset = 266;
	
	  ;% rtB.bpvwc2wtxs
	  section.data(213).logicalSrcIdx = 212;
	  section.data(213).dtTransOffset = 268;
	
	  ;% rtB.mrmctl4ouh
	  section.data(214).logicalSrcIdx = 213;
	  section.data(214).dtTransOffset = 269;
	
	  ;% rtB.fh1zk0jwdl
	  section.data(215).logicalSrcIdx = 214;
	  section.data(215).dtTransOffset = 271;
	
	  ;% rtB.bkczs0rgig
	  section.data(216).logicalSrcIdx = 215;
	  section.data(216).dtTransOffset = 272;
	
	  ;% rtB.n4uk00kdia
	  section.data(217).logicalSrcIdx = 216;
	  section.data(217).dtTransOffset = 273;
	
	  ;% rtB.gqznk4ohus
	  section.data(218).logicalSrcIdx = 217;
	  section.data(218).dtTransOffset = 274;
	
	  ;% rtB.c5ubn1fw3x
	  section.data(219).logicalSrcIdx = 218;
	  section.data(219).dtTransOffset = 275;
	
	  ;% rtB.mkps5lmqxp
	  section.data(220).logicalSrcIdx = 219;
	  section.data(220).dtTransOffset = 279;
	
	  ;% rtB.ljcv0f20dx
	  section.data(221).logicalSrcIdx = 220;
	  section.data(221).dtTransOffset = 283;
	
	  ;% rtB.odqk34pxv4
	  section.data(222).logicalSrcIdx = 221;
	  section.data(222).dtTransOffset = 287;
	
	  ;% rtB.h524nvoxyr
	  section.data(223).logicalSrcIdx = 222;
	  section.data(223).dtTransOffset = 291;
	
	  ;% rtB.mqsdawspxk
	  section.data(224).logicalSrcIdx = 223;
	  section.data(224).dtTransOffset = 292;
	
	  ;% rtB.otljw5bfqz
	  section.data(225).logicalSrcIdx = 224;
	  section.data(225).dtTransOffset = 293;
	
	  ;% rtB.ooxivauy2x
	  section.data(226).logicalSrcIdx = 225;
	  section.data(226).dtTransOffset = 294;
	
	  ;% rtB.ftuq1tkirb
	  section.data(227).logicalSrcIdx = 226;
	  section.data(227).dtTransOffset = 298;
	
	  ;% rtB.p0apn1tlxl
	  section.data(228).logicalSrcIdx = 227;
	  section.data(228).dtTransOffset = 302;
	
	  ;% rtB.igqicy0x3l
	  section.data(229).logicalSrcIdx = 228;
	  section.data(229).dtTransOffset = 306;
	
	  ;% rtB.bsptkj545k
	  section.data(230).logicalSrcIdx = 229;
	  section.data(230).dtTransOffset = 310;
	
	  ;% rtB.ienzqz0wrj
	  section.data(231).logicalSrcIdx = 230;
	  section.data(231).dtTransOffset = 311;
	
	  ;% rtB.nxkj21olit
	  section.data(232).logicalSrcIdx = 231;
	  section.data(232).dtTransOffset = 312;
	
	  ;% rtB.eiglycnzan
	  section.data(233).logicalSrcIdx = 232;
	  section.data(233).dtTransOffset = 313;
	
	  ;% rtB.meyjept3hg
	  section.data(234).logicalSrcIdx = 233;
	  section.data(234).dtTransOffset = 317;
	
	  ;% rtB.jhubv1l5zc
	  section.data(235).logicalSrcIdx = 234;
	  section.data(235).dtTransOffset = 321;
	
	  ;% rtB.oypuqwf0gd
	  section.data(236).logicalSrcIdx = 235;
	  section.data(236).dtTransOffset = 325;
	
	  ;% rtB.fzjqlg4y3i
	  section.data(237).logicalSrcIdx = 236;
	  section.data(237).dtTransOffset = 329;
	
	  ;% rtB.b133p02glv
	  section.data(238).logicalSrcIdx = 237;
	  section.data(238).dtTransOffset = 330;
	
	  ;% rtB.orsju1bbcs
	  section.data(239).logicalSrcIdx = 238;
	  section.data(239).dtTransOffset = 331;
	
	  ;% rtB.mtmk2ehsha
	  section.data(240).logicalSrcIdx = 239;
	  section.data(240).dtTransOffset = 332;
	
	  ;% rtB.ad1xsvu0e2
	  section.data(241).logicalSrcIdx = 240;
	  section.data(241).dtTransOffset = 336;
	
	  ;% rtB.i4xsfrvnpt
	  section.data(242).logicalSrcIdx = 241;
	  section.data(242).dtTransOffset = 340;
	
	  ;% rtB.fhqvahxlzh
	  section.data(243).logicalSrcIdx = 242;
	  section.data(243).dtTransOffset = 344;
	
	  ;% rtB.l40n3fusaj
	  section.data(244).logicalSrcIdx = 243;
	  section.data(244).dtTransOffset = 348;
	
	  ;% rtB.okwsnxfcwm
	  section.data(245).logicalSrcIdx = 244;
	  section.data(245).dtTransOffset = 349;
	
	  ;% rtB.hzuw02gvc4
	  section.data(246).logicalSrcIdx = 245;
	  section.data(246).dtTransOffset = 350;
	
	  ;% rtB.hhvpdaqnq4
	  section.data(247).logicalSrcIdx = 246;
	  section.data(247).dtTransOffset = 351;
	
	  ;% rtB.c4dz3ztpxj
	  section.data(248).logicalSrcIdx = 247;
	  section.data(248).dtTransOffset = 355;
	
	  ;% rtB.h40smwlveg
	  section.data(249).logicalSrcIdx = 248;
	  section.data(249).dtTransOffset = 359;
	
	  ;% rtB.mvyppbw32h
	  section.data(250).logicalSrcIdx = 249;
	  section.data(250).dtTransOffset = 363;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 35;
      section.data(35)  = dumData; %prealloc
      
	  ;% rtB.kmc5f3pvgr
	  section.data(1).logicalSrcIdx = 250;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.ottjrsvg2b
	  section.data(2).logicalSrcIdx = 251;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.gbl1xcr4zw
	  section.data(3).logicalSrcIdx = 252;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtB.jz1nhvdeap
	  section.data(4).logicalSrcIdx = 253;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtB.gvvtz2d2av
	  section.data(5).logicalSrcIdx = 254;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtB.o4wzll3qjg
	  section.data(6).logicalSrcIdx = 255;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtB.jrlz1gdkjb
	  section.data(7).logicalSrcIdx = 256;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtB.fzgromwfrh
	  section.data(8).logicalSrcIdx = 257;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtB.n0hhvlmhsx
	  section.data(9).logicalSrcIdx = 258;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtB.le2uootisz
	  section.data(10).logicalSrcIdx = 259;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtB.n30sif3yf3
	  section.data(11).logicalSrcIdx = 260;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtB.fanfrrdn0p
	  section.data(12).logicalSrcIdx = 261;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtB.hy1qp5kmnb
	  section.data(13).logicalSrcIdx = 262;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtB.ixe2myxgue
	  section.data(14).logicalSrcIdx = 263;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtB.db3qyyuroe
	  section.data(15).logicalSrcIdx = 264;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtB.hqnpeamwdn
	  section.data(16).logicalSrcIdx = 265;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtB.dixauele0b
	  section.data(17).logicalSrcIdx = 266;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtB.ggsuorkr3o
	  section.data(18).logicalSrcIdx = 267;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtB.ndpfkqx0ft
	  section.data(19).logicalSrcIdx = 268;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtB.jatdb2hgzm
	  section.data(20).logicalSrcIdx = 269;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtB.cvyse4x1ck
	  section.data(21).logicalSrcIdx = 270;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtB.m5lqxlhg5k
	  section.data(22).logicalSrcIdx = 271;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtB.egc5tqeng4
	  section.data(23).logicalSrcIdx = 272;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtB.hdec1eqbit
	  section.data(24).logicalSrcIdx = 273;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtB.dxpca0qb4k
	  section.data(25).logicalSrcIdx = 274;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtB.hd4g4dpfnd
	  section.data(26).logicalSrcIdx = 275;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtB.cj3lmhi2x0
	  section.data(27).logicalSrcIdx = 276;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtB.ewvip3v1vs
	  section.data(28).logicalSrcIdx = 277;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtB.aj1fizh15j
	  section.data(29).logicalSrcIdx = 278;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtB.ekz0c33q4s
	  section.data(30).logicalSrcIdx = 279;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtB.gkdril5bnk
	  section.data(31).logicalSrcIdx = 280;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtB.bklkra2upj
	  section.data(32).logicalSrcIdx = 281;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtB.azrlqv35vl
	  section.data(33).logicalSrcIdx = 282;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtB.ldbnroag1b
	  section.data(34).logicalSrcIdx = 283;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtB.ovwc5iskjn
	  section.data(35).logicalSrcIdx = 284;
	  section.data(35).dtTransOffset = 34;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.o1zcbbtrng.odhgoorqbc
	  section.data(1).logicalSrcIdx = 285;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.o1zcbbtrng.nbuwrhuier
	  section.data(2).logicalSrcIdx = 286;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(3) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.dieezpzkpy.odhgoorqbc
	  section.data(1).logicalSrcIdx = 287;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.dieezpzkpy.nbuwrhuier
	  section.data(2).logicalSrcIdx = 288;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(4) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.dc2alimajs.odhgoorqbc
	  section.data(1).logicalSrcIdx = 289;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.dc2alimajs.nbuwrhuier
	  section.data(2).logicalSrcIdx = 290;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(5) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.cq21slkg0n.odhgoorqbc
	  section.data(1).logicalSrcIdx = 291;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.cq21slkg0n.nbuwrhuier
	  section.data(2).logicalSrcIdx = 292;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(6) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.g3klpnnfu2.odhgoorqbc
	  section.data(1).logicalSrcIdx = 293;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.g3klpnnfu2.nbuwrhuier
	  section.data(2).logicalSrcIdx = 294;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(7) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.ph0zzilf0u.odhgoorqbc
	  section.data(1).logicalSrcIdx = 295;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.ph0zzilf0u.nbuwrhuier
	  section.data(2).logicalSrcIdx = 296;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(8) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 6;
    sectIdxOffset = 8;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtDW)
    ;%
      section.nData     = 28;
      section.data(28)  = dumData; %prealloc
      
	  ;% rtDW.mx5vjacu5q
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.gu33m3cujr
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.ihabibaari
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.g45xtcsm1y
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.mde444qrus
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.egfu4zp5ck
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.jjpmmqdhaq
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.knijrjnyhh
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.curbfhmvfh
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.h51d42z1yp
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.evcbaypssu
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.fcr2tgbfvo
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtDW.glz3hn24br
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtDW.peu253ymia
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtDW.b0muitc2hd
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtDW.llaf3ewbkp
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtDW.axv0fdx2my
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtDW.azndzkmkcs
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtDW.nthq3z5tt5
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtDW.plxwewmbjw
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtDW.ftugzjzi0o
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtDW.gipv354qpb
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtDW.j1mmhsj1qj
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtDW.k4c4pmfnv2
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtDW.mfqivfq3il
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtDW.pxyvizid1y
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtDW.feyc5lmf2r
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtDW.ebuw4ix1ne
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 6;
      section.data(6)  = dumData; %prealloc
      
	  ;% rtDW.jvh5mician
	  section.data(1).logicalSrcIdx = 28;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.cdm1pyiexh
	  section.data(2).logicalSrcIdx = 29;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.k0umb4nsxj
	  section.data(3).logicalSrcIdx = 30;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.a1ahum4gsl
	  section.data(4).logicalSrcIdx = 31;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.fmvszapqpi
	  section.data(5).logicalSrcIdx = 32;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.ko5gsxzsuc
	  section.data(6).logicalSrcIdx = 33;
	  section.data(6).dtTransOffset = 5;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.p3thioyq1j
	  section.data(1).logicalSrcIdx = 34;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 12;
      section.data(12)  = dumData; %prealloc
      
	  ;% rtDW.grbdzf5eku
	  section.data(1).logicalSrcIdx = 35;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.iewdw05cht.LoggedData
	  section.data(2).logicalSrcIdx = 36;
	  section.data(2).dtTransOffset = 22;
	
	  ;% rtDW.dbblrjj2tk.AQHandles
	  section.data(3).logicalSrcIdx = 37;
	  section.data(3).dtTransOffset = 27;
	
	  ;% rtDW.l22qnqwzjn.AQHandles
	  section.data(4).logicalSrcIdx = 38;
	  section.data(4).dtTransOffset = 28;
	
	  ;% rtDW.fo3wh2yatx.AQHandles
	  section.data(5).logicalSrcIdx = 39;
	  section.data(5).dtTransOffset = 29;
	
	  ;% rtDW.k2ffp3ntfr.AQHandles
	  section.data(6).logicalSrcIdx = 40;
	  section.data(6).dtTransOffset = 30;
	
	  ;% rtDW.nyfzlmf145.AQHandles
	  section.data(7).logicalSrcIdx = 41;
	  section.data(7).dtTransOffset = 31;
	
	  ;% rtDW.h04wi2qgv5.AQHandles
	  section.data(8).logicalSrcIdx = 42;
	  section.data(8).dtTransOffset = 32;
	
	  ;% rtDW.jgsevaes2d.AQHandles
	  section.data(9).logicalSrcIdx = 43;
	  section.data(9).dtTransOffset = 33;
	
	  ;% rtDW.j2pvryuk2u.AQHandles
	  section.data(10).logicalSrcIdx = 44;
	  section.data(10).dtTransOffset = 34;
	
	  ;% rtDW.hqpvabyibc.AQHandles
	  section.data(11).logicalSrcIdx = 45;
	  section.data(11).dtTransOffset = 35;
	
	  ;% rtDW.nwagpl0vbs.LoggedData
	  section.data(12).logicalSrcIdx = 46;
	  section.data(12).dtTransOffset = 36;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 33;
      section.data(33)  = dumData; %prealloc
      
	  ;% rtDW.g55jrpbizl
	  section.data(1).logicalSrcIdx = 47;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.ojsrsvfc4d
	  section.data(2).logicalSrcIdx = 48;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.lldjl4eyzi
	  section.data(3).logicalSrcIdx = 49;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.gxvtetrs04
	  section.data(4).logicalSrcIdx = 50;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.frtlsutffh
	  section.data(5).logicalSrcIdx = 51;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.pzgimzosty
	  section.data(6).logicalSrcIdx = 52;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.m3sjkfetzr
	  section.data(7).logicalSrcIdx = 53;
	  section.data(7).dtTransOffset = 28;
	
	  ;% rtDW.jmxabr1urn
	  section.data(8).logicalSrcIdx = 54;
	  section.data(8).dtTransOffset = 29;
	
	  ;% rtDW.hrm4dgu33i
	  section.data(9).logicalSrcIdx = 55;
	  section.data(9).dtTransOffset = 30;
	
	  ;% rtDW.ge34ybq3a0
	  section.data(10).logicalSrcIdx = 56;
	  section.data(10).dtTransOffset = 31;
	
	  ;% rtDW.ed3nvtxxjm
	  section.data(11).logicalSrcIdx = 57;
	  section.data(11).dtTransOffset = 32;
	
	  ;% rtDW.dsor1ukpll
	  section.data(12).logicalSrcIdx = 58;
	  section.data(12).dtTransOffset = 33;
	
	  ;% rtDW.cokzwj0i4g
	  section.data(13).logicalSrcIdx = 59;
	  section.data(13).dtTransOffset = 34;
	
	  ;% rtDW.gnfw0t231h
	  section.data(14).logicalSrcIdx = 60;
	  section.data(14).dtTransOffset = 35;
	
	  ;% rtDW.lv22brfstt
	  section.data(15).logicalSrcIdx = 61;
	  section.data(15).dtTransOffset = 36;
	
	  ;% rtDW.as2ykd4ql3
	  section.data(16).logicalSrcIdx = 62;
	  section.data(16).dtTransOffset = 37;
	
	  ;% rtDW.kaytcmiwya
	  section.data(17).logicalSrcIdx = 63;
	  section.data(17).dtTransOffset = 38;
	
	  ;% rtDW.dcn3au535t
	  section.data(18).logicalSrcIdx = 64;
	  section.data(18).dtTransOffset = 63;
	
	  ;% rtDW.jertq5slcs
	  section.data(19).logicalSrcIdx = 65;
	  section.data(19).dtTransOffset = 64;
	
	  ;% rtDW.l0t1omik1w
	  section.data(20).logicalSrcIdx = 66;
	  section.data(20).dtTransOffset = 65;
	
	  ;% rtDW.hdetrxmovp
	  section.data(21).logicalSrcIdx = 67;
	  section.data(21).dtTransOffset = 66;
	
	  ;% rtDW.d4gcz4s4op
	  section.data(22).logicalSrcIdx = 68;
	  section.data(22).dtTransOffset = 67;
	
	  ;% rtDW.o0qveok2yn
	  section.data(23).logicalSrcIdx = 69;
	  section.data(23).dtTransOffset = 68;
	
	  ;% rtDW.jpp24x3j0b
	  section.data(24).logicalSrcIdx = 70;
	  section.data(24).dtTransOffset = 69;
	
	  ;% rtDW.dkr0lmfwa5
	  section.data(25).logicalSrcIdx = 71;
	  section.data(25).dtTransOffset = 70;
	
	  ;% rtDW.nrpmm2hefl
	  section.data(26).logicalSrcIdx = 72;
	  section.data(26).dtTransOffset = 71;
	
	  ;% rtDW.audfqsd0mm
	  section.data(27).logicalSrcIdx = 73;
	  section.data(27).dtTransOffset = 72;
	
	  ;% rtDW.hwrms4izrt
	  section.data(28).logicalSrcIdx = 74;
	  section.data(28).dtTransOffset = 73;
	
	  ;% rtDW.gtcdjshroe
	  section.data(29).logicalSrcIdx = 75;
	  section.data(29).dtTransOffset = 74;
	
	  ;% rtDW.fqhd2sk321
	  section.data(30).logicalSrcIdx = 76;
	  section.data(30).dtTransOffset = 75;
	
	  ;% rtDW.kxwxa3byt5
	  section.data(31).logicalSrcIdx = 77;
	  section.data(31).dtTransOffset = 76;
	
	  ;% rtDW.fogzt5jbmz
	  section.data(32).logicalSrcIdx = 78;
	  section.data(32).dtTransOffset = 77;
	
	  ;% rtDW.oq1utabldx
	  section.data(33).logicalSrcIdx = 79;
	  section.data(33).dtTransOffset = 78;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
      section.nData     = 74;
      section.data(74)  = dumData; %prealloc
      
	  ;% rtDW.exu1prz21a
	  section.data(1).logicalSrcIdx = 80;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.bs0tfwzjp3
	  section.data(2).logicalSrcIdx = 81;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.msxvlyne10
	  section.data(3).logicalSrcIdx = 82;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.owram20lcx
	  section.data(4).logicalSrcIdx = 83;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.ktypzgdlxt
	  section.data(5).logicalSrcIdx = 84;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.otvz1o3ztq
	  section.data(6).logicalSrcIdx = 85;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.pkopjswp3e
	  section.data(7).logicalSrcIdx = 86;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.e0qedsyqjn
	  section.data(8).logicalSrcIdx = 87;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.pkpw1tsasy
	  section.data(9).logicalSrcIdx = 88;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.mx41mp51rp
	  section.data(10).logicalSrcIdx = 89;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.jansurp50c
	  section.data(11).logicalSrcIdx = 90;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.c4szg1j5wf
	  section.data(12).logicalSrcIdx = 91;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtDW.izsp05gss2
	  section.data(13).logicalSrcIdx = 92;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtDW.b554rpqups
	  section.data(14).logicalSrcIdx = 93;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtDW.pbezlulnm5
	  section.data(15).logicalSrcIdx = 94;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtDW.oyiznhfz3f
	  section.data(16).logicalSrcIdx = 95;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtDW.djo5beq3n0
	  section.data(17).logicalSrcIdx = 96;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtDW.gil4ie50ol
	  section.data(18).logicalSrcIdx = 97;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtDW.aarpnpqgmu
	  section.data(19).logicalSrcIdx = 98;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtDW.cgfl554d0l
	  section.data(20).logicalSrcIdx = 99;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtDW.p51wmaigg2
	  section.data(21).logicalSrcIdx = 100;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtDW.geb4p4zdgn
	  section.data(22).logicalSrcIdx = 101;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtDW.opozmxoahv
	  section.data(23).logicalSrcIdx = 102;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtDW.p3ylutwfna
	  section.data(24).logicalSrcIdx = 103;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtDW.fma5ryxgkz
	  section.data(25).logicalSrcIdx = 104;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtDW.khxogtuz1l
	  section.data(26).logicalSrcIdx = 105;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtDW.d4qmht1xff
	  section.data(27).logicalSrcIdx = 106;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtDW.hjxqlr4sag
	  section.data(28).logicalSrcIdx = 107;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtDW.eg3zr5htps
	  section.data(29).logicalSrcIdx = 108;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtDW.gazfgp55bt
	  section.data(30).logicalSrcIdx = 109;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtDW.jkumuiblmb
	  section.data(31).logicalSrcIdx = 110;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtDW.nt4ghy3024
	  section.data(32).logicalSrcIdx = 111;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtDW.aux30da2zu
	  section.data(33).logicalSrcIdx = 112;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtDW.aqmi0ximsk
	  section.data(34).logicalSrcIdx = 113;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtDW.bf132dfs4i
	  section.data(35).logicalSrcIdx = 114;
	  section.data(35).dtTransOffset = 34;
	
	  ;% rtDW.n22ezzj533
	  section.data(36).logicalSrcIdx = 115;
	  section.data(36).dtTransOffset = 35;
	
	  ;% rtDW.egy3i3psvd
	  section.data(37).logicalSrcIdx = 116;
	  section.data(37).dtTransOffset = 36;
	
	  ;% rtDW.i5m44h50ql
	  section.data(38).logicalSrcIdx = 117;
	  section.data(38).dtTransOffset = 37;
	
	  ;% rtDW.axjy40izfe
	  section.data(39).logicalSrcIdx = 118;
	  section.data(39).dtTransOffset = 38;
	
	  ;% rtDW.jq3vvbxrjf
	  section.data(40).logicalSrcIdx = 119;
	  section.data(40).dtTransOffset = 39;
	
	  ;% rtDW.okvjyaztbz
	  section.data(41).logicalSrcIdx = 120;
	  section.data(41).dtTransOffset = 40;
	
	  ;% rtDW.mez5whsqc3
	  section.data(42).logicalSrcIdx = 121;
	  section.data(42).dtTransOffset = 41;
	
	  ;% rtDW.pbjw4010b3
	  section.data(43).logicalSrcIdx = 122;
	  section.data(43).dtTransOffset = 42;
	
	  ;% rtDW.oyet01vjge
	  section.data(44).logicalSrcIdx = 123;
	  section.data(44).dtTransOffset = 43;
	
	  ;% rtDW.bu03oe0pwq
	  section.data(45).logicalSrcIdx = 124;
	  section.data(45).dtTransOffset = 44;
	
	  ;% rtDW.n1fso1av4u
	  section.data(46).logicalSrcIdx = 125;
	  section.data(46).dtTransOffset = 45;
	
	  ;% rtDW.orvtgsw01i
	  section.data(47).logicalSrcIdx = 126;
	  section.data(47).dtTransOffset = 46;
	
	  ;% rtDW.i0pn21xe2p
	  section.data(48).logicalSrcIdx = 127;
	  section.data(48).dtTransOffset = 47;
	
	  ;% rtDW.gljdehuiwg
	  section.data(49).logicalSrcIdx = 128;
	  section.data(49).dtTransOffset = 48;
	
	  ;% rtDW.mmoscpngve
	  section.data(50).logicalSrcIdx = 129;
	  section.data(50).dtTransOffset = 49;
	
	  ;% rtDW.icvovv1jq2
	  section.data(51).logicalSrcIdx = 130;
	  section.data(51).dtTransOffset = 50;
	
	  ;% rtDW.fwfrplulil
	  section.data(52).logicalSrcIdx = 131;
	  section.data(52).dtTransOffset = 51;
	
	  ;% rtDW.dxjlf0kpmf
	  section.data(53).logicalSrcIdx = 132;
	  section.data(53).dtTransOffset = 52;
	
	  ;% rtDW.os5dfkhn1w
	  section.data(54).logicalSrcIdx = 133;
	  section.data(54).dtTransOffset = 53;
	
	  ;% rtDW.iw1ylkptc1
	  section.data(55).logicalSrcIdx = 134;
	  section.data(55).dtTransOffset = 54;
	
	  ;% rtDW.ggmjvv0lb3
	  section.data(56).logicalSrcIdx = 135;
	  section.data(56).dtTransOffset = 55;
	
	  ;% rtDW.fbe3y1q2sg
	  section.data(57).logicalSrcIdx = 136;
	  section.data(57).dtTransOffset = 56;
	
	  ;% rtDW.aslrlvkkcc
	  section.data(58).logicalSrcIdx = 137;
	  section.data(58).dtTransOffset = 57;
	
	  ;% rtDW.hekwrhnl5m
	  section.data(59).logicalSrcIdx = 138;
	  section.data(59).dtTransOffset = 58;
	
	  ;% rtDW.doiwoekzov
	  section.data(60).logicalSrcIdx = 139;
	  section.data(60).dtTransOffset = 59;
	
	  ;% rtDW.jdnmbiwx3f
	  section.data(61).logicalSrcIdx = 140;
	  section.data(61).dtTransOffset = 60;
	
	  ;% rtDW.aphrz0r2os
	  section.data(62).logicalSrcIdx = 141;
	  section.data(62).dtTransOffset = 61;
	
	  ;% rtDW.offqujpaki
	  section.data(63).logicalSrcIdx = 142;
	  section.data(63).dtTransOffset = 62;
	
	  ;% rtDW.bhhlshfa0t
	  section.data(64).logicalSrcIdx = 143;
	  section.data(64).dtTransOffset = 63;
	
	  ;% rtDW.hxxbbgmykq
	  section.data(65).logicalSrcIdx = 144;
	  section.data(65).dtTransOffset = 64;
	
	  ;% rtDW.md1zdgbsoe
	  section.data(66).logicalSrcIdx = 145;
	  section.data(66).dtTransOffset = 65;
	
	  ;% rtDW.hlvtogm2ca
	  section.data(67).logicalSrcIdx = 146;
	  section.data(67).dtTransOffset = 66;
	
	  ;% rtDW.ot0jlfqn3i
	  section.data(68).logicalSrcIdx = 147;
	  section.data(68).dtTransOffset = 67;
	
	  ;% rtDW.awhbfmptso
	  section.data(69).logicalSrcIdx = 148;
	  section.data(69).dtTransOffset = 68;
	
	  ;% rtDW.fdy0jfy1tu
	  section.data(70).logicalSrcIdx = 149;
	  section.data(70).dtTransOffset = 69;
	
	  ;% rtDW.i2lws3rgth
	  section.data(71).logicalSrcIdx = 150;
	  section.data(71).dtTransOffset = 70;
	
	  ;% rtDW.oasl5bklsg
	  section.data(72).logicalSrcIdx = 151;
	  section.data(72).dtTransOffset = 71;
	
	  ;% rtDW.l0150x51ms
	  section.data(73).logicalSrcIdx = 152;
	  section.data(73).dtTransOffset = 72;
	
	  ;% rtDW.p4r02ywybb
	  section.data(74).logicalSrcIdx = 153;
	  section.data(74).dtTransOffset = 73;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(6) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 2020061266;
  targMap.checksum1 = 3753598033;
  targMap.checksum2 = 1176490380;
  targMap.checksum3 = 1620534263;

