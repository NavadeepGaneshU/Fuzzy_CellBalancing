#ifndef RTW_HEADER_activeBalancing3_h_
#define RTW_HEADER_activeBalancing3_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap_simtarget.h"
#ifndef activeBalancing3_COMMON_INCLUDES_
#define activeBalancing3_COMMON_INCLUDES_
#include <stdlib.h>
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "activeBalancing3_types.h"
#include "multiword_types.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "rt_zcfcn.h"
#include "mwmathutil.h"
#include "rt_defines.h"
#define MODEL_NAME activeBalancing3
#define NSAMPLE_TIMES (9) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (310) 
#define NUM_ZC_EVENTS (5) 
#ifndef NCSTATES
#define NCSTATES (26)   
#elif NCSTATES != 26
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T fsk1owdmw3 [ 2 ] ; real_T k3oc5pn3ee [ 101 ] ; }
iczfebuibr ; typedef struct { real_T ldokaf3uyj ; real_T hitd4jbxxo ; real_T
g3cnit1gts ; real_T lssfzuya44 ; real_T patx3e3lyu ; real_T o3tagh4era ;
real_T iyrb00kscp ; real_T mpjucudbtk ; real_T cgbzrrdvnj ; real_T apptu0x5zl
; real_T j04p5reu3p ; real_T cklmpkcmxr ; real_T gwc4gctvfb ; real_T
if50jzplnu ; real_T khbkyi2o4w ; real_T pabcbevt20 ; real_T pqzrrvf1s1 ;
real_T p4p2fahxpn ; real_T n0wyyiyl2w ; real_T bjzh2zswrf ; real_T dvd3eelqxy
; real_T htgwxujgfn ; real_T ipzhuu4ptw ; real_T mxtffwnyug ; real_T
olx2nutnfv ; real_T iadrygzp4x ; real_T fd3qiys2ps ; real_T mkvq5xwqnm ;
real_T biwszoosgc ; real_T cd5jv3welm ; real_T pse0v0upak ; real_T j1vwznyubj
; real_T nqwiqvxip0 ; real_T me3a54u35r ; real_T fj5f5uf5pw ; real_T
gjz4ggefl2 ; real_T gukj05tcnp ; real_T hr1ymwwo43 ; real_T hcjtzzfngx ;
real_T izpbloaset ; real_T af10lxjheq ; real_T oomylrj2ck ; real_T dawtfnjz3t
; real_T aqn3egakkx ; real_T f2scb5rf13 ; real_T ja533qrntz ; real_T
b5ot5krztj ; real_T dsgitwjsjs ; real_T bjsmudeh15 ; real_T lnjfdccy2h ;
real_T pgstoxbe4q ; real_T n5erhw4hry ; real_T al5llquoyw ; real_T olt2mencvc
; real_T fwpjmaqmyl ; real_T iacqlbe2tg ; real_T fbim3ivtyq ; real_T
inr0z52r4v ; real_T jrt1dp0uea ; real_T onxjmnda4f ; real_T atav4hz2t0 ;
real_T lhhtg1palw ; real_T cwlnlciysh ; real_T k0tidcedyr ; real_T cahmoz3lmb
; real_T ctz0crt1lg ; real_T oc0dumgulu ; real_T ebcqidfawa ; real_T
jlrqkf40e4 ; real_T hmnedoi5ok ; real_T bvviu2o2gh ; real_T lfgqqylnmm ;
real_T pmwqhxrjfr ; real_T nw2inaond5 ; real_T crm3deon3z ; real_T nocrqzmy3a
; real_T h3gzco2fqa ; real_T oocd2yqorm ; real_T e0au3fw2j3 ; real_T
aprnkbzhsq ; real_T fmzs5132om ; real_T nqjaq0ah0p ; real_T jgxdelnl3s ;
real_T nfrth1ueqb ; real_T gomqwjxzd5 ; real_T knag0fuf4e ; real_T ngfkb5ghae
; real_T mt1bcogztp ; real_T bs00yavsbm ; real_T eacgl4yov2 ; real_T
orwu5t0tyg ; real_T imwf4qbc3k ; real_T n5szlr3nqx ; real_T cngflnzqr2 ;
real_T nwootfl0wl ; real_T hjgu4nxp5v ; real_T a1pwur2f3n ; real_T gjgshqegfr
; real_T lehkr3fuer ; real_T e42dsovuoz ; real_T ermmdxeqvq ; real_T
f5toqxhshz ; real_T bcqp5bw5m5 ; real_T mymfehhqyf ; real_T dkrfxtvrav ;
real_T psl1pylfxp ; real_T ggcp4lpehl ; real_T mxu3fd52lg ; real_T j1rfmexczt
; real_T enfj1pjw2o ; real_T nawqkqqhwd ; real_T gy2pn1xoxf ; real_T
oihkxrrgl0 ; real_T neo3wgh5k0 ; real_T b05wxiklmy ; real_T gzwwnxifap [ 7 ]
; real_T e4hlm2rw4k [ 72 ] ; real_T dnpga1izxq ; real_T mharr3pkm3 ; real_T
c1cjcg0vdp ; real_T anodlblzme ; real_T cszbfywqst ; real_T lt0d3owsjr ;
real_T i2s0aqv5oj ; real_T c4edbm3lnu ; real_T mnn2sdpcg2 ; real_T czbyl5orjk
; real_T jkh0lpzdyl ; real_T m5q0x4yj0k ; real_T ccjxi5v2q0 ; real_T
cw0w1vgwxh ; real_T pcrjjj3bl2 ; real_T bmkbfj44hc ; real_T fngvfw2vbc ;
real_T mgwtedhsbf ; real_T gsugcfegmq ; real_T nh3tyegvgp ; real_T hjlmg51yd0
; real_T a1xkvgib3c ; real_T dip4hm3fie ; real_T gu2lxqjoee ; real_T
glfgd2gxlp ; real_T fntfm0klq3 ; real_T dzdzcnn4k1 ; real_T otjjwnfbam ;
real_T f4hgeqqzrq ; real_T pch3fntlad ; real_T eiotr3cj2j ; real_T ooqdf4csin
; real_T deezhakrkc ; real_T i0ea205hal ; real_T be32mwjpny ; real_T
aqgrfvolcg ; real_T bdqvl4emoj ; real_T niay40fjqf ; real_T c51nh4xf1q ;
real_T jv5t3iflfp ; real_T cdukvsxdzj ; real_T hjnfpefc4k ; real_T dfsyb51tzv
; real_T nka52w5p2z ; real_T hkcf5uul0d ; real_T ad5v3ototp ; real_T
nhbww2xvcr ; real_T jxi4eauchh ; real_T cfafquv2xr ; real_T fmprtpx12v ;
real_T gn1ehycyi2 ; real_T ofqxlds3eh ; real_T byqwyjabue ; real_T kz5y1t5h5o
; real_T h4lwnoqm5x ; real_T l0fygtafkq ; real_T nsz3sakdbs ; real_T
nszpfs0j4c ; real_T aqj5tzxay2 ; real_T pzkcy4pfea ; real_T gbmzzjn501 ;
real_T cxzbwqcn1v ; real_T kwlwx42yav ; real_T cjyi1ugvfp ; real_T buretmbzch
; real_T hwbt4zhehe ; real_T ghpkp3e4ii ; real_T ala2ctnapt ; real_T
palr0v3uue ; real_T mgdng0j5ju ; real_T iilivmsrjv ; real_T hc4tipfzoi ;
real_T cpkwdk2p01 ; real_T pblcvwi5vj ; real_T fjax0ymfvv ; real_T owzswdceo3
; real_T lnwt3320xf ; real_T f1jzjr5wtp ; real_T ezdk1hee5n ; real_T
mhvcgzbyma ; real_T dcu2acxtfg ; real_T lnh2z2pbk3 ; real_T ovmxhmbhlf ;
real_T g2q1v5iy2d ; real_T pbgvg2nezd ; real_T jzeacrnsxs ; real_T klom0nem0m
; real_T aolyxnh1an ; real_T fzhbdpl21m ; real_T fllp1jvygi ; real_T
ln3b5mokgm ; real_T krwk3nllsf ; real_T kxozrd4z5i ; real_T ighohgvfas ;
real_T etxojvnaot ; real_T gwktivfwpd ; real_T ekw0zt1xfm ; real_T cqsienutuc
; real_T krygur50zl ; real_T mlxflzoh35 [ 2 ] ; real_T g00batsh4u ; real_T
hcz2xlgk3d [ 2 ] ; real_T oj2fro1nlz ; real_T nsl1liuisf [ 2 ] ; real_T
o2kdszic3h ; real_T kkozylqz2v [ 2 ] ; real_T hr44golvpy ; real_T fzbe5vkjui
[ 2 ] ; real_T dmpeej2qt1 ; real_T cxgw4hmvl5 [ 2 ] ; real_T h0hbhcvnx4 ;
real_T n2s1hb1sdd ; real_T po4oftxsww ; real_T mu2u0ykmdh ; real_T b101dzqhyh
[ 4 ] ; real_T itee030nb5 [ 4 ] ; real_T i0nwte41mb [ 4 ] ; real_T j2yhvvmzdt
[ 4 ] ; real_T e1he2cpfsi ; real_T c1yr1t1pln ; real_T l52vljxmqk ; real_T
kygrahp5cz [ 4 ] ; real_T cjndlopolx [ 4 ] ; real_T d1gpz5ny3l [ 4 ] ; real_T
at40po5flv [ 4 ] ; real_T lhj1mrpnaq ; real_T ijry4eme3e ; real_T kkv1oof2ml
; real_T kcfelslddn [ 4 ] ; real_T hcovsf5jov [ 4 ] ; real_T ndunxwoqnz [ 4 ]
; real_T lphjnbgv2d [ 4 ] ; real_T enbnzlp5pu ; real_T m5mik3hen3 ; real_T
cywrrn5vf0 ; real_T d4u1qga40r [ 4 ] ; real_T fpc3kvomhx [ 4 ] ; real_T
cxpepskh1k [ 4 ] ; real_T mg1gi4ne5h [ 4 ] ; real_T a0ohbtp3be ; real_T
bvpvkwxod3 ; real_T oxbbdbrc3h ; real_T byyxlan4vv [ 4 ] ; real_T gnqhbaw5wi
[ 4 ] ; real_T kkvkd0imzv [ 4 ] ; real_T ccegoze1r3 [ 4 ] ; boolean_T
iezulznyyl ; boolean_T d5jbm0zxii ; boolean_T kcf35vodg1 ; boolean_T
bwnprsaklm ; boolean_T jakgot214r ; boolean_T hmuvnzmkyq ; boolean_T
ptudxy54cl ; boolean_T hr53vp5214 ; boolean_T cfvuxsaes1 ; boolean_T
cc2mpg0gqp ; boolean_T cl1znduuno ; boolean_T pykujdhald ; boolean_T
kttme4p4ih ; boolean_T nuzd1nehkt ; boolean_T bn2cyxj3zl ; boolean_T
dnc1haqpya ; boolean_T ou3lkm5huj ; boolean_T ivfkkggxvv ; boolean_T
hvbdhrufgk ; boolean_T oipwcmrhbu ; boolean_T ojebse5nps ; boolean_T
ixwvnfjyht ; boolean_T njmqdqum11 ; boolean_T e0eegacwfw ; boolean_T
ammqm2ucfq ; boolean_T jhzdsfrzpr ; boolean_T kgz10dnw3h ; boolean_T
aww14lps2o ; boolean_T cpybkyynn4 ; boolean_T cgviec4bkd ; boolean_T
filzxjl5ur ; boolean_T dtff1cx0dd ; boolean_T epmqzfkazx ; boolean_T
n244nv1bl5 ; boolean_T lvnp1e1py5 ; iczfebuibr lykrvem450 ; iczfebuibr
ea4xfcwbtn ; iczfebuibr fmo52byvhh ; iczfebuibr ju3bvdpq4f ; iczfebuibr
hn5ndxahiz ; iczfebuibr jc1djgafdm ; } B ; typedef struct { real_T mwtjai2xzq
; real_T abnasr53i2 ; real_T puhqb53xlf ; real_T cgtn4vtk4v ; real_T
e5chgaqzdi ; real_T br1vosysg0 ; real_T bw2f200uhe ; real_T h1kn4wxczz ;
real_T fwi0pu3glv ; real_T m35jm4htkc ; real_T ep01khxy3s ; real_T fnsfdleb5s
; real_T mg0udjzg3z ; real_T esnkvscczq ; real_T o2neiszzpu ; real_T
h21d2fqnwl ; real_T f4vpteq14c ; real_T mlaq1sf05w ; real_T imnddva2yd ;
real_T bv3ta2c31d ; real_T gvyq4tdih4 ; real_T cukktpbdau ; real_T hwclgprvm0
; real_T nlleqzlpac ; real_T h0ir15tiwo ; real_T dp1esyh3gc ; real_T
dul0uayr5l ; real_T mk2k513iba ; uint64_T gil1dfunsb ; uint64_T oxz1dp4rtp ;
uint64_T i4itkhygug ; uint64_T fzl1x30105 ; uint64_T kuacjottby ; uint64_T
dtdzggbusy ; real_T pipgbkjgsg [ 2 ] ; void * bl3jeskmlg [ 22 ] ; struct {
void * LoggedData [ 5 ] ; } c5xpztgxst ; struct { void * AQHandles ; }
kefwpubmhm ; struct { void * AQHandles ; } pvibdkum0b ; struct { void *
AQHandles ; } a1aeuz3o44 ; struct { void * AQHandles ; } m5pgrgp4cg ; struct
{ void * AQHandles ; } oee5uekymg ; struct { void * AQHandles ; } jrgeolpedl
; struct { void * AQHandles ; } l4br0owshy ; struct { void * AQHandles ; }
eqbzffk253 ; struct { void * AQHandles ; } m1fwuqpiaf ; struct { void *
LoggedData [ 5 ] ; } pf5orjqb5m ; struct { void * LoggedData [ 2 ] ; }
hluh0ska1a ; int_T mjabmoou2z ; int_T apw4epat2u ; int_T fid4f0juyg ; int_T
a12tj2tqvt ; int_T lb53h134aw ; int_T badooczfnm [ 23 ] ; int_T ndyjjzoyah ;
int_T iv0bm1cwdz ; int_T pngsgibtfq ; int_T ewtqwav4k3 ; int_T cbhsw3xyhw ;
int_T g5hpe50c5f ; int_T nfdtmpqmjl ; int_T gxhonuhkhs ; int_T blabp2utic ;
int_T hdt4znz2bx ; int_T imyqo2srel [ 37 ] ; int_T c3pj1kxqrj ; int_T
py5uw1xsam ; int_T o2st5ljikx ; int_T cqvf2g25lz ; int_T h4owravycx ; int_T
dgvo4khvek ; int_T ehr4lffvuj ; int_T pavtbhl4x1 ; int_T ctdq2e5yzh ; int_T
eucrjtmh5k ; int_T ev0agwtynm ; int_T lg5hzw2ze0 ; int_T gglvg5yhwg ; int_T
bhkajjcc0s ; int_T bw1ne04erh ; int_T lk5j3i1cks ; boolean_T oemcgetehw ;
boolean_T mcoopbxhas ; boolean_T hfhq12age4 ; boolean_T odkj4eftfi ;
boolean_T mlgiqc4qhd ; boolean_T o4yhobhacw ; boolean_T b4xvp05dsp ;
boolean_T obaqwkwqid ; boolean_T kqhwhpbc2l ; boolean_T lptbui3bdr ;
boolean_T hz3s4vrezj ; boolean_T dhbq4fq1y5 ; boolean_T gwmmodqfqo ;
boolean_T flqyr4ponx ; boolean_T drp1pdx1o2 ; boolean_T mwzj54zeve ;
boolean_T gh40xceltm ; boolean_T hxqj0wmr1s ; boolean_T ayf5sqzvgu ;
boolean_T hsuqfg2xm4 ; boolean_T aeubopidzx ; boolean_T jlwexkwoi3 ;
boolean_T nxd2nqjick ; boolean_T nkllg3btfs ; boolean_T hxobozywci ;
boolean_T abeepxeuaz ; boolean_T fsznzndz1h ; boolean_T pnxsmfjtjg ;
boolean_T kvk4rwajxg ; boolean_T paol22gume ; boolean_T nzxxvc5aaq ;
boolean_T azkim3bav2 ; boolean_T fbtobfkzln ; boolean_T ds2iyglcuj ;
boolean_T gv2gxwgcyr ; boolean_T og2ibrr5dj ; boolean_T podpzxkpcc ;
boolean_T gorulf3t0p ; boolean_T flctwqyusi ; boolean_T bshhfd5mls ;
boolean_T g11vzlfqpn ; boolean_T e4xlinrnnb ; boolean_T bct0r40oxs ;
boolean_T ezdcqawxtb ; boolean_T lh3hvz10l4 ; boolean_T b0t15mq1oh ;
boolean_T dx31ootphe ; boolean_T lbbdcegp5z ; boolean_T cj1yejiuj0 ;
boolean_T potnbsja2x ; boolean_T hyvrqtp0nq ; boolean_T f4jvehgaau ;
boolean_T fatdrnikff ; boolean_T dz22xyy0n2 ; boolean_T oklojozd5l ;
boolean_T gutf54om0t ; boolean_T awriz1pum1 ; boolean_T hwlma5twap ;
boolean_T lkdrn04ha3 ; boolean_T n2wn2lgi4k ; boolean_T lptg51m4go ;
boolean_T c4mx45ei5j ; boolean_T cwj4t5csvl ; boolean_T cgi440wi10 ;
boolean_T nqrddpnaqi ; boolean_T lvplimut2k ; boolean_T b45hsrgxk4 ;
boolean_T ff0qbzbocl ; boolean_T j553vsqqsn ; boolean_T kevb4e4jpg ;
boolean_T d0uk2u5ily ; boolean_T opghe0hhiz ; boolean_T hykritwrbg ;
boolean_T aznjkggrjt ; } DW ; typedef struct { real_T btwaflzkr2 ; real_T
cwzgk12fex ; real_T p2dwfugebo ; real_T gzwgpg3i32 ; real_T ieqye3wyr3 ;
real_T edarxfgg3m ; real_T n1mefgeo42 ; real_T kwkmxprem3 ; real_T g0ii5xynxb
; real_T hytl13jcro ; real_T daazrzvjzg ; real_T kmijbaomfh ; real_T
e3mceh2nlv ; real_T hqm1okddyw ; real_T abk5ytngnj ; real_T kskuxricdl ;
real_T lx3xuxie2j ; real_T brizaijzew ; real_T jjfpdr1zyr ; real_T imz4v0p4of
; real_T lwbwvxj00j [ 6 ] ; } X ; typedef struct { real_T btwaflzkr2 ; real_T
cwzgk12fex ; real_T p2dwfugebo ; real_T gzwgpg3i32 ; real_T ieqye3wyr3 ;
real_T edarxfgg3m ; real_T n1mefgeo42 ; real_T kwkmxprem3 ; real_T g0ii5xynxb
; real_T hytl13jcro ; real_T daazrzvjzg ; real_T kmijbaomfh ; real_T
e3mceh2nlv ; real_T hqm1okddyw ; real_T abk5ytngnj ; real_T kskuxricdl ;
real_T lx3xuxie2j ; real_T brizaijzew ; real_T jjfpdr1zyr ; real_T imz4v0p4of
; real_T lwbwvxj00j [ 6 ] ; } XDot ; typedef struct { boolean_T btwaflzkr2 ;
boolean_T cwzgk12fex ; boolean_T p2dwfugebo ; boolean_T gzwgpg3i32 ;
boolean_T ieqye3wyr3 ; boolean_T edarxfgg3m ; boolean_T n1mefgeo42 ;
boolean_T kwkmxprem3 ; boolean_T g0ii5xynxb ; boolean_T hytl13jcro ;
boolean_T daazrzvjzg ; boolean_T kmijbaomfh ; boolean_T e3mceh2nlv ;
boolean_T hqm1okddyw ; boolean_T abk5ytngnj ; boolean_T kskuxricdl ;
boolean_T lx3xuxie2j ; boolean_T brizaijzew ; boolean_T jjfpdr1zyr ;
boolean_T imz4v0p4of ; boolean_T lwbwvxj00j [ 6 ] ; } XDis ; typedef struct {
real_T btwaflzkr2 ; real_T cwzgk12fex ; real_T p2dwfugebo ; real_T gzwgpg3i32
; real_T ieqye3wyr3 ; real_T edarxfgg3m ; real_T n1mefgeo42 ; real_T
kwkmxprem3 ; real_T g0ii5xynxb ; real_T hytl13jcro ; real_T daazrzvjzg ;
real_T kmijbaomfh ; real_T e3mceh2nlv ; real_T hqm1okddyw ; real_T abk5ytngnj
; real_T kskuxricdl ; real_T lx3xuxie2j ; real_T brizaijzew ; real_T
jjfpdr1zyr ; real_T imz4v0p4of ; real_T lwbwvxj00j [ 6 ] ; } CStateAbsTol ;
typedef struct { real_T btwaflzkr2 ; real_T cwzgk12fex ; real_T p2dwfugebo ;
real_T gzwgpg3i32 ; real_T ieqye3wyr3 ; real_T edarxfgg3m ; real_T n1mefgeo42
; real_T kwkmxprem3 ; real_T g0ii5xynxb ; real_T hytl13jcro ; real_T
daazrzvjzg ; real_T kmijbaomfh ; real_T e3mceh2nlv ; real_T hqm1okddyw ;
real_T abk5ytngnj ; real_T kskuxricdl ; real_T lx3xuxie2j ; real_T brizaijzew
; real_T jjfpdr1zyr ; real_T imz4v0p4of ; real_T lwbwvxj00j [ 6 ] ; } CXPtMin
; typedef struct { real_T btwaflzkr2 ; real_T cwzgk12fex ; real_T p2dwfugebo
; real_T gzwgpg3i32 ; real_T ieqye3wyr3 ; real_T edarxfgg3m ; real_T
n1mefgeo42 ; real_T kwkmxprem3 ; real_T g0ii5xynxb ; real_T hytl13jcro ;
real_T daazrzvjzg ; real_T kmijbaomfh ; real_T e3mceh2nlv ; real_T hqm1okddyw
; real_T abk5ytngnj ; real_T kskuxricdl ; real_T lx3xuxie2j ; real_T
brizaijzew ; real_T jjfpdr1zyr ; real_T imz4v0p4of ; real_T lwbwvxj00j [ 6 ]
; } CXPtMax ; typedef struct { real_T dpon5t3zds ; real_T ji5jqtgbsi ; real_T
h12uqoqmiq ; real_T klvhdymfwp ; real_T jqp2i1ve4i ; real_T icvrclk4au ;
real_T afddasuzac ; real_T kc4y1yee3p ; real_T c3ixazwym1 ; real_T loaosuz0go
; real_T duvffkgaqs ; real_T m4ux3bcx3x ; real_T g5g4l0y42j ; real_T
nkfuqbe0ew ; real_T b4gicyjgcf ; real_T nqhf1ryrfa ; real_T f0wzh5ubb3 ;
real_T l5lfpvrvuy ; real_T ge1opwpogo ; real_T parudjb3ad ; real_T a3xmp4xhja
; real_T k2acyyht0h ; real_T lfxejjfiae ; real_T immgmtvdhe ; real_T
jb1rvtaper ; real_T jxgaj2ldm0 ; real_T mtl5u0lk3w ; real_T fa2kp2l4x5 ;
real_T dinys3acfp ; real_T fqu4g4bwdc ; real_T kslios301p ; real_T l2dqzarfof
; real_T edj4fsz5jj ; real_T bxboupuav2 ; real_T ftsh5pehvr ; real_T
n1u2yvuukx ; real_T eeniiexdz4 ; real_T iinseslf21 ; real_T byeoj1g00g ;
real_T fz2sfbu2li ; real_T dxjap1y2hu ; real_T pj5afrzsk1 ; real_T fda2am4ddo
; real_T jqptvkklyb ; real_T lmsx3qxry2 ; real_T f3iezawgro ; real_T
exg4ri5ese ; real_T ctsjyrsrwf ; real_T blxyuqpo0t ; real_T bozmxnbwx0 ;
real_T n2sobzq5kv ; real_T ihjgtx03o3 ; real_T bfcuy22y45 ; real_T ax1nsihfjd
; real_T fumtwk3ksm ; real_T gdbo3gtvxr ; real_T ntdwmivoif ; real_T
lb1sh0efu4 ; real_T d3s2st3bgc ; real_T d0h3iumb2c ; real_T nulp2ugcrt ;
real_T l53cipipxl ; real_T pwpsfaf2h0 ; real_T a1rqeng10c ; real_T etitv5r1sa
; real_T dvvojtxfl0 ; real_T aicckewnqd ; real_T ha2ftbblio ; real_T
kx1tvjophx ; real_T eeoq0zfn5c ; real_T pn2bszjmi0 ; real_T pcq1wfk3g4 ;
real_T ebs50zws43 ; real_T nq2n4hq1vx ; real_T gb5vqnkthp ; real_T dt132ajetl
[ 37 ] ; real_T ktxcx52jqi ; real_T hdeanbf5bj ; real_T cifrbym2j5 ; real_T
kwcqgahbhx ; real_T g332hceh05 ; real_T afehf4h1gc ; real_T jw0tis5o2a ;
real_T nlhita2tjm ; real_T d4pswc0ibx ; real_T ad0wx4ny25 ; real_T kame3an42b
; real_T dwu5vwjndy ; real_T h31sbmogo5 ; real_T f5it25ggpi ; real_T
lnxt5cpz0j ; real_T gs24r0gq3p ; real_T jsvaru1iar ; real_T i1ho113ysj ;
real_T h2e4epdjes ; real_T necoxhezuu ; real_T brgayjstgx ; real_T dagytij501
; real_T a5adlyl4bb ; real_T prio0gcowu ; real_T f25eellwxd ; real_T
j13ozua51f ; } ZCV ; typedef struct { ZCSigState prxdc20lxc ; ZCSigState
oizxtz1h42 ; ZCSigState dmvlae2fk1 ; ZCSigState hgdvl4elkh ; ZCSigState
kdatxxubrk ; } PrevZCX ; typedef struct { rtwCAPI_ModelMappingInfo mmi ; }
DataMapInfo ; struct P_ { real_T Battery1_BatType ; real_T Battery2_BatType ;
real_T Battery3_BatType ; real_T Battery4_BatType ; real_T Battery5_BatType ;
real_T PWM_Period ; real_T PWM1_Period ; real_T PWM2_Period ; real_T
PWM3_Period ; real_T PWM4_Period ; real_T PWM5_Period ; real_T
OutputSamplePoints_Value [ 101 ] ; real_T OutputSamplePoints_Value_bs0he10brt
[ 101 ] ; real_T OutputSamplePoints_Value_mmzz2j1vii [ 101 ] ; real_T
OutputSamplePoints_Value_h5oozv5nnj [ 101 ] ; real_T
OutputSamplePoints_Value_mkqnjleygm [ 101 ] ; real_T
OutputSamplePoints_Value_k42vy4v1xv [ 101 ] ; real_T Constant_Value ; real_T
Constant_Value_efypwvyyax ; real_T Constant_Value_ogegtmkzv0 ; real_T
Constant_Value_pbqzqfbpnm ; real_T Constant_Value_hu3rmuppbn ; real_T
Constant_Value_h5irp45zuu ; real_T Constant_Value_bksqnhysc0 ; real_T
Constant_Value_owtewy0ssm ; real_T Constant_Value_k5pwul1wle ; real_T
Constant_Value_kedzfrfegv ; real_T Constant_Value_opaksbgo21 ; real_T
Constant_Value_pp4lg2cwxs ; real_T Constant_Value_epq2rsx4ba ; real_T
Constant_Value_h45zreb2fb ; real_T Constant_Value_khiqevv1tc ; real_T
itinit1_InitialCondition ; real_T R2_Gain ; real_T Currentfilter_A ; real_T
Currentfilter_C ; real_T itinit_InitialCondition ; real_T inti_UpperSat ;
real_T inti_LowerSat ; real_T Gain_Gain ; real_T R3_Gain ; real_T
Integrator2_IC ; real_T Saturation_UpperSat ; real_T Saturation_LowerSat ;
real_T BAL_A ; real_T BAL_C ; real_T R1_Gain ; real_T
itinit1_InitialCondition_l3j5mkh0dv ; real_T R2_Gain_jrqfqsl4vo ; real_T
Currentfilter_A_hazdhojaym ; real_T Currentfilter_C_ldprzne4qv ; real_T
itinit_InitialCondition_pv4h4vt0ps ; real_T inti_UpperSat_itldayqrxp ; real_T
inti_LowerSat_lz3gh0icex ; real_T Gain_Gain_ozvwrv1fuy ; real_T
R3_Gain_dgx1dntlxw ; real_T Integrator2_IC_finfcihmmt ; real_T
Saturation_UpperSat_lxx4j3fnoa ; real_T Saturation_LowerSat_kwi433xk5g ;
real_T BAL_A_cudqa1u03y ; real_T BAL_C_pnvzkp4ayj ; real_T R1_Gain_k1h1x1zryv
; real_T itinit1_InitialCondition_go30gfvhlp ; real_T R2_Gain_fij43s2whq ;
real_T Currentfilter_A_pyl0ygpghg ; real_T Currentfilter_C_hx4sknoziy ;
real_T itinit_InitialCondition_nf4pvnucgc ; real_T inti_UpperSat_nowwhgaxwk ;
real_T inti_LowerSat_cwekkzbyq1 ; real_T Gain_Gain_jbuudt1ftk ; real_T
R3_Gain_de1tgv0zzw ; real_T Integrator2_IC_kqbwod02j2 ; real_T
Saturation_UpperSat_blj3ug4rzx ; real_T Saturation_LowerSat_o0i20janpw ;
real_T BAL_A_n35zxahhei ; real_T BAL_C_ix2bm3qtha ; real_T R1_Gain_elo0441xsu
; real_T itinit1_InitialCondition_ia2mtm2bdv ; real_T R2_Gain_akgkexbqnd ;
real_T Currentfilter_A_bsszjj1hem ; real_T Currentfilter_C_muylregegy ;
real_T itinit_InitialCondition_atlhsczubb ; real_T inti_UpperSat_itde10ibkj ;
real_T inti_LowerSat_nb1wwuftgl ; real_T Gain_Gain_l5lbde12wy ; real_T
R3_Gain_nk0ujvzftk ; real_T Integrator2_IC_gtek0x1of0 ; real_T
Saturation_UpperSat_c0l2pkijii ; real_T Saturation_LowerSat_g1ovkjgj1x ;
real_T BAL_A_jgidwk4hmh ; real_T BAL_C_hfghx3gysd ; real_T R1_Gain_ay3u4mrv4p
; real_T itinit1_InitialCondition_po45v3mmic ; real_T R2_Gain_axv50jbqfg ;
real_T Currentfilter_A_o3r40a2fs0 ; real_T Currentfilter_C_e5mev0pk52 ;
real_T itinit_InitialCondition_mh2yj0opxq ; real_T inti_UpperSat_ff0nysnmjy ;
real_T inti_LowerSat_hzpmw3xl5s ; real_T Gain_Gain_a4qiy5rws3 ; real_T
R3_Gain_hslbhc5rsq ; real_T Integrator2_IC_iw5ohpmyuz ; real_T
Saturation_UpperSat_dr1jmbb0we ; real_T Saturation_LowerSat_haspwmkdbs ;
real_T BAL_A_oad34lr4nf ; real_T BAL_C_cq3wtorxkj ; real_T R1_Gain_bdgjwewy0w
; real_T StateSpace_P1_Size [ 2 ] ; real_T StateSpace_P1 [ 4998 ] ; real_T
StateSpace_P2_Size [ 2 ] ; real_T StateSpace_P2 [ 4 ] ; real_T
StateSpace_P3_Size [ 2 ] ; real_T StateSpace_P3 [ 6 ] ; real_T
StateSpace_P4_Size [ 2 ] ; real_T StateSpace_P4 [ 3978 ] ; real_T
StateSpace_P5_Size [ 2 ] ; real_T StateSpace_P5 [ 72 ] ; real_T
StateSpace_P6_Size [ 2 ] ; real_T StateSpace_P6 [ 36 ] ; real_T
StateSpace_P7_Size [ 2 ] ; real_T StateSpace_P7 [ 36 ] ; real_T
StateSpace_P8_Size [ 2 ] ; real_T StateSpace_P8 [ 36 ] ; real_T
StateSpace_P9_Size [ 2 ] ; real_T StateSpace_P9 ; real_T StateSpace_P10_Size
[ 2 ] ; real_T StateSpace_P10 ; real_T R4_Gain ; real_T
Saturation_UpperSat_aqwzuangfk ; real_T Saturation_LowerSat_bcd3czsgyq ;
real_T R4_Gain_ckkisgzyfx ; real_T Saturation_UpperSat_i3x3oscagf ; real_T
Saturation_LowerSat_gnz45aadu0 ; real_T R4_Gain_dz5jfuhlfd ; real_T
Saturation_UpperSat_pcz043fnep ; real_T Saturation_LowerSat_b05y2t0vvl ;
real_T R4_Gain_nfptou1h22 ; real_T Saturation_UpperSat_luxvjfmfd3 ; real_T
Saturation_LowerSat_mqcesji40p ; real_T R4_Gain_e51nv5aiyc ; real_T
Saturation_UpperSat_p4wbgcsokm ; real_T Saturation_LowerSat_gdbbvpyvzg ;
real_T donotdeletethisgain_Gain ; real_T R_Gain ; real_T
donotdeletethisgain_Gain_o42imifl5k ; real_T R_Gain_g4gmpqe5wx ; real_T
donotdeletethisgain_Gain_fjipbfzkks ; real_T R_Gain_biqz0al5hr ; real_T
donotdeletethisgain_Gain_ave45anr4u ; real_T R_Gain_bq04dmcpzt ; real_T
donotdeletethisgain_Gain_dywzmacz1o ; real_T R_Gain_cwdppwgit4 ; real_T
Gain4_Gain ; real_T Gain1_Gain ; real_T Gain2_Gain ; real_T
Gain4_Gain_kh00znyazs ; real_T Gain1_Gain_og11bwmhu2 ; real_T
Gain2_Gain_m4x3vq3y1f ; real_T Gain4_Gain_fstjjgzlds ; real_T
Gain1_Gain_anymdqpqln ; real_T Gain2_Gain_jptbha03po ; real_T
Gain4_Gain_n2oajsg4xg ; real_T Gain1_Gain_baecfd2g1g ; real_T
Gain2_Gain_fe3eihrk0b ; real_T Gain4_Gain_j4eqtusam3 ; real_T
Gain1_Gain_dq4vkdpk0h ; real_T Gain2_Gain_of2pa5ka31 ; real_T
donotdeletethisgain_Gain_jslrw2wpeb ; real_T
donotdeletethisgain_Gain_hwxhghbjtm ; real_T Constant_Value_jorngiczgp ;
real_T Constant1_Value ; real_T Constant12_Value ; real_T Constant9_Value ;
real_T Constant1_Value_ks0gbwvaxk ; real_T Constant2_Value ; real_T
Constant3_Value ; real_T Constant4_Value ; real_T Constant_Value_fzmb45jy2r ;
real_T Constant1_Value_jelmmtr1rj ; real_T Constant12_Value_df3z3yuypl ;
real_T Constant9_Value_bfo0fnc5l1 ; real_T Constant1_Value_jxqfbvs00y ;
real_T Constant2_Value_nbkvr3eqsy ; real_T Constant3_Value_k030zkojhy ;
real_T Constant4_Value_p1xz0cpgth ; real_T Constant_Value_kiu123temw ; real_T
Constant1_Value_jj3f5fu3xp ; real_T Constant12_Value_ktnzmkcekm ; real_T
Constant9_Value_nhyzz1ckmw ; real_T Constant1_Value_gbfcrdkgqa ; real_T
Constant2_Value_gnk2tjoo5o ; real_T Constant3_Value_hat1prtoip ; real_T
Constant4_Value_cmgjzabbd1 ; real_T Constant_Value_em2zyolrnm ; real_T
Constant1_Value_myhrse5szs ; real_T Constant12_Value_jkrk5dvljw ; real_T
Constant9_Value_ffsooduwum ; real_T Constant1_Value_am3al2n15v ; real_T
Constant2_Value_odhbgl2n1s ; real_T Constant3_Value_mujtf1guv4 ; real_T
Constant4_Value_ohbtynzx54 ; real_T Constant_Value_pfu1thap3i ; real_T
Constant1_Value_h1thd4w1zg ; real_T Constant12_Value_oujd2whfki ; real_T
Constant9_Value_bcezbzp4a1 ; real_T Constant1_Value_ny1xdqiske ; real_T
Constant2_Value_ppmjeluned ; real_T Constant3_Value_kuyjih2run ; real_T
Constant4_Value_om2zghpbx3 ; real_T Constant2_Value_e4jyxae25b ; real_T
Constant3_Value_bkb3mktfvw ; real_T Constant6_Value ; real_T Constant7_Value
; real_T Constant8_Value ; real_T Constant9_Value_crabpzohh2 ; real_T
gate_Value ; real_T gate_Value_ghlgnnffhp ; real_T gate_Value_e2pzllcxv0 ;
real_T gate_Value_odvaswnitz ; real_T gate_Value_pf2c4dq35r ; real_T
gate_Value_a3a3irpdyg ; real_T gate_Value_bnwmvqs5lt ; real_T
gate_Value_poeni2w0ko ; real_T gate_Value_pp1t0xusap ; real_T
gate_Value_ibmjcspxwo ; real_T gate_Value_hrisjp3q0m ; real_T
gate_Value_gy4tkqzmme ; real_T gate_Value_hu4hogb4lk ; real_T
gate_Value_hob43axlzj ; real_T gate_Value_o02a13bzdb ; real_T
gate_Value_awsbj1udfy ; real_T gate_Value_lcm302k1d0 ; real_T
gate_Value_hzvnhzjbik ; } ; extern const char * RT_MEMORY_ALLOCATION_ERROR ;
extern B rtB ; extern X rtX ; extern DW rtDW ; extern PrevZCX rtPrevZCX ;
extern P rtP ; extern mxArray * mr_activeBalancing3_GetDWork ( ) ; extern
void mr_activeBalancing3_SetDWork ( const mxArray * ssDW ) ; extern mxArray *
mr_activeBalancing3_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * activeBalancing3_GetCAPIStaticMap ( void ) ;
extern SimStruct * const rtS ; extern const int_T gblNumToFiles ; extern
const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ; extern
rtInportTUtable * gblInportTUtables ; extern const char * gblInportFileName ;
extern const int_T gblNumRootInportBlks ; extern const int_T
gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ; extern
const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [ ] ;
extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
