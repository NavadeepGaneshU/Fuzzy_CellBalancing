  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtP)
    ;%
      section.nData     = 233;
      section.data(233)  = dumData; %prealloc
      
	  ;% rtP.Battery1_BatType
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtP.Battery2_BatType
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtP.Battery3_BatType
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtP.Battery4_BatType
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtP.Battery5_BatType
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtP.PWM_Period
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtP.PWM1_Period
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtP.PWM2_Period
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtP.PWM3_Period
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtP.PWM4_Period
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtP.PWM5_Period
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtP.OutputSamplePoints_Value
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtP.OutputSamplePoints_Value_bs0he10brt
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 112;
	
	  ;% rtP.OutputSamplePoints_Value_mmzz2j1vii
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 213;
	
	  ;% rtP.OutputSamplePoints_Value_h5oozv5nnj
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 314;
	
	  ;% rtP.OutputSamplePoints_Value_mkqnjleygm
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 415;
	
	  ;% rtP.OutputSamplePoints_Value_k42vy4v1xv
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 516;
	
	  ;% rtP.Constant_Value
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 617;
	
	  ;% rtP.Constant_Value_efypwvyyax
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 618;
	
	  ;% rtP.Constant_Value_ogegtmkzv0
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 619;
	
	  ;% rtP.Constant_Value_pbqzqfbpnm
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 620;
	
	  ;% rtP.Constant_Value_hu3rmuppbn
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 621;
	
	  ;% rtP.Constant_Value_h5irp45zuu
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 622;
	
	  ;% rtP.Constant_Value_bksqnhysc0
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 623;
	
	  ;% rtP.Constant_Value_owtewy0ssm
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 624;
	
	  ;% rtP.Constant_Value_k5pwul1wle
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 625;
	
	  ;% rtP.Constant_Value_kedzfrfegv
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 626;
	
	  ;% rtP.Constant_Value_opaksbgo21
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 627;
	
	  ;% rtP.Constant_Value_pp4lg2cwxs
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 628;
	
	  ;% rtP.Constant_Value_epq2rsx4ba
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 629;
	
	  ;% rtP.Constant_Value_h45zreb2fb
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 630;
	
	  ;% rtP.Constant_Value_khiqevv1tc
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 631;
	
	  ;% rtP.itinit1_InitialCondition
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 632;
	
	  ;% rtP.R2_Gain
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 633;
	
	  ;% rtP.Currentfilter_A
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 634;
	
	  ;% rtP.Currentfilter_C
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 635;
	
	  ;% rtP.itinit_InitialCondition
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 636;
	
	  ;% rtP.inti_UpperSat
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 637;
	
	  ;% rtP.inti_LowerSat
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 638;
	
	  ;% rtP.Gain_Gain
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 639;
	
	  ;% rtP.R3_Gain
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 640;
	
	  ;% rtP.Integrator2_IC
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 641;
	
	  ;% rtP.Saturation_UpperSat
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 642;
	
	  ;% rtP.Saturation_LowerSat
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 643;
	
	  ;% rtP.BAL_A
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 644;
	
	  ;% rtP.BAL_C
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 645;
	
	  ;% rtP.R1_Gain
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 646;
	
	  ;% rtP.itinit1_InitialCondition_l3j5mkh0dv
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 647;
	
	  ;% rtP.R2_Gain_jrqfqsl4vo
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 648;
	
	  ;% rtP.Currentfilter_A_hazdhojaym
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 649;
	
	  ;% rtP.Currentfilter_C_ldprzne4qv
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 650;
	
	  ;% rtP.itinit_InitialCondition_pv4h4vt0ps
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 651;
	
	  ;% rtP.inti_UpperSat_itldayqrxp
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 652;
	
	  ;% rtP.inti_LowerSat_lz3gh0icex
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 653;
	
	  ;% rtP.Gain_Gain_ozvwrv1fuy
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 654;
	
	  ;% rtP.R3_Gain_dgx1dntlxw
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 655;
	
	  ;% rtP.Integrator2_IC_finfcihmmt
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 656;
	
	  ;% rtP.Saturation_UpperSat_lxx4j3fnoa
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 657;
	
	  ;% rtP.Saturation_LowerSat_kwi433xk5g
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 658;
	
	  ;% rtP.BAL_A_cudqa1u03y
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 659;
	
	  ;% rtP.BAL_C_pnvzkp4ayj
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 660;
	
	  ;% rtP.R1_Gain_k1h1x1zryv
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 661;
	
	  ;% rtP.itinit1_InitialCondition_go30gfvhlp
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 662;
	
	  ;% rtP.R2_Gain_fij43s2whq
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 663;
	
	  ;% rtP.Currentfilter_A_pyl0ygpghg
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 664;
	
	  ;% rtP.Currentfilter_C_hx4sknoziy
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 665;
	
	  ;% rtP.itinit_InitialCondition_nf4pvnucgc
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 666;
	
	  ;% rtP.inti_UpperSat_nowwhgaxwk
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 667;
	
	  ;% rtP.inti_LowerSat_cwekkzbyq1
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 668;
	
	  ;% rtP.Gain_Gain_jbuudt1ftk
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 669;
	
	  ;% rtP.R3_Gain_de1tgv0zzw
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 670;
	
	  ;% rtP.Integrator2_IC_kqbwod02j2
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 671;
	
	  ;% rtP.Saturation_UpperSat_blj3ug4rzx
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 672;
	
	  ;% rtP.Saturation_LowerSat_o0i20janpw
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 673;
	
	  ;% rtP.BAL_A_n35zxahhei
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 674;
	
	  ;% rtP.BAL_C_ix2bm3qtha
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 675;
	
	  ;% rtP.R1_Gain_elo0441xsu
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 676;
	
	  ;% rtP.itinit1_InitialCondition_ia2mtm2bdv
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 677;
	
	  ;% rtP.R2_Gain_akgkexbqnd
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 678;
	
	  ;% rtP.Currentfilter_A_bsszjj1hem
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 679;
	
	  ;% rtP.Currentfilter_C_muylregegy
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 680;
	
	  ;% rtP.itinit_InitialCondition_atlhsczubb
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 681;
	
	  ;% rtP.inti_UpperSat_itde10ibkj
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 682;
	
	  ;% rtP.inti_LowerSat_nb1wwuftgl
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 683;
	
	  ;% rtP.Gain_Gain_l5lbde12wy
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 684;
	
	  ;% rtP.R3_Gain_nk0ujvzftk
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 685;
	
	  ;% rtP.Integrator2_IC_gtek0x1of0
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 686;
	
	  ;% rtP.Saturation_UpperSat_c0l2pkijii
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 687;
	
	  ;% rtP.Saturation_LowerSat_g1ovkjgj1x
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 688;
	
	  ;% rtP.BAL_A_jgidwk4hmh
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 689;
	
	  ;% rtP.BAL_C_hfghx3gysd
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 690;
	
	  ;% rtP.R1_Gain_ay3u4mrv4p
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 691;
	
	  ;% rtP.itinit1_InitialCondition_po45v3mmic
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 692;
	
	  ;% rtP.R2_Gain_axv50jbqfg
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 693;
	
	  ;% rtP.Currentfilter_A_o3r40a2fs0
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 694;
	
	  ;% rtP.Currentfilter_C_e5mev0pk52
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 695;
	
	  ;% rtP.itinit_InitialCondition_mh2yj0opxq
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 696;
	
	  ;% rtP.inti_UpperSat_ff0nysnmjy
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 697;
	
	  ;% rtP.inti_LowerSat_hzpmw3xl5s
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 698;
	
	  ;% rtP.Gain_Gain_a4qiy5rws3
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 699;
	
	  ;% rtP.R3_Gain_hslbhc5rsq
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 700;
	
	  ;% rtP.Integrator2_IC_iw5ohpmyuz
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 701;
	
	  ;% rtP.Saturation_UpperSat_dr1jmbb0we
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 702;
	
	  ;% rtP.Saturation_LowerSat_haspwmkdbs
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 703;
	
	  ;% rtP.BAL_A_oad34lr4nf
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 704;
	
	  ;% rtP.BAL_C_cq3wtorxkj
	  section.data(106).logicalSrcIdx = 105;
	  section.data(106).dtTransOffset = 705;
	
	  ;% rtP.R1_Gain_bdgjwewy0w
	  section.data(107).logicalSrcIdx = 106;
	  section.data(107).dtTransOffset = 706;
	
	  ;% rtP.StateSpace_P1_Size
	  section.data(108).logicalSrcIdx = 107;
	  section.data(108).dtTransOffset = 707;
	
	  ;% rtP.StateSpace_P1
	  section.data(109).logicalSrcIdx = 108;
	  section.data(109).dtTransOffset = 709;
	
	  ;% rtP.StateSpace_P2_Size
	  section.data(110).logicalSrcIdx = 109;
	  section.data(110).dtTransOffset = 5707;
	
	  ;% rtP.StateSpace_P2
	  section.data(111).logicalSrcIdx = 110;
	  section.data(111).dtTransOffset = 5709;
	
	  ;% rtP.StateSpace_P3_Size
	  section.data(112).logicalSrcIdx = 111;
	  section.data(112).dtTransOffset = 5713;
	
	  ;% rtP.StateSpace_P3
	  section.data(113).logicalSrcIdx = 112;
	  section.data(113).dtTransOffset = 5715;
	
	  ;% rtP.StateSpace_P4_Size
	  section.data(114).logicalSrcIdx = 113;
	  section.data(114).dtTransOffset = 5721;
	
	  ;% rtP.StateSpace_P4
	  section.data(115).logicalSrcIdx = 114;
	  section.data(115).dtTransOffset = 5723;
	
	  ;% rtP.StateSpace_P5_Size
	  section.data(116).logicalSrcIdx = 115;
	  section.data(116).dtTransOffset = 9701;
	
	  ;% rtP.StateSpace_P5
	  section.data(117).logicalSrcIdx = 116;
	  section.data(117).dtTransOffset = 9703;
	
	  ;% rtP.StateSpace_P6_Size
	  section.data(118).logicalSrcIdx = 117;
	  section.data(118).dtTransOffset = 9775;
	
	  ;% rtP.StateSpace_P6
	  section.data(119).logicalSrcIdx = 118;
	  section.data(119).dtTransOffset = 9777;
	
	  ;% rtP.StateSpace_P7_Size
	  section.data(120).logicalSrcIdx = 119;
	  section.data(120).dtTransOffset = 9813;
	
	  ;% rtP.StateSpace_P7
	  section.data(121).logicalSrcIdx = 120;
	  section.data(121).dtTransOffset = 9815;
	
	  ;% rtP.StateSpace_P8_Size
	  section.data(122).logicalSrcIdx = 121;
	  section.data(122).dtTransOffset = 9851;
	
	  ;% rtP.StateSpace_P8
	  section.data(123).logicalSrcIdx = 122;
	  section.data(123).dtTransOffset = 9853;
	
	  ;% rtP.StateSpace_P9_Size
	  section.data(124).logicalSrcIdx = 123;
	  section.data(124).dtTransOffset = 9889;
	
	  ;% rtP.StateSpace_P9
	  section.data(125).logicalSrcIdx = 124;
	  section.data(125).dtTransOffset = 9891;
	
	  ;% rtP.StateSpace_P10_Size
	  section.data(126).logicalSrcIdx = 125;
	  section.data(126).dtTransOffset = 9892;
	
	  ;% rtP.StateSpace_P10
	  section.data(127).logicalSrcIdx = 126;
	  section.data(127).dtTransOffset = 9894;
	
	  ;% rtP.R4_Gain
	  section.data(128).logicalSrcIdx = 127;
	  section.data(128).dtTransOffset = 9895;
	
	  ;% rtP.Saturation_UpperSat_aqwzuangfk
	  section.data(129).logicalSrcIdx = 128;
	  section.data(129).dtTransOffset = 9896;
	
	  ;% rtP.Saturation_LowerSat_bcd3czsgyq
	  section.data(130).logicalSrcIdx = 129;
	  section.data(130).dtTransOffset = 9897;
	
	  ;% rtP.R4_Gain_ckkisgzyfx
	  section.data(131).logicalSrcIdx = 130;
	  section.data(131).dtTransOffset = 9898;
	
	  ;% rtP.Saturation_UpperSat_i3x3oscagf
	  section.data(132).logicalSrcIdx = 131;
	  section.data(132).dtTransOffset = 9899;
	
	  ;% rtP.Saturation_LowerSat_gnz45aadu0
	  section.data(133).logicalSrcIdx = 132;
	  section.data(133).dtTransOffset = 9900;
	
	  ;% rtP.R4_Gain_dz5jfuhlfd
	  section.data(134).logicalSrcIdx = 133;
	  section.data(134).dtTransOffset = 9901;
	
	  ;% rtP.Saturation_UpperSat_pcz043fnep
	  section.data(135).logicalSrcIdx = 134;
	  section.data(135).dtTransOffset = 9902;
	
	  ;% rtP.Saturation_LowerSat_b05y2t0vvl
	  section.data(136).logicalSrcIdx = 135;
	  section.data(136).dtTransOffset = 9903;
	
	  ;% rtP.R4_Gain_nfptou1h22
	  section.data(137).logicalSrcIdx = 136;
	  section.data(137).dtTransOffset = 9904;
	
	  ;% rtP.Saturation_UpperSat_luxvjfmfd3
	  section.data(138).logicalSrcIdx = 137;
	  section.data(138).dtTransOffset = 9905;
	
	  ;% rtP.Saturation_LowerSat_mqcesji40p
	  section.data(139).logicalSrcIdx = 138;
	  section.data(139).dtTransOffset = 9906;
	
	  ;% rtP.R4_Gain_e51nv5aiyc
	  section.data(140).logicalSrcIdx = 139;
	  section.data(140).dtTransOffset = 9907;
	
	  ;% rtP.Saturation_UpperSat_p4wbgcsokm
	  section.data(141).logicalSrcIdx = 140;
	  section.data(141).dtTransOffset = 9908;
	
	  ;% rtP.Saturation_LowerSat_gdbbvpyvzg
	  section.data(142).logicalSrcIdx = 141;
	  section.data(142).dtTransOffset = 9909;
	
	  ;% rtP.donotdeletethisgain_Gain
	  section.data(143).logicalSrcIdx = 142;
	  section.data(143).dtTransOffset = 9910;
	
	  ;% rtP.R_Gain
	  section.data(144).logicalSrcIdx = 143;
	  section.data(144).dtTransOffset = 9911;
	
	  ;% rtP.donotdeletethisgain_Gain_o42imifl5k
	  section.data(145).logicalSrcIdx = 144;
	  section.data(145).dtTransOffset = 9912;
	
	  ;% rtP.R_Gain_g4gmpqe5wx
	  section.data(146).logicalSrcIdx = 145;
	  section.data(146).dtTransOffset = 9913;
	
	  ;% rtP.donotdeletethisgain_Gain_fjipbfzkks
	  section.data(147).logicalSrcIdx = 146;
	  section.data(147).dtTransOffset = 9914;
	
	  ;% rtP.R_Gain_biqz0al5hr
	  section.data(148).logicalSrcIdx = 147;
	  section.data(148).dtTransOffset = 9915;
	
	  ;% rtP.donotdeletethisgain_Gain_ave45anr4u
	  section.data(149).logicalSrcIdx = 148;
	  section.data(149).dtTransOffset = 9916;
	
	  ;% rtP.R_Gain_bq04dmcpzt
	  section.data(150).logicalSrcIdx = 149;
	  section.data(150).dtTransOffset = 9917;
	
	  ;% rtP.donotdeletethisgain_Gain_dywzmacz1o
	  section.data(151).logicalSrcIdx = 150;
	  section.data(151).dtTransOffset = 9918;
	
	  ;% rtP.R_Gain_cwdppwgit4
	  section.data(152).logicalSrcIdx = 151;
	  section.data(152).dtTransOffset = 9919;
	
	  ;% rtP.Gain4_Gain
	  section.data(153).logicalSrcIdx = 152;
	  section.data(153).dtTransOffset = 9920;
	
	  ;% rtP.Gain1_Gain
	  section.data(154).logicalSrcIdx = 153;
	  section.data(154).dtTransOffset = 9921;
	
	  ;% rtP.Gain2_Gain
	  section.data(155).logicalSrcIdx = 154;
	  section.data(155).dtTransOffset = 9922;
	
	  ;% rtP.Gain4_Gain_kh00znyazs
	  section.data(156).logicalSrcIdx = 155;
	  section.data(156).dtTransOffset = 9923;
	
	  ;% rtP.Gain1_Gain_og11bwmhu2
	  section.data(157).logicalSrcIdx = 156;
	  section.data(157).dtTransOffset = 9924;
	
	  ;% rtP.Gain2_Gain_m4x3vq3y1f
	  section.data(158).logicalSrcIdx = 157;
	  section.data(158).dtTransOffset = 9925;
	
	  ;% rtP.Gain4_Gain_fstjjgzlds
	  section.data(159).logicalSrcIdx = 158;
	  section.data(159).dtTransOffset = 9926;
	
	  ;% rtP.Gain1_Gain_anymdqpqln
	  section.data(160).logicalSrcIdx = 159;
	  section.data(160).dtTransOffset = 9927;
	
	  ;% rtP.Gain2_Gain_jptbha03po
	  section.data(161).logicalSrcIdx = 160;
	  section.data(161).dtTransOffset = 9928;
	
	  ;% rtP.Gain4_Gain_n2oajsg4xg
	  section.data(162).logicalSrcIdx = 161;
	  section.data(162).dtTransOffset = 9929;
	
	  ;% rtP.Gain1_Gain_baecfd2g1g
	  section.data(163).logicalSrcIdx = 162;
	  section.data(163).dtTransOffset = 9930;
	
	  ;% rtP.Gain2_Gain_fe3eihrk0b
	  section.data(164).logicalSrcIdx = 163;
	  section.data(164).dtTransOffset = 9931;
	
	  ;% rtP.Gain4_Gain_j4eqtusam3
	  section.data(165).logicalSrcIdx = 164;
	  section.data(165).dtTransOffset = 9932;
	
	  ;% rtP.Gain1_Gain_dq4vkdpk0h
	  section.data(166).logicalSrcIdx = 165;
	  section.data(166).dtTransOffset = 9933;
	
	  ;% rtP.Gain2_Gain_of2pa5ka31
	  section.data(167).logicalSrcIdx = 166;
	  section.data(167).dtTransOffset = 9934;
	
	  ;% rtP.donotdeletethisgain_Gain_jslrw2wpeb
	  section.data(168).logicalSrcIdx = 167;
	  section.data(168).dtTransOffset = 9935;
	
	  ;% rtP.donotdeletethisgain_Gain_hwxhghbjtm
	  section.data(169).logicalSrcIdx = 168;
	  section.data(169).dtTransOffset = 9936;
	
	  ;% rtP.Constant_Value_jorngiczgp
	  section.data(170).logicalSrcIdx = 169;
	  section.data(170).dtTransOffset = 9937;
	
	  ;% rtP.Constant1_Value
	  section.data(171).logicalSrcIdx = 170;
	  section.data(171).dtTransOffset = 9938;
	
	  ;% rtP.Constant12_Value
	  section.data(172).logicalSrcIdx = 171;
	  section.data(172).dtTransOffset = 9939;
	
	  ;% rtP.Constant9_Value
	  section.data(173).logicalSrcIdx = 172;
	  section.data(173).dtTransOffset = 9940;
	
	  ;% rtP.Constant1_Value_ks0gbwvaxk
	  section.data(174).logicalSrcIdx = 173;
	  section.data(174).dtTransOffset = 9941;
	
	  ;% rtP.Constant2_Value
	  section.data(175).logicalSrcIdx = 174;
	  section.data(175).dtTransOffset = 9942;
	
	  ;% rtP.Constant3_Value
	  section.data(176).logicalSrcIdx = 175;
	  section.data(176).dtTransOffset = 9943;
	
	  ;% rtP.Constant4_Value
	  section.data(177).logicalSrcIdx = 176;
	  section.data(177).dtTransOffset = 9944;
	
	  ;% rtP.Constant_Value_fzmb45jy2r
	  section.data(178).logicalSrcIdx = 177;
	  section.data(178).dtTransOffset = 9945;
	
	  ;% rtP.Constant1_Value_jelmmtr1rj
	  section.data(179).logicalSrcIdx = 178;
	  section.data(179).dtTransOffset = 9946;
	
	  ;% rtP.Constant12_Value_df3z3yuypl
	  section.data(180).logicalSrcIdx = 179;
	  section.data(180).dtTransOffset = 9947;
	
	  ;% rtP.Constant9_Value_bfo0fnc5l1
	  section.data(181).logicalSrcIdx = 180;
	  section.data(181).dtTransOffset = 9948;
	
	  ;% rtP.Constant1_Value_jxqfbvs00y
	  section.data(182).logicalSrcIdx = 181;
	  section.data(182).dtTransOffset = 9949;
	
	  ;% rtP.Constant2_Value_nbkvr3eqsy
	  section.data(183).logicalSrcIdx = 182;
	  section.data(183).dtTransOffset = 9950;
	
	  ;% rtP.Constant3_Value_k030zkojhy
	  section.data(184).logicalSrcIdx = 183;
	  section.data(184).dtTransOffset = 9951;
	
	  ;% rtP.Constant4_Value_p1xz0cpgth
	  section.data(185).logicalSrcIdx = 184;
	  section.data(185).dtTransOffset = 9952;
	
	  ;% rtP.Constant_Value_kiu123temw
	  section.data(186).logicalSrcIdx = 185;
	  section.data(186).dtTransOffset = 9953;
	
	  ;% rtP.Constant1_Value_jj3f5fu3xp
	  section.data(187).logicalSrcIdx = 186;
	  section.data(187).dtTransOffset = 9954;
	
	  ;% rtP.Constant12_Value_ktnzmkcekm
	  section.data(188).logicalSrcIdx = 187;
	  section.data(188).dtTransOffset = 9955;
	
	  ;% rtP.Constant9_Value_nhyzz1ckmw
	  section.data(189).logicalSrcIdx = 188;
	  section.data(189).dtTransOffset = 9956;
	
	  ;% rtP.Constant1_Value_gbfcrdkgqa
	  section.data(190).logicalSrcIdx = 189;
	  section.data(190).dtTransOffset = 9957;
	
	  ;% rtP.Constant2_Value_gnk2tjoo5o
	  section.data(191).logicalSrcIdx = 190;
	  section.data(191).dtTransOffset = 9958;
	
	  ;% rtP.Constant3_Value_hat1prtoip
	  section.data(192).logicalSrcIdx = 191;
	  section.data(192).dtTransOffset = 9959;
	
	  ;% rtP.Constant4_Value_cmgjzabbd1
	  section.data(193).logicalSrcIdx = 192;
	  section.data(193).dtTransOffset = 9960;
	
	  ;% rtP.Constant_Value_em2zyolrnm
	  section.data(194).logicalSrcIdx = 193;
	  section.data(194).dtTransOffset = 9961;
	
	  ;% rtP.Constant1_Value_myhrse5szs
	  section.data(195).logicalSrcIdx = 194;
	  section.data(195).dtTransOffset = 9962;
	
	  ;% rtP.Constant12_Value_jkrk5dvljw
	  section.data(196).logicalSrcIdx = 195;
	  section.data(196).dtTransOffset = 9963;
	
	  ;% rtP.Constant9_Value_ffsooduwum
	  section.data(197).logicalSrcIdx = 196;
	  section.data(197).dtTransOffset = 9964;
	
	  ;% rtP.Constant1_Value_am3al2n15v
	  section.data(198).logicalSrcIdx = 197;
	  section.data(198).dtTransOffset = 9965;
	
	  ;% rtP.Constant2_Value_odhbgl2n1s
	  section.data(199).logicalSrcIdx = 198;
	  section.data(199).dtTransOffset = 9966;
	
	  ;% rtP.Constant3_Value_mujtf1guv4
	  section.data(200).logicalSrcIdx = 199;
	  section.data(200).dtTransOffset = 9967;
	
	  ;% rtP.Constant4_Value_ohbtynzx54
	  section.data(201).logicalSrcIdx = 200;
	  section.data(201).dtTransOffset = 9968;
	
	  ;% rtP.Constant_Value_pfu1thap3i
	  section.data(202).logicalSrcIdx = 201;
	  section.data(202).dtTransOffset = 9969;
	
	  ;% rtP.Constant1_Value_h1thd4w1zg
	  section.data(203).logicalSrcIdx = 202;
	  section.data(203).dtTransOffset = 9970;
	
	  ;% rtP.Constant12_Value_oujd2whfki
	  section.data(204).logicalSrcIdx = 203;
	  section.data(204).dtTransOffset = 9971;
	
	  ;% rtP.Constant9_Value_bcezbzp4a1
	  section.data(205).logicalSrcIdx = 204;
	  section.data(205).dtTransOffset = 9972;
	
	  ;% rtP.Constant1_Value_ny1xdqiske
	  section.data(206).logicalSrcIdx = 205;
	  section.data(206).dtTransOffset = 9973;
	
	  ;% rtP.Constant2_Value_ppmjeluned
	  section.data(207).logicalSrcIdx = 206;
	  section.data(207).dtTransOffset = 9974;
	
	  ;% rtP.Constant3_Value_kuyjih2run
	  section.data(208).logicalSrcIdx = 207;
	  section.data(208).dtTransOffset = 9975;
	
	  ;% rtP.Constant4_Value_om2zghpbx3
	  section.data(209).logicalSrcIdx = 208;
	  section.data(209).dtTransOffset = 9976;
	
	  ;% rtP.Constant2_Value_e4jyxae25b
	  section.data(210).logicalSrcIdx = 209;
	  section.data(210).dtTransOffset = 9977;
	
	  ;% rtP.Constant3_Value_bkb3mktfvw
	  section.data(211).logicalSrcIdx = 210;
	  section.data(211).dtTransOffset = 9978;
	
	  ;% rtP.Constant6_Value
	  section.data(212).logicalSrcIdx = 211;
	  section.data(212).dtTransOffset = 9979;
	
	  ;% rtP.Constant7_Value
	  section.data(213).logicalSrcIdx = 212;
	  section.data(213).dtTransOffset = 9980;
	
	  ;% rtP.Constant8_Value
	  section.data(214).logicalSrcIdx = 213;
	  section.data(214).dtTransOffset = 9981;
	
	  ;% rtP.Constant9_Value_crabpzohh2
	  section.data(215).logicalSrcIdx = 214;
	  section.data(215).dtTransOffset = 9982;
	
	  ;% rtP.gate_Value
	  section.data(216).logicalSrcIdx = 215;
	  section.data(216).dtTransOffset = 9983;
	
	  ;% rtP.gate_Value_ghlgnnffhp
	  section.data(217).logicalSrcIdx = 216;
	  section.data(217).dtTransOffset = 9984;
	
	  ;% rtP.gate_Value_e2pzllcxv0
	  section.data(218).logicalSrcIdx = 217;
	  section.data(218).dtTransOffset = 9985;
	
	  ;% rtP.gate_Value_odvaswnitz
	  section.data(219).logicalSrcIdx = 218;
	  section.data(219).dtTransOffset = 9986;
	
	  ;% rtP.gate_Value_pf2c4dq35r
	  section.data(220).logicalSrcIdx = 219;
	  section.data(220).dtTransOffset = 9987;
	
	  ;% rtP.gate_Value_a3a3irpdyg
	  section.data(221).logicalSrcIdx = 220;
	  section.data(221).dtTransOffset = 9988;
	
	  ;% rtP.gate_Value_bnwmvqs5lt
	  section.data(222).logicalSrcIdx = 221;
	  section.data(222).dtTransOffset = 9989;
	
	  ;% rtP.gate_Value_poeni2w0ko
	  section.data(223).logicalSrcIdx = 222;
	  section.data(223).dtTransOffset = 9990;
	
	  ;% rtP.gate_Value_pp1t0xusap
	  section.data(224).logicalSrcIdx = 223;
	  section.data(224).dtTransOffset = 9991;
	
	  ;% rtP.gate_Value_ibmjcspxwo
	  section.data(225).logicalSrcIdx = 224;
	  section.data(225).dtTransOffset = 9992;
	
	  ;% rtP.gate_Value_hrisjp3q0m
	  section.data(226).logicalSrcIdx = 225;
	  section.data(226).dtTransOffset = 9993;
	
	  ;% rtP.gate_Value_gy4tkqzmme
	  section.data(227).logicalSrcIdx = 226;
	  section.data(227).dtTransOffset = 9994;
	
	  ;% rtP.gate_Value_hu4hogb4lk
	  section.data(228).logicalSrcIdx = 227;
	  section.data(228).dtTransOffset = 9995;
	
	  ;% rtP.gate_Value_hob43axlzj
	  section.data(229).logicalSrcIdx = 228;
	  section.data(229).dtTransOffset = 9996;
	
	  ;% rtP.gate_Value_o02a13bzdb
	  section.data(230).logicalSrcIdx = 229;
	  section.data(230).dtTransOffset = 9997;
	
	  ;% rtP.gate_Value_awsbj1udfy
	  section.data(231).logicalSrcIdx = 230;
	  section.data(231).dtTransOffset = 9998;
	
	  ;% rtP.gate_Value_lcm302k1d0
	  section.data(232).logicalSrcIdx = 231;
	  section.data(232).dtTransOffset = 9999;
	
	  ;% rtP.gate_Value_hzvnhzjbik
	  section.data(233).logicalSrcIdx = 232;
	  section.data(233).dtTransOffset = 10000;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 8;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtB)
    ;%
      section.nData     = 263;
      section.data(263)  = dumData; %prealloc
      
	  ;% rtB.ldokaf3uyj
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.hitd4jbxxo
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.g3cnit1gts
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtB.lssfzuya44
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtB.patx3e3lyu
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtB.o3tagh4era
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtB.iyrb00kscp
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtB.mpjucudbtk
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtB.cgbzrrdvnj
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtB.apptu0x5zl
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtB.j04p5reu3p
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtB.cklmpkcmxr
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtB.gwc4gctvfb
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtB.if50jzplnu
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtB.khbkyi2o4w
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtB.pabcbevt20
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtB.pqzrrvf1s1
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtB.p4p2fahxpn
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtB.n0wyyiyl2w
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtB.bjzh2zswrf
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtB.dvd3eelqxy
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtB.htgwxujgfn
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtB.ipzhuu4ptw
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtB.mxtffwnyug
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtB.olx2nutnfv
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtB.iadrygzp4x
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtB.fd3qiys2ps
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtB.mkvq5xwqnm
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtB.biwszoosgc
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtB.cd5jv3welm
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtB.pse0v0upak
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtB.j1vwznyubj
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtB.nqwiqvxip0
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtB.me3a54u35r
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtB.fj5f5uf5pw
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 34;
	
	  ;% rtB.gjz4ggefl2
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 35;
	
	  ;% rtB.gukj05tcnp
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 36;
	
	  ;% rtB.hr1ymwwo43
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 37;
	
	  ;% rtB.hcjtzzfngx
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 38;
	
	  ;% rtB.izpbloaset
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 39;
	
	  ;% rtB.af10lxjheq
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 40;
	
	  ;% rtB.oomylrj2ck
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 41;
	
	  ;% rtB.dawtfnjz3t
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 42;
	
	  ;% rtB.aqn3egakkx
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 43;
	
	  ;% rtB.f2scb5rf13
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 44;
	
	  ;% rtB.ja533qrntz
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 45;
	
	  ;% rtB.b5ot5krztj
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 46;
	
	  ;% rtB.dsgitwjsjs
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 47;
	
	  ;% rtB.bjsmudeh15
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 48;
	
	  ;% rtB.lnjfdccy2h
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 49;
	
	  ;% rtB.pgstoxbe4q
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 50;
	
	  ;% rtB.n5erhw4hry
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 51;
	
	  ;% rtB.al5llquoyw
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 52;
	
	  ;% rtB.olt2mencvc
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 53;
	
	  ;% rtB.fwpjmaqmyl
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 54;
	
	  ;% rtB.iacqlbe2tg
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 55;
	
	  ;% rtB.fbim3ivtyq
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 56;
	
	  ;% rtB.inr0z52r4v
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 57;
	
	  ;% rtB.jrt1dp0uea
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 58;
	
	  ;% rtB.onxjmnda4f
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 59;
	
	  ;% rtB.atav4hz2t0
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 60;
	
	  ;% rtB.lhhtg1palw
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 61;
	
	  ;% rtB.cwlnlciysh
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 62;
	
	  ;% rtB.k0tidcedyr
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 63;
	
	  ;% rtB.cahmoz3lmb
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 64;
	
	  ;% rtB.ctz0crt1lg
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 65;
	
	  ;% rtB.oc0dumgulu
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 66;
	
	  ;% rtB.ebcqidfawa
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 67;
	
	  ;% rtB.jlrqkf40e4
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 68;
	
	  ;% rtB.hmnedoi5ok
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 69;
	
	  ;% rtB.bvviu2o2gh
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 70;
	
	  ;% rtB.lfgqqylnmm
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 71;
	
	  ;% rtB.pmwqhxrjfr
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 72;
	
	  ;% rtB.nw2inaond5
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 73;
	
	  ;% rtB.crm3deon3z
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 74;
	
	  ;% rtB.nocrqzmy3a
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 75;
	
	  ;% rtB.h3gzco2fqa
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 76;
	
	  ;% rtB.oocd2yqorm
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 77;
	
	  ;% rtB.e0au3fw2j3
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 78;
	
	  ;% rtB.aprnkbzhsq
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 79;
	
	  ;% rtB.fmzs5132om
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 80;
	
	  ;% rtB.nqjaq0ah0p
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 81;
	
	  ;% rtB.jgxdelnl3s
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 82;
	
	  ;% rtB.nfrth1ueqb
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 83;
	
	  ;% rtB.gomqwjxzd5
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 84;
	
	  ;% rtB.knag0fuf4e
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 85;
	
	  ;% rtB.ngfkb5ghae
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 86;
	
	  ;% rtB.mt1bcogztp
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 87;
	
	  ;% rtB.bs00yavsbm
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 88;
	
	  ;% rtB.eacgl4yov2
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 89;
	
	  ;% rtB.orwu5t0tyg
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 90;
	
	  ;% rtB.imwf4qbc3k
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 91;
	
	  ;% rtB.n5szlr3nqx
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 92;
	
	  ;% rtB.cngflnzqr2
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 93;
	
	  ;% rtB.nwootfl0wl
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 94;
	
	  ;% rtB.hjgu4nxp5v
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 95;
	
	  ;% rtB.a1pwur2f3n
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 96;
	
	  ;% rtB.gjgshqegfr
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 97;
	
	  ;% rtB.lehkr3fuer
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 98;
	
	  ;% rtB.e42dsovuoz
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 99;
	
	  ;% rtB.ermmdxeqvq
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 100;
	
	  ;% rtB.f5toqxhshz
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 101;
	
	  ;% rtB.bcqp5bw5m5
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 102;
	
	  ;% rtB.mymfehhqyf
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 103;
	
	  ;% rtB.dkrfxtvrav
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 104;
	
	  ;% rtB.psl1pylfxp
	  section.data(106).logicalSrcIdx = 105;
	  section.data(106).dtTransOffset = 105;
	
	  ;% rtB.ggcp4lpehl
	  section.data(107).logicalSrcIdx = 106;
	  section.data(107).dtTransOffset = 106;
	
	  ;% rtB.mxu3fd52lg
	  section.data(108).logicalSrcIdx = 107;
	  section.data(108).dtTransOffset = 107;
	
	  ;% rtB.j1rfmexczt
	  section.data(109).logicalSrcIdx = 108;
	  section.data(109).dtTransOffset = 108;
	
	  ;% rtB.enfj1pjw2o
	  section.data(110).logicalSrcIdx = 109;
	  section.data(110).dtTransOffset = 109;
	
	  ;% rtB.nawqkqqhwd
	  section.data(111).logicalSrcIdx = 110;
	  section.data(111).dtTransOffset = 110;
	
	  ;% rtB.gy2pn1xoxf
	  section.data(112).logicalSrcIdx = 111;
	  section.data(112).dtTransOffset = 111;
	
	  ;% rtB.oihkxrrgl0
	  section.data(113).logicalSrcIdx = 112;
	  section.data(113).dtTransOffset = 112;
	
	  ;% rtB.neo3wgh5k0
	  section.data(114).logicalSrcIdx = 113;
	  section.data(114).dtTransOffset = 113;
	
	  ;% rtB.b05wxiklmy
	  section.data(115).logicalSrcIdx = 114;
	  section.data(115).dtTransOffset = 114;
	
	  ;% rtB.gzwwnxifap
	  section.data(116).logicalSrcIdx = 115;
	  section.data(116).dtTransOffset = 115;
	
	  ;% rtB.e4hlm2rw4k
	  section.data(117).logicalSrcIdx = 116;
	  section.data(117).dtTransOffset = 122;
	
	  ;% rtB.dnpga1izxq
	  section.data(118).logicalSrcIdx = 117;
	  section.data(118).dtTransOffset = 194;
	
	  ;% rtB.mharr3pkm3
	  section.data(119).logicalSrcIdx = 118;
	  section.data(119).dtTransOffset = 195;
	
	  ;% rtB.c1cjcg0vdp
	  section.data(120).logicalSrcIdx = 119;
	  section.data(120).dtTransOffset = 196;
	
	  ;% rtB.anodlblzme
	  section.data(121).logicalSrcIdx = 120;
	  section.data(121).dtTransOffset = 197;
	
	  ;% rtB.cszbfywqst
	  section.data(122).logicalSrcIdx = 121;
	  section.data(122).dtTransOffset = 198;
	
	  ;% rtB.lt0d3owsjr
	  section.data(123).logicalSrcIdx = 122;
	  section.data(123).dtTransOffset = 199;
	
	  ;% rtB.i2s0aqv5oj
	  section.data(124).logicalSrcIdx = 123;
	  section.data(124).dtTransOffset = 200;
	
	  ;% rtB.c4edbm3lnu
	  section.data(125).logicalSrcIdx = 124;
	  section.data(125).dtTransOffset = 201;
	
	  ;% rtB.mnn2sdpcg2
	  section.data(126).logicalSrcIdx = 125;
	  section.data(126).dtTransOffset = 202;
	
	  ;% rtB.czbyl5orjk
	  section.data(127).logicalSrcIdx = 126;
	  section.data(127).dtTransOffset = 203;
	
	  ;% rtB.jkh0lpzdyl
	  section.data(128).logicalSrcIdx = 127;
	  section.data(128).dtTransOffset = 204;
	
	  ;% rtB.m5q0x4yj0k
	  section.data(129).logicalSrcIdx = 128;
	  section.data(129).dtTransOffset = 205;
	
	  ;% rtB.ccjxi5v2q0
	  section.data(130).logicalSrcIdx = 129;
	  section.data(130).dtTransOffset = 206;
	
	  ;% rtB.cw0w1vgwxh
	  section.data(131).logicalSrcIdx = 130;
	  section.data(131).dtTransOffset = 207;
	
	  ;% rtB.pcrjjj3bl2
	  section.data(132).logicalSrcIdx = 131;
	  section.data(132).dtTransOffset = 208;
	
	  ;% rtB.bmkbfj44hc
	  section.data(133).logicalSrcIdx = 132;
	  section.data(133).dtTransOffset = 209;
	
	  ;% rtB.fngvfw2vbc
	  section.data(134).logicalSrcIdx = 133;
	  section.data(134).dtTransOffset = 210;
	
	  ;% rtB.mgwtedhsbf
	  section.data(135).logicalSrcIdx = 134;
	  section.data(135).dtTransOffset = 211;
	
	  ;% rtB.gsugcfegmq
	  section.data(136).logicalSrcIdx = 135;
	  section.data(136).dtTransOffset = 212;
	
	  ;% rtB.nh3tyegvgp
	  section.data(137).logicalSrcIdx = 136;
	  section.data(137).dtTransOffset = 213;
	
	  ;% rtB.hjlmg51yd0
	  section.data(138).logicalSrcIdx = 137;
	  section.data(138).dtTransOffset = 214;
	
	  ;% rtB.a1xkvgib3c
	  section.data(139).logicalSrcIdx = 138;
	  section.data(139).dtTransOffset = 215;
	
	  ;% rtB.dip4hm3fie
	  section.data(140).logicalSrcIdx = 139;
	  section.data(140).dtTransOffset = 216;
	
	  ;% rtB.gu2lxqjoee
	  section.data(141).logicalSrcIdx = 140;
	  section.data(141).dtTransOffset = 217;
	
	  ;% rtB.glfgd2gxlp
	  section.data(142).logicalSrcIdx = 141;
	  section.data(142).dtTransOffset = 218;
	
	  ;% rtB.fntfm0klq3
	  section.data(143).logicalSrcIdx = 142;
	  section.data(143).dtTransOffset = 219;
	
	  ;% rtB.dzdzcnn4k1
	  section.data(144).logicalSrcIdx = 143;
	  section.data(144).dtTransOffset = 220;
	
	  ;% rtB.otjjwnfbam
	  section.data(145).logicalSrcIdx = 144;
	  section.data(145).dtTransOffset = 221;
	
	  ;% rtB.f4hgeqqzrq
	  section.data(146).logicalSrcIdx = 145;
	  section.data(146).dtTransOffset = 222;
	
	  ;% rtB.pch3fntlad
	  section.data(147).logicalSrcIdx = 146;
	  section.data(147).dtTransOffset = 223;
	
	  ;% rtB.eiotr3cj2j
	  section.data(148).logicalSrcIdx = 147;
	  section.data(148).dtTransOffset = 224;
	
	  ;% rtB.ooqdf4csin
	  section.data(149).logicalSrcIdx = 148;
	  section.data(149).dtTransOffset = 225;
	
	  ;% rtB.deezhakrkc
	  section.data(150).logicalSrcIdx = 149;
	  section.data(150).dtTransOffset = 226;
	
	  ;% rtB.i0ea205hal
	  section.data(151).logicalSrcIdx = 150;
	  section.data(151).dtTransOffset = 227;
	
	  ;% rtB.be32mwjpny
	  section.data(152).logicalSrcIdx = 151;
	  section.data(152).dtTransOffset = 228;
	
	  ;% rtB.aqgrfvolcg
	  section.data(153).logicalSrcIdx = 152;
	  section.data(153).dtTransOffset = 229;
	
	  ;% rtB.bdqvl4emoj
	  section.data(154).logicalSrcIdx = 153;
	  section.data(154).dtTransOffset = 230;
	
	  ;% rtB.niay40fjqf
	  section.data(155).logicalSrcIdx = 154;
	  section.data(155).dtTransOffset = 231;
	
	  ;% rtB.c51nh4xf1q
	  section.data(156).logicalSrcIdx = 155;
	  section.data(156).dtTransOffset = 232;
	
	  ;% rtB.jv5t3iflfp
	  section.data(157).logicalSrcIdx = 156;
	  section.data(157).dtTransOffset = 233;
	
	  ;% rtB.cdukvsxdzj
	  section.data(158).logicalSrcIdx = 157;
	  section.data(158).dtTransOffset = 234;
	
	  ;% rtB.hjnfpefc4k
	  section.data(159).logicalSrcIdx = 158;
	  section.data(159).dtTransOffset = 235;
	
	  ;% rtB.dfsyb51tzv
	  section.data(160).logicalSrcIdx = 159;
	  section.data(160).dtTransOffset = 236;
	
	  ;% rtB.nka52w5p2z
	  section.data(161).logicalSrcIdx = 160;
	  section.data(161).dtTransOffset = 237;
	
	  ;% rtB.hkcf5uul0d
	  section.data(162).logicalSrcIdx = 161;
	  section.data(162).dtTransOffset = 238;
	
	  ;% rtB.ad5v3ototp
	  section.data(163).logicalSrcIdx = 162;
	  section.data(163).dtTransOffset = 239;
	
	  ;% rtB.nhbww2xvcr
	  section.data(164).logicalSrcIdx = 163;
	  section.data(164).dtTransOffset = 240;
	
	  ;% rtB.jxi4eauchh
	  section.data(165).logicalSrcIdx = 164;
	  section.data(165).dtTransOffset = 241;
	
	  ;% rtB.cfafquv2xr
	  section.data(166).logicalSrcIdx = 165;
	  section.data(166).dtTransOffset = 242;
	
	  ;% rtB.fmprtpx12v
	  section.data(167).logicalSrcIdx = 166;
	  section.data(167).dtTransOffset = 243;
	
	  ;% rtB.gn1ehycyi2
	  section.data(168).logicalSrcIdx = 167;
	  section.data(168).dtTransOffset = 244;
	
	  ;% rtB.ofqxlds3eh
	  section.data(169).logicalSrcIdx = 168;
	  section.data(169).dtTransOffset = 245;
	
	  ;% rtB.byqwyjabue
	  section.data(170).logicalSrcIdx = 169;
	  section.data(170).dtTransOffset = 246;
	
	  ;% rtB.kz5y1t5h5o
	  section.data(171).logicalSrcIdx = 170;
	  section.data(171).dtTransOffset = 247;
	
	  ;% rtB.h4lwnoqm5x
	  section.data(172).logicalSrcIdx = 171;
	  section.data(172).dtTransOffset = 248;
	
	  ;% rtB.l0fygtafkq
	  section.data(173).logicalSrcIdx = 172;
	  section.data(173).dtTransOffset = 249;
	
	  ;% rtB.nsz3sakdbs
	  section.data(174).logicalSrcIdx = 173;
	  section.data(174).dtTransOffset = 250;
	
	  ;% rtB.nszpfs0j4c
	  section.data(175).logicalSrcIdx = 174;
	  section.data(175).dtTransOffset = 251;
	
	  ;% rtB.aqj5tzxay2
	  section.data(176).logicalSrcIdx = 175;
	  section.data(176).dtTransOffset = 252;
	
	  ;% rtB.pzkcy4pfea
	  section.data(177).logicalSrcIdx = 176;
	  section.data(177).dtTransOffset = 253;
	
	  ;% rtB.gbmzzjn501
	  section.data(178).logicalSrcIdx = 177;
	  section.data(178).dtTransOffset = 254;
	
	  ;% rtB.cxzbwqcn1v
	  section.data(179).logicalSrcIdx = 178;
	  section.data(179).dtTransOffset = 255;
	
	  ;% rtB.kwlwx42yav
	  section.data(180).logicalSrcIdx = 179;
	  section.data(180).dtTransOffset = 256;
	
	  ;% rtB.cjyi1ugvfp
	  section.data(181).logicalSrcIdx = 180;
	  section.data(181).dtTransOffset = 257;
	
	  ;% rtB.buretmbzch
	  section.data(182).logicalSrcIdx = 181;
	  section.data(182).dtTransOffset = 258;
	
	  ;% rtB.hwbt4zhehe
	  section.data(183).logicalSrcIdx = 182;
	  section.data(183).dtTransOffset = 259;
	
	  ;% rtB.ghpkp3e4ii
	  section.data(184).logicalSrcIdx = 183;
	  section.data(184).dtTransOffset = 260;
	
	  ;% rtB.ala2ctnapt
	  section.data(185).logicalSrcIdx = 184;
	  section.data(185).dtTransOffset = 261;
	
	  ;% rtB.palr0v3uue
	  section.data(186).logicalSrcIdx = 185;
	  section.data(186).dtTransOffset = 262;
	
	  ;% rtB.mgdng0j5ju
	  section.data(187).logicalSrcIdx = 186;
	  section.data(187).dtTransOffset = 263;
	
	  ;% rtB.iilivmsrjv
	  section.data(188).logicalSrcIdx = 187;
	  section.data(188).dtTransOffset = 264;
	
	  ;% rtB.hc4tipfzoi
	  section.data(189).logicalSrcIdx = 188;
	  section.data(189).dtTransOffset = 265;
	
	  ;% rtB.cpkwdk2p01
	  section.data(190).logicalSrcIdx = 189;
	  section.data(190).dtTransOffset = 266;
	
	  ;% rtB.pblcvwi5vj
	  section.data(191).logicalSrcIdx = 190;
	  section.data(191).dtTransOffset = 267;
	
	  ;% rtB.fjax0ymfvv
	  section.data(192).logicalSrcIdx = 191;
	  section.data(192).dtTransOffset = 268;
	
	  ;% rtB.owzswdceo3
	  section.data(193).logicalSrcIdx = 192;
	  section.data(193).dtTransOffset = 269;
	
	  ;% rtB.lnwt3320xf
	  section.data(194).logicalSrcIdx = 193;
	  section.data(194).dtTransOffset = 270;
	
	  ;% rtB.f1jzjr5wtp
	  section.data(195).logicalSrcIdx = 194;
	  section.data(195).dtTransOffset = 271;
	
	  ;% rtB.ezdk1hee5n
	  section.data(196).logicalSrcIdx = 195;
	  section.data(196).dtTransOffset = 272;
	
	  ;% rtB.mhvcgzbyma
	  section.data(197).logicalSrcIdx = 196;
	  section.data(197).dtTransOffset = 273;
	
	  ;% rtB.dcu2acxtfg
	  section.data(198).logicalSrcIdx = 197;
	  section.data(198).dtTransOffset = 274;
	
	  ;% rtB.lnh2z2pbk3
	  section.data(199).logicalSrcIdx = 198;
	  section.data(199).dtTransOffset = 275;
	
	  ;% rtB.ovmxhmbhlf
	  section.data(200).logicalSrcIdx = 199;
	  section.data(200).dtTransOffset = 276;
	
	  ;% rtB.g2q1v5iy2d
	  section.data(201).logicalSrcIdx = 200;
	  section.data(201).dtTransOffset = 277;
	
	  ;% rtB.pbgvg2nezd
	  section.data(202).logicalSrcIdx = 201;
	  section.data(202).dtTransOffset = 278;
	
	  ;% rtB.jzeacrnsxs
	  section.data(203).logicalSrcIdx = 202;
	  section.data(203).dtTransOffset = 279;
	
	  ;% rtB.klom0nem0m
	  section.data(204).logicalSrcIdx = 203;
	  section.data(204).dtTransOffset = 280;
	
	  ;% rtB.aolyxnh1an
	  section.data(205).logicalSrcIdx = 204;
	  section.data(205).dtTransOffset = 281;
	
	  ;% rtB.fzhbdpl21m
	  section.data(206).logicalSrcIdx = 205;
	  section.data(206).dtTransOffset = 282;
	
	  ;% rtB.fllp1jvygi
	  section.data(207).logicalSrcIdx = 206;
	  section.data(207).dtTransOffset = 283;
	
	  ;% rtB.ln3b5mokgm
	  section.data(208).logicalSrcIdx = 207;
	  section.data(208).dtTransOffset = 284;
	
	  ;% rtB.krwk3nllsf
	  section.data(209).logicalSrcIdx = 208;
	  section.data(209).dtTransOffset = 285;
	
	  ;% rtB.kxozrd4z5i
	  section.data(210).logicalSrcIdx = 209;
	  section.data(210).dtTransOffset = 286;
	
	  ;% rtB.ighohgvfas
	  section.data(211).logicalSrcIdx = 210;
	  section.data(211).dtTransOffset = 287;
	
	  ;% rtB.etxojvnaot
	  section.data(212).logicalSrcIdx = 211;
	  section.data(212).dtTransOffset = 288;
	
	  ;% rtB.gwktivfwpd
	  section.data(213).logicalSrcIdx = 212;
	  section.data(213).dtTransOffset = 289;
	
	  ;% rtB.ekw0zt1xfm
	  section.data(214).logicalSrcIdx = 213;
	  section.data(214).dtTransOffset = 290;
	
	  ;% rtB.cqsienutuc
	  section.data(215).logicalSrcIdx = 214;
	  section.data(215).dtTransOffset = 291;
	
	  ;% rtB.krygur50zl
	  section.data(216).logicalSrcIdx = 215;
	  section.data(216).dtTransOffset = 292;
	
	  ;% rtB.mlxflzoh35
	  section.data(217).logicalSrcIdx = 216;
	  section.data(217).dtTransOffset = 293;
	
	  ;% rtB.g00batsh4u
	  section.data(218).logicalSrcIdx = 217;
	  section.data(218).dtTransOffset = 295;
	
	  ;% rtB.hcz2xlgk3d
	  section.data(219).logicalSrcIdx = 218;
	  section.data(219).dtTransOffset = 296;
	
	  ;% rtB.oj2fro1nlz
	  section.data(220).logicalSrcIdx = 219;
	  section.data(220).dtTransOffset = 298;
	
	  ;% rtB.nsl1liuisf
	  section.data(221).logicalSrcIdx = 220;
	  section.data(221).dtTransOffset = 299;
	
	  ;% rtB.o2kdszic3h
	  section.data(222).logicalSrcIdx = 221;
	  section.data(222).dtTransOffset = 301;
	
	  ;% rtB.kkozylqz2v
	  section.data(223).logicalSrcIdx = 222;
	  section.data(223).dtTransOffset = 302;
	
	  ;% rtB.hr44golvpy
	  section.data(224).logicalSrcIdx = 223;
	  section.data(224).dtTransOffset = 304;
	
	  ;% rtB.fzbe5vkjui
	  section.data(225).logicalSrcIdx = 224;
	  section.data(225).dtTransOffset = 305;
	
	  ;% rtB.dmpeej2qt1
	  section.data(226).logicalSrcIdx = 225;
	  section.data(226).dtTransOffset = 307;
	
	  ;% rtB.cxgw4hmvl5
	  section.data(227).logicalSrcIdx = 226;
	  section.data(227).dtTransOffset = 308;
	
	  ;% rtB.h0hbhcvnx4
	  section.data(228).logicalSrcIdx = 227;
	  section.data(228).dtTransOffset = 310;
	
	  ;% rtB.n2s1hb1sdd
	  section.data(229).logicalSrcIdx = 228;
	  section.data(229).dtTransOffset = 311;
	
	  ;% rtB.po4oftxsww
	  section.data(230).logicalSrcIdx = 229;
	  section.data(230).dtTransOffset = 312;
	
	  ;% rtB.mu2u0ykmdh
	  section.data(231).logicalSrcIdx = 230;
	  section.data(231).dtTransOffset = 313;
	
	  ;% rtB.b101dzqhyh
	  section.data(232).logicalSrcIdx = 231;
	  section.data(232).dtTransOffset = 314;
	
	  ;% rtB.itee030nb5
	  section.data(233).logicalSrcIdx = 232;
	  section.data(233).dtTransOffset = 318;
	
	  ;% rtB.i0nwte41mb
	  section.data(234).logicalSrcIdx = 233;
	  section.data(234).dtTransOffset = 322;
	
	  ;% rtB.j2yhvvmzdt
	  section.data(235).logicalSrcIdx = 234;
	  section.data(235).dtTransOffset = 326;
	
	  ;% rtB.e1he2cpfsi
	  section.data(236).logicalSrcIdx = 235;
	  section.data(236).dtTransOffset = 330;
	
	  ;% rtB.c1yr1t1pln
	  section.data(237).logicalSrcIdx = 236;
	  section.data(237).dtTransOffset = 331;
	
	  ;% rtB.l52vljxmqk
	  section.data(238).logicalSrcIdx = 237;
	  section.data(238).dtTransOffset = 332;
	
	  ;% rtB.kygrahp5cz
	  section.data(239).logicalSrcIdx = 238;
	  section.data(239).dtTransOffset = 333;
	
	  ;% rtB.cjndlopolx
	  section.data(240).logicalSrcIdx = 239;
	  section.data(240).dtTransOffset = 337;
	
	  ;% rtB.d1gpz5ny3l
	  section.data(241).logicalSrcIdx = 240;
	  section.data(241).dtTransOffset = 341;
	
	  ;% rtB.at40po5flv
	  section.data(242).logicalSrcIdx = 241;
	  section.data(242).dtTransOffset = 345;
	
	  ;% rtB.lhj1mrpnaq
	  section.data(243).logicalSrcIdx = 242;
	  section.data(243).dtTransOffset = 349;
	
	  ;% rtB.ijry4eme3e
	  section.data(244).logicalSrcIdx = 243;
	  section.data(244).dtTransOffset = 350;
	
	  ;% rtB.kkv1oof2ml
	  section.data(245).logicalSrcIdx = 244;
	  section.data(245).dtTransOffset = 351;
	
	  ;% rtB.kcfelslddn
	  section.data(246).logicalSrcIdx = 245;
	  section.data(246).dtTransOffset = 352;
	
	  ;% rtB.hcovsf5jov
	  section.data(247).logicalSrcIdx = 246;
	  section.data(247).dtTransOffset = 356;
	
	  ;% rtB.ndunxwoqnz
	  section.data(248).logicalSrcIdx = 247;
	  section.data(248).dtTransOffset = 360;
	
	  ;% rtB.lphjnbgv2d
	  section.data(249).logicalSrcIdx = 248;
	  section.data(249).dtTransOffset = 364;
	
	  ;% rtB.enbnzlp5pu
	  section.data(250).logicalSrcIdx = 249;
	  section.data(250).dtTransOffset = 368;
	
	  ;% rtB.m5mik3hen3
	  section.data(251).logicalSrcIdx = 250;
	  section.data(251).dtTransOffset = 369;
	
	  ;% rtB.cywrrn5vf0
	  section.data(252).logicalSrcIdx = 251;
	  section.data(252).dtTransOffset = 370;
	
	  ;% rtB.d4u1qga40r
	  section.data(253).logicalSrcIdx = 252;
	  section.data(253).dtTransOffset = 371;
	
	  ;% rtB.fpc3kvomhx
	  section.data(254).logicalSrcIdx = 253;
	  section.data(254).dtTransOffset = 375;
	
	  ;% rtB.cxpepskh1k
	  section.data(255).logicalSrcIdx = 254;
	  section.data(255).dtTransOffset = 379;
	
	  ;% rtB.mg1gi4ne5h
	  section.data(256).logicalSrcIdx = 255;
	  section.data(256).dtTransOffset = 383;
	
	  ;% rtB.a0ohbtp3be
	  section.data(257).logicalSrcIdx = 256;
	  section.data(257).dtTransOffset = 387;
	
	  ;% rtB.bvpvkwxod3
	  section.data(258).logicalSrcIdx = 257;
	  section.data(258).dtTransOffset = 388;
	
	  ;% rtB.oxbbdbrc3h
	  section.data(259).logicalSrcIdx = 258;
	  section.data(259).dtTransOffset = 389;
	
	  ;% rtB.byyxlan4vv
	  section.data(260).logicalSrcIdx = 259;
	  section.data(260).dtTransOffset = 390;
	
	  ;% rtB.gnqhbaw5wi
	  section.data(261).logicalSrcIdx = 260;
	  section.data(261).dtTransOffset = 394;
	
	  ;% rtB.kkvkd0imzv
	  section.data(262).logicalSrcIdx = 261;
	  section.data(262).dtTransOffset = 398;
	
	  ;% rtB.ccegoze1r3
	  section.data(263).logicalSrcIdx = 262;
	  section.data(263).dtTransOffset = 402;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 35;
      section.data(35)  = dumData; %prealloc
      
	  ;% rtB.iezulznyyl
	  section.data(1).logicalSrcIdx = 263;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.d5jbm0zxii
	  section.data(2).logicalSrcIdx = 264;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.kcf35vodg1
	  section.data(3).logicalSrcIdx = 265;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtB.bwnprsaklm
	  section.data(4).logicalSrcIdx = 266;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtB.jakgot214r
	  section.data(5).logicalSrcIdx = 267;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtB.hmuvnzmkyq
	  section.data(6).logicalSrcIdx = 268;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtB.ptudxy54cl
	  section.data(7).logicalSrcIdx = 269;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtB.hr53vp5214
	  section.data(8).logicalSrcIdx = 270;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtB.cfvuxsaes1
	  section.data(9).logicalSrcIdx = 271;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtB.cc2mpg0gqp
	  section.data(10).logicalSrcIdx = 272;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtB.cl1znduuno
	  section.data(11).logicalSrcIdx = 273;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtB.pykujdhald
	  section.data(12).logicalSrcIdx = 274;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtB.kttme4p4ih
	  section.data(13).logicalSrcIdx = 275;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtB.nuzd1nehkt
	  section.data(14).logicalSrcIdx = 276;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtB.bn2cyxj3zl
	  section.data(15).logicalSrcIdx = 277;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtB.dnc1haqpya
	  section.data(16).logicalSrcIdx = 278;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtB.ou3lkm5huj
	  section.data(17).logicalSrcIdx = 279;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtB.ivfkkggxvv
	  section.data(18).logicalSrcIdx = 280;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtB.hvbdhrufgk
	  section.data(19).logicalSrcIdx = 281;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtB.oipwcmrhbu
	  section.data(20).logicalSrcIdx = 282;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtB.ojebse5nps
	  section.data(21).logicalSrcIdx = 283;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtB.ixwvnfjyht
	  section.data(22).logicalSrcIdx = 284;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtB.njmqdqum11
	  section.data(23).logicalSrcIdx = 285;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtB.e0eegacwfw
	  section.data(24).logicalSrcIdx = 286;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtB.ammqm2ucfq
	  section.data(25).logicalSrcIdx = 287;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtB.jhzdsfrzpr
	  section.data(26).logicalSrcIdx = 288;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtB.kgz10dnw3h
	  section.data(27).logicalSrcIdx = 289;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtB.aww14lps2o
	  section.data(28).logicalSrcIdx = 290;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtB.cpybkyynn4
	  section.data(29).logicalSrcIdx = 291;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtB.cgviec4bkd
	  section.data(30).logicalSrcIdx = 292;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtB.filzxjl5ur
	  section.data(31).logicalSrcIdx = 293;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtB.dtff1cx0dd
	  section.data(32).logicalSrcIdx = 294;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtB.epmqzfkazx
	  section.data(33).logicalSrcIdx = 295;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtB.n244nv1bl5
	  section.data(34).logicalSrcIdx = 296;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtB.lvnp1e1py5
	  section.data(35).logicalSrcIdx = 297;
	  section.data(35).dtTransOffset = 34;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.lykrvem450.fsk1owdmw3
	  section.data(1).logicalSrcIdx = 298;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.lykrvem450.k3oc5pn3ee
	  section.data(2).logicalSrcIdx = 299;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(3) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.ea4xfcwbtn.fsk1owdmw3
	  section.data(1).logicalSrcIdx = 300;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.ea4xfcwbtn.k3oc5pn3ee
	  section.data(2).logicalSrcIdx = 301;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(4) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.fmo52byvhh.fsk1owdmw3
	  section.data(1).logicalSrcIdx = 302;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.fmo52byvhh.k3oc5pn3ee
	  section.data(2).logicalSrcIdx = 303;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(5) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.ju3bvdpq4f.fsk1owdmw3
	  section.data(1).logicalSrcIdx = 304;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.ju3bvdpq4f.k3oc5pn3ee
	  section.data(2).logicalSrcIdx = 305;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(6) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.hn5ndxahiz.fsk1owdmw3
	  section.data(1).logicalSrcIdx = 306;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.hn5ndxahiz.k3oc5pn3ee
	  section.data(2).logicalSrcIdx = 307;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(7) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.jc1djgafdm.fsk1owdmw3
	  section.data(1).logicalSrcIdx = 308;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.jc1djgafdm.k3oc5pn3ee
	  section.data(2).logicalSrcIdx = 309;
	  section.data(2).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(8) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 6;
    sectIdxOffset = 8;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtDW)
    ;%
      section.nData     = 28;
      section.data(28)  = dumData; %prealloc
      
	  ;% rtDW.mwtjai2xzq
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.abnasr53i2
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.puhqb53xlf
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.cgtn4vtk4v
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.e5chgaqzdi
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.br1vosysg0
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.bw2f200uhe
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.h1kn4wxczz
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.fwi0pu3glv
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.m35jm4htkc
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.ep01khxy3s
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.fnsfdleb5s
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtDW.mg0udjzg3z
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtDW.esnkvscczq
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtDW.o2neiszzpu
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtDW.h21d2fqnwl
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtDW.f4vpteq14c
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtDW.mlaq1sf05w
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtDW.imnddva2yd
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtDW.bv3ta2c31d
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtDW.gvyq4tdih4
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtDW.cukktpbdau
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtDW.hwclgprvm0
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtDW.nlleqzlpac
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtDW.h0ir15tiwo
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtDW.dp1esyh3gc
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtDW.dul0uayr5l
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtDW.mk2k513iba
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 6;
      section.data(6)  = dumData; %prealloc
      
	  ;% rtDW.gil1dfunsb
	  section.data(1).logicalSrcIdx = 28;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.oxz1dp4rtp
	  section.data(2).logicalSrcIdx = 29;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.i4itkhygug
	  section.data(3).logicalSrcIdx = 30;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.fzl1x30105
	  section.data(4).logicalSrcIdx = 31;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.kuacjottby
	  section.data(5).logicalSrcIdx = 32;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.dtdzggbusy
	  section.data(6).logicalSrcIdx = 33;
	  section.data(6).dtTransOffset = 5;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.pipgbkjgsg
	  section.data(1).logicalSrcIdx = 34;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 13;
      section.data(13)  = dumData; %prealloc
      
	  ;% rtDW.bl3jeskmlg
	  section.data(1).logicalSrcIdx = 35;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.c5xpztgxst.LoggedData
	  section.data(2).logicalSrcIdx = 36;
	  section.data(2).dtTransOffset = 22;
	
	  ;% rtDW.kefwpubmhm.AQHandles
	  section.data(3).logicalSrcIdx = 37;
	  section.data(3).dtTransOffset = 27;
	
	  ;% rtDW.pvibdkum0b.AQHandles
	  section.data(4).logicalSrcIdx = 38;
	  section.data(4).dtTransOffset = 28;
	
	  ;% rtDW.a1aeuz3o44.AQHandles
	  section.data(5).logicalSrcIdx = 39;
	  section.data(5).dtTransOffset = 29;
	
	  ;% rtDW.m5pgrgp4cg.AQHandles
	  section.data(6).logicalSrcIdx = 40;
	  section.data(6).dtTransOffset = 30;
	
	  ;% rtDW.oee5uekymg.AQHandles
	  section.data(7).logicalSrcIdx = 41;
	  section.data(7).dtTransOffset = 31;
	
	  ;% rtDW.jrgeolpedl.AQHandles
	  section.data(8).logicalSrcIdx = 42;
	  section.data(8).dtTransOffset = 32;
	
	  ;% rtDW.l4br0owshy.AQHandles
	  section.data(9).logicalSrcIdx = 43;
	  section.data(9).dtTransOffset = 33;
	
	  ;% rtDW.eqbzffk253.AQHandles
	  section.data(10).logicalSrcIdx = 44;
	  section.data(10).dtTransOffset = 34;
	
	  ;% rtDW.m1fwuqpiaf.AQHandles
	  section.data(11).logicalSrcIdx = 45;
	  section.data(11).dtTransOffset = 35;
	
	  ;% rtDW.pf5orjqb5m.LoggedData
	  section.data(12).logicalSrcIdx = 46;
	  section.data(12).dtTransOffset = 36;
	
	  ;% rtDW.hluh0ska1a.LoggedData
	  section.data(13).logicalSrcIdx = 47;
	  section.data(13).dtTransOffset = 41;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 33;
      section.data(33)  = dumData; %prealloc
      
	  ;% rtDW.mjabmoou2z
	  section.data(1).logicalSrcIdx = 48;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.apw4epat2u
	  section.data(2).logicalSrcIdx = 49;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.fid4f0juyg
	  section.data(3).logicalSrcIdx = 50;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.a12tj2tqvt
	  section.data(4).logicalSrcIdx = 51;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.lb53h134aw
	  section.data(5).logicalSrcIdx = 52;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.badooczfnm
	  section.data(6).logicalSrcIdx = 53;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.ndyjjzoyah
	  section.data(7).logicalSrcIdx = 54;
	  section.data(7).dtTransOffset = 28;
	
	  ;% rtDW.iv0bm1cwdz
	  section.data(8).logicalSrcIdx = 55;
	  section.data(8).dtTransOffset = 29;
	
	  ;% rtDW.pngsgibtfq
	  section.data(9).logicalSrcIdx = 56;
	  section.data(9).dtTransOffset = 30;
	
	  ;% rtDW.ewtqwav4k3
	  section.data(10).logicalSrcIdx = 57;
	  section.data(10).dtTransOffset = 31;
	
	  ;% rtDW.cbhsw3xyhw
	  section.data(11).logicalSrcIdx = 58;
	  section.data(11).dtTransOffset = 32;
	
	  ;% rtDW.g5hpe50c5f
	  section.data(12).logicalSrcIdx = 59;
	  section.data(12).dtTransOffset = 33;
	
	  ;% rtDW.nfdtmpqmjl
	  section.data(13).logicalSrcIdx = 60;
	  section.data(13).dtTransOffset = 34;
	
	  ;% rtDW.gxhonuhkhs
	  section.data(14).logicalSrcIdx = 61;
	  section.data(14).dtTransOffset = 35;
	
	  ;% rtDW.blabp2utic
	  section.data(15).logicalSrcIdx = 62;
	  section.data(15).dtTransOffset = 36;
	
	  ;% rtDW.hdt4znz2bx
	  section.data(16).logicalSrcIdx = 63;
	  section.data(16).dtTransOffset = 37;
	
	  ;% rtDW.imyqo2srel
	  section.data(17).logicalSrcIdx = 64;
	  section.data(17).dtTransOffset = 38;
	
	  ;% rtDW.c3pj1kxqrj
	  section.data(18).logicalSrcIdx = 65;
	  section.data(18).dtTransOffset = 75;
	
	  ;% rtDW.py5uw1xsam
	  section.data(19).logicalSrcIdx = 66;
	  section.data(19).dtTransOffset = 76;
	
	  ;% rtDW.o2st5ljikx
	  section.data(20).logicalSrcIdx = 67;
	  section.data(20).dtTransOffset = 77;
	
	  ;% rtDW.cqvf2g25lz
	  section.data(21).logicalSrcIdx = 68;
	  section.data(21).dtTransOffset = 78;
	
	  ;% rtDW.h4owravycx
	  section.data(22).logicalSrcIdx = 69;
	  section.data(22).dtTransOffset = 79;
	
	  ;% rtDW.dgvo4khvek
	  section.data(23).logicalSrcIdx = 70;
	  section.data(23).dtTransOffset = 80;
	
	  ;% rtDW.ehr4lffvuj
	  section.data(24).logicalSrcIdx = 71;
	  section.data(24).dtTransOffset = 81;
	
	  ;% rtDW.pavtbhl4x1
	  section.data(25).logicalSrcIdx = 72;
	  section.data(25).dtTransOffset = 82;
	
	  ;% rtDW.ctdq2e5yzh
	  section.data(26).logicalSrcIdx = 73;
	  section.data(26).dtTransOffset = 83;
	
	  ;% rtDW.eucrjtmh5k
	  section.data(27).logicalSrcIdx = 74;
	  section.data(27).dtTransOffset = 84;
	
	  ;% rtDW.ev0agwtynm
	  section.data(28).logicalSrcIdx = 75;
	  section.data(28).dtTransOffset = 85;
	
	  ;% rtDW.lg5hzw2ze0
	  section.data(29).logicalSrcIdx = 76;
	  section.data(29).dtTransOffset = 86;
	
	  ;% rtDW.gglvg5yhwg
	  section.data(30).logicalSrcIdx = 77;
	  section.data(30).dtTransOffset = 87;
	
	  ;% rtDW.bhkajjcc0s
	  section.data(31).logicalSrcIdx = 78;
	  section.data(31).dtTransOffset = 88;
	
	  ;% rtDW.bw1ne04erh
	  section.data(32).logicalSrcIdx = 79;
	  section.data(32).dtTransOffset = 89;
	
	  ;% rtDW.lk5j3i1cks
	  section.data(33).logicalSrcIdx = 80;
	  section.data(33).dtTransOffset = 90;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
      section.nData     = 74;
      section.data(74)  = dumData; %prealloc
      
	  ;% rtDW.oemcgetehw
	  section.data(1).logicalSrcIdx = 81;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.mcoopbxhas
	  section.data(2).logicalSrcIdx = 82;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.hfhq12age4
	  section.data(3).logicalSrcIdx = 83;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.odkj4eftfi
	  section.data(4).logicalSrcIdx = 84;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.mlgiqc4qhd
	  section.data(5).logicalSrcIdx = 85;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.o4yhobhacw
	  section.data(6).logicalSrcIdx = 86;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.b4xvp05dsp
	  section.data(7).logicalSrcIdx = 87;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.obaqwkwqid
	  section.data(8).logicalSrcIdx = 88;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.kqhwhpbc2l
	  section.data(9).logicalSrcIdx = 89;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.lptbui3bdr
	  section.data(10).logicalSrcIdx = 90;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.hz3s4vrezj
	  section.data(11).logicalSrcIdx = 91;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.dhbq4fq1y5
	  section.data(12).logicalSrcIdx = 92;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtDW.gwmmodqfqo
	  section.data(13).logicalSrcIdx = 93;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtDW.flqyr4ponx
	  section.data(14).logicalSrcIdx = 94;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtDW.drp1pdx1o2
	  section.data(15).logicalSrcIdx = 95;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtDW.mwzj54zeve
	  section.data(16).logicalSrcIdx = 96;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtDW.gh40xceltm
	  section.data(17).logicalSrcIdx = 97;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtDW.hxqj0wmr1s
	  section.data(18).logicalSrcIdx = 98;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtDW.ayf5sqzvgu
	  section.data(19).logicalSrcIdx = 99;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtDW.hsuqfg2xm4
	  section.data(20).logicalSrcIdx = 100;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtDW.aeubopidzx
	  section.data(21).logicalSrcIdx = 101;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtDW.jlwexkwoi3
	  section.data(22).logicalSrcIdx = 102;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtDW.nxd2nqjick
	  section.data(23).logicalSrcIdx = 103;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtDW.nkllg3btfs
	  section.data(24).logicalSrcIdx = 104;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtDW.hxobozywci
	  section.data(25).logicalSrcIdx = 105;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtDW.abeepxeuaz
	  section.data(26).logicalSrcIdx = 106;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtDW.fsznzndz1h
	  section.data(27).logicalSrcIdx = 107;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtDW.pnxsmfjtjg
	  section.data(28).logicalSrcIdx = 108;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtDW.kvk4rwajxg
	  section.data(29).logicalSrcIdx = 109;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtDW.paol22gume
	  section.data(30).logicalSrcIdx = 110;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtDW.nzxxvc5aaq
	  section.data(31).logicalSrcIdx = 111;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtDW.azkim3bav2
	  section.data(32).logicalSrcIdx = 112;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtDW.fbtobfkzln
	  section.data(33).logicalSrcIdx = 113;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtDW.ds2iyglcuj
	  section.data(34).logicalSrcIdx = 114;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtDW.gv2gxwgcyr
	  section.data(35).logicalSrcIdx = 115;
	  section.data(35).dtTransOffset = 34;
	
	  ;% rtDW.og2ibrr5dj
	  section.data(36).logicalSrcIdx = 116;
	  section.data(36).dtTransOffset = 35;
	
	  ;% rtDW.podpzxkpcc
	  section.data(37).logicalSrcIdx = 117;
	  section.data(37).dtTransOffset = 36;
	
	  ;% rtDW.gorulf3t0p
	  section.data(38).logicalSrcIdx = 118;
	  section.data(38).dtTransOffset = 37;
	
	  ;% rtDW.flctwqyusi
	  section.data(39).logicalSrcIdx = 119;
	  section.data(39).dtTransOffset = 38;
	
	  ;% rtDW.bshhfd5mls
	  section.data(40).logicalSrcIdx = 120;
	  section.data(40).dtTransOffset = 39;
	
	  ;% rtDW.g11vzlfqpn
	  section.data(41).logicalSrcIdx = 121;
	  section.data(41).dtTransOffset = 40;
	
	  ;% rtDW.e4xlinrnnb
	  section.data(42).logicalSrcIdx = 122;
	  section.data(42).dtTransOffset = 41;
	
	  ;% rtDW.bct0r40oxs
	  section.data(43).logicalSrcIdx = 123;
	  section.data(43).dtTransOffset = 42;
	
	  ;% rtDW.ezdcqawxtb
	  section.data(44).logicalSrcIdx = 124;
	  section.data(44).dtTransOffset = 43;
	
	  ;% rtDW.lh3hvz10l4
	  section.data(45).logicalSrcIdx = 125;
	  section.data(45).dtTransOffset = 44;
	
	  ;% rtDW.b0t15mq1oh
	  section.data(46).logicalSrcIdx = 126;
	  section.data(46).dtTransOffset = 45;
	
	  ;% rtDW.dx31ootphe
	  section.data(47).logicalSrcIdx = 127;
	  section.data(47).dtTransOffset = 46;
	
	  ;% rtDW.lbbdcegp5z
	  section.data(48).logicalSrcIdx = 128;
	  section.data(48).dtTransOffset = 47;
	
	  ;% rtDW.cj1yejiuj0
	  section.data(49).logicalSrcIdx = 129;
	  section.data(49).dtTransOffset = 48;
	
	  ;% rtDW.potnbsja2x
	  section.data(50).logicalSrcIdx = 130;
	  section.data(50).dtTransOffset = 49;
	
	  ;% rtDW.hyvrqtp0nq
	  section.data(51).logicalSrcIdx = 131;
	  section.data(51).dtTransOffset = 50;
	
	  ;% rtDW.f4jvehgaau
	  section.data(52).logicalSrcIdx = 132;
	  section.data(52).dtTransOffset = 51;
	
	  ;% rtDW.fatdrnikff
	  section.data(53).logicalSrcIdx = 133;
	  section.data(53).dtTransOffset = 52;
	
	  ;% rtDW.dz22xyy0n2
	  section.data(54).logicalSrcIdx = 134;
	  section.data(54).dtTransOffset = 53;
	
	  ;% rtDW.oklojozd5l
	  section.data(55).logicalSrcIdx = 135;
	  section.data(55).dtTransOffset = 54;
	
	  ;% rtDW.gutf54om0t
	  section.data(56).logicalSrcIdx = 136;
	  section.data(56).dtTransOffset = 55;
	
	  ;% rtDW.awriz1pum1
	  section.data(57).logicalSrcIdx = 137;
	  section.data(57).dtTransOffset = 56;
	
	  ;% rtDW.hwlma5twap
	  section.data(58).logicalSrcIdx = 138;
	  section.data(58).dtTransOffset = 57;
	
	  ;% rtDW.lkdrn04ha3
	  section.data(59).logicalSrcIdx = 139;
	  section.data(59).dtTransOffset = 58;
	
	  ;% rtDW.n2wn2lgi4k
	  section.data(60).logicalSrcIdx = 140;
	  section.data(60).dtTransOffset = 59;
	
	  ;% rtDW.lptg51m4go
	  section.data(61).logicalSrcIdx = 141;
	  section.data(61).dtTransOffset = 60;
	
	  ;% rtDW.c4mx45ei5j
	  section.data(62).logicalSrcIdx = 142;
	  section.data(62).dtTransOffset = 61;
	
	  ;% rtDW.cwj4t5csvl
	  section.data(63).logicalSrcIdx = 143;
	  section.data(63).dtTransOffset = 62;
	
	  ;% rtDW.cgi440wi10
	  section.data(64).logicalSrcIdx = 144;
	  section.data(64).dtTransOffset = 63;
	
	  ;% rtDW.nqrddpnaqi
	  section.data(65).logicalSrcIdx = 145;
	  section.data(65).dtTransOffset = 64;
	
	  ;% rtDW.lvplimut2k
	  section.data(66).logicalSrcIdx = 146;
	  section.data(66).dtTransOffset = 65;
	
	  ;% rtDW.b45hsrgxk4
	  section.data(67).logicalSrcIdx = 147;
	  section.data(67).dtTransOffset = 66;
	
	  ;% rtDW.ff0qbzbocl
	  section.data(68).logicalSrcIdx = 148;
	  section.data(68).dtTransOffset = 67;
	
	  ;% rtDW.j553vsqqsn
	  section.data(69).logicalSrcIdx = 149;
	  section.data(69).dtTransOffset = 68;
	
	  ;% rtDW.kevb4e4jpg
	  section.data(70).logicalSrcIdx = 150;
	  section.data(70).dtTransOffset = 69;
	
	  ;% rtDW.d0uk2u5ily
	  section.data(71).logicalSrcIdx = 151;
	  section.data(71).dtTransOffset = 70;
	
	  ;% rtDW.opghe0hhiz
	  section.data(72).logicalSrcIdx = 152;
	  section.data(72).dtTransOffset = 71;
	
	  ;% rtDW.hykritwrbg
	  section.data(73).logicalSrcIdx = 153;
	  section.data(73).dtTransOffset = 72;
	
	  ;% rtDW.aznjkggrjt
	  section.data(74).logicalSrcIdx = 154;
	  section.data(74).dtTransOffset = 73;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(6) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 1550680249;
  targMap.checksum1 = 746654945;
  targMap.checksum2 = 2628067688;
  targMap.checksum3 = 4181925083;

