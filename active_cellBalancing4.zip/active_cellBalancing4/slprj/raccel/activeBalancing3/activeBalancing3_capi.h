#ifndef RTW_HEADER_activeBalancing3_capi_h
#define RTW_HEADER_activeBalancing3_capi_h
#include "activeBalancing3.h"
extern void activeBalancing3_InitializeDataMapInfo ( void ) ;
#endif
