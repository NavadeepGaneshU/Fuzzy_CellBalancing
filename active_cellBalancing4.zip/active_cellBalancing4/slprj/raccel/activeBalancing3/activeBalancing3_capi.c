#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "activeBalancing3_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#ifndef SS_INT64
#define SS_INT64  21
#endif
#ifndef SS_UINT64
#define SS_UINT64  22
#endif
#else
#include "builtin_typeid_types.h"
#include "activeBalancing3.h"
#include "activeBalancing3_capi.h"
#include "activeBalancing3_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 41 , TARGET_STRING
( "activeBalancing3/Fuzzy Logic  Controller 12_34" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 1 , 45 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 1_2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 2 , 49 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 23_45" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 3 , 53 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 2_3" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 4 , 57 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 3_4" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 5 , 61 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 4_5" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 6 , 65 , TARGET_STRING (
"activeBalancing3/MATLAB Function" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 ,
0 } , { 7 , 65 , TARGET_STRING ( "activeBalancing3/MATLAB Function" ) ,
TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , { 8 , 65 , TARGET_STRING (
"activeBalancing3/MATLAB Function" ) , TARGET_STRING ( "" ) , 2 , 0 , 0 , 0 ,
0 } , { 9 , 65 , TARGET_STRING ( "activeBalancing3/MATLAB Function" ) ,
TARGET_STRING ( "" ) , 3 , 0 , 0 , 0 , 0 } , { 10 , 65 , TARGET_STRING (
"activeBalancing3/MATLAB Function" ) , TARGET_STRING ( "" ) , 4 , 0 , 0 , 0 ,
0 } , { 11 , 65 , TARGET_STRING ( "activeBalancing3/MATLAB Function" ) ,
TARGET_STRING ( "" ) , 5 , 0 , 0 , 0 , 0 } , { 12 , 0 , TARGET_STRING (
"activeBalancing3/Add11" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , {
13 , 0 , TARGET_STRING ( "activeBalancing3/Add4" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 14 , 0 , TARGET_STRING ( "activeBalancing3/Add5" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 15 , 0 , TARGET_STRING (
"activeBalancing3/Add6" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 16
, 0 , TARGET_STRING ( "activeBalancing3/Add7" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 17 , 0 , TARGET_STRING ( "activeBalancing3/Add9" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 18 , 0 , TARGET_STRING (
"activeBalancing3/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 19 , 41 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 12_34/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 20 , 43 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 12_34/Evaluate Rule Consequents" )
, TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 21 , 45 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 1_2/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 22 , 47 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 1_2/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 23 , 49 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 23_45/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 24 , 51 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 23_45/Evaluate Rule Consequents" )
, TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 25 , 53 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 2_3/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 26 , 55 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 2_3/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 27 , 57 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 3_4/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 28 , 59 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 3_4/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 29 , 61 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 4_5/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 30 , 63 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 4_5/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 31 , 0 , TARGET_STRING (
"activeBalancing3/PWM/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 32 , 0 , TARGET_STRING (
"activeBalancing3/PWM1/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 33 , 0 , TARGET_STRING (
"activeBalancing3/PWM2/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 34 , 0 , TARGET_STRING (
"activeBalancing3/PWM3/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 35 , 0 , TARGET_STRING (
"activeBalancing3/PWM4/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 36 , 0 , TARGET_STRING (
"activeBalancing3/PWM5/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 37 , 0 , TARGET_STRING (
"activeBalancing3/Voltage Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 38 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 39 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 40 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 41 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 42 , 0 , TARGET_STRING ( "activeBalancing3/Battery1/Model/Fcn6" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 43 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 44 , 0 , TARGET_STRING ( "activeBalancing3/Battery1/Model/Gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 45 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 46 , 0 , TARGET_STRING ( "activeBalancing3/Battery1/Model/R1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 47 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 48 , 0 , TARGET_STRING ( "activeBalancing3/Battery1/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 49 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 50 , 0 , TARGET_STRING ( "activeBalancing3/Battery1/Model/int(i)" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 51 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 52 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 53 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 54 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 55 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 56 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 57 , 0 , TARGET_STRING ( "activeBalancing3/Battery1/Model/Add3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 58 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 59 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 60 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 61 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 62 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 63 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 64 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 65 , 0 , TARGET_STRING ( "activeBalancing3/Battery2/Model/Fcn6" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 66 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 67 , 0 , TARGET_STRING ( "activeBalancing3/Battery2/Model/Gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 68 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 69 , 0 , TARGET_STRING ( "activeBalancing3/Battery2/Model/R1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 70 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 71 , 0 , TARGET_STRING ( "activeBalancing3/Battery2/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 72 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 73 , 0 , TARGET_STRING ( "activeBalancing3/Battery2/Model/int(i)" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 74 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 75 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 76 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 77 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 78 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 79 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 80 , 0 , TARGET_STRING ( "activeBalancing3/Battery2/Model/Add3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 81 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 82 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 83 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 84 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 85 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 86 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 87 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 88 , 0 , TARGET_STRING ( "activeBalancing3/Battery3/Model/Fcn6" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 89 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 90 , 0 , TARGET_STRING ( "activeBalancing3/Battery3/Model/Gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 91 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 92 , 0 , TARGET_STRING ( "activeBalancing3/Battery3/Model/R1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 93 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 94 , 0 , TARGET_STRING ( "activeBalancing3/Battery3/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 95 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 96 , 0 , TARGET_STRING ( "activeBalancing3/Battery3/Model/int(i)" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 97 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 98 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 99 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 100 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 101 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 102 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 103 , 0 , TARGET_STRING ( "activeBalancing3/Battery3/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 104 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 105 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 106 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 107 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 108 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 109 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 110 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 111 , 0 , TARGET_STRING ( "activeBalancing3/Battery4/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 112 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 113 , 0 , TARGET_STRING ( "activeBalancing3/Battery4/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 114 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 115 , 0 , TARGET_STRING ( "activeBalancing3/Battery4/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 116 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 117 , 0 , TARGET_STRING ( "activeBalancing3/Battery4/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 118 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 119 , 0 , TARGET_STRING ( "activeBalancing3/Battery4/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 120 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 121 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 122 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 123 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 124 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 125 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 126 , 0 , TARGET_STRING ( "activeBalancing3/Battery4/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 127 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 128 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 129 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 130 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 131 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 132 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 133 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 134 , 0 , TARGET_STRING ( "activeBalancing3/Battery5/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 135 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 136 , 0 , TARGET_STRING ( "activeBalancing3/Battery5/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 137 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 138 , 0 , TARGET_STRING ( "activeBalancing3/Battery5/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 139 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 140 , 0 , TARGET_STRING ( "activeBalancing3/Battery5/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 141 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 142 , 0 , TARGET_STRING ( "activeBalancing3/Battery5/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 143 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 144 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 145 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 146 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 147 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 148 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 149 , 0 , TARGET_STRING ( "activeBalancing3/Battery5/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 150 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 151 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 152 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 153 , 0 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"" ) , 0 , 0 , 2 , 0 , 0 } , { 154 , 0 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"" ) , 1 , 0 , 3 , 0 , 0 } , { 155 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 156 , 2 , TARGET_STRING (
"activeBalancing3/Battery1/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 157 , 4 , TARGET_STRING (
"activeBalancing3/Battery1/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 158 , 3 , TARGET_STRING (
"activeBalancing3/Battery1/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 159 , 1 , TARGET_STRING (
"activeBalancing3/Battery1/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 160 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 161 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 162 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 163 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 164 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 165 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 166 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 167 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 168 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 169 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 170 , 6 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 171 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 172 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 173 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 174 , 7 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 175 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 176 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 177 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 178 , 8 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 179 , 0 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 180 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 181 , 10 , TARGET_STRING (
"activeBalancing3/Battery2/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 182 , 12 , TARGET_STRING (
"activeBalancing3/Battery2/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 183 , 11 , TARGET_STRING (
"activeBalancing3/Battery2/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 184 , 9 , TARGET_STRING (
"activeBalancing3/Battery2/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 185 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 186 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 187 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 188 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 189 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 190 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 191 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 192 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 193 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 194 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 195 , 14 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 196 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 197 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 198 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 199 , 15 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 200 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 201 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 202 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 203 , 16 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 204 , 0 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 205 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 206 , 18 , TARGET_STRING (
"activeBalancing3/Battery3/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 207 , 20 , TARGET_STRING (
"activeBalancing3/Battery3/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 208 , 19 , TARGET_STRING (
"activeBalancing3/Battery3/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 209 , 17 , TARGET_STRING (
"activeBalancing3/Battery3/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 210 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 211 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 212 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 213 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 214 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 215 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 216 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 217 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 218 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 219 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 220 , 22 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 221 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 222 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 223 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 224 , 23 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 225 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 226 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 227 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 228 , 24 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 229 , 0 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 230 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 231 , 26 , TARGET_STRING (
"activeBalancing3/Battery4/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 232 , 28 , TARGET_STRING (
"activeBalancing3/Battery4/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 233 , 27 , TARGET_STRING (
"activeBalancing3/Battery4/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 234 , 25 , TARGET_STRING (
"activeBalancing3/Battery4/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 235 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 236 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 237 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 238 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 239 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 240 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 241 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 242 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 243 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 244 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 245 , 30 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 246 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 247 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 248 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 249 , 31 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 250 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 251 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 252 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 253 , 32 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 254 , 0 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 255 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 256 , 34 , TARGET_STRING (
"activeBalancing3/Battery5/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 257 , 36 , TARGET_STRING (
"activeBalancing3/Battery5/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 258 , 35 , TARGET_STRING (
"activeBalancing3/Battery5/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 259 , 33 , TARGET_STRING (
"activeBalancing3/Battery5/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 260 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 261 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 262 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 263 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 264 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 265 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 266 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 267 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 268 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 269 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 270 , 38 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 271 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 272 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 273 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 274 , 39 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 275 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 276 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 277 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 278 , 40 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 279 , 0 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 280 , 0 , TARGET_STRING (
"activeBalancing3/M1/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 281 , 0 , TARGET_STRING (
"activeBalancing3/M10/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 282 , 0 , TARGET_STRING (
"activeBalancing3/M10/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 283 , 0 , TARGET_STRING (
"activeBalancing3/M11/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 284 , 0 , TARGET_STRING (
"activeBalancing3/M12/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 285 , 0 , TARGET_STRING (
"activeBalancing3/M12/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 286 , 0 , TARGET_STRING (
"activeBalancing3/M13/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 287 , 0 , TARGET_STRING (
"activeBalancing3/M14/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 288 , 0 , TARGET_STRING (
"activeBalancing3/M15/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 289 , 0 , TARGET_STRING (
"activeBalancing3/M16/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 290 , 0 , TARGET_STRING (
"activeBalancing3/M17/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 291 , 0 , TARGET_STRING (
"activeBalancing3/M18/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 292 , 0 , TARGET_STRING (
"activeBalancing3/M2/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 293 , 0 , TARGET_STRING (
"activeBalancing3/M2/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 294 , 0 , TARGET_STRING (
"activeBalancing3/M3/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 295 , 0 , TARGET_STRING (
"activeBalancing3/M4/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 296 , 0 , TARGET_STRING (
"activeBalancing3/M4/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 297 , 0 , TARGET_STRING (
"activeBalancing3/M5/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 298 , 0 , TARGET_STRING (
"activeBalancing3/M6/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 299 , 0 , TARGET_STRING (
"activeBalancing3/M6/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 300 , 0 , TARGET_STRING (
"activeBalancing3/M7/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 301 , 0 , TARGET_STRING (
"activeBalancing3/M8/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 302 , 0 , TARGET_STRING (
"activeBalancing3/M8/Ideal Switch/Model/Data Type Conversion" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 303 , 0 , TARGET_STRING (
"activeBalancing3/M9/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static
const rtwCAPI_BlockParameters rtBlockParameters [ ] = { { 304 , TARGET_STRING
( "activeBalancing3/Battery1" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } ,
{ 305 , TARGET_STRING ( "activeBalancing3/Battery2" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 306 , TARGET_STRING (
"activeBalancing3/Battery3" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } , {
307 , TARGET_STRING ( "activeBalancing3/Battery4" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 308 , TARGET_STRING (
"activeBalancing3/Battery5" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } , {
309 , TARGET_STRING ( "activeBalancing3/PWM" ) , TARGET_STRING ( "Period" ) ,
0 , 0 , 0 } , { 310 , TARGET_STRING ( "activeBalancing3/PWM1" ) ,
TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 311 , TARGET_STRING (
"activeBalancing3/PWM2" ) , TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 312
, TARGET_STRING ( "activeBalancing3/PWM3" ) , TARGET_STRING ( "Period" ) , 0
, 0 , 0 } , { 313 , TARGET_STRING ( "activeBalancing3/PWM4" ) , TARGET_STRING
( "Period" ) , 0 , 0 , 0 } , { 314 , TARGET_STRING ( "activeBalancing3/PWM5"
) , TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 315 , TARGET_STRING (
"activeBalancing3/Constant2" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
316 , TARGET_STRING ( "activeBalancing3/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 317 , TARGET_STRING (
"activeBalancing3/Constant6" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
318 , TARGET_STRING ( "activeBalancing3/Constant7" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 319 , TARGET_STRING (
"activeBalancing3/Constant8" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
320 , TARGET_STRING ( "activeBalancing3/Constant9" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 321 , TARGET_STRING (
"activeBalancing3/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 322 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 12_34/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 323 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 1_2/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 324 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 23_45/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 325 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 2_3/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 326 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 3_4/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 327 , TARGET_STRING (
"activeBalancing3/Fuzzy Logic  Controller 4_5/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 328 , TARGET_STRING (
"activeBalancing3/Voltage Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 329 , TARGET_STRING (
"activeBalancing3/Battery1/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 330 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 331 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 332 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 333 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 334 , TARGET_STRING ( "activeBalancing3/Battery1/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 335 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 336 , TARGET_STRING ( "activeBalancing3/Battery1/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 337 , TARGET_STRING (
"activeBalancing3/Battery1/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 338 , TARGET_STRING ( "activeBalancing3/Battery1/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 339 , TARGET_STRING (
"activeBalancing3/Battery1/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 340 , TARGET_STRING ( "activeBalancing3/Battery1/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 341 , TARGET_STRING (
"activeBalancing3/Battery1/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 342 , TARGET_STRING (
"activeBalancing3/Battery1/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 343 , TARGET_STRING (
"activeBalancing3/Battery1/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 344 , TARGET_STRING (
"activeBalancing3/Battery1/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 345 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 346 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 347 , TARGET_STRING (
"activeBalancing3/Battery1/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 348 , TARGET_STRING ( "activeBalancing3/Battery1/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 349 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 350 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 351 , TARGET_STRING (
"activeBalancing3/Battery2/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 352 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 353 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 354 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 355 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 356 , TARGET_STRING ( "activeBalancing3/Battery2/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 357 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 358 , TARGET_STRING ( "activeBalancing3/Battery2/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 359 , TARGET_STRING (
"activeBalancing3/Battery2/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 360 , TARGET_STRING ( "activeBalancing3/Battery2/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 361 , TARGET_STRING (
"activeBalancing3/Battery2/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 362 , TARGET_STRING ( "activeBalancing3/Battery2/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 363 , TARGET_STRING (
"activeBalancing3/Battery2/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 364 , TARGET_STRING (
"activeBalancing3/Battery2/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 365 , TARGET_STRING (
"activeBalancing3/Battery2/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 366 , TARGET_STRING (
"activeBalancing3/Battery2/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 367 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 368 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 369 , TARGET_STRING (
"activeBalancing3/Battery2/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 370 , TARGET_STRING ( "activeBalancing3/Battery2/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 371 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 372 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 373 , TARGET_STRING (
"activeBalancing3/Battery3/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 374 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 375 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 376 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 377 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 378 , TARGET_STRING ( "activeBalancing3/Battery3/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 379 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 380 , TARGET_STRING ( "activeBalancing3/Battery3/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 381 , TARGET_STRING (
"activeBalancing3/Battery3/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 382 , TARGET_STRING ( "activeBalancing3/Battery3/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 383 , TARGET_STRING (
"activeBalancing3/Battery3/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 384 , TARGET_STRING ( "activeBalancing3/Battery3/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 385 , TARGET_STRING (
"activeBalancing3/Battery3/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 386 , TARGET_STRING (
"activeBalancing3/Battery3/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 387 , TARGET_STRING (
"activeBalancing3/Battery3/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 388 , TARGET_STRING (
"activeBalancing3/Battery3/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 389 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 390 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 391 , TARGET_STRING (
"activeBalancing3/Battery3/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 392 , TARGET_STRING ( "activeBalancing3/Battery3/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 393 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 394 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 395 , TARGET_STRING (
"activeBalancing3/Battery4/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 396 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 397 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 398 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 399 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 400 , TARGET_STRING ( "activeBalancing3/Battery4/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 401 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 402 , TARGET_STRING ( "activeBalancing3/Battery4/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 403 , TARGET_STRING (
"activeBalancing3/Battery4/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 404 , TARGET_STRING ( "activeBalancing3/Battery4/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 405 , TARGET_STRING (
"activeBalancing3/Battery4/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 406 , TARGET_STRING ( "activeBalancing3/Battery4/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 407 , TARGET_STRING (
"activeBalancing3/Battery4/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 408 , TARGET_STRING (
"activeBalancing3/Battery4/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 409 , TARGET_STRING (
"activeBalancing3/Battery4/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 410 , TARGET_STRING (
"activeBalancing3/Battery4/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 411 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 412 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 413 , TARGET_STRING (
"activeBalancing3/Battery4/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 414 , TARGET_STRING ( "activeBalancing3/Battery4/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 415 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 416 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 417 , TARGET_STRING (
"activeBalancing3/Battery5/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 418 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 419 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 420 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 421 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 422 , TARGET_STRING ( "activeBalancing3/Battery5/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 423 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 424 , TARGET_STRING ( "activeBalancing3/Battery5/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 425 , TARGET_STRING (
"activeBalancing3/Battery5/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 426 , TARGET_STRING ( "activeBalancing3/Battery5/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 427 , TARGET_STRING (
"activeBalancing3/Battery5/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 428 , TARGET_STRING ( "activeBalancing3/Battery5/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 429 , TARGET_STRING (
"activeBalancing3/Battery5/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 430 , TARGET_STRING (
"activeBalancing3/Battery5/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 431 , TARGET_STRING (
"activeBalancing3/Battery5/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 432 , TARGET_STRING (
"activeBalancing3/Battery5/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 433 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 434 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 435 , TARGET_STRING (
"activeBalancing3/Battery5/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 436 , TARGET_STRING ( "activeBalancing3/Battery5/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 437 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 438 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 439 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P1" ) , 0 , 6 , 0 } , { 440 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P2" ) , 0 , 7 , 0 } , { 441 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P3" ) , 0 , 8 , 0 } , { 442 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P4" ) , 0 , 9 , 0 } , { 443 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P5" ) , 0 , 10 , 0 } , { 444 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P6" ) , 0 , 11 , 0 } , { 445 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P7" ) , 0 , 12 , 0 } , { 446 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P8" ) , 0 , 11 , 0 } , { 447 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P9" ) , 0 , 0 , 0 } , { 448 , TARGET_STRING (
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P10" ) , 0 , 0 , 0 } , { 449 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 450 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 451 , TARGET_STRING (
"activeBalancing3/Battery1/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 452 , TARGET_STRING (
"activeBalancing3/Battery1/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 453 , TARGET_STRING (
"activeBalancing3/Battery1/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 454 , TARGET_STRING (
"activeBalancing3/Battery1/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 455 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 456 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 457 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 458 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 459 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 460 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 461 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 462 , TARGET_STRING (
"activeBalancing3/Battery2/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 463 , TARGET_STRING (
"activeBalancing3/Battery2/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 464 , TARGET_STRING (
"activeBalancing3/Battery2/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 465 , TARGET_STRING (
"activeBalancing3/Battery2/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 466 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 467 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 468 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 469 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 470 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 471 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 472 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 473 , TARGET_STRING (
"activeBalancing3/Battery3/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 474 , TARGET_STRING (
"activeBalancing3/Battery3/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 475 , TARGET_STRING (
"activeBalancing3/Battery3/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 476 , TARGET_STRING (
"activeBalancing3/Battery3/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 477 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 478 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 479 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 480 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 481 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 482 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 483 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 484 , TARGET_STRING (
"activeBalancing3/Battery4/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 485 , TARGET_STRING (
"activeBalancing3/Battery4/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 486 , TARGET_STRING (
"activeBalancing3/Battery4/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 487 , TARGET_STRING (
"activeBalancing3/Battery4/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 488 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 489 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 490 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 491 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 492 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 493 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 494 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 495 , TARGET_STRING (
"activeBalancing3/Battery5/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 496 , TARGET_STRING (
"activeBalancing3/Battery5/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 497 , TARGET_STRING (
"activeBalancing3/Battery5/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 498 , TARGET_STRING (
"activeBalancing3/Battery5/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 499 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 500 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 501 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 502 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 503 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 504 , TARGET_STRING (
"activeBalancing3/M1/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 505 , TARGET_STRING ( "activeBalancing3/M10/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 506 , TARGET_STRING (
"activeBalancing3/M11/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 507 , TARGET_STRING ( "activeBalancing3/M12/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 508 , TARGET_STRING (
"activeBalancing3/M13/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 509 , TARGET_STRING ( "activeBalancing3/M14/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 510 , TARGET_STRING (
"activeBalancing3/M15/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 511 , TARGET_STRING ( "activeBalancing3/M16/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 512 , TARGET_STRING (
"activeBalancing3/M17/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 513 , TARGET_STRING ( "activeBalancing3/M18/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 514 , TARGET_STRING (
"activeBalancing3/M2/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 515 , TARGET_STRING ( "activeBalancing3/M3/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 516 , TARGET_STRING (
"activeBalancing3/M4/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 517 , TARGET_STRING ( "activeBalancing3/M5/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 518 , TARGET_STRING (
"activeBalancing3/M6/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 519 , TARGET_STRING ( "activeBalancing3/M7/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 520 , TARGET_STRING (
"activeBalancing3/M8/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 521 , TARGET_STRING ( "activeBalancing3/M9/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 522 , TARGET_STRING (
"activeBalancing3/Battery1/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 523 , TARGET_STRING (
"activeBalancing3/Battery2/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 524 , TARGET_STRING (
"activeBalancing3/Battery3/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 525 , TARGET_STRING (
"activeBalancing3/Battery4/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 526 , TARGET_STRING (
"activeBalancing3/Battery5/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 } } ; static int_T rt_LoggedStateIdxList [ ] = { - 1 } ; static const
rtwCAPI_Signals rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 , 0 , 0 } } ; static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0 , 0 ,
( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_ModelParameters rtModelParameters [ ] = { { 0 , ( NULL ) , 0 , 0 , 0
} } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . h0hbhcvnx4 , & rtB . dmpeej2qt1 ,
& rtB . hr44golvpy , & rtB . o2kdszic3h , & rtB . oj2fro1nlz , & rtB .
g00batsh4u , & rtB . ighohgvfas , & rtB . etxojvnaot , & rtB . gwktivfwpd , &
rtB . ekw0zt1xfm , & rtB . cqsienutuc , & rtB . krygur50zl , & rtB .
hjlmg51yd0 , & rtB . i2s0aqv5oj , & rtB . jkh0lpzdyl , & rtB . mgwtedhsbf , &
rtB . gsugcfegmq , & rtB . nh3tyegvgp , & rtB . fjax0ymfvv , & rtB .
h0hbhcvnx4 , & rtB . jc1djgafdm . k3oc5pn3ee [ 0 ] , & rtB . dmpeej2qt1 , &
rtB . hn5ndxahiz . k3oc5pn3ee [ 0 ] , & rtB . hr44golvpy , & rtB . ju3bvdpq4f
. k3oc5pn3ee [ 0 ] , & rtB . o2kdszic3h , & rtB . fmo52byvhh . k3oc5pn3ee [ 0
] , & rtB . oj2fro1nlz , & rtB . ea4xfcwbtn . k3oc5pn3ee [ 0 ] , & rtB .
g00batsh4u , & rtB . lykrvem450 . k3oc5pn3ee [ 0 ] , & rtB . cjyi1ugvfp , &
rtB . hwbt4zhehe , & rtB . ala2ctnapt , & rtB . mgdng0j5ju , & rtB .
hc4tipfzoi , & rtB . cxzbwqcn1v , & rtB . pblcvwi5vj , & rtB . pch3fntlad , &
rtB . if50jzplnu , & rtB . patx3e3lyu , & rtB . mnn2sdpcg2 , & rtB .
cklmpkcmxr , & rtB . g3cnit1gts , & rtB . mpjucudbtk , & rtB . bdqvl4emoj , &
rtB . htgwxujgfn , & rtB . hitd4jbxxo , & rtB . j04p5reu3p , & rtB .
c4edbm3lnu , & rtB . iyrb00kscp , & rtB . o3tagh4era , & rtB . ldokaf3uyj , &
rtB . kcf35vodg1 , & rtB . czbyl5orjk , & rtB . eiotr3cj2j , & rtB .
n0wyyiyl2w , & rtB . bjzh2zswrf , & rtB . apptu0x5zl , & rtB . dvd3eelqxy , &
rtB . lssfzuya44 , & rtB . a1xkvgib3c , & rtB . gukj05tcnp , & rtB .
mkvq5xwqnm , & rtB . mharr3pkm3 , & rtB . fj5f5uf5pw , & rtB . iadrygzp4x , &
rtB . pse0v0upak , & rtB . dfsyb51tzv , & rtB . f2scb5rf13 , & rtB .
olx2nutnfv , & rtB . me3a54u35r , & rtB . dnpga1izxq , & rtB . cd5jv3welm , &
rtB . biwszoosgc , & rtB . mxtffwnyug , & rtB . cc2mpg0gqp , & rtB .
c1cjcg0vdp , & rtB . dip4hm3fie , & rtB . oomylrj2ck , & rtB . dawtfnjz3t , &
rtB . nqwiqvxip0 , & rtB . aqn3egakkx , & rtB . fd3qiys2ps , & rtB .
gu2lxqjoee , & rtB . onxjmnda4f , & rtB . pgstoxbe4q , & rtB . cszbfywqst , &
rtB . inr0z52r4v , & rtB . bjsmudeh15 , & rtB . olt2mencvc , & rtB .
cfafquv2xr , & rtB . ebcqidfawa , & rtB . dsgitwjsjs , & rtB . fbim3ivtyq , &
rtB . anodlblzme , & rtB . al5llquoyw , & rtB . n5erhw4hry , & rtB .
b5ot5krztj , & rtB . ou3lkm5huj , & rtB . lt0d3owsjr , & rtB . glfgd2gxlp , &
rtB . cahmoz3lmb , & rtB . ctz0crt1lg , & rtB . iacqlbe2tg , & rtB .
oc0dumgulu , & rtB . lnjfdccy2h , & rtB . fntfm0klq3 , & rtB . jgxdelnl3s , &
rtB . nw2inaond5 , & rtB . ccjxi5v2q0 , & rtB . fmzs5132om , & rtB .
lfgqqylnmm , & rtB . h3gzco2fqa , & rtB . h4lwnoqm5x , & rtB . orwu5t0tyg , &
rtB . bvviu2o2gh , & rtB . aprnkbzhsq , & rtB . m5q0x4yj0k , & rtB .
nocrqzmy3a , & rtB . crm3deon3z , & rtB . hmnedoi5ok , & rtB . e0eegacwfw , &
rtB . cw0w1vgwxh , & rtB . dzdzcnn4k1 , & rtB . mt1bcogztp , & rtB .
bs00yavsbm , & rtB . e0au3fw2j3 , & rtB . eacgl4yov2 , & rtB . pmwqhxrjfr , &
rtB . otjjwnfbam , & rtB . psl1pylfxp , & rtB . a1pwur2f3n , & rtB .
bmkbfj44hc , & rtB . mymfehhqyf , & rtB . nwootfl0wl , & rtB . e42dsovuoz , &
rtB . gbmzzjn501 , & rtB . neo3wgh5k0 , & rtB . cngflnzqr2 , & rtB .
bcqp5bw5m5 , & rtB . pcrjjj3bl2 , & rtB . lehkr3fuer , & rtB . gjgshqegfr , &
rtB . n5szlr3nqx , & rtB . filzxjl5ur , & rtB . fngvfw2vbc , & rtB .
f4hgeqqzrq , & rtB . nawqkqqhwd , & rtB . gy2pn1xoxf , & rtB . f5toqxhshz , &
rtB . oihkxrrgl0 , & rtB . hjgu4nxp5v , & rtB . gzwwnxifap [ 0 ] , & rtB .
e4hlm2rw4k [ 0 ] , & rtB . khbkyi2o4w , & rtB . kkvkd0imzv [ 0 ] , & rtB .
byyxlan4vv [ 0 ] , & rtB . gnqhbaw5wi [ 0 ] , & rtB . ccegoze1r3 [ 0 ] , &
rtB . ooqdf4csin , & rtB . aqgrfvolcg , & rtB . deezhakrkc , & rtB .
pabcbevt20 , & rtB . p4p2fahxpn , & rtB . be32mwjpny , & rtB . pqzrrvf1s1 , &
rtB . i0ea205hal , & rtB . hmuvnzmkyq , & rtB . ptudxy54cl , & rtB .
oxbbdbrc3h , & rtB . ipzhuu4ptw , & rtB . iezulznyyl , & rtB . d5jbm0zxii , &
rtB . bvpvkwxod3 , & rtB . cgbzrrdvnj , & rtB . bwnprsaklm , & rtB .
jakgot214r , & rtB . a0ohbtp3be , & rtB . gwc4gctvfb , & rtB . hr1ymwwo43 , &
rtB . cxpepskh1k [ 0 ] , & rtB . d4u1qga40r [ 0 ] , & rtB . fpc3kvomhx [ 0 ]
, & rtB . mg1gi4ne5h [ 0 ] , & rtB . niay40fjqf , & rtB . hjnfpefc4k , & rtB
. c51nh4xf1q , & rtB . hcjtzzfngx , & rtB . af10lxjheq , & rtB . cdukvsxdzj ,
& rtB . izpbloaset , & rtB . jv5t3iflfp , & rtB . kttme4p4ih , & rtB .
nuzd1nehkt , & rtB . cywrrn5vf0 , & rtB . ja533qrntz , & rtB . hr53vp5214 , &
rtB . cfvuxsaes1 , & rtB . m5mik3hen3 , & rtB . j1vwznyubj , & rtB .
cl1znduuno , & rtB . pykujdhald , & rtB . enbnzlp5pu , & rtB . gjz4ggefl2 , &
rtB . atav4hz2t0 , & rtB . ndunxwoqnz [ 0 ] , & rtB . kcfelslddn [ 0 ] , &
rtB . hcovsf5jov [ 0 ] , & rtB . lphjnbgv2d [ 0 ] , & rtB . nka52w5p2z , &
rtB . jxi4eauchh , & rtB . hkcf5uul0d , & rtB . lhhtg1palw , & rtB .
k0tidcedyr , & rtB . nhbww2xvcr , & rtB . cwlnlciysh , & rtB . ad5v3ototp , &
rtB . oipwcmrhbu , & rtB . ojebse5nps , & rtB . kkv1oof2ml , & rtB .
jlrqkf40e4 , & rtB . bn2cyxj3zl , & rtB . dnc1haqpya , & rtB . ijry4eme3e , &
rtB . fwpjmaqmyl , & rtB . ivfkkggxvv , & rtB . hvbdhrufgk , & rtB .
lhj1mrpnaq , & rtB . jrt1dp0uea , & rtB . nfrth1ueqb , & rtB . d1gpz5ny3l [ 0
] , & rtB . kygrahp5cz [ 0 ] , & rtB . cjndlopolx [ 0 ] , & rtB . at40po5flv
[ 0 ] , & rtB . fmprtpx12v , & rtB . kz5y1t5h5o , & rtB . gn1ehycyi2 , & rtB
. gomqwjxzd5 , & rtB . ngfkb5ghae , & rtB . byqwyjabue , & rtB . knag0fuf4e ,
& rtB . ofqxlds3eh , & rtB . kgz10dnw3h , & rtB . aww14lps2o , & rtB .
l52vljxmqk , & rtB . imwf4qbc3k , & rtB . ixwvnfjyht , & rtB . njmqdqum11 , &
rtB . c1yr1t1pln , & rtB . oocd2yqorm , & rtB . ammqm2ucfq , & rtB .
jhzdsfrzpr , & rtB . e1he2cpfsi , & rtB . nqjaq0ah0p , & rtB . ggcp4lpehl , &
rtB . i0nwte41mb [ 0 ] , & rtB . b101dzqhyh [ 0 ] , & rtB . itee030nb5 [ 0 ]
, & rtB . j2yhvvmzdt [ 0 ] , & rtB . l0fygtafkq , & rtB . pzkcy4pfea , & rtB
. nsz3sakdbs , & rtB . mxu3fd52lg , & rtB . enfj1pjw2o , & rtB . aqj5tzxay2 ,
& rtB . j1rfmexczt , & rtB . nszpfs0j4c , & rtB . n244nv1bl5 , & rtB .
lvnp1e1py5 , & rtB . mu2u0ykmdh , & rtB . b05wxiklmy , & rtB . cpybkyynn4 , &
rtB . cgviec4bkd , & rtB . po4oftxsww , & rtB . ermmdxeqvq , & rtB .
dtff1cx0dd , & rtB . epmqzfkazx , & rtB . n2s1hb1sdd , & rtB . dkrfxtvrav , &
rtB . owzswdceo3 , & rtB . lnwt3320xf , & rtB . kwlwx42yav , & rtB .
f1jzjr5wtp , & rtB . ezdk1hee5n , & rtB . buretmbzch , & rtB . mhvcgzbyma , &
rtB . dcu2acxtfg , & rtB . lnh2z2pbk3 , & rtB . ovmxhmbhlf , & rtB .
g2q1v5iy2d , & rtB . pbgvg2nezd , & rtB . jzeacrnsxs , & rtB . ghpkp3e4ii , &
rtB . klom0nem0m , & rtB . aolyxnh1an , & rtB . palr0v3uue , & rtB .
fzhbdpl21m , & rtB . fllp1jvygi , & rtB . iilivmsrjv , & rtB . ln3b5mokgm , &
rtB . krwk3nllsf , & rtB . cpkwdk2p01 , & rtB . kxozrd4z5i , & rtP .
Battery1_BatType , & rtP . Battery2_BatType , & rtP . Battery3_BatType , &
rtP . Battery4_BatType , & rtP . Battery5_BatType , & rtP . PWM_Period , &
rtP . PWM1_Period , & rtP . PWM2_Period , & rtP . PWM3_Period , & rtP .
PWM4_Period , & rtP . PWM5_Period , & rtP . Constant2_Value_e4jyxae25b , &
rtP . Constant3_Value_bkb3mktfvw , & rtP . Constant6_Value , & rtP .
Constant7_Value , & rtP . Constant8_Value , & rtP .
Constant9_Value_crabpzohh2 , & rtP . donotdeletethisgain_Gain_hwxhghbjtm , &
rtP . OutputSamplePoints_Value [ 0 ] , & rtP .
OutputSamplePoints_Value_bs0he10brt [ 0 ] , & rtP .
OutputSamplePoints_Value_mmzz2j1vii [ 0 ] , & rtP .
OutputSamplePoints_Value_h5oozv5nnj [ 0 ] , & rtP .
OutputSamplePoints_Value_mkqnjleygm [ 0 ] , & rtP .
OutputSamplePoints_Value_k42vy4v1xv [ 0 ] , & rtP .
donotdeletethisgain_Gain_jslrw2wpeb , & rtP .
donotdeletethisgain_Gain_dywzmacz1o , & rtP . Constant_Value_jorngiczgp , &
rtP . Constant1_Value , & rtP . Constant12_Value , & rtP . Constant9_Value ,
& rtP . Gain_Gain , & rtP . Gain2_Gain , & rtP . R_Gain_cwdppwgit4 , & rtP .
R1_Gain , & rtP . R2_Gain , & rtP . R3_Gain , & rtP . R4_Gain_dz5jfuhlfd , &
rtP . inti_UpperSat , & rtP . inti_LowerSat , & rtP . itinit_InitialCondition
, & rtP . itinit1_InitialCondition , & rtP . Saturation_UpperSat_pcz043fnep ,
& rtP . Saturation_LowerSat_b05y2t0vvl , & rtP . BAL_A , & rtP . BAL_C , &
rtP . Currentfilter_A , & rtP . Currentfilter_C , & rtP .
donotdeletethisgain_Gain , & rtP . Constant_Value_fzmb45jy2r , & rtP .
Constant1_Value_jelmmtr1rj , & rtP . Constant12_Value_df3z3yuypl , & rtP .
Constant9_Value_bfo0fnc5l1 , & rtP . Gain_Gain_ozvwrv1fuy , & rtP .
Gain2_Gain_m4x3vq3y1f , & rtP . R_Gain , & rtP . R1_Gain_k1h1x1zryv , & rtP .
R2_Gain_jrqfqsl4vo , & rtP . R3_Gain_dgx1dntlxw , & rtP . R4_Gain , & rtP .
inti_UpperSat_itldayqrxp , & rtP . inti_LowerSat_lz3gh0icex , & rtP .
itinit_InitialCondition_pv4h4vt0ps , & rtP .
itinit1_InitialCondition_l3j5mkh0dv , & rtP . Saturation_UpperSat_aqwzuangfk
, & rtP . Saturation_LowerSat_bcd3czsgyq , & rtP . BAL_A_cudqa1u03y , & rtP .
BAL_C_pnvzkp4ayj , & rtP . Currentfilter_A_hazdhojaym , & rtP .
Currentfilter_C_ldprzne4qv , & rtP . donotdeletethisgain_Gain_o42imifl5k , &
rtP . Constant_Value_kiu123temw , & rtP . Constant1_Value_jj3f5fu3xp , & rtP
. Constant12_Value_ktnzmkcekm , & rtP . Constant9_Value_nhyzz1ckmw , & rtP .
Gain_Gain_jbuudt1ftk , & rtP . Gain2_Gain_jptbha03po , & rtP .
R_Gain_g4gmpqe5wx , & rtP . R1_Gain_elo0441xsu , & rtP . R2_Gain_fij43s2whq ,
& rtP . R3_Gain_de1tgv0zzw , & rtP . R4_Gain_ckkisgzyfx , & rtP .
inti_UpperSat_nowwhgaxwk , & rtP . inti_LowerSat_cwekkzbyq1 , & rtP .
itinit_InitialCondition_nf4pvnucgc , & rtP .
itinit1_InitialCondition_go30gfvhlp , & rtP . Saturation_UpperSat_i3x3oscagf
, & rtP . Saturation_LowerSat_gnz45aadu0 , & rtP . BAL_A_n35zxahhei , & rtP .
BAL_C_ix2bm3qtha , & rtP . Currentfilter_A_pyl0ygpghg , & rtP .
Currentfilter_C_hx4sknoziy , & rtP . donotdeletethisgain_Gain_fjipbfzkks , &
rtP . Constant_Value_em2zyolrnm , & rtP . Constant1_Value_myhrse5szs , & rtP
. Constant12_Value_jkrk5dvljw , & rtP . Constant9_Value_ffsooduwum , & rtP .
Gain_Gain_l5lbde12wy , & rtP . Gain2_Gain_fe3eihrk0b , & rtP .
R_Gain_biqz0al5hr , & rtP . R1_Gain_ay3u4mrv4p , & rtP . R2_Gain_akgkexbqnd ,
& rtP . R3_Gain_nk0ujvzftk , & rtP . R4_Gain_nfptou1h22 , & rtP .
inti_UpperSat_itde10ibkj , & rtP . inti_LowerSat_nb1wwuftgl , & rtP .
itinit_InitialCondition_atlhsczubb , & rtP .
itinit1_InitialCondition_ia2mtm2bdv , & rtP . Saturation_UpperSat_luxvjfmfd3
, & rtP . Saturation_LowerSat_mqcesji40p , & rtP . BAL_A_jgidwk4hmh , & rtP .
BAL_C_hfghx3gysd , & rtP . Currentfilter_A_bsszjj1hem , & rtP .
Currentfilter_C_muylregegy , & rtP . donotdeletethisgain_Gain_ave45anr4u , &
rtP . Constant_Value_pfu1thap3i , & rtP . Constant1_Value_h1thd4w1zg , & rtP
. Constant12_Value_oujd2whfki , & rtP . Constant9_Value_bcezbzp4a1 , & rtP .
Gain_Gain_a4qiy5rws3 , & rtP . Gain2_Gain_of2pa5ka31 , & rtP .
R_Gain_bq04dmcpzt , & rtP . R1_Gain_bdgjwewy0w , & rtP . R2_Gain_axv50jbqfg ,
& rtP . R3_Gain_hslbhc5rsq , & rtP . R4_Gain_e51nv5aiyc , & rtP .
inti_UpperSat_ff0nysnmjy , & rtP . inti_LowerSat_hzpmw3xl5s , & rtP .
itinit_InitialCondition_mh2yj0opxq , & rtP .
itinit1_InitialCondition_po45v3mmic , & rtP . Saturation_UpperSat_p4wbgcsokm
, & rtP . Saturation_LowerSat_gdbbvpyvzg , & rtP . BAL_A_oad34lr4nf , & rtP .
BAL_C_cq3wtorxkj , & rtP . Currentfilter_A_o3r40a2fs0 , & rtP .
Currentfilter_C_e5mev0pk52 , & rtP . StateSpace_P1 [ 0 ] , & rtP .
StateSpace_P2 [ 0 ] , & rtP . StateSpace_P3 [ 0 ] , & rtP . StateSpace_P4 [ 0
] , & rtP . StateSpace_P5 [ 0 ] , & rtP . StateSpace_P6 [ 0 ] , & rtP .
StateSpace_P7 [ 0 ] , & rtP . StateSpace_P8 [ 0 ] , & rtP . StateSpace_P9 , &
rtP . StateSpace_P10 , & rtP . Constant_Value , & rtP .
Constant_Value_efypwvyyax , & rtP . Constant1_Value_ks0gbwvaxk , & rtP .
Constant2_Value , & rtP . Constant3_Value , & rtP . Constant4_Value , & rtP .
Gain1_Gain , & rtP . Gain4_Gain , & rtP . Integrator2_IC , & rtP .
Saturation_UpperSat , & rtP . Saturation_LowerSat , & rtP .
Constant_Value_pbqzqfbpnm , & rtP . Constant_Value_hu3rmuppbn , & rtP .
Constant1_Value_jxqfbvs00y , & rtP . Constant2_Value_nbkvr3eqsy , & rtP .
Constant3_Value_k030zkojhy , & rtP . Constant4_Value_p1xz0cpgth , & rtP .
Gain1_Gain_og11bwmhu2 , & rtP . Gain4_Gain_kh00znyazs , & rtP .
Integrator2_IC_finfcihmmt , & rtP . Saturation_UpperSat_lxx4j3fnoa , & rtP .
Saturation_LowerSat_kwi433xk5g , & rtP . Constant_Value_bksqnhysc0 , & rtP .
Constant_Value_owtewy0ssm , & rtP . Constant1_Value_gbfcrdkgqa , & rtP .
Constant2_Value_gnk2tjoo5o , & rtP . Constant3_Value_hat1prtoip , & rtP .
Constant4_Value_cmgjzabbd1 , & rtP . Gain1_Gain_anymdqpqln , & rtP .
Gain4_Gain_fstjjgzlds , & rtP . Integrator2_IC_kqbwod02j2 , & rtP .
Saturation_UpperSat_blj3ug4rzx , & rtP . Saturation_LowerSat_o0i20janpw , &
rtP . Constant_Value_kedzfrfegv , & rtP . Constant_Value_opaksbgo21 , & rtP .
Constant1_Value_am3al2n15v , & rtP . Constant2_Value_odhbgl2n1s , & rtP .
Constant3_Value_mujtf1guv4 , & rtP . Constant4_Value_ohbtynzx54 , & rtP .
Gain1_Gain_baecfd2g1g , & rtP . Gain4_Gain_n2oajsg4xg , & rtP .
Integrator2_IC_gtek0x1of0 , & rtP . Saturation_UpperSat_c0l2pkijii , & rtP .
Saturation_LowerSat_g1ovkjgj1x , & rtP . Constant_Value_epq2rsx4ba , & rtP .
Constant_Value_h45zreb2fb , & rtP . Constant1_Value_ny1xdqiske , & rtP .
Constant2_Value_ppmjeluned , & rtP . Constant3_Value_kuyjih2run , & rtP .
Constant4_Value_om2zghpbx3 , & rtP . Gain1_Gain_dq4vkdpk0h , & rtP .
Gain4_Gain_j4eqtusam3 , & rtP . Integrator2_IC_iw5ohpmyuz , & rtP .
Saturation_UpperSat_dr1jmbb0we , & rtP . Saturation_LowerSat_haspwmkdbs , &
rtP . gate_Value , & rtP . gate_Value_ghlgnnffhp , & rtP .
gate_Value_e2pzllcxv0 , & rtP . gate_Value_odvaswnitz , & rtP .
gate_Value_pf2c4dq35r , & rtP . gate_Value_a3a3irpdyg , & rtP .
gate_Value_bnwmvqs5lt , & rtP . gate_Value_poeni2w0ko , & rtP .
gate_Value_pp1t0xusap , & rtP . gate_Value_ibmjcspxwo , & rtP .
gate_Value_hrisjp3q0m , & rtP . gate_Value_gy4tkqzmme , & rtP .
gate_Value_hu4hogb4lk , & rtP . gate_Value_hob43axlzj , & rtP .
gate_Value_o02a13bzdb , & rtP . gate_Value_awsbj1udfy , & rtP .
gate_Value_lcm302k1d0 , & rtP . gate_Value_hzvnhzjbik , & rtP .
Constant_Value_ogegtmkzv0 , & rtP . Constant_Value_h5irp45zuu , & rtP .
Constant_Value_k5pwul1wle , & rtP . Constant_Value_pp4lg2cwxs , & rtP .
Constant_Value_khiqevv1tc , } ; static int32_T * rtVarDimsAddrMap [ ] = { (
NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 , 0 } , {
"unsigned char" , "boolean_T" , 0 , 0 , sizeof ( boolean_T ) , SS_BOOLEAN , 0
, 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 2 , 2 , 0 } , {
rtwCAPI_VECTOR , 4 , 2 , 0 } , { rtwCAPI_VECTOR , 6 , 2 , 0 } , {
rtwCAPI_VECTOR , 8 , 2 , 0 } , { rtwCAPI_VECTOR , 10 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 12 , 2 , 0 } , { rtwCAPI_VECTOR , 14 , 2 , 0 } , {
rtwCAPI_VECTOR , 16 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 18 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 20 , 2 , 0 } , { rtwCAPI_VECTOR , 22 , 2 , 0 } , {
rtwCAPI_VECTOR , 24 , 2 , 0 } } ; static const uint_T rtDimensionArray [ ] =
{ 1 , 1 , 101 , 1 , 7 , 1 , 72 , 1 , 4 , 1 , 1 , 101 , 102 , 49 , 1 , 4 , 6 ,
1 , 102 , 39 , 2 , 36 , 1 , 36 , 36 , 1 } ; static const real_T
rtcapiStoredFloats [ ] = { 0.0 , 1.0 } ; static const rtwCAPI_FixPtMap
rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) , rtwCAPI_FIX_RESERVED , 0 , 0 , 0 }
, } ; static const rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const
void * ) & rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [
0 ] , 0 , 0 } , { ( const void * ) & rtcapiStoredFloats [ 0 ] , ( const void
* ) & rtcapiStoredFloats [ 1 ] , 1 , 0 } , { ( NULL ) , ( NULL ) , 8 , 0 } }
; static rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 304
, rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 223 ,
rtModelParameters , 0 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 1550680249U , 746654945U , 2628067688U , 4181925083U } , ( NULL ) , 0 , 0
, rt_LoggedStateIdxList } ; const rtwCAPI_ModelMappingStaticInfo *
activeBalancing3_GetCAPIStaticMap ( void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void activeBalancing3_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion ( (
* rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void activeBalancing3_host_InitializeDataMapInfo (
activeBalancing3_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
