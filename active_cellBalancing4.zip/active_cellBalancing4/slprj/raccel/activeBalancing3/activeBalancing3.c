#include "rt_logging_mmi.h"
#include "activeBalancing3_capi.h"
#include <math.h>
#include "activeBalancing3.h"
#include "activeBalancing3_private.h"
#include "activeBalancing3_dt.h"
#include "sfcn_loader_c_api.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 8 , & stopRequested ) ; }
rtExtModeShutdown ( 8 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 0 ; int_T gbl_raccel_NumST = 9 ; const char_T
* gbl_raccel_Version = "9.5 (R2021a) 14-Nov-2020" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; const char *
raccelLoadInputsAndAperiodicHitTimes ( SimStruct * S , const char *
inportFileName , int * matFileFormat ) { return rt_RAccelReadInportsMatFile (
S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
B rtB ; X rtX ; DW rtDW ; PrevZCX rtPrevZCX ; static SimStruct model_S ;
SimStruct * const rtS = & model_S ; static void kbzm3ohuay ( const real_T x [
101 ] , const real_T params [ 3 ] , real_T y [ 101 ] ) ; static real_T
fmzhqpumbn ( real_T x , const real_T params [ 3 ] ) ; static void kbzm3ohuay
( const real_T x [ 101 ] , const real_T params [ 3 ] , real_T y [ 101 ] ) {
real_T a ; real_T b ; real_T c ; real_T x_p ; int32_T i ; a = params [ 0 ] ;
b = params [ 1 ] ; c = params [ 2 ] ; for ( i = 0 ; i < 101 ; i ++ ) { x_p =
x [ i ] ; y [ i ] = 0.0 ; if ( ( a != b ) && ( a < x_p ) && ( x_p < b ) ) { y
[ i ] = 1.0 / ( b - a ) * ( x_p - a ) ; } if ( ( b != c ) && ( b < x_p ) && (
x_p < c ) ) { y [ i ] = 1.0 / ( c - b ) * ( c - x_p ) ; } if ( x_p == b ) { y
[ i ] = 1.0 ; } } } void mpg2xj2m34 ( real_T m0o1r2frf5 , real_T jq1ntp1fsq ,
const real_T j2k3hjzsd2 [ 9 ] , const real_T n0wsumkwal [ 101 ] , iczfebuibr
* localB ) { real_T outputMFCache [ 505 ] ; real_T tmp [ 101 ] ; real_T tmp_g
[ 101 ] ; real_T tmp_i [ 101 ] ; real_T tmp_m [ 101 ] ; real_T tmp_p [ 101 ]
; real_T tmp_e [ 3 ] ; real_T mfVal ; real_T x_idx_0 ; real_T x_idx_1 ;
int32_T i ; int32_T sampleID ; static const real_T b [ 3 ] = { 0.04167 , 0.25
, 0.4583 } ; static const real_T c [ 3 ] = { 0.2917 , 0.5 , 0.7083 } ; static
const int8_T d [ 9 ] = { 1 , 4 , 2 , 2 , 5 , 3 , 3 , 3 , 3 } ; localB ->
fsk1owdmw3 [ 0 ] = m0o1r2frf5 ; localB -> fsk1owdmw3 [ 1 ] = jq1ntp1fsq ;
kbzm3ohuay ( n0wsumkwal , b , tmp ) ; kbzm3ohuay ( n0wsumkwal , c , tmp_p ) ;
tmp_e [ 0 ] = 0.5417 ; tmp_e [ 1 ] = 0.75 ; tmp_e [ 2 ] = 0.9583 ; kbzm3ohuay
( n0wsumkwal , tmp_e , tmp_i ) ; tmp_e [ 0 ] = 0.25 ; tmp_e [ 1 ] = 0.375 ;
tmp_e [ 2 ] = 0.5 ; kbzm3ohuay ( n0wsumkwal , tmp_e , tmp_m ) ; tmp_e [ 0 ] =
0.5 ; tmp_e [ 1 ] = 0.625 ; tmp_e [ 2 ] = 0.75 ; kbzm3ohuay ( n0wsumkwal ,
tmp_e , tmp_g ) ; for ( i = 0 ; i < 101 ; i ++ ) { localB -> k3oc5pn3ee [ i ]
= 0.0 ; outputMFCache [ 5 * i ] = tmp [ i ] ; outputMFCache [ 5 * i + 1 ] =
tmp_p [ i ] ; outputMFCache [ 5 * i + 2 ] = tmp_i [ i ] ; outputMFCache [ 5 *
i + 3 ] = tmp_m [ i ] ; outputMFCache [ 5 * i + 4 ] = tmp_g [ i ] ; } for ( i
= 0 ; i < 9 ; i ++ ) { x_idx_1 = j2k3hjzsd2 [ i ] ; for ( sampleID = 0 ;
sampleID < 101 ; sampleID ++ ) { x_idx_0 = outputMFCache [ ( 5 * sampleID + d
[ i ] ) - 1 ] ; if ( ( x_idx_0 > x_idx_1 ) || ( muDoubleScalarIsNaN ( x_idx_0
) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { mfVal = x_idx_1 ; } else {
mfVal = x_idx_0 ; } x_idx_0 = localB -> k3oc5pn3ee [ sampleID ] ; if ( (
x_idx_0 < mfVal ) || ( muDoubleScalarIsNaN ( x_idx_0 ) && ( !
muDoubleScalarIsNaN ( mfVal ) ) ) ) { localB -> k3oc5pn3ee [ sampleID ] =
mfVal ; } else { localB -> k3oc5pn3ee [ sampleID ] = x_idx_0 ; } } } } static
real_T fmzhqpumbn ( real_T x , const real_T params [ 3 ] ) { real_T y ; y =
0.0 ; if ( ( params [ 0 ] != params [ 1 ] ) && ( params [ 0 ] < x ) && ( x <
params [ 1 ] ) ) { y = 1.0 / ( params [ 1 ] - params [ 0 ] ) * ( x - params [
0 ] ) ; } if ( ( params [ 1 ] != params [ 2 ] ) && ( params [ 1 ] < x ) && (
x < params [ 2 ] ) ) { y = 1.0 / ( params [ 2 ] - params [ 1 ] ) * ( params [
2 ] - x ) ; } if ( x == params [ 1 ] ) { y = 1.0 ; } return y ; } void
MdlInitialize ( void ) { boolean_T tmp ; rtDW . mwtjai2xzq = rtP .
itinit1_InitialCondition ; rtX . btwaflzkr2 = 0.0 ; rtDW . abnasr53i2 = rtP .
itinit_InitialCondition ; rtDW . mjabmoou2z = 1 ; if ( ssIsFirstInitCond (
rtS ) ) { rtX . cwzgk12fex = 0.0 ; tmp = slIsRapidAcceleratorSimulating ( ) ;
if ( tmp ) { tmp = ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW .
mjabmoou2z = ! tmp ; } else { rtDW . mjabmoou2z = 1 ; } rtX . edarxfgg3m =
0.0 ; } rtX . p2dwfugebo = rtP . Integrator2_IC ; rtX . gzwgpg3i32 = 0.0 ;
rtDW . puhqb53xlf = rtP . itinit1_InitialCondition_l3j5mkh0dv ; rtX .
ieqye3wyr3 = 0.0 ; rtDW . cgtn4vtk4v = rtP .
itinit_InitialCondition_pv4h4vt0ps ; rtDW . apw4epat2u = 1 ; if (
ssIsFirstInitCond ( rtS ) ) { tmp = slIsRapidAcceleratorSimulating ( ) ; if (
tmp ) { tmp = ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . apw4epat2u =
! tmp ; } else { rtDW . apw4epat2u = 1 ; } rtX . hytl13jcro = 0.0 ; } rtX .
n1mefgeo42 = rtP . Integrator2_IC_finfcihmmt ; rtX . kwkmxprem3 = 0.0 ; rtDW
. e5chgaqzdi = rtP . itinit1_InitialCondition_go30gfvhlp ; rtX . g0ii5xynxb =
0.0 ; rtDW . br1vosysg0 = rtP . itinit_InitialCondition_nf4pvnucgc ; rtDW .
fid4f0juyg = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . fid4f0juyg = ! tmp ; }
else { rtDW . fid4f0juyg = 1 ; } rtX . hqm1okddyw = 0.0 ; } rtX . daazrzvjzg
= rtP . Integrator2_IC_kqbwod02j2 ; rtX . kmijbaomfh = 0.0 ; rtDW .
bw2f200uhe = rtP . itinit1_InitialCondition_ia2mtm2bdv ; rtX . e3mceh2nlv =
0.0 ; rtDW . h1kn4wxczz = rtP . itinit_InitialCondition_atlhsczubb ; rtDW .
a12tj2tqvt = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . a12tj2tqvt = ! tmp ; }
else { rtDW . a12tj2tqvt = 1 ; } rtX . brizaijzew = 0.0 ; } rtX . abk5ytngnj
= rtP . Integrator2_IC_gtek0x1of0 ; rtX . kskuxricdl = 0.0 ; rtDW .
fwi0pu3glv = rtP . itinit1_InitialCondition_po45v3mmic ; rtX . lx3xuxie2j =
0.0 ; rtDW . m35jm4htkc = rtP . itinit_InitialCondition_mh2yj0opxq ; rtDW .
lb53h134aw = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . lb53h134aw = ! tmp ; }
else { rtDW . lb53h134aw = 1 ; } } rtX . jjfpdr1zyr = rtP .
Integrator2_IC_iw5ohpmyuz ; rtX . imz4v0p4of = 0.0 ; { SimStruct * rts =
ssGetSFunction ( rtS , 0 ) ; sfcnInitializeConditions ( rts ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } rtDW . ep01khxy3s =
ssGetTaskTime ( rtS , 6 ) ; rtDW . hyvrqtp0nq = true ; rtDW . f4jvehgaau =
true ; rtDW . fnsfdleb5s = ssGetTaskTime ( rtS , 6 ) ; rtDW . mg0udjzg3z = (
rtMinusInf ) ; rtDW . gil1dfunsb = 0ULL ; rtDW . fatdrnikff = true ; rtDW .
dz22xyy0n2 = true ; rtDW . esnkvscczq = ssGetTaskTime ( rtS , 5 ) ; rtDW .
oklojozd5l = true ; rtDW . gutf54om0t = true ; rtDW . o2neiszzpu =
ssGetTaskTime ( rtS , 5 ) ; rtDW . h21d2fqnwl = ( rtMinusInf ) ; rtDW .
oxz1dp4rtp = 0ULL ; rtDW . awriz1pum1 = true ; rtDW . hwlma5twap = true ;
rtDW . f4vpteq14c = ssGetTaskTime ( rtS , 7 ) ; rtDW . lkdrn04ha3 = true ;
rtDW . n2wn2lgi4k = true ; rtDW . mlaq1sf05w = ssGetTaskTime ( rtS , 7 ) ;
rtDW . imnddva2yd = ( rtMinusInf ) ; rtDW . i4itkhygug = 0ULL ; rtDW .
lptg51m4go = true ; rtDW . c4mx45ei5j = true ; rtDW . bv3ta2c31d =
ssGetTaskTime ( rtS , 4 ) ; rtDW . cwj4t5csvl = true ; rtDW . cgi440wi10 =
true ; rtDW . gvyq4tdih4 = ssGetTaskTime ( rtS , 4 ) ; rtDW . cukktpbdau = (
rtMinusInf ) ; rtDW . fzl1x30105 = 0ULL ; rtDW . nqrddpnaqi = true ; rtDW .
lvplimut2k = true ; rtDW . hwclgprvm0 = ssGetTaskTime ( rtS , 3 ) ; rtDW .
b45hsrgxk4 = true ; rtDW . ff0qbzbocl = true ; rtDW . nlleqzlpac =
ssGetTaskTime ( rtS , 3 ) ; rtDW . h0ir15tiwo = ( rtMinusInf ) ; rtDW .
kuacjottby = 0ULL ; rtDW . j553vsqqsn = true ; rtDW . kevb4e4jpg = true ;
rtDW . dp1esyh3gc = ssGetTaskTime ( rtS , 2 ) ; rtDW . d0uk2u5ily = true ;
rtDW . opghe0hhiz = true ; rtDW . dul0uayr5l = ssGetTaskTime ( rtS , 2 ) ;
rtDW . mk2k513iba = ( rtMinusInf ) ; rtDW . dtdzggbusy = 0ULL ; rtDW .
hykritwrbg = true ; rtDW . aznjkggrjt = true ; } void MdlEnable ( void ) {
_ssSetSampleHit ( rtS , 6 , 1 ) ; _ssSetTaskTime ( rtS , 6 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 4 , ssGetT ( rtS ) ) ; ; rtDW . hyvrqtp0nq =
true ; rtDW . f4jvehgaau = true ; rtDW . fnsfdleb5s = ssGetTaskTime ( rtS , 6
) ; rtDW . mg0udjzg3z = ( rtMinusInf ) ; rtDW . gil1dfunsb = 0ULL ;
_ssSetSampleHit ( rtS , 5 , 1 ) ; _ssSetTaskTime ( rtS , 5 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 3 , ssGetT ( rtS ) ) ; ; rtDW . oklojozd5l =
true ; rtDW . gutf54om0t = true ; rtDW . o2neiszzpu = ssGetTaskTime ( rtS , 5
) ; rtDW . h21d2fqnwl = ( rtMinusInf ) ; rtDW . oxz1dp4rtp = 0ULL ;
_ssSetSampleHit ( rtS , 7 , 1 ) ; _ssSetTaskTime ( rtS , 7 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 5 , ssGetT ( rtS ) ) ; ; rtDW . lkdrn04ha3 =
true ; rtDW . n2wn2lgi4k = true ; rtDW . mlaq1sf05w = ssGetTaskTime ( rtS , 7
) ; rtDW . imnddva2yd = ( rtMinusInf ) ; rtDW . i4itkhygug = 0ULL ;
_ssSetSampleHit ( rtS , 4 , 1 ) ; _ssSetTaskTime ( rtS , 4 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 2 , ssGetT ( rtS ) ) ; ; rtDW . cwj4t5csvl =
true ; rtDW . cgi440wi10 = true ; rtDW . gvyq4tdih4 = ssGetTaskTime ( rtS , 4
) ; rtDW . cukktpbdau = ( rtMinusInf ) ; rtDW . fzl1x30105 = 0ULL ;
_ssSetSampleHit ( rtS , 3 , 1 ) ; _ssSetTaskTime ( rtS , 3 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 1 , ssGetT ( rtS ) ) ; ; rtDW . b45hsrgxk4 =
true ; rtDW . ff0qbzbocl = true ; rtDW . nlleqzlpac = ssGetTaskTime ( rtS , 3
) ; rtDW . h0ir15tiwo = ( rtMinusInf ) ; rtDW . kuacjottby = 0ULL ;
_ssSetSampleHit ( rtS , 2 , 1 ) ; _ssSetTaskTime ( rtS , 2 , ssGetT ( rtS ) )
; _ssSetVarNextHitTime ( rtS , 0 , ssGetT ( rtS ) ) ; ; rtDW . d0uk2u5ily =
true ; rtDW . opghe0hhiz = true ; rtDW . dul0uayr5l = ssGetTaskTime ( rtS , 2
) ; rtDW . mk2k513iba = ( rtMinusInf ) ; rtDW . dtdzggbusy = 0ULL ; } void
MdlStart ( void ) { { bool externalInputIsInDatasetFormat = false ; void *
pISigstreamManager = rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} { { { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "SOC2" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "<SOC (%)>" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"activeBalancing3/Bus Selector1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "SOC2" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . kefwpubmhm . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "bc928828-f7de-48f6-9ec8-b6dc569c33a2" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. kefwpubmhm . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . kefwpubmhm
. AQHandles , "Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime
( rtDW . kefwpubmhm . AQHandles , ssGetTaskTime ( rtS , 1 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . kefwpubmhm . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . kefwpubmhm . AQHandles ,
loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } } { { { { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"activeBalancing3/Bus Selector1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. pvibdkum0b . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"dc40be72-4db7-4137-bbe8-15e107fa0caa" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . pvibdkum0b . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . pvibdkum0b . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . pvibdkum0b .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . pvibdkum0b . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . pvibdkum0b . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC3" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing3/Bus Selector2" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC3" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. a1aeuz3o44 . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"a514b898-4976-4bee-a1ac-8413caef0228" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . a1aeuz3o44 . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . a1aeuz3o44 . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . a1aeuz3o44 .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . a1aeuz3o44 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . a1aeuz3o44 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing3/Bus Selector2"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. m5pgrgp4cg . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"141e062c-9d6d-4d13-9c94-8b4bba7503c3" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . m5pgrgp4cg . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . m5pgrgp4cg . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . m5pgrgp4cg .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . m5pgrgp4cg . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . m5pgrgp4cg . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC4" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing3/Bus Selector3" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC4" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. oee5uekymg . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"64e5b82e-3a05-4427-8055-b0dc4a4e5225" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . oee5uekymg . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . oee5uekymg . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . oee5uekymg .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . oee5uekymg . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . oee5uekymg . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing3/Bus Selector3"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. jrgeolpedl . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"629ccaab-13f8-47b0-b182-ebe006cd73e6" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . jrgeolpedl . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . jrgeolpedl . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . jrgeolpedl .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . jrgeolpedl . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . jrgeolpedl . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC5" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing3/Bus Selector4" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC5" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. l4br0owshy . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"e753d860-6817-4def-9046-bcc29b14f700" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . l4br0owshy . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . l4br0owshy . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . l4br0owshy .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . l4br0owshy . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . l4br0owshy . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing3/Bus Selector4"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. eqbzffk253 . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"4a575a04-7830-4cab-ba5a-587d9c457182" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . eqbzffk253 . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . eqbzffk253 . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . eqbzffk253 .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . eqbzffk253 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . eqbzffk253 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC1" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing3/Bus Selector" ) ; sdiLabelU blockSID
= sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( ""
) ; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "SOC1" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . m1fwuqpiaf . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "3030bc16-1ac7-4b16-a924-f1470b0899e9" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. m1fwuqpiaf . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . m1fwuqpiaf
. AQHandles , "Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime
( rtDW . m1fwuqpiaf . AQHandles , ssGetTaskTime ( rtS , 1 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . m1fwuqpiaf . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . m1fwuqpiaf . AQHandles ,
loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } } { SimStruct * rts = ssGetSFunction ( rtS
, 0 ) ; sfcnStart ( rts ) ; if ( ssGetErrorStatus ( rts ) != ( NULL ) )
return ; } MdlInitialize ( ) ; MdlEnable ( ) ; } void MdlOutputs ( int_T tid
) { real_T hjc2zrpfd1 ; real_T klzckgpczr ; real_T emdery3j3h ; real_T
ljjscjpyp3 ; real_T clfo2evmya ; real_T mvqo31tded ; real_T a22jepug13 ;
real_T cvslmzqbuu ; real_T keqr5ofuik ; real_T e31snwaiia ; real_T ggdrwjpthm
; real_T es2okkv3ou ; real_T hsohdbixmb [ 9 ] ; real_T dsdonux4di [ 9 ] ;
real_T o1xehwvj4t [ 9 ] ; real_T owrgksly4x [ 9 ] ; real_T cuo1icjl4a [ 9 ] ;
real_T d1e4amgrqc [ 9 ] ; real_T inputMFCache [ 6 ] ; real_T tmp_p [ 3 ] ;
real_T jmuz0todoh ; real_T k0qu5tzxih ; real_T x_idx_1 ; int_T iy ; boolean_T
tmp ; ZCEventType zcEvent ; static const real_T b [ 3 ] = { 0.4167 , 2.5 ,
4.583 } ; static const real_T c [ 3 ] = { 2.917 , 5.0 , 7.085 } ; static
const real_T d [ 3 ] = { 8.333 , 50.0 , 91.67 } ; static const real_T e [ 3 ]
= { 58.33 , 100.0 , 141.7 } ; static const int8_T f [ 18 ] = { 1 , 1 , 1 , 2
, 2 , 2 , 3 , 3 , 3 , 3 , 2 , 1 , 3 , 2 , 1 , 1 , 2 , 3 } ; rtB . lssfzuya44
= 0.0 ; rtB . lssfzuya44 += rtP . Currentfilter_C * rtX . btwaflzkr2 ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . ldokaf3uyj = rtDW . mwtjai2xzq ; rtB
. hitd4jbxxo = rtP . R2_Gain * rtB . ldokaf3uyj ; rtB . g3cnit1gts = 1.000001
* rtB . hitd4jbxxo * 0.96711798839458663 / 0.9999 ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . oemcgetehw = ( rtB . lssfzuya44 >
rtP . Constant_Value ) ; } rtB . patx3e3lyu = rtDW . oemcgetehw ; rtB .
o3tagh4era = rtDW . abnasr53i2 ; } tmp = ssGetIsOkayToUpdateMode ( rtS ) ; if
( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
prxdc20lxc , ( rtB . patx3e3lyu ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . mjabmoou2z != 0 ) ) { rtX . cwzgk12fex = rtB . o3tagh4era ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . cwzgk12fex
>= rtP . inti_UpperSat ) { if ( rtX . cwzgk12fex != rtP . inti_UpperSat ) {
rtX . cwzgk12fex = rtP . inti_UpperSat ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . ndyjjzoyah = 3
; } else if ( rtX . cwzgk12fex <= rtP . inti_LowerSat ) { if ( rtX .
cwzgk12fex != rtP . inti_LowerSat ) { rtX . cwzgk12fex = rtP . inti_LowerSat
; ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . ndyjjzoyah =
4 ; } else { if ( rtDW . ndyjjzoyah != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . ndyjjzoyah = 0
; } rtB . iyrb00kscp = rtX . cwzgk12fex ; } else { rtB . iyrb00kscp = rtX .
cwzgk12fex ; } rtB . mpjucudbtk = rtP . Gain_Gain * rtB . iyrb00kscp ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . mcoopbxhas = ( rtB . mpjucudbtk > rtB . hitd4jbxxo ) ; } rtB .
iezulznyyl = rtDW . mcoopbxhas ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . hfhq12age4 = ( rtB . mpjucudbtk < rtP . Constant9_Value ) ; } rtB .
d5jbm0zxii = rtDW . hfhq12age4 ; } if ( rtB . iezulznyyl ) { rtB . cgbzrrdvnj
= rtB . hitd4jbxxo ; } else { if ( rtB . d5jbm0zxii ) { rtB . bvpvkwxod3 =
rtP . Constant9_Value ; } else { rtB . bvpvkwxod3 = rtB . mpjucudbtk ; } rtB
. cgbzrrdvnj = rtB . bvpvkwxod3 ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . odkj4eftfi = ( rtB . g3cnit1gts
<= rtB . cgbzrrdvnj ) ; } rtB . kcf35vodg1 = rtDW . odkj4eftfi ; } if ( rtB .
kcf35vodg1 ) { rtB . apptu0x5zl = rtB . hitd4jbxxo ; } else { rtB .
apptu0x5zl = rtB . cgbzrrdvnj ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
ldokaf3uyj / ( rtB . ldokaf3uyj - rtB . apptu0x5zl ) * rtB . apptu0x5zl ;
jmuz0todoh = - rtB . patx3e3lyu * 0.00461995246297257 * rtB . lssfzuya44 *
rtB . ldokaf3uyj / ( rtB . ldokaf3uyj - rtB . apptu0x5zl ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . j04p5reu3p = rtP . R3_Gain * rtB .
ldokaf3uyj ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . mlgiqc4qhd = (
rtB . mpjucudbtk > rtB . j04p5reu3p ) ; } rtB . bwnprsaklm = rtDW .
mlgiqc4qhd ; rtB . cklmpkcmxr = - rtB . j04p5reu3p * 0.999 * 0.1 * 0.9999 ;
if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . o4yhobhacw = ( rtB .
mpjucudbtk < rtB . cklmpkcmxr ) ; } rtB . jakgot214r = rtDW . o4yhobhacw ; }
if ( rtB . bwnprsaklm ) { rtB . gwc4gctvfb = rtB . j04p5reu3p ; } else { if (
rtB . jakgot214r ) { rtB . a0ohbtp3be = rtB . cklmpkcmxr ; } else { rtB .
a0ohbtp3be = rtB . mpjucudbtk ; } rtB . gwc4gctvfb = rtB . a0ohbtp3be ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . b4xvp05dsp = ( rtB . lssfzuya44 < rtP . Constant_Value_efypwvyyax ) ;
} rtB . if50jzplnu = rtDW . b4xvp05dsp ; } switch ( ( int32_T ) rtP .
Battery1_BatType ) { case 1 : rtB . ccegoze1r3 [ 0 ] = rtP . Constant4_Value
* rtB . gwc4gctvfb ; rtB . ccegoze1r3 [ 1 ] = rtP . Constant4_Value * rtB .
lssfzuya44 ; rtB . ccegoze1r3 [ 2 ] = rtP . Constant4_Value * rtB .
if50jzplnu ; rtB . ccegoze1r3 [ 3 ] = rtP . Constant4_Value * rtB .
ldokaf3uyj ; rtB . khbkyi2o4w = - rtB . ccegoze1r3 [ 2 ] *
0.00461995246297257 * rtB . ccegoze1r3 [ 1 ] * ( 6.2039999999999846 / ( rtB .
ccegoze1r3 [ 0 ] + 0.62039999999999851 ) ) ; break ; case 2 : rtB .
kkvkd0imzv [ 0 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . gwc4gctvfb ; rtB
. kkvkd0imzv [ 1 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . lssfzuya44 ;
rtB . kkvkd0imzv [ 2 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . if50jzplnu
; rtB . kkvkd0imzv [ 3 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB .
ldokaf3uyj ; rtB . khbkyi2o4w = - rtB . kkvkd0imzv [ 2 ] *
0.00461995246297257 * rtB . kkvkd0imzv [ 1 ] * rtB . kkvkd0imzv [ 3 ] / ( rtB
. kkvkd0imzv [ 3 ] * 0.1 + rtB . kkvkd0imzv [ 0 ] ) ; break ; case 3 : rtB .
gnqhbaw5wi [ 0 ] = rtP . Constant3_Value * rtB . gwc4gctvfb ; rtB .
gnqhbaw5wi [ 1 ] = rtP . Constant3_Value * rtB . lssfzuya44 ; rtB .
gnqhbaw5wi [ 2 ] = rtP . Constant3_Value * rtB . if50jzplnu ; rtB .
gnqhbaw5wi [ 3 ] = rtP . Constant3_Value * rtB . ldokaf3uyj ; rtB .
khbkyi2o4w = - rtB . gnqhbaw5wi [ 2 ] * 0.00461995246297257 * rtB .
gnqhbaw5wi [ 1 ] * ( 6.2039999999999846 / ( muDoubleScalarAbs ( rtB .
gnqhbaw5wi [ 0 ] ) + 0.62039999999999851 ) ) ; break ; default : rtB .
byyxlan4vv [ 0 ] = rtP . Constant2_Value * rtB . gwc4gctvfb ; rtB .
byyxlan4vv [ 1 ] = rtP . Constant2_Value * rtB . lssfzuya44 ; rtB .
byyxlan4vv [ 2 ] = rtP . Constant2_Value * rtB . if50jzplnu ; rtB .
byyxlan4vv [ 3 ] = rtP . Constant2_Value * rtB . ldokaf3uyj ; rtB .
khbkyi2o4w = - rtB . byyxlan4vv [ 2 ] * 0.00461995246297257 * rtB .
byyxlan4vv [ 1 ] * ( 6.2039999999999846 / ( muDoubleScalarAbs ( rtB .
byyxlan4vv [ 0 ] ) + 0.62039999999999851 ) ) ; break ; } rtB . pabcbevt20 =
rtX . p2dwfugebo ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . iv0bm1cwdz = rtB
. apptu0x5zl >= rtP . Saturation_UpperSat ? 1 : rtB . apptu0x5zl > rtP .
Saturation_LowerSat ? 0 : - 1 ; } rtB . pqzrrvf1s1 = rtDW . iv0bm1cwdz == 1 ?
rtP . Saturation_UpperSat : rtDW . iv0bm1cwdz == - 1 ? rtP .
Saturation_LowerSat : rtB . apptu0x5zl ; switch ( ( int32_T ) rtP .
Battery1_BatType ) { case 1 : rtB . p4p2fahxpn = rtB . pabcbevt20 ; break ;
case 2 : rtB . p4p2fahxpn = muDoubleScalarExp ( - 10.176991150442477 * rtB .
pqzrrvf1s1 ) * 0.310711063328515 ; break ; case 3 : rtB . p4p2fahxpn = rtB .
pabcbevt20 ; break ; default : rtB . p4p2fahxpn = rtB . pabcbevt20 ; break ;
} rtB . n0wyyiyl2w = ( ( ( k0qu5tzxih + jmuz0todoh ) + rtB . khbkyi2o4w ) +
rtB . p4p2fahxpn ) + - 0.0 * rtB . apptu0x5zl ; rtB . bjzh2zswrf = rtP .
Constant_Value_jorngiczgp + rtB . n0wyyiyl2w ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . obaqwkwqid = ( rtB .
bjzh2zswrf > rtP . Constant1_Value ) ; } rtB . hmuvnzmkyq = rtDW . obaqwkwqid
; } rtB . dvd3eelqxy = 0.0 ; rtB . dvd3eelqxy += rtP . BAL_C * rtX .
gzwgpg3i32 ; rtB . htgwxujgfn = rtP . R1_Gain * rtB . dvd3eelqxy ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . kqhwhpbc2l = ( rtB . bjzh2zswrf < rtB . htgwxujgfn ) ; } rtB .
ptudxy54cl = rtDW . kqhwhpbc2l ; rtB . mxtffwnyug = rtDW . puhqb53xlf ; rtB .
olx2nutnfv = rtP . R2_Gain_jrqfqsl4vo * rtB . mxtffwnyug ; rtB . iadrygzp4x =
1.000001 * rtB . olx2nutnfv * 0.96711798839458663 / 0.9999 ; } if ( rtB .
hmuvnzmkyq ) { rtB . ipzhuu4ptw = rtP . Constant1_Value ; } else { if ( rtB .
ptudxy54cl ) { rtB . oxbbdbrc3h = rtB . htgwxujgfn ; } else { rtB .
oxbbdbrc3h = rtB . bjzh2zswrf ; } rtB . ipzhuu4ptw = rtB . oxbbdbrc3h ; } rtB
. fd3qiys2ps = 0.0 ; rtB . fd3qiys2ps += rtP . Currentfilter_C_ldprzne4qv *
rtX . ieqye3wyr3 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . lptbui3bdr = ( rtB . fd3qiys2ps >
rtP . Constant_Value_pbqzqfbpnm ) ; } rtB . mkvq5xwqnm = rtDW . lptbui3bdr ;
rtB . biwszoosgc = rtDW . cgtn4vtk4v ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
oizxtz1h42 , ( rtB . mkvq5xwqnm ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . apw4epat2u != 0 ) ) { rtX . edarxfgg3m = rtB . biwszoosgc ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . edarxfgg3m
>= rtP . inti_UpperSat_itldayqrxp ) { if ( rtX . edarxfgg3m != rtP .
inti_UpperSat_itldayqrxp ) { rtX . edarxfgg3m = rtP .
inti_UpperSat_itldayqrxp ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . pngsgibtfq = 3 ; } else if ( rtX . edarxfgg3m <= rtP .
inti_LowerSat_lz3gh0icex ) { if ( rtX . edarxfgg3m != rtP .
inti_LowerSat_lz3gh0icex ) { rtX . edarxfgg3m = rtP .
inti_LowerSat_lz3gh0icex ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . pngsgibtfq = 4 ; } else { if ( rtDW . pngsgibtfq != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . pngsgibtfq = 0
; } rtB . cd5jv3welm = rtX . edarxfgg3m ; } else { rtB . cd5jv3welm = rtX .
edarxfgg3m ; } rtB . pse0v0upak = rtP . Gain_Gain_ozvwrv1fuy * rtB .
cd5jv3welm ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hz3s4vrezj = ( rtB . pse0v0upak >
rtB . olx2nutnfv ) ; } rtB . hr53vp5214 = rtDW . hz3s4vrezj ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . dhbq4fq1y5 = ( rtB . pse0v0upak <
rtP . Constant9_Value_bfo0fnc5l1 ) ; } rtB . cfvuxsaes1 = rtDW . dhbq4fq1y5 ;
} if ( rtB . hr53vp5214 ) { rtB . j1vwznyubj = rtB . olx2nutnfv ; } else { if
( rtB . cfvuxsaes1 ) { rtB . m5mik3hen3 = rtP . Constant9_Value_bfo0fnc5l1 ;
} else { rtB . m5mik3hen3 = rtB . pse0v0upak ; } rtB . j1vwznyubj = rtB .
m5mik3hen3 ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . gwmmodqfqo = ( rtB . iadrygzp4x <=
rtB . j1vwznyubj ) ; } rtB . cc2mpg0gqp = rtDW . gwmmodqfqo ; } if ( rtB .
cc2mpg0gqp ) { rtB . nqwiqvxip0 = rtB . olx2nutnfv ; } else { rtB .
nqwiqvxip0 = rtB . j1vwznyubj ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
mxtffwnyug / ( rtB . mxtffwnyug - rtB . nqwiqvxip0 ) * rtB . nqwiqvxip0 ;
jmuz0todoh = - rtB . mkvq5xwqnm * 0.00461995246297257 * rtB . fd3qiys2ps *
rtB . mxtffwnyug / ( rtB . mxtffwnyug - rtB . nqwiqvxip0 ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . me3a54u35r = rtP . R3_Gain_dgx1dntlxw
* rtB . mxtffwnyug ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
flqyr4ponx = ( rtB . pse0v0upak > rtB . me3a54u35r ) ; } rtB . cl1znduuno =
rtDW . flqyr4ponx ; rtB . fj5f5uf5pw = - rtB . me3a54u35r * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . drp1pdx1o2 = ( rtB .
pse0v0upak < rtB . fj5f5uf5pw ) ; } rtB . pykujdhald = rtDW . drp1pdx1o2 ; }
if ( rtB . cl1znduuno ) { rtB . gjz4ggefl2 = rtB . me3a54u35r ; } else { if (
rtB . pykujdhald ) { rtB . enbnzlp5pu = rtB . fj5f5uf5pw ; } else { rtB .
enbnzlp5pu = rtB . pse0v0upak ; } rtB . gjz4ggefl2 = rtB . enbnzlp5pu ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . mwzj54zeve = ( rtB . fd3qiys2ps < rtP . Constant_Value_hu3rmuppbn ) ;
} rtB . gukj05tcnp = rtDW . mwzj54zeve ; } switch ( ( int32_T ) rtP .
Battery2_BatType ) { case 1 : rtB . mg1gi4ne5h [ 0 ] = rtP .
Constant4_Value_p1xz0cpgth * rtB . gjz4ggefl2 ; rtB . mg1gi4ne5h [ 1 ] = rtP
. Constant4_Value_p1xz0cpgth * rtB . fd3qiys2ps ; rtB . mg1gi4ne5h [ 2 ] =
rtP . Constant4_Value_p1xz0cpgth * rtB . gukj05tcnp ; rtB . mg1gi4ne5h [ 3 ]
= rtP . Constant4_Value_p1xz0cpgth * rtB . mxtffwnyug ; rtB . hr1ymwwo43 = -
rtB . mg1gi4ne5h [ 2 ] * 0.00461995246297257 * rtB . mg1gi4ne5h [ 1 ] * (
6.2039999999999846 / ( rtB . mg1gi4ne5h [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . cxpepskh1k [ 0 ] = rtP . Constant1_Value_jxqfbvs00y *
rtB . gjz4ggefl2 ; rtB . cxpepskh1k [ 1 ] = rtP . Constant1_Value_jxqfbvs00y
* rtB . fd3qiys2ps ; rtB . cxpepskh1k [ 2 ] = rtP .
Constant1_Value_jxqfbvs00y * rtB . gukj05tcnp ; rtB . cxpepskh1k [ 3 ] = rtP
. Constant1_Value_jxqfbvs00y * rtB . mxtffwnyug ; rtB . hr1ymwwo43 = - rtB .
cxpepskh1k [ 2 ] * 0.00461995246297257 * rtB . cxpepskh1k [ 1 ] * rtB .
cxpepskh1k [ 3 ] / ( rtB . cxpepskh1k [ 3 ] * 0.1 + rtB . cxpepskh1k [ 0 ] )
; break ; case 3 : rtB . fpc3kvomhx [ 0 ] = rtP . Constant3_Value_k030zkojhy
* rtB . gjz4ggefl2 ; rtB . fpc3kvomhx [ 1 ] = rtP .
Constant3_Value_k030zkojhy * rtB . fd3qiys2ps ; rtB . fpc3kvomhx [ 2 ] = rtP
. Constant3_Value_k030zkojhy * rtB . gukj05tcnp ; rtB . fpc3kvomhx [ 3 ] =
rtP . Constant3_Value_k030zkojhy * rtB . mxtffwnyug ; rtB . hr1ymwwo43 = -
rtB . fpc3kvomhx [ 2 ] * 0.00461995246297257 * rtB . fpc3kvomhx [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . fpc3kvomhx [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . d4u1qga40r [ 0 ] = rtP .
Constant2_Value_nbkvr3eqsy * rtB . gjz4ggefl2 ; rtB . d4u1qga40r [ 1 ] = rtP
. Constant2_Value_nbkvr3eqsy * rtB . fd3qiys2ps ; rtB . d4u1qga40r [ 2 ] =
rtP . Constant2_Value_nbkvr3eqsy * rtB . gukj05tcnp ; rtB . d4u1qga40r [ 3 ]
= rtP . Constant2_Value_nbkvr3eqsy * rtB . mxtffwnyug ; rtB . hr1ymwwo43 = -
rtB . d4u1qga40r [ 2 ] * 0.00461995246297257 * rtB . d4u1qga40r [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . d4u1qga40r [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . hcjtzzfngx = rtX . n1mefgeo42 ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . ewtqwav4k3 = rtB . nqwiqvxip0 >= rtP .
Saturation_UpperSat_lxx4j3fnoa ? 1 : rtB . nqwiqvxip0 > rtP .
Saturation_LowerSat_kwi433xk5g ? 0 : - 1 ; } rtB . izpbloaset = rtDW .
ewtqwav4k3 == 1 ? rtP . Saturation_UpperSat_lxx4j3fnoa : rtDW . ewtqwav4k3 ==
- 1 ? rtP . Saturation_LowerSat_kwi433xk5g : rtB . nqwiqvxip0 ; switch ( (
int32_T ) rtP . Battery2_BatType ) { case 1 : rtB . af10lxjheq = rtB .
hcjtzzfngx ; break ; case 2 : rtB . af10lxjheq = muDoubleScalarExp ( -
10.176991150442477 * rtB . izpbloaset ) * 0.310711063328515 ; break ; case 3
: rtB . af10lxjheq = rtB . hcjtzzfngx ; break ; default : rtB . af10lxjheq =
rtB . hcjtzzfngx ; break ; } rtB . oomylrj2ck = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . hr1ymwwo43 ) + rtB . af10lxjheq ) + - 0.0 * rtB . nqwiqvxip0 ; rtB
. dawtfnjz3t = rtP . Constant_Value_fzmb45jy2r + rtB . oomylrj2ck ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . gh40xceltm = ( rtB . dawtfnjz3t > rtP . Constant1_Value_jelmmtr1rj ) ;
} rtB . kttme4p4ih = rtDW . gh40xceltm ; } rtB . aqn3egakkx = 0.0 ; rtB .
aqn3egakkx += rtP . BAL_C_pnvzkp4ayj * rtX . kwkmxprem3 ; rtB . f2scb5rf13 =
rtP . R1_Gain_k1h1x1zryv * rtB . aqn3egakkx ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hxqj0wmr1s = ( rtB .
dawtfnjz3t < rtB . f2scb5rf13 ) ; } rtB . nuzd1nehkt = rtDW . hxqj0wmr1s ;
rtB . b5ot5krztj = rtDW . e5chgaqzdi ; rtB . dsgitwjsjs = rtP .
R2_Gain_fij43s2whq * rtB . b5ot5krztj ; rtB . bjsmudeh15 = 1.000001 * rtB .
dsgitwjsjs * 0.96711798839458663 / 0.9999 ; } if ( rtB . kttme4p4ih ) { rtB .
ja533qrntz = rtP . Constant1_Value_jelmmtr1rj ; } else { if ( rtB .
nuzd1nehkt ) { rtB . cywrrn5vf0 = rtB . f2scb5rf13 ; } else { rtB .
cywrrn5vf0 = rtB . dawtfnjz3t ; } rtB . ja533qrntz = rtB . cywrrn5vf0 ; } rtB
. lnjfdccy2h = 0.0 ; rtB . lnjfdccy2h += rtP . Currentfilter_C_hx4sknoziy *
rtX . g0ii5xynxb ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . ayf5sqzvgu = ( rtB . lnjfdccy2h >
rtP . Constant_Value_bksqnhysc0 ) ; } rtB . pgstoxbe4q = rtDW . ayf5sqzvgu ;
rtB . n5erhw4hry = rtDW . br1vosysg0 ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
dmvlae2fk1 , ( rtB . pgstoxbe4q ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . fid4f0juyg != 0 ) ) { rtX . hytl13jcro = rtB . n5erhw4hry ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . hytl13jcro
>= rtP . inti_UpperSat_nowwhgaxwk ) { if ( rtX . hytl13jcro != rtP .
inti_UpperSat_nowwhgaxwk ) { rtX . hytl13jcro = rtP .
inti_UpperSat_nowwhgaxwk ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . cbhsw3xyhw = 3 ; } else if ( rtX . hytl13jcro <= rtP .
inti_LowerSat_cwekkzbyq1 ) { if ( rtX . hytl13jcro != rtP .
inti_LowerSat_cwekkzbyq1 ) { rtX . hytl13jcro = rtP .
inti_LowerSat_cwekkzbyq1 ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . cbhsw3xyhw = 4 ; } else { if ( rtDW . cbhsw3xyhw != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . cbhsw3xyhw = 0
; } rtB . al5llquoyw = rtX . hytl13jcro ; } else { rtB . al5llquoyw = rtX .
hytl13jcro ; } rtB . olt2mencvc = rtP . Gain_Gain_jbuudt1ftk * rtB .
al5llquoyw ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hsuqfg2xm4 = ( rtB . olt2mencvc >
rtB . dsgitwjsjs ) ; } rtB . bn2cyxj3zl = rtDW . hsuqfg2xm4 ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . aeubopidzx = ( rtB . olt2mencvc <
rtP . Constant9_Value_nhyzz1ckmw ) ; } rtB . dnc1haqpya = rtDW . aeubopidzx ;
} if ( rtB . bn2cyxj3zl ) { rtB . fwpjmaqmyl = rtB . dsgitwjsjs ; } else { if
( rtB . dnc1haqpya ) { rtB . ijry4eme3e = rtP . Constant9_Value_nhyzz1ckmw ;
} else { rtB . ijry4eme3e = rtB . olt2mencvc ; } rtB . fwpjmaqmyl = rtB .
ijry4eme3e ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . jlwexkwoi3 = ( rtB . bjsmudeh15 <=
rtB . fwpjmaqmyl ) ; } rtB . ou3lkm5huj = rtDW . jlwexkwoi3 ; } if ( rtB .
ou3lkm5huj ) { rtB . iacqlbe2tg = rtB . dsgitwjsjs ; } else { rtB .
iacqlbe2tg = rtB . fwpjmaqmyl ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
b5ot5krztj / ( rtB . b5ot5krztj - rtB . iacqlbe2tg ) * rtB . iacqlbe2tg ;
jmuz0todoh = - rtB . pgstoxbe4q * 0.00461995246297257 * rtB . lnjfdccy2h *
rtB . b5ot5krztj / ( rtB . b5ot5krztj - rtB . iacqlbe2tg ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . fbim3ivtyq = rtP . R3_Gain_de1tgv0zzw
* rtB . b5ot5krztj ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
nxd2nqjick = ( rtB . olt2mencvc > rtB . fbim3ivtyq ) ; } rtB . ivfkkggxvv =
rtDW . nxd2nqjick ; rtB . inr0z52r4v = - rtB . fbim3ivtyq * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nkllg3btfs = ( rtB .
olt2mencvc < rtB . inr0z52r4v ) ; } rtB . hvbdhrufgk = rtDW . nkllg3btfs ; }
if ( rtB . ivfkkggxvv ) { rtB . jrt1dp0uea = rtB . fbim3ivtyq ; } else { if (
rtB . hvbdhrufgk ) { rtB . lhj1mrpnaq = rtB . inr0z52r4v ; } else { rtB .
lhj1mrpnaq = rtB . olt2mencvc ; } rtB . jrt1dp0uea = rtB . lhj1mrpnaq ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . hxobozywci = ( rtB . lnjfdccy2h < rtP . Constant_Value_owtewy0ssm ) ;
} rtB . onxjmnda4f = rtDW . hxobozywci ; } switch ( ( int32_T ) rtP .
Battery3_BatType ) { case 1 : rtB . lphjnbgv2d [ 0 ] = rtP .
Constant4_Value_cmgjzabbd1 * rtB . jrt1dp0uea ; rtB . lphjnbgv2d [ 1 ] = rtP
. Constant4_Value_cmgjzabbd1 * rtB . lnjfdccy2h ; rtB . lphjnbgv2d [ 2 ] =
rtP . Constant4_Value_cmgjzabbd1 * rtB . onxjmnda4f ; rtB . lphjnbgv2d [ 3 ]
= rtP . Constant4_Value_cmgjzabbd1 * rtB . b5ot5krztj ; rtB . atav4hz2t0 = -
rtB . lphjnbgv2d [ 2 ] * 0.00461995246297257 * rtB . lphjnbgv2d [ 1 ] * (
6.2039999999999846 / ( rtB . lphjnbgv2d [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . ndunxwoqnz [ 0 ] = rtP . Constant1_Value_gbfcrdkgqa *
rtB . jrt1dp0uea ; rtB . ndunxwoqnz [ 1 ] = rtP . Constant1_Value_gbfcrdkgqa
* rtB . lnjfdccy2h ; rtB . ndunxwoqnz [ 2 ] = rtP .
Constant1_Value_gbfcrdkgqa * rtB . onxjmnda4f ; rtB . ndunxwoqnz [ 3 ] = rtP
. Constant1_Value_gbfcrdkgqa * rtB . b5ot5krztj ; rtB . atav4hz2t0 = - rtB .
ndunxwoqnz [ 2 ] * 0.00461995246297257 * rtB . ndunxwoqnz [ 1 ] * rtB .
ndunxwoqnz [ 3 ] / ( rtB . ndunxwoqnz [ 3 ] * 0.1 + rtB . ndunxwoqnz [ 0 ] )
; break ; case 3 : rtB . hcovsf5jov [ 0 ] = rtP . Constant3_Value_hat1prtoip
* rtB . jrt1dp0uea ; rtB . hcovsf5jov [ 1 ] = rtP .
Constant3_Value_hat1prtoip * rtB . lnjfdccy2h ; rtB . hcovsf5jov [ 2 ] = rtP
. Constant3_Value_hat1prtoip * rtB . onxjmnda4f ; rtB . hcovsf5jov [ 3 ] =
rtP . Constant3_Value_hat1prtoip * rtB . b5ot5krztj ; rtB . atav4hz2t0 = -
rtB . hcovsf5jov [ 2 ] * 0.00461995246297257 * rtB . hcovsf5jov [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . hcovsf5jov [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . kcfelslddn [ 0 ] = rtP .
Constant2_Value_gnk2tjoo5o * rtB . jrt1dp0uea ; rtB . kcfelslddn [ 1 ] = rtP
. Constant2_Value_gnk2tjoo5o * rtB . lnjfdccy2h ; rtB . kcfelslddn [ 2 ] =
rtP . Constant2_Value_gnk2tjoo5o * rtB . onxjmnda4f ; rtB . kcfelslddn [ 3 ]
= rtP . Constant2_Value_gnk2tjoo5o * rtB . b5ot5krztj ; rtB . atav4hz2t0 = -
rtB . kcfelslddn [ 2 ] * 0.00461995246297257 * rtB . kcfelslddn [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . kcfelslddn [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . lhhtg1palw = rtX . daazrzvjzg ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . g5hpe50c5f = rtB . iacqlbe2tg >= rtP .
Saturation_UpperSat_blj3ug4rzx ? 1 : rtB . iacqlbe2tg > rtP .
Saturation_LowerSat_o0i20janpw ? 0 : - 1 ; } rtB . cwlnlciysh = rtDW .
g5hpe50c5f == 1 ? rtP . Saturation_UpperSat_blj3ug4rzx : rtDW . g5hpe50c5f ==
- 1 ? rtP . Saturation_LowerSat_o0i20janpw : rtB . iacqlbe2tg ; switch ( (
int32_T ) rtP . Battery3_BatType ) { case 1 : rtB . k0tidcedyr = rtB .
lhhtg1palw ; break ; case 2 : rtB . k0tidcedyr = muDoubleScalarExp ( -
10.176991150442477 * rtB . cwlnlciysh ) * 0.310711063328515 ; break ; case 3
: rtB . k0tidcedyr = rtB . lhhtg1palw ; break ; default : rtB . k0tidcedyr =
rtB . lhhtg1palw ; break ; } rtB . cahmoz3lmb = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . atav4hz2t0 ) + rtB . k0tidcedyr ) + - 0.0 * rtB . iacqlbe2tg ; rtB
. ctz0crt1lg = rtP . Constant_Value_kiu123temw + rtB . cahmoz3lmb ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . abeepxeuaz = ( rtB . ctz0crt1lg > rtP . Constant1_Value_jj3f5fu3xp ) ;
} rtB . oipwcmrhbu = rtDW . abeepxeuaz ; } rtB . oc0dumgulu = 0.0 ; rtB .
oc0dumgulu += rtP . BAL_C_ix2bm3qtha * rtX . kmijbaomfh ; rtB . ebcqidfawa =
rtP . R1_Gain_elo0441xsu * rtB . oc0dumgulu ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . fsznzndz1h = ( rtB .
ctz0crt1lg < rtB . ebcqidfawa ) ; } rtB . ojebse5nps = rtDW . fsznzndz1h ;
rtB . hmnedoi5ok = rtDW . bw2f200uhe ; rtB . bvviu2o2gh = rtP .
R2_Gain_akgkexbqnd * rtB . hmnedoi5ok ; rtB . lfgqqylnmm = 1.000001 * rtB .
bvviu2o2gh * 0.96711798839458663 / 0.9999 ; } if ( rtB . oipwcmrhbu ) { rtB .
jlrqkf40e4 = rtP . Constant1_Value_jj3f5fu3xp ; } else { if ( rtB .
ojebse5nps ) { rtB . kkv1oof2ml = rtB . ebcqidfawa ; } else { rtB .
kkv1oof2ml = rtB . ctz0crt1lg ; } rtB . jlrqkf40e4 = rtB . kkv1oof2ml ; } rtB
. pmwqhxrjfr = 0.0 ; rtB . pmwqhxrjfr += rtP . Currentfilter_C_muylregegy *
rtX . e3mceh2nlv ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . pnxsmfjtjg = ( rtB . pmwqhxrjfr >
rtP . Constant_Value_kedzfrfegv ) ; } rtB . nw2inaond5 = rtDW . pnxsmfjtjg ;
rtB . crm3deon3z = rtDW . h1kn4wxczz ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
hgdvl4elkh , ( rtB . nw2inaond5 ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . a12tj2tqvt != 0 ) ) { rtX . hqm1okddyw = rtB . crm3deon3z ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . hqm1okddyw
>= rtP . inti_UpperSat_itde10ibkj ) { if ( rtX . hqm1okddyw != rtP .
inti_UpperSat_itde10ibkj ) { rtX . hqm1okddyw = rtP .
inti_UpperSat_itde10ibkj ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . nfdtmpqmjl = 3 ; } else if ( rtX . hqm1okddyw <= rtP .
inti_LowerSat_nb1wwuftgl ) { if ( rtX . hqm1okddyw != rtP .
inti_LowerSat_nb1wwuftgl ) { rtX . hqm1okddyw = rtP .
inti_LowerSat_nb1wwuftgl ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . nfdtmpqmjl = 4 ; } else { if ( rtDW . nfdtmpqmjl != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . nfdtmpqmjl = 0
; } rtB . nocrqzmy3a = rtX . hqm1okddyw ; } else { rtB . nocrqzmy3a = rtX .
hqm1okddyw ; } rtB . h3gzco2fqa = rtP . Gain_Gain_l5lbde12wy * rtB .
nocrqzmy3a ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . kvk4rwajxg = ( rtB . h3gzco2fqa >
rtB . bvviu2o2gh ) ; } rtB . ixwvnfjyht = rtDW . kvk4rwajxg ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . paol22gume = ( rtB . h3gzco2fqa <
rtP . Constant9_Value_ffsooduwum ) ; } rtB . njmqdqum11 = rtDW . paol22gume ;
} if ( rtB . ixwvnfjyht ) { rtB . oocd2yqorm = rtB . bvviu2o2gh ; } else { if
( rtB . njmqdqum11 ) { rtB . c1yr1t1pln = rtP . Constant9_Value_ffsooduwum ;
} else { rtB . c1yr1t1pln = rtB . h3gzco2fqa ; } rtB . oocd2yqorm = rtB .
c1yr1t1pln ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nzxxvc5aaq = ( rtB . lfgqqylnmm <=
rtB . oocd2yqorm ) ; } rtB . e0eegacwfw = rtDW . nzxxvc5aaq ; } if ( rtB .
e0eegacwfw ) { rtB . e0au3fw2j3 = rtB . bvviu2o2gh ; } else { rtB .
e0au3fw2j3 = rtB . oocd2yqorm ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
hmnedoi5ok / ( rtB . hmnedoi5ok - rtB . e0au3fw2j3 ) * rtB . e0au3fw2j3 ;
jmuz0todoh = - rtB . nw2inaond5 * 0.00461995246297257 * rtB . pmwqhxrjfr *
rtB . hmnedoi5ok / ( rtB . hmnedoi5ok - rtB . e0au3fw2j3 ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . aprnkbzhsq = rtP . R3_Gain_nk0ujvzftk
* rtB . hmnedoi5ok ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
azkim3bav2 = ( rtB . h3gzco2fqa > rtB . aprnkbzhsq ) ; } rtB . ammqm2ucfq =
rtDW . azkim3bav2 ; rtB . fmzs5132om = - rtB . aprnkbzhsq * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . fbtobfkzln = ( rtB .
h3gzco2fqa < rtB . fmzs5132om ) ; } rtB . jhzdsfrzpr = rtDW . fbtobfkzln ; }
if ( rtB . ammqm2ucfq ) { rtB . nqjaq0ah0p = rtB . aprnkbzhsq ; } else { if (
rtB . jhzdsfrzpr ) { rtB . e1he2cpfsi = rtB . fmzs5132om ; } else { rtB .
e1he2cpfsi = rtB . h3gzco2fqa ; } rtB . nqjaq0ah0p = rtB . e1he2cpfsi ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . ds2iyglcuj = ( rtB . pmwqhxrjfr < rtP . Constant_Value_opaksbgo21 ) ;
} rtB . jgxdelnl3s = rtDW . ds2iyglcuj ; } switch ( ( int32_T ) rtP .
Battery4_BatType ) { case 1 : rtB . at40po5flv [ 0 ] = rtP .
Constant4_Value_ohbtynzx54 * rtB . nqjaq0ah0p ; rtB . at40po5flv [ 1 ] = rtP
. Constant4_Value_ohbtynzx54 * rtB . pmwqhxrjfr ; rtB . at40po5flv [ 2 ] =
rtP . Constant4_Value_ohbtynzx54 * rtB . jgxdelnl3s ; rtB . at40po5flv [ 3 ]
= rtP . Constant4_Value_ohbtynzx54 * rtB . hmnedoi5ok ; rtB . nfrth1ueqb = -
rtB . at40po5flv [ 2 ] * 0.00461995246297257 * rtB . at40po5flv [ 1 ] * (
6.2039999999999846 / ( rtB . at40po5flv [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . d1gpz5ny3l [ 0 ] = rtP . Constant1_Value_am3al2n15v *
rtB . nqjaq0ah0p ; rtB . d1gpz5ny3l [ 1 ] = rtP . Constant1_Value_am3al2n15v
* rtB . pmwqhxrjfr ; rtB . d1gpz5ny3l [ 2 ] = rtP .
Constant1_Value_am3al2n15v * rtB . jgxdelnl3s ; rtB . d1gpz5ny3l [ 3 ] = rtP
. Constant1_Value_am3al2n15v * rtB . hmnedoi5ok ; rtB . nfrth1ueqb = - rtB .
d1gpz5ny3l [ 2 ] * 0.00461995246297257 * rtB . d1gpz5ny3l [ 1 ] * rtB .
d1gpz5ny3l [ 3 ] / ( rtB . d1gpz5ny3l [ 3 ] * 0.1 + rtB . d1gpz5ny3l [ 0 ] )
; break ; case 3 : rtB . cjndlopolx [ 0 ] = rtP . Constant3_Value_mujtf1guv4
* rtB . nqjaq0ah0p ; rtB . cjndlopolx [ 1 ] = rtP .
Constant3_Value_mujtf1guv4 * rtB . pmwqhxrjfr ; rtB . cjndlopolx [ 2 ] = rtP
. Constant3_Value_mujtf1guv4 * rtB . jgxdelnl3s ; rtB . cjndlopolx [ 3 ] =
rtP . Constant3_Value_mujtf1guv4 * rtB . hmnedoi5ok ; rtB . nfrth1ueqb = -
rtB . cjndlopolx [ 2 ] * 0.00461995246297257 * rtB . cjndlopolx [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . cjndlopolx [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . kygrahp5cz [ 0 ] = rtP .
Constant2_Value_odhbgl2n1s * rtB . nqjaq0ah0p ; rtB . kygrahp5cz [ 1 ] = rtP
. Constant2_Value_odhbgl2n1s * rtB . pmwqhxrjfr ; rtB . kygrahp5cz [ 2 ] =
rtP . Constant2_Value_odhbgl2n1s * rtB . jgxdelnl3s ; rtB . kygrahp5cz [ 3 ]
= rtP . Constant2_Value_odhbgl2n1s * rtB . hmnedoi5ok ; rtB . nfrth1ueqb = -
rtB . kygrahp5cz [ 2 ] * 0.00461995246297257 * rtB . kygrahp5cz [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . kygrahp5cz [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . gomqwjxzd5 = rtX . abk5ytngnj ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . gxhonuhkhs = rtB . e0au3fw2j3 >= rtP .
Saturation_UpperSat_c0l2pkijii ? 1 : rtB . e0au3fw2j3 > rtP .
Saturation_LowerSat_g1ovkjgj1x ? 0 : - 1 ; } rtB . knag0fuf4e = rtDW .
gxhonuhkhs == 1 ? rtP . Saturation_UpperSat_c0l2pkijii : rtDW . gxhonuhkhs ==
- 1 ? rtP . Saturation_LowerSat_g1ovkjgj1x : rtB . e0au3fw2j3 ; switch ( (
int32_T ) rtP . Battery4_BatType ) { case 1 : rtB . ngfkb5ghae = rtB .
gomqwjxzd5 ; break ; case 2 : rtB . ngfkb5ghae = muDoubleScalarExp ( -
10.176991150442477 * rtB . knag0fuf4e ) * 0.310711063328515 ; break ; case 3
: rtB . ngfkb5ghae = rtB . gomqwjxzd5 ; break ; default : rtB . ngfkb5ghae =
rtB . gomqwjxzd5 ; break ; } rtB . mt1bcogztp = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . nfrth1ueqb ) + rtB . ngfkb5ghae ) + - 0.0 * rtB . e0au3fw2j3 ; rtB
. bs00yavsbm = rtP . Constant_Value_em2zyolrnm + rtB . mt1bcogztp ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . gv2gxwgcyr = ( rtB . bs00yavsbm > rtP . Constant1_Value_myhrse5szs ) ;
} rtB . kgz10dnw3h = rtDW . gv2gxwgcyr ; } rtB . eacgl4yov2 = 0.0 ; rtB .
eacgl4yov2 += rtP . BAL_C_hfghx3gysd * rtX . kskuxricdl ; rtB . orwu5t0tyg =
rtP . R1_Gain_ay3u4mrv4p * rtB . eacgl4yov2 ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . og2ibrr5dj = ( rtB .
bs00yavsbm < rtB . orwu5t0tyg ) ; } rtB . aww14lps2o = rtDW . og2ibrr5dj ;
rtB . n5szlr3nqx = rtDW . fwi0pu3glv ; rtB . cngflnzqr2 = rtP .
R2_Gain_axv50jbqfg * rtB . n5szlr3nqx ; rtB . nwootfl0wl = 1.000001 * rtB .
cngflnzqr2 * 0.96711798839458663 / 0.9999 ; } if ( rtB . kgz10dnw3h ) { rtB .
imwf4qbc3k = rtP . Constant1_Value_myhrse5szs ; } else { if ( rtB .
aww14lps2o ) { rtB . l52vljxmqk = rtB . orwu5t0tyg ; } else { rtB .
l52vljxmqk = rtB . bs00yavsbm ; } rtB . imwf4qbc3k = rtB . l52vljxmqk ; } rtB
. hjgu4nxp5v = 0.0 ; rtB . hjgu4nxp5v += rtP . Currentfilter_C_e5mev0pk52 *
rtX . lx3xuxie2j ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . podpzxkpcc = ( rtB . hjgu4nxp5v >
rtP . Constant_Value_epq2rsx4ba ) ; } rtB . a1pwur2f3n = rtDW . podpzxkpcc ;
rtB . gjgshqegfr = rtDW . m35jm4htkc ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
kdatxxubrk , ( rtB . a1pwur2f3n ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . lb53h134aw != 0 ) ) { rtX . brizaijzew = rtB . gjgshqegfr ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . brizaijzew
>= rtP . inti_UpperSat_ff0nysnmjy ) { if ( rtX . brizaijzew != rtP .
inti_UpperSat_ff0nysnmjy ) { rtX . brizaijzew = rtP .
inti_UpperSat_ff0nysnmjy ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . blabp2utic = 3 ; } else if ( rtX . brizaijzew <= rtP .
inti_LowerSat_hzpmw3xl5s ) { if ( rtX . brizaijzew != rtP .
inti_LowerSat_hzpmw3xl5s ) { rtX . brizaijzew = rtP .
inti_LowerSat_hzpmw3xl5s ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . blabp2utic = 4 ; } else { if ( rtDW . blabp2utic != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . blabp2utic = 0
; } rtB . lehkr3fuer = rtX . brizaijzew ; } else { rtB . lehkr3fuer = rtX .
brizaijzew ; } rtB . e42dsovuoz = rtP . Gain_Gain_a4qiy5rws3 * rtB .
lehkr3fuer ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . gorulf3t0p = ( rtB . e42dsovuoz >
rtB . cngflnzqr2 ) ; } rtB . cpybkyynn4 = rtDW . gorulf3t0p ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . flctwqyusi = ( rtB . e42dsovuoz <
rtP . Constant9_Value_bcezbzp4a1 ) ; } rtB . cgviec4bkd = rtDW . flctwqyusi ;
} if ( rtB . cpybkyynn4 ) { rtB . ermmdxeqvq = rtB . cngflnzqr2 ; } else { if
( rtB . cgviec4bkd ) { rtB . po4oftxsww = rtP . Constant9_Value_bcezbzp4a1 ;
} else { rtB . po4oftxsww = rtB . e42dsovuoz ; } rtB . ermmdxeqvq = rtB .
po4oftxsww ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . bshhfd5mls = ( rtB . nwootfl0wl <=
rtB . ermmdxeqvq ) ; } rtB . filzxjl5ur = rtDW . bshhfd5mls ; } if ( rtB .
filzxjl5ur ) { rtB . f5toqxhshz = rtB . cngflnzqr2 ; } else { rtB .
f5toqxhshz = rtB . ermmdxeqvq ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
n5szlr3nqx / ( rtB . n5szlr3nqx - rtB . f5toqxhshz ) * rtB . f5toqxhshz ;
jmuz0todoh = - rtB . a1pwur2f3n * 0.00461995246297257 * rtB . hjgu4nxp5v *
rtB . n5szlr3nqx / ( rtB . n5szlr3nqx - rtB . f5toqxhshz ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . bcqp5bw5m5 = rtP . R3_Gain_hslbhc5rsq
* rtB . n5szlr3nqx ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
g11vzlfqpn = ( rtB . e42dsovuoz > rtB . bcqp5bw5m5 ) ; } rtB . dtff1cx0dd =
rtDW . g11vzlfqpn ; rtB . mymfehhqyf = - rtB . bcqp5bw5m5 * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . e4xlinrnnb = ( rtB .
e42dsovuoz < rtB . mymfehhqyf ) ; } rtB . epmqzfkazx = rtDW . e4xlinrnnb ; }
if ( rtB . dtff1cx0dd ) { rtB . dkrfxtvrav = rtB . bcqp5bw5m5 ; } else { if (
rtB . epmqzfkazx ) { rtB . n2s1hb1sdd = rtB . mymfehhqyf ; } else { rtB .
n2s1hb1sdd = rtB . e42dsovuoz ; } rtB . dkrfxtvrav = rtB . n2s1hb1sdd ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . bct0r40oxs = ( rtB . hjgu4nxp5v < rtP . Constant_Value_h45zreb2fb ) ;
} rtB . psl1pylfxp = rtDW . bct0r40oxs ; } switch ( ( int32_T ) rtP .
Battery5_BatType ) { case 1 : rtB . j2yhvvmzdt [ 0 ] = rtP .
Constant4_Value_om2zghpbx3 * rtB . dkrfxtvrav ; rtB . j2yhvvmzdt [ 1 ] = rtP
. Constant4_Value_om2zghpbx3 * rtB . hjgu4nxp5v ; rtB . j2yhvvmzdt [ 2 ] =
rtP . Constant4_Value_om2zghpbx3 * rtB . psl1pylfxp ; rtB . j2yhvvmzdt [ 3 ]
= rtP . Constant4_Value_om2zghpbx3 * rtB . n5szlr3nqx ; rtB . ggcp4lpehl = -
rtB . j2yhvvmzdt [ 2 ] * 0.00461995246297257 * rtB . j2yhvvmzdt [ 1 ] * (
6.2039999999999846 / ( rtB . j2yhvvmzdt [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . i0nwte41mb [ 0 ] = rtP . Constant1_Value_ny1xdqiske *
rtB . dkrfxtvrav ; rtB . i0nwte41mb [ 1 ] = rtP . Constant1_Value_ny1xdqiske
* rtB . hjgu4nxp5v ; rtB . i0nwte41mb [ 2 ] = rtP .
Constant1_Value_ny1xdqiske * rtB . psl1pylfxp ; rtB . i0nwte41mb [ 3 ] = rtP
. Constant1_Value_ny1xdqiske * rtB . n5szlr3nqx ; rtB . ggcp4lpehl = - rtB .
i0nwte41mb [ 2 ] * 0.00461995246297257 * rtB . i0nwte41mb [ 1 ] * rtB .
i0nwte41mb [ 3 ] / ( rtB . i0nwte41mb [ 3 ] * 0.1 + rtB . i0nwte41mb [ 0 ] )
; break ; case 3 : rtB . itee030nb5 [ 0 ] = rtP . Constant3_Value_kuyjih2run
* rtB . dkrfxtvrav ; rtB . itee030nb5 [ 1 ] = rtP .
Constant3_Value_kuyjih2run * rtB . hjgu4nxp5v ; rtB . itee030nb5 [ 2 ] = rtP
. Constant3_Value_kuyjih2run * rtB . psl1pylfxp ; rtB . itee030nb5 [ 3 ] =
rtP . Constant3_Value_kuyjih2run * rtB . n5szlr3nqx ; rtB . ggcp4lpehl = -
rtB . itee030nb5 [ 2 ] * 0.00461995246297257 * rtB . itee030nb5 [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . itee030nb5 [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . b101dzqhyh [ 0 ] = rtP .
Constant2_Value_ppmjeluned * rtB . dkrfxtvrav ; rtB . b101dzqhyh [ 1 ] = rtP
. Constant2_Value_ppmjeluned * rtB . hjgu4nxp5v ; rtB . b101dzqhyh [ 2 ] =
rtP . Constant2_Value_ppmjeluned * rtB . psl1pylfxp ; rtB . b101dzqhyh [ 3 ]
= rtP . Constant2_Value_ppmjeluned * rtB . n5szlr3nqx ; rtB . ggcp4lpehl = -
rtB . b101dzqhyh [ 2 ] * 0.00461995246297257 * rtB . b101dzqhyh [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . b101dzqhyh [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . mxu3fd52lg = rtX . jjfpdr1zyr ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . hdt4znz2bx = rtB . f5toqxhshz >= rtP .
Saturation_UpperSat_dr1jmbb0we ? 1 : rtB . f5toqxhshz > rtP .
Saturation_LowerSat_haspwmkdbs ? 0 : - 1 ; } rtB . j1rfmexczt = rtDW .
hdt4znz2bx == 1 ? rtP . Saturation_UpperSat_dr1jmbb0we : rtDW . hdt4znz2bx ==
- 1 ? rtP . Saturation_LowerSat_haspwmkdbs : rtB . f5toqxhshz ; switch ( (
int32_T ) rtP . Battery5_BatType ) { case 1 : rtB . enfj1pjw2o = rtB .
mxu3fd52lg ; break ; case 2 : rtB . enfj1pjw2o = muDoubleScalarExp ( -
10.176991150442477 * rtB . j1rfmexczt ) * 0.310711063328515 ; break ; case 3
: rtB . enfj1pjw2o = rtB . mxu3fd52lg ; break ; default : rtB . enfj1pjw2o =
rtB . mxu3fd52lg ; break ; } rtB . nawqkqqhwd = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . ggcp4lpehl ) + rtB . enfj1pjw2o ) + - 0.0 * rtB . f5toqxhshz ; rtB
. gy2pn1xoxf = rtP . Constant_Value_pfu1thap3i + rtB . nawqkqqhwd ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . ezdcqawxtb = ( rtB . gy2pn1xoxf > rtP . Constant1_Value_h1thd4w1zg ) ;
} rtB . n244nv1bl5 = rtDW . ezdcqawxtb ; } rtB . oihkxrrgl0 = 0.0 ; rtB .
oihkxrrgl0 += rtP . BAL_C_cq3wtorxkj * rtX . imz4v0p4of ; rtB . neo3wgh5k0 =
rtP . R1_Gain_bdgjwewy0w * rtB . oihkxrrgl0 ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . lh3hvz10l4 = ( rtB .
gy2pn1xoxf < rtB . neo3wgh5k0 ) ; } rtB . lvnp1e1py5 = rtDW . lh3hvz10l4 ; }
if ( rtB . n244nv1bl5 ) { rtB . b05wxiklmy = rtP . Constant1_Value_h1thd4w1zg
; } else { if ( rtB . lvnp1e1py5 ) { rtB . mu2u0ykmdh = rtB . neo3wgh5k0 ; }
else { rtB . mu2u0ykmdh = rtB . gy2pn1xoxf ; } rtB . b05wxiklmy = rtB .
mu2u0ykmdh ; } { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnOutputs (
rts , 0 ) ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . dnpga1izxq = rtP .
R4_Gain * rtB . mxtffwnyug ; } rtB . mharr3pkm3 = ( 1.0 - rtB . nqwiqvxip0 /
rtB . dnpga1izxq ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW .
c3pj1kxqrj = rtB . mharr3pkm3 >= rtP . Saturation_UpperSat_aqwzuangfk ? 1 :
rtB . mharr3pkm3 > rtP . Saturation_LowerSat_bcd3czsgyq ? 0 : - 1 ; } rtB .
c1cjcg0vdp = rtDW . c3pj1kxqrj == 1 ? rtP . Saturation_UpperSat_aqwzuangfk :
rtDW . c3pj1kxqrj == - 1 ? rtP . Saturation_LowerSat_bcd3czsgyq : rtB .
mharr3pkm3 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . anodlblzme = rtP .
R4_Gain_ckkisgzyfx * rtB . b5ot5krztj ; } rtB . cszbfywqst = ( 1.0 - rtB .
iacqlbe2tg / rtB . anodlblzme ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . py5uw1xsam = rtB . cszbfywqst >= rtP . Saturation_UpperSat_i3x3oscagf
? 1 : rtB . cszbfywqst > rtP . Saturation_LowerSat_gnz45aadu0 ? 0 : - 1 ; }
rtB . lt0d3owsjr = rtDW . py5uw1xsam == 1 ? rtP .
Saturation_UpperSat_i3x3oscagf : rtDW . py5uw1xsam == - 1 ? rtP .
Saturation_LowerSat_gnz45aadu0 : rtB . cszbfywqst ; rtB . i2s0aqv5oj = rtB .
c1cjcg0vdp - rtB . lt0d3owsjr ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW
. o2st5ljikx = ( rtB . i2s0aqv5oj >= 0.0 ) ; } hjc2zrpfd1 = rtDW . o2st5ljikx
> 0 ? rtB . i2s0aqv5oj : - rtB . i2s0aqv5oj ; klzckgpczr = ( rtB . c1cjcg0vdp
+ rtB . lt0d3owsjr ) * rtP . Constant7_Value ; rtB . nsl1liuisf [ 0 ] =
hjc2zrpfd1 ; rtB . nsl1liuisf [ 1 ] = klzckgpczr ; k0qu5tzxih = 0.0 ; tmp_p [
0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ]
= fmzhqpumbn ( rtB . nsl1liuisf [ 0 ] , tmp_p ) ; inputMFCache [ 1 ] =
fmzhqpumbn ( rtB . nsl1liuisf [ 0 ] , b ) ; inputMFCache [ 2 ] = fmzhqpumbn (
rtB . nsl1liuisf [ 0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ;
tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ] = fmzhqpumbn ( rtB . nsl1liuisf [ 1
] , tmp_p ) ; inputMFCache [ 4 ] = fmzhqpumbn ( rtB . nsl1liuisf [ 1 ] , d )
; inputMFCache [ 5 ] = fmzhqpumbn ( rtB . nsl1liuisf [ 1 ] , e ) ; for ( iy =
0 ; iy < 9 ; iy ++ ) { o1xehwvj4t [ iy ] = 1.0 ; jmuz0todoh = o1xehwvj4t [ iy
] ; x_idx_1 = inputMFCache [ f [ iy ] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 )
|| ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1
) ) ) ) { o1xehwvj4t [ iy ] = x_idx_1 ; } else { o1xehwvj4t [ iy ] =
jmuz0todoh ; } jmuz0todoh = o1xehwvj4t [ iy ] ; x_idx_1 = inputMFCache [ f [
iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN (
jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { o1xehwvj4t [ iy ]
= x_idx_1 ; } else { o1xehwvj4t [ iy ] = jmuz0todoh ; } k0qu5tzxih +=
o1xehwvj4t [ iy ] ; } mpg2xj2m34 ( hjc2zrpfd1 , klzckgpczr , o1xehwvj4t , rtP
. OutputSamplePoints_Value_h5oozv5nnj , & rtB . fmo52byvhh ) ; if (
k0qu5tzxih == 0.0 ) { rtB . o2kdszic3h = 0.5 ; } else { k0qu5tzxih = 0.0 ;
jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh += rtB .
fmo52byvhh . k3oc5pn3ee [ iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB .
o2kdszic3h = ( rtP . OutputSamplePoints_Value_h5oozv5nnj [ 0 ] + rtP .
OutputSamplePoints_Value_h5oozv5nnj [ 100 ] ) / 2.0 ; } else { for ( iy = 0 ;
iy < 101 ; iy ++ ) { k0qu5tzxih += rtP . OutputSamplePoints_Value_h5oozv5nnj
[ iy ] * rtB . fmo52byvhh . k3oc5pn3ee [ iy ] ; } rtB . o2kdszic3h = 1.0 /
jmuz0todoh * k0qu5tzxih ; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB .
c4edbm3lnu = rtP . R4_Gain_dz5jfuhlfd * rtB . ldokaf3uyj ; } rtB . mnn2sdpcg2
= ( 1.0 - rtB . apptu0x5zl / rtB . c4edbm3lnu ) * 100.0 ; if (
ssIsMajorTimeStep ( rtS ) ) { rtDW . cqvf2g25lz = rtB . mnn2sdpcg2 >= rtP .
Saturation_UpperSat_pcz043fnep ? 1 : rtB . mnn2sdpcg2 > rtP .
Saturation_LowerSat_b05y2t0vvl ? 0 : - 1 ; } rtB . czbyl5orjk = rtDW .
cqvf2g25lz == 1 ? rtP . Saturation_UpperSat_pcz043fnep : rtDW . cqvf2g25lz ==
- 1 ? rtP . Saturation_LowerSat_b05y2t0vvl : rtB . mnn2sdpcg2 ; rtB .
jkh0lpzdyl = rtB . czbyl5orjk - rtB . c1cjcg0vdp ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . h4owravycx = ( rtB . jkh0lpzdyl >=
0.0 ) ; } emdery3j3h = rtDW . h4owravycx > 0 ? rtB . jkh0lpzdyl : - rtB .
jkh0lpzdyl ; ljjscjpyp3 = ( rtB . czbyl5orjk + rtB . c1cjcg0vdp ) * rtP .
Constant6_Value ; rtB . fzbe5vkjui [ 0 ] = emdery3j3h ; rtB . fzbe5vkjui [ 1
] = ljjscjpyp3 ; k0qu5tzxih = 0.0 ; tmp_p [ 0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0
; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ] = fmzhqpumbn ( rtB . fzbe5vkjui [
0 ] , tmp_p ) ; inputMFCache [ 1 ] = fmzhqpumbn ( rtB . fzbe5vkjui [ 0 ] , b
) ; inputMFCache [ 2 ] = fmzhqpumbn ( rtB . fzbe5vkjui [ 0 ] , c ) ; tmp_p [
0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ]
= fmzhqpumbn ( rtB . fzbe5vkjui [ 1 ] , tmp_p ) ; inputMFCache [ 4 ] =
fmzhqpumbn ( rtB . fzbe5vkjui [ 1 ] , d ) ; inputMFCache [ 5 ] = fmzhqpumbn (
rtB . fzbe5vkjui [ 1 ] , e ) ; for ( iy = 0 ; iy < 9 ; iy ++ ) { cuo1icjl4a [
iy ] = 1.0 ; jmuz0todoh = cuo1icjl4a [ iy ] ; x_idx_1 = inputMFCache [ f [ iy
] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN ( jmuz0todoh
) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { cuo1icjl4a [ iy ] = x_idx_1
; } else { cuo1icjl4a [ iy ] = jmuz0todoh ; } jmuz0todoh = cuo1icjl4a [ iy ]
; x_idx_1 = inputMFCache [ f [ iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 )
|| ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1
) ) ) ) { cuo1icjl4a [ iy ] = x_idx_1 ; } else { cuo1icjl4a [ iy ] =
jmuz0todoh ; } k0qu5tzxih += cuo1icjl4a [ iy ] ; } mpg2xj2m34 ( emdery3j3h ,
ljjscjpyp3 , cuo1icjl4a , rtP . OutputSamplePoints_Value_bs0he10brt , & rtB .
hn5ndxahiz ) ; if ( k0qu5tzxih == 0.0 ) { rtB . dmpeej2qt1 = 0.5 ; } else {
k0qu5tzxih = 0.0 ; jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) {
jmuz0todoh += rtB . hn5ndxahiz . k3oc5pn3ee [ iy ] ; } if ( jmuz0todoh == 0.0
) { rtB . dmpeej2qt1 = ( rtP . OutputSamplePoints_Value_bs0he10brt [ 0 ] +
rtP . OutputSamplePoints_Value_bs0he10brt [ 100 ] ) / 2.0 ; } else { for ( iy
= 0 ; iy < 101 ; iy ++ ) { k0qu5tzxih += rtP .
OutputSamplePoints_Value_bs0he10brt [ iy ] * rtB . hn5ndxahiz . k3oc5pn3ee [
iy ] ; } rtB . dmpeej2qt1 = 1.0 / jmuz0todoh * k0qu5tzxih ; } } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . m5q0x4yj0k = rtP . R4_Gain_nfptou1h22
* rtB . hmnedoi5ok ; } rtB . ccjxi5v2q0 = ( 1.0 - rtB . e0au3fw2j3 / rtB .
m5q0x4yj0k ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . dgvo4khvek =
rtB . ccjxi5v2q0 >= rtP . Saturation_UpperSat_luxvjfmfd3 ? 1 : rtB .
ccjxi5v2q0 > rtP . Saturation_LowerSat_mqcesji40p ? 0 : - 1 ; } rtB .
cw0w1vgwxh = rtDW . dgvo4khvek == 1 ? rtP . Saturation_UpperSat_luxvjfmfd3 :
rtDW . dgvo4khvek == - 1 ? rtP . Saturation_LowerSat_mqcesji40p : rtB .
ccjxi5v2q0 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . pcrjjj3bl2 = rtP .
R4_Gain_e51nv5aiyc * rtB . n5szlr3nqx ; } rtB . bmkbfj44hc = ( 1.0 - rtB .
f5toqxhshz / rtB . pcrjjj3bl2 ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . ehr4lffvuj = rtB . bmkbfj44hc >= rtP . Saturation_UpperSat_p4wbgcsokm
? 1 : rtB . bmkbfj44hc > rtP . Saturation_LowerSat_gdbbvpyvzg ? 0 : - 1 ; }
rtB . fngvfw2vbc = rtDW . ehr4lffvuj == 1 ? rtP .
Saturation_UpperSat_p4wbgcsokm : rtDW . ehr4lffvuj == - 1 ? rtP .
Saturation_LowerSat_gdbbvpyvzg : rtB . bmkbfj44hc ; rtB . mgwtedhsbf = rtB .
cw0w1vgwxh - rtB . fngvfw2vbc ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW
. pavtbhl4x1 = ( rtB . mgwtedhsbf >= 0.0 ) ; } clfo2evmya = rtDW . pavtbhl4x1
> 0 ? rtB . mgwtedhsbf : - rtB . mgwtedhsbf ; mvqo31tded = ( rtB . cw0w1vgwxh
+ rtB . fngvfw2vbc ) * rtP . Constant9_Value_crabpzohh2 ; rtB . mlxflzoh35 [
0 ] = clfo2evmya ; rtB . mlxflzoh35 [ 1 ] = mvqo31tded ; k0qu5tzxih = 0.0 ;
tmp_p [ 0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ;
inputMFCache [ 0 ] = fmzhqpumbn ( rtB . mlxflzoh35 [ 0 ] , tmp_p ) ;
inputMFCache [ 1 ] = fmzhqpumbn ( rtB . mlxflzoh35 [ 0 ] , b ) ; inputMFCache
[ 2 ] = fmzhqpumbn ( rtB . mlxflzoh35 [ 0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ;
tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ] = fmzhqpumbn (
rtB . mlxflzoh35 [ 1 ] , tmp_p ) ; inputMFCache [ 4 ] = fmzhqpumbn ( rtB .
mlxflzoh35 [ 1 ] , d ) ; inputMFCache [ 5 ] = fmzhqpumbn ( rtB . mlxflzoh35 [
1 ] , e ) ; for ( iy = 0 ; iy < 9 ; iy ++ ) { hsohdbixmb [ iy ] = 1.0 ;
jmuz0todoh = hsohdbixmb [ iy ] ; x_idx_1 = inputMFCache [ f [ iy ] - 1 ] ; if
( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( !
muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { hsohdbixmb [ iy ] = x_idx_1 ; } else
{ hsohdbixmb [ iy ] = jmuz0todoh ; } jmuz0todoh = hsohdbixmb [ iy ] ; x_idx_1
= inputMFCache [ f [ iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 ) || (
muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) )
) { hsohdbixmb [ iy ] = x_idx_1 ; } else { hsohdbixmb [ iy ] = jmuz0todoh ; }
k0qu5tzxih += hsohdbixmb [ iy ] ; } mpg2xj2m34 ( clfo2evmya , mvqo31tded ,
hsohdbixmb , rtP . OutputSamplePoints_Value_k42vy4v1xv , & rtB . lykrvem450 )
; if ( k0qu5tzxih == 0.0 ) { rtB . g00batsh4u = 0.5 ; } else { k0qu5tzxih =
0.0 ; jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh +=
rtB . lykrvem450 . k3oc5pn3ee [ iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB .
g00batsh4u = ( rtP . OutputSamplePoints_Value_k42vy4v1xv [ 0 ] + rtP .
OutputSamplePoints_Value_k42vy4v1xv [ 100 ] ) / 2.0 ; } else { for ( iy = 0 ;
iy < 101 ; iy ++ ) { k0qu5tzxih += rtP . OutputSamplePoints_Value_k42vy4v1xv
[ iy ] * rtB . lykrvem450 . k3oc5pn3ee [ iy ] ; } rtB . g00batsh4u = 1.0 /
jmuz0todoh * k0qu5tzxih ; } } rtB . gsugcfegmq = rtB . lt0d3owsjr - rtB .
cw0w1vgwxh ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . ctdq2e5yzh = (
rtB . gsugcfegmq >= 0.0 ) ; } a22jepug13 = rtDW . ctdq2e5yzh > 0 ? rtB .
gsugcfegmq : - rtB . gsugcfegmq ; cvslmzqbuu = ( rtB . lt0d3owsjr + rtB .
cw0w1vgwxh ) * rtP . Constant8_Value ; rtB . hcz2xlgk3d [ 0 ] = a22jepug13 ;
rtB . hcz2xlgk3d [ 1 ] = cvslmzqbuu ; k0qu5tzxih = 0.0 ; tmp_p [ 0 ] = -
2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ] =
fmzhqpumbn ( rtB . hcz2xlgk3d [ 0 ] , tmp_p ) ; inputMFCache [ 1 ] =
fmzhqpumbn ( rtB . hcz2xlgk3d [ 0 ] , b ) ; inputMFCache [ 2 ] = fmzhqpumbn (
rtB . hcz2xlgk3d [ 0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ;
tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ] = fmzhqpumbn ( rtB . hcz2xlgk3d [ 1
] , tmp_p ) ; inputMFCache [ 4 ] = fmzhqpumbn ( rtB . hcz2xlgk3d [ 1 ] , d )
; inputMFCache [ 5 ] = fmzhqpumbn ( rtB . hcz2xlgk3d [ 1 ] , e ) ; for ( iy =
0 ; iy < 9 ; iy ++ ) { dsdonux4di [ iy ] = 1.0 ; jmuz0todoh = dsdonux4di [ iy
] ; x_idx_1 = inputMFCache [ f [ iy ] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 )
|| ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1
) ) ) ) { dsdonux4di [ iy ] = x_idx_1 ; } else { dsdonux4di [ iy ] =
jmuz0todoh ; } jmuz0todoh = dsdonux4di [ iy ] ; x_idx_1 = inputMFCache [ f [
iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN (
jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { dsdonux4di [ iy ]
= x_idx_1 ; } else { dsdonux4di [ iy ] = jmuz0todoh ; } k0qu5tzxih +=
dsdonux4di [ iy ] ; } mpg2xj2m34 ( a22jepug13 , cvslmzqbuu , dsdonux4di , rtP
. OutputSamplePoints_Value_mkqnjleygm , & rtB . ea4xfcwbtn ) ; if (
k0qu5tzxih == 0.0 ) { rtB . oj2fro1nlz = 0.5 ; } else { k0qu5tzxih = 0.0 ;
jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh += rtB .
ea4xfcwbtn . k3oc5pn3ee [ iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB .
oj2fro1nlz = ( rtP . OutputSamplePoints_Value_mkqnjleygm [ 0 ] + rtP .
OutputSamplePoints_Value_mkqnjleygm [ 100 ] ) / 2.0 ; } else { for ( iy = 0 ;
iy < 101 ; iy ++ ) { k0qu5tzxih += rtP . OutputSamplePoints_Value_mkqnjleygm
[ iy ] * rtB . ea4xfcwbtn . k3oc5pn3ee [ iy ] ; } rtB . oj2fro1nlz = 1.0 /
jmuz0todoh * k0qu5tzxih ; } } rtB . nh3tyegvgp = ljjscjpyp3 - cvslmzqbuu ; if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . eucrjtmh5k = ( rtB . nh3tyegvgp
>= 0.0 ) ; } keqr5ofuik = rtDW . eucrjtmh5k > 0 ? rtB . nh3tyegvgp : - rtB .
nh3tyegvgp ; e31snwaiia = ( ljjscjpyp3 + cvslmzqbuu ) * rtP .
Constant2_Value_e4jyxae25b ; rtB . cxgw4hmvl5 [ 0 ] = keqr5ofuik ; rtB .
cxgw4hmvl5 [ 1 ] = e31snwaiia ; k0qu5tzxih = 0.0 ; tmp_p [ 0 ] = - 2.085 ;
tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ] = fmzhqpumbn (
rtB . cxgw4hmvl5 [ 0 ] , tmp_p ) ; inputMFCache [ 1 ] = fmzhqpumbn ( rtB .
cxgw4hmvl5 [ 0 ] , b ) ; inputMFCache [ 2 ] = fmzhqpumbn ( rtB . cxgw4hmvl5 [
0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ;
inputMFCache [ 3 ] = fmzhqpumbn ( rtB . cxgw4hmvl5 [ 1 ] , tmp_p ) ;
inputMFCache [ 4 ] = fmzhqpumbn ( rtB . cxgw4hmvl5 [ 1 ] , d ) ; inputMFCache
[ 5 ] = fmzhqpumbn ( rtB . cxgw4hmvl5 [ 1 ] , e ) ; for ( iy = 0 ; iy < 9 ;
iy ++ ) { d1e4amgrqc [ iy ] = 1.0 ; jmuz0todoh = d1e4amgrqc [ iy ] ; x_idx_1
= inputMFCache [ f [ iy ] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 ) || (
muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) )
) { d1e4amgrqc [ iy ] = x_idx_1 ; } else { d1e4amgrqc [ iy ] = jmuz0todoh ; }
jmuz0todoh = d1e4amgrqc [ iy ] ; x_idx_1 = inputMFCache [ f [ iy + 9 ] + 2 ]
; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN ( jmuz0todoh ) && (
! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { d1e4amgrqc [ iy ] = x_idx_1 ; }
else { d1e4amgrqc [ iy ] = jmuz0todoh ; } k0qu5tzxih += d1e4amgrqc [ iy ] ; }
mpg2xj2m34 ( keqr5ofuik , e31snwaiia , d1e4amgrqc , rtP .
OutputSamplePoints_Value , & rtB . jc1djgafdm ) ; if ( k0qu5tzxih == 0.0 ) {
rtB . h0hbhcvnx4 = 0.5 ; } else { k0qu5tzxih = 0.0 ; jmuz0todoh = 0.0 ; for (
iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh += rtB . jc1djgafdm . k3oc5pn3ee [
iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB . h0hbhcvnx4 = ( rtP .
OutputSamplePoints_Value [ 0 ] + rtP . OutputSamplePoints_Value [ 100 ] ) /
2.0 ; } else { for ( iy = 0 ; iy < 101 ; iy ++ ) { k0qu5tzxih += rtP .
OutputSamplePoints_Value [ iy ] * rtB . jc1djgafdm . k3oc5pn3ee [ iy ] ; }
rtB . h0hbhcvnx4 = 1.0 / jmuz0todoh * k0qu5tzxih ; } } rtB . hjlmg51yd0 =
klzckgpczr - mvqo31tded ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
ev0agwtynm = ( rtB . hjlmg51yd0 >= 0.0 ) ; } ggdrwjpthm = rtDW . ev0agwtynm >
0 ? rtB . hjlmg51yd0 : - rtB . hjlmg51yd0 ; es2okkv3ou = ( klzckgpczr +
mvqo31tded ) * rtP . Constant3_Value_bkb3mktfvw ; rtB . kkozylqz2v [ 0 ] =
ggdrwjpthm ; rtB . kkozylqz2v [ 1 ] = es2okkv3ou ; k0qu5tzxih = 0.0 ; tmp_p [
0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache [ 0 ]
= fmzhqpumbn ( rtB . kkozylqz2v [ 0 ] , tmp_p ) ; inputMFCache [ 1 ] =
fmzhqpumbn ( rtB . kkozylqz2v [ 0 ] , b ) ; inputMFCache [ 2 ] = fmzhqpumbn (
rtB . kkozylqz2v [ 0 ] , c ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ;
tmp_p [ 2 ] = 41.67 ; inputMFCache [ 3 ] = fmzhqpumbn ( rtB . kkozylqz2v [ 1
] , tmp_p ) ; inputMFCache [ 4 ] = fmzhqpumbn ( rtB . kkozylqz2v [ 1 ] , d )
; inputMFCache [ 5 ] = fmzhqpumbn ( rtB . kkozylqz2v [ 1 ] , e ) ; for ( iy =
0 ; iy < 9 ; iy ++ ) { owrgksly4x [ iy ] = 1.0 ; jmuz0todoh = owrgksly4x [ iy
] ; x_idx_1 = inputMFCache [ f [ iy ] - 1 ] ; if ( ( jmuz0todoh > x_idx_1 )
|| ( muDoubleScalarIsNaN ( jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1
) ) ) ) { owrgksly4x [ iy ] = x_idx_1 ; } else { owrgksly4x [ iy ] =
jmuz0todoh ; } jmuz0todoh = owrgksly4x [ iy ] ; x_idx_1 = inputMFCache [ f [
iy + 9 ] + 2 ] ; if ( ( jmuz0todoh > x_idx_1 ) || ( muDoubleScalarIsNaN (
jmuz0todoh ) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { owrgksly4x [ iy ]
= x_idx_1 ; } else { owrgksly4x [ iy ] = jmuz0todoh ; } k0qu5tzxih +=
owrgksly4x [ iy ] ; } mpg2xj2m34 ( ggdrwjpthm , es2okkv3ou , owrgksly4x , rtP
. OutputSamplePoints_Value_mmzz2j1vii , & rtB . ju3bvdpq4f ) ; if (
k0qu5tzxih == 0.0 ) { rtB . hr44golvpy = 0.5 ; } else { k0qu5tzxih = 0.0 ;
jmuz0todoh = 0.0 ; for ( iy = 0 ; iy < 101 ; iy ++ ) { jmuz0todoh += rtB .
ju3bvdpq4f . k3oc5pn3ee [ iy ] ; } if ( jmuz0todoh == 0.0 ) { rtB .
hr44golvpy = ( rtP . OutputSamplePoints_Value_mmzz2j1vii [ 0 ] + rtP .
OutputSamplePoints_Value_mmzz2j1vii [ 100 ] ) / 2.0 ; } else { for ( iy = 0 ;
iy < 101 ; iy ++ ) { k0qu5tzxih += rtP . OutputSamplePoints_Value_mmzz2j1vii
[ iy ] * rtB . ju3bvdpq4f . k3oc5pn3ee [ iy ] ; } rtB . hr44golvpy = 1.0 /
jmuz0todoh * k0qu5tzxih ; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { if (
rtDW . kefwpubmhm . AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal (
rtDW . kefwpubmhm . AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB
. c1cjcg0vdp + 0 ) ; } } } rtB . a1xkvgib3c = rtP . donotdeletethisgain_Gain
* rtB . gzwwnxifap [ 2 ] ; rtB . dip4hm3fie = rtB . ja533qrntz - rtP . R_Gain
* rtB . a1xkvgib3c ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { if ( rtDW .
pvibdkum0b . AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW .
pvibdkum0b . AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB .
dip4hm3fie + 0 ) ; } } { if ( rtDW . a1aeuz3o44 . AQHandles && ssGetLogOutput
( rtS ) ) { sdiWriteSignal ( rtDW . a1aeuz3o44 . AQHandles , ssGetTaskTime (
rtS , 1 ) , ( char * ) & rtB . lt0d3owsjr + 0 ) ; } } } rtB . gu2lxqjoee =
rtP . donotdeletethisgain_Gain_o42imifl5k * rtB . gzwwnxifap [ 3 ] ; rtB .
glfgd2gxlp = rtB . jlrqkf40e4 - rtP . R_Gain_g4gmpqe5wx * rtB . gu2lxqjoee ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { if ( rtDW . m5pgrgp4cg . AQHandles
&& ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . m5pgrgp4cg . AQHandles
, ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . glfgd2gxlp + 0 ) ; } } { if
( rtDW . oee5uekymg . AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal
( rtDW . oee5uekymg . AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) &
rtB . cw0w1vgwxh + 0 ) ; } } } rtB . fntfm0klq3 = rtP .
donotdeletethisgain_Gain_fjipbfzkks * rtB . gzwwnxifap [ 4 ] ; rtB .
dzdzcnn4k1 = rtB . imwf4qbc3k - rtP . R_Gain_biqz0al5hr * rtB . fntfm0klq3 ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { if ( rtDW . jrgeolpedl . AQHandles
&& ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . jrgeolpedl . AQHandles
, ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . dzdzcnn4k1 + 0 ) ; } } { if
( rtDW . l4br0owshy . AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal
( rtDW . l4br0owshy . AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) &
rtB . fngvfw2vbc + 0 ) ; } } } rtB . otjjwnfbam = rtP .
donotdeletethisgain_Gain_ave45anr4u * rtB . gzwwnxifap [ 5 ] ; rtB .
f4hgeqqzrq = rtB . b05wxiklmy - rtP . R_Gain_bq04dmcpzt * rtB . otjjwnfbam ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { if ( rtDW . eqbzffk253 . AQHandles
&& ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . eqbzffk253 . AQHandles
, ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . f4hgeqqzrq + 0 ) ; } } { if
( rtDW . m1fwuqpiaf . AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal
( rtDW . m1fwuqpiaf . AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) &
rtB . czbyl5orjk + 0 ) ; } } } rtB . pch3fntlad = rtP .
donotdeletethisgain_Gain_dywzmacz1o * rtB . gzwwnxifap [ 1 ] ; rtB .
eiotr3cj2j = rtB . ipzhuu4ptw - rtP . R_Gain_cwdppwgit4 * rtB . pch3fntlad ;
if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . lg5hzw2ze0 = ( rtB .
pch3fntlad >= 0.0 ) ; } rtB . ooqdf4csin = rtDW . lg5hzw2ze0 > 0 ? rtB .
pch3fntlad : - rtB . pch3fntlad ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . b0t15mq1oh = ( rtB . pch3fntlad <
rtP . Constant_Value_ogegtmkzv0 ) ; } rtB . deezhakrkc = rtP . Gain4_Gain * (
real_T ) rtDW . b0t15mq1oh ; } rtB . i0ea205hal = rtB . deezhakrkc - rtB .
pabcbevt20 ; rtB . be32mwjpny = rtB . ooqdf4csin * rtB . i0ea205hal ; rtB .
aqgrfvolcg = rtP . Gain1_Gain * rtB . be32mwjpny ; rtB . bdqvl4emoj = rtP .
Gain2_Gain * rtB . apptu0x5zl ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW
. gglvg5yhwg = ( rtB . a1xkvgib3c >= 0.0 ) ; } rtB . niay40fjqf = rtDW .
gglvg5yhwg > 0 ? rtB . a1xkvgib3c : - rtB . a1xkvgib3c ; if ( ssIsSampleHit (
rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . dx31ootphe
= ( rtB . a1xkvgib3c < rtP . Constant_Value_h5irp45zuu ) ; } rtB . c51nh4xf1q
= rtP . Gain4_Gain_kh00znyazs * ( real_T ) rtDW . dx31ootphe ; } rtB .
jv5t3iflfp = rtB . c51nh4xf1q - rtB . hcjtzzfngx ; rtB . cdukvsxdzj = rtB .
niay40fjqf * rtB . jv5t3iflfp ; rtB . hjnfpefc4k = rtP .
Gain1_Gain_og11bwmhu2 * rtB . cdukvsxdzj ; rtB . dfsyb51tzv = rtP .
Gain2_Gain_m4x3vq3y1f * rtB . nqwiqvxip0 ; if ( ssGetIsOkayToUpdateMode ( rtS
) ) { rtDW . bhkajjcc0s = ( rtB . gu2lxqjoee >= 0.0 ) ; } rtB . nka52w5p2z =
rtDW . bhkajjcc0s > 0 ? rtB . gu2lxqjoee : - rtB . gu2lxqjoee ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . lbbdcegp5z = ( rtB . gu2lxqjoee < rtP . Constant_Value_k5pwul1wle ) ;
} rtB . hkcf5uul0d = rtP . Gain4_Gain_fstjjgzlds * ( real_T ) rtDW .
lbbdcegp5z ; } rtB . ad5v3ototp = rtB . hkcf5uul0d - rtB . lhhtg1palw ; rtB .
nhbww2xvcr = rtB . nka52w5p2z * rtB . ad5v3ototp ; rtB . jxi4eauchh = rtP .
Gain1_Gain_anymdqpqln * rtB . nhbww2xvcr ; rtB . cfafquv2xr = rtP .
Gain2_Gain_jptbha03po * rtB . iacqlbe2tg ; if ( ssGetIsOkayToUpdateMode ( rtS
) ) { rtDW . bw1ne04erh = ( rtB . fntfm0klq3 >= 0.0 ) ; } rtB . fmprtpx12v =
rtDW . bw1ne04erh > 0 ? rtB . fntfm0klq3 : - rtB . fntfm0klq3 ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . cj1yejiuj0 = ( rtB . fntfm0klq3 < rtP . Constant_Value_pp4lg2cwxs ) ;
} rtB . gn1ehycyi2 = rtP . Gain4_Gain_n2oajsg4xg * ( real_T ) rtDW .
cj1yejiuj0 ; } rtB . ofqxlds3eh = rtB . gn1ehycyi2 - rtB . gomqwjxzd5 ; rtB .
byqwyjabue = rtB . fmprtpx12v * rtB . ofqxlds3eh ; rtB . kz5y1t5h5o = rtP .
Gain1_Gain_baecfd2g1g * rtB . byqwyjabue ; rtB . h4lwnoqm5x = rtP .
Gain2_Gain_fe3eihrk0b * rtB . e0au3fw2j3 ; if ( ssGetIsOkayToUpdateMode ( rtS
) ) { rtDW . lk5j3i1cks = ( rtB . otjjwnfbam >= 0.0 ) ; } rtB . l0fygtafkq =
rtDW . lk5j3i1cks > 0 ? rtB . otjjwnfbam : - rtB . otjjwnfbam ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . potnbsja2x = ( rtB . otjjwnfbam < rtP . Constant_Value_khiqevv1tc ) ;
} rtB . nsz3sakdbs = rtP . Gain4_Gain_j4eqtusam3 * ( real_T ) rtDW .
potnbsja2x ; } rtB . nszpfs0j4c = rtB . nsz3sakdbs - rtB . mxu3fd52lg ; rtB .
aqj5tzxay2 = rtB . l0fygtafkq * rtB . nszpfs0j4c ; rtB . pzkcy4pfea = rtP .
Gain1_Gain_dq4vkdpk0h * rtB . aqj5tzxay2 ; rtB . gbmzzjn501 = rtP .
Gain2_Gain_of2pa5ka31 * rtB . f5toqxhshz ; if ( ssIsSampleHit ( rtS , 6 , 0 )
) { if ( ( rtB . hr44golvpy * rtP . PWM5_Period + ssGetTaskTime ( rtS , 6 )
<= ssGetTaskTime ( rtS , 6 ) + 2.8421709430404007E-14 ) && rtDW . f4jvehgaau
) { rtB . cxzbwqcn1v = 0.0 ; rtDW . hyvrqtp0nq = false ; } else { rtB .
cxzbwqcn1v = rtDW . hyvrqtp0nq ; } } if ( ssIsSampleHit ( rtS , 5 , 0 ) ) {
if ( ( rtB . h0hbhcvnx4 * rtP . PWM_Period + ssGetTaskTime ( rtS , 5 ) <=
ssGetTaskTime ( rtS , 5 ) + 2.8421709430404007E-14 ) && rtDW . gutf54om0t ) {
rtB . cjyi1ugvfp = 0.0 ; rtDW . oklojozd5l = false ; } else { rtB .
cjyi1ugvfp = rtDW . oklojozd5l ; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . kwlwx42yav = ! ( rtB . cxzbwqcn1v != 0.0 ) ; } if ( ssIsSampleHit ( rtS
, 7 , 0 ) ) { if ( ( rtB . dmpeej2qt1 * rtP . PWM1_Period + ssGetTaskTime (
rtS , 7 ) <= ssGetTaskTime ( rtS , 7 ) + 2.8421709430404007E-14 ) && rtDW .
n2wn2lgi4k ) { rtB . hwbt4zhehe = 0.0 ; rtDW . lkdrn04ha3 = false ; } else {
rtB . hwbt4zhehe = rtDW . lkdrn04ha3 ; } } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtB . buretmbzch = ! ( rtB . cjyi1ugvfp != 0.0 ) ; } if ( ssIsSampleHit (
rtS , 4 , 0 ) ) { if ( ( rtB . o2kdszic3h * rtP . PWM2_Period + ssGetTaskTime
( rtS , 4 ) <= ssGetTaskTime ( rtS , 4 ) + 2.8421709430404007E-14 ) && rtDW .
cgi440wi10 ) { rtB . ala2ctnapt = 0.0 ; rtDW . cwj4t5csvl = false ; } else {
rtB . ala2ctnapt = rtDW . cwj4t5csvl ; } } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtB . ghpkp3e4ii = ! ( rtB . hwbt4zhehe != 0.0 ) ; } if ( ssIsSampleHit (
rtS , 3 , 0 ) ) { if ( ( rtB . oj2fro1nlz * rtP . PWM3_Period + ssGetTaskTime
( rtS , 3 ) <= ssGetTaskTime ( rtS , 3 ) + 2.8421709430404007E-14 ) && rtDW .
ff0qbzbocl ) { rtB . mgdng0j5ju = 0.0 ; rtDW . b45hsrgxk4 = false ; } else {
rtB . mgdng0j5ju = rtDW . b45hsrgxk4 ; } } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtB . palr0v3uue = ! ( rtB . ala2ctnapt != 0.0 ) ; } if ( ssIsSampleHit (
rtS , 2 , 0 ) ) { if ( ( rtB . g00batsh4u * rtP . PWM4_Period + ssGetTaskTime
( rtS , 2 ) <= ssGetTaskTime ( rtS , 2 ) + 2.8421709430404007E-14 ) && rtDW .
opghe0hhiz ) { rtB . hc4tipfzoi = 0.0 ; rtDW . d0uk2u5ily = false ; } else {
rtB . hc4tipfzoi = rtDW . d0uk2u5ily ; } } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtB . iilivmsrjv = ! ( rtB . mgdng0j5ju != 0.0 ) ; rtB . cpkwdk2p01 = ! (
rtB . hc4tipfzoi != 0.0 ) ; } rtB . ighohgvfas = 1.0 ; rtB . etxojvnaot = 1.0
; rtB . gwktivfwpd = 1.0 ; rtB . ekw0zt1xfm = 1.0 ; rtB . cqsienutuc = 1.0 ;
rtB . krygur50zl = 1.0 ; rtB . pblcvwi5vj = rtP .
donotdeletethisgain_Gain_jslrw2wpeb * rtB . gzwwnxifap [ 0 ] ; rtB .
fjax0ymfvv = rtP . donotdeletethisgain_Gain_hwxhghbjtm * rtB . gzwwnxifap [ 6
] ; UNUSED_PARAMETER ( tid ) ; } void MdlOutputsTID8 ( int_T tid ) { rtB .
owzswdceo3 = rtP . gate_Value ; rtB . lnwt3320xf = rtP .
gate_Value_ghlgnnffhp ; rtB . f1jzjr5wtp = rtP . gate_Value_e2pzllcxv0 ; rtB
. ezdk1hee5n = rtP . gate_Value_odvaswnitz ; rtB . mhvcgzbyma = rtP .
gate_Value_pf2c4dq35r ; rtB . dcu2acxtfg = rtP . gate_Value_a3a3irpdyg ; rtB
. lnh2z2pbk3 = rtP . gate_Value_bnwmvqs5lt ; rtB . ovmxhmbhlf = rtP .
gate_Value_poeni2w0ko ; rtB . g2q1v5iy2d = rtP . gate_Value_pp1t0xusap ; rtB
. pbgvg2nezd = rtP . gate_Value_ibmjcspxwo ; rtB . jzeacrnsxs = rtP .
gate_Value_hrisjp3q0m ; rtB . klom0nem0m = rtP . gate_Value_gy4tkqzmme ; rtB
. aolyxnh1an = rtP . gate_Value_hu4hogb4lk ; rtB . fzhbdpl21m = rtP .
gate_Value_hob43axlzj ; rtB . fllp1jvygi = rtP . gate_Value_o02a13bzdb ; rtB
. ln3b5mokgm = rtP . gate_Value_awsbj1udfy ; rtB . krwk3nllsf = rtP .
gate_Value_lcm302k1d0 ; rtB . kxozrd4z5i = rtP . gate_Value_hzvnhzjbik ;
UNUSED_PARAMETER ( tid ) ; } void MdlUpdate ( int_T tid ) { XDis * _rtXdis ;
real_T dc ; SimStruct * S ; void * diag ; _rtXdis = ( ( XDis * )
ssGetContStateDisabled ( rtS ) ) ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtDW . mwtjai2xzq = rtP . Constant12_Value ; rtDW . abnasr53i2 = rtB .
bdqvl4emoj ; } rtDW . mjabmoou2z = 0 ; switch ( rtDW . ndyjjzoyah ) { case 3
: if ( rtB . pch3fntlad < 0.0 ) { rtDW . ndyjjzoyah = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . pch3fntlad > 0.0 ) { rtDW . ndyjjzoyah = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
cwzgk12fex = ( ( rtDW . ndyjjzoyah == 3 ) || ( rtDW . ndyjjzoyah == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . puhqb53xlf = rtP .
Constant12_Value_df3z3yuypl ; rtDW . cgtn4vtk4v = rtB . dfsyb51tzv ; } rtDW .
apw4epat2u = 0 ; switch ( rtDW . pngsgibtfq ) { case 3 : if ( rtB .
a1xkvgib3c < 0.0 ) { rtDW . pngsgibtfq = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . a1xkvgib3c > 0.0 ) { rtDW . pngsgibtfq = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
edarxfgg3m = ( ( rtDW . pngsgibtfq == 3 ) || ( rtDW . pngsgibtfq == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . e5chgaqzdi = rtP .
Constant12_Value_ktnzmkcekm ; rtDW . br1vosysg0 = rtB . cfafquv2xr ; } rtDW .
fid4f0juyg = 0 ; switch ( rtDW . cbhsw3xyhw ) { case 3 : if ( rtB .
gu2lxqjoee < 0.0 ) { rtDW . cbhsw3xyhw = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . gu2lxqjoee > 0.0 ) { rtDW . cbhsw3xyhw = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
hytl13jcro = ( ( rtDW . cbhsw3xyhw == 3 ) || ( rtDW . cbhsw3xyhw == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . bw2f200uhe = rtP .
Constant12_Value_jkrk5dvljw ; rtDW . h1kn4wxczz = rtB . h4lwnoqm5x ; } rtDW .
a12tj2tqvt = 0 ; switch ( rtDW . nfdtmpqmjl ) { case 3 : if ( rtB .
fntfm0klq3 < 0.0 ) { rtDW . nfdtmpqmjl = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . fntfm0klq3 > 0.0 ) { rtDW . nfdtmpqmjl = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
hqm1okddyw = ( ( rtDW . nfdtmpqmjl == 3 ) || ( rtDW . nfdtmpqmjl == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . fwi0pu3glv = rtP .
Constant12_Value_oujd2whfki ; rtDW . m35jm4htkc = rtB . gbmzzjn501 ; } rtDW .
lb53h134aw = 0 ; switch ( rtDW . blabp2utic ) { case 3 : if ( rtB .
otjjwnfbam < 0.0 ) { rtDW . blabp2utic = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . otjjwnfbam > 0.0 ) { rtDW . blabp2utic = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
brizaijzew = ( ( rtDW . blabp2utic == 3 ) || ( rtDW . blabp2utic == 4 ) ) ; {
SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnUpdate ( rts , 0 ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } if ( ssIsSampleHit ( rtS ,
6 , 0 ) ) { if ( rtDW . hyvrqtp0nq ) { dc = rtB . hr44golvpy ; if ( ( rtP .
PWM5_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM5_Period ) || ( rtP
. PWM5_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr
( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM5/Variable Pulse Generator" , 2 , rtP . PWM5_Period , 2
, ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM5_Period + ssGetTaskTime ( rtS , 6 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 6 ) + ssGetTaskTime ( rtS , 6 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing3/PWM5/Variable Pulse Generator" , 2 , rtB . hr44golvpy , 2 ,
rtP . PWM5_Period , 2 , ssGetTaskTime ( rtS , 6 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . fatdrnikff ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
6 ) , 2 , rtB . hr44golvpy , 3 ,
"activeBalancing3/PWM5/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . fatdrnikff = false ; } }
if ( ( rtDW . mg0udjzg3z > 0.0 ) && ( rtDW . mg0udjzg3z == rtP . PWM5_Period
) ) { rtDW . gil1dfunsb ++ ; } else { rtDW . gil1dfunsb = 1ULL ; rtDW .
mg0udjzg3z = rtP . PWM5_Period ; rtDW . fnsfdleb5s = ssGetTaskTime ( rtS , 6
) ; } rtDW . ep01khxy3s = rtDW . mg0udjzg3z * ( real_T ) rtDW . gil1dfunsb +
rtDW . fnsfdleb5s ; if ( rtDW . ep01khxy3s - ( dc * rtP . PWM5_Period +
ssGetTaskTime ( rtS , 6 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
6 ) ) { _ssSetVarNextHitTime ( rtS , 4 , ssGetTaskTime ( rtS , 6 ) + dc * rtP
. PWM5_Period ) ; rtDW . hyvrqtp0nq = false ; rtDW . f4jvehgaau = false ; }
else if ( ( rtDW . ep01khxy3s - ( dc * rtP . PWM5_Period + ssGetTaskTime (
rtS , 6 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 6 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM5/Variable Pulse Generator" , 2 , rtP . PWM5_Period , 2
, ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 4 , rtDW . ep01khxy3s ) ; rtDW . hyvrqtp0nq =
true ; rtDW . f4jvehgaau = true ; } } else { if ( rtDW . f4jvehgaau ) { if (
( rtP . PWM5_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM5_Period )
|| ( rtP . PWM5_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM5/Variable Pulse Generator" , 2 , rtP . PWM5_Period , 2
, ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. hr44golvpy < 0.0 ) && rtDW . dz22xyy0n2 ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 6 ) , 2 , rtB . hr44golvpy , 3 ,
"activeBalancing3/PWM5/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . dz22xyy0n2 = false ; }
if ( ( rtDW . mg0udjzg3z > 0.0 ) && ( rtDW . mg0udjzg3z == rtP . PWM5_Period
) ) { rtDW . gil1dfunsb ++ ; } else { rtDW . gil1dfunsb = 1ULL ; rtDW .
mg0udjzg3z = rtP . PWM5_Period ; rtDW . fnsfdleb5s = ssGetTaskTime ( rtS , 6
) ; } _ssSetVarNextHitTime ( rtS , 4 , ssGetTaskTime ( rtS , 6 ) + rtP .
PWM5_Period ) ; } else if ( rtDW . ep01khxy3s > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 6 ) + ssGetTaskTime ( rtS , 6 ) ) {
_ssSetVarNextHitTime ( rtS , 4 , rtDW . ep01khxy3s ) ; } rtDW . hyvrqtp0nq =
true ; rtDW . f4jvehgaau = true ; } } if ( ssIsSampleHit ( rtS , 5 , 0 ) ) {
if ( rtDW . oklojozd5l ) { dc = rtB . h0hbhcvnx4 ; if ( ( rtP . PWM_Period <=
0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM_Period ) || ( rtP . PWM_Period ==
( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM/Variable Pulse Generator" , 2 , rtP . PWM_Period , 2 ,
ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM_Period + ssGetTaskTime ( rtS , 5 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 5 ) + ssGetTaskTime ( rtS , 5 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing3/PWM/Variable Pulse Generator" , 2 , rtB . h0hbhcvnx4 , 2 ,
rtP . PWM_Period , 2 , ssGetTaskTime ( rtS , 5 ) , 2 , 2.8421709430404007E-14
* ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc >
1.0 ) { dc = 1.0 ; if ( rtDW . awriz1pum1 ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleGreaterThanOne" , 3
, 2 , ssGetTaskTime ( rtS , 5 ) , 2 , rtB . h0hbhcvnx4 , 3 ,
"activeBalancing3/PWM/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . awriz1pum1 = false ; } }
if ( ( rtDW . h21d2fqnwl > 0.0 ) && ( rtDW . h21d2fqnwl == rtP . PWM_Period )
) { rtDW . oxz1dp4rtp ++ ; } else { rtDW . oxz1dp4rtp = 1ULL ; rtDW .
h21d2fqnwl = rtP . PWM_Period ; rtDW . o2neiszzpu = ssGetTaskTime ( rtS , 5 )
; } rtDW . esnkvscczq = rtDW . h21d2fqnwl * ( real_T ) rtDW . oxz1dp4rtp +
rtDW . o2neiszzpu ; if ( rtDW . esnkvscczq - ( dc * rtP . PWM_Period +
ssGetTaskTime ( rtS , 5 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
5 ) ) { _ssSetVarNextHitTime ( rtS , 3 , ssGetTaskTime ( rtS , 5 ) + dc * rtP
. PWM_Period ) ; rtDW . oklojozd5l = false ; rtDW . gutf54om0t = false ; }
else if ( ( rtDW . esnkvscczq - ( dc * rtP . PWM_Period + ssGetTaskTime ( rtS
, 5 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 5 ) ) && ( dc > 0.0
) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM/Variable Pulse Generator" , 2 , rtP . PWM_Period , 2 ,
ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 3 , rtDW . esnkvscczq ) ; rtDW . oklojozd5l =
true ; rtDW . gutf54om0t = true ; } } else { if ( rtDW . gutf54om0t ) { if (
( rtP . PWM_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM_Period ) ||
( rtP . PWM_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM/Variable Pulse Generator" , 2 , rtP . PWM_Period , 2 ,
ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB .
h0hbhcvnx4 < 0.0 ) && rtDW . hwlma5twap ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 5 ) , 2 , rtB . h0hbhcvnx4 , 3 ,
"activeBalancing3/PWM/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . hwlma5twap = false ; }
if ( ( rtDW . h21d2fqnwl > 0.0 ) && ( rtDW . h21d2fqnwl == rtP . PWM_Period )
) { rtDW . oxz1dp4rtp ++ ; } else { rtDW . oxz1dp4rtp = 1ULL ; rtDW .
h21d2fqnwl = rtP . PWM_Period ; rtDW . o2neiszzpu = ssGetTaskTime ( rtS , 5 )
; } _ssSetVarNextHitTime ( rtS , 3 , ssGetTaskTime ( rtS , 5 ) + rtP .
PWM_Period ) ; } else if ( rtDW . esnkvscczq > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 5 ) + ssGetTaskTime ( rtS , 5 ) ) {
_ssSetVarNextHitTime ( rtS , 3 , rtDW . esnkvscczq ) ; } rtDW . oklojozd5l =
true ; rtDW . gutf54om0t = true ; } } if ( ssIsSampleHit ( rtS , 7 , 0 ) ) {
if ( rtDW . lkdrn04ha3 ) { dc = rtB . dmpeej2qt1 ; if ( ( rtP . PWM1_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM1_Period ) || ( rtP .
PWM1_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM1/Variable Pulse Generator" , 2 , rtP . PWM1_Period , 2
, ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM1_Period + ssGetTaskTime ( rtS , 7 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 7 ) + ssGetTaskTime ( rtS , 7 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing3/PWM1/Variable Pulse Generator" , 2 , rtB . dmpeej2qt1 , 2 ,
rtP . PWM1_Period , 2 , ssGetTaskTime ( rtS , 7 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . lptg51m4go ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
7 ) , 2 , rtB . dmpeej2qt1 , 3 ,
"activeBalancing3/PWM1/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . lptg51m4go = false ; } }
if ( ( rtDW . imnddva2yd > 0.0 ) && ( rtDW . imnddva2yd == rtP . PWM1_Period
) ) { rtDW . i4itkhygug ++ ; } else { rtDW . i4itkhygug = 1ULL ; rtDW .
imnddva2yd = rtP . PWM1_Period ; rtDW . mlaq1sf05w = ssGetTaskTime ( rtS , 7
) ; } rtDW . f4vpteq14c = rtDW . imnddva2yd * ( real_T ) rtDW . i4itkhygug +
rtDW . mlaq1sf05w ; if ( rtDW . f4vpteq14c - ( dc * rtP . PWM1_Period +
ssGetTaskTime ( rtS , 7 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
7 ) ) { _ssSetVarNextHitTime ( rtS , 5 , ssGetTaskTime ( rtS , 7 ) + dc * rtP
. PWM1_Period ) ; rtDW . lkdrn04ha3 = false ; rtDW . n2wn2lgi4k = false ; }
else if ( ( rtDW . f4vpteq14c - ( dc * rtP . PWM1_Period + ssGetTaskTime (
rtS , 7 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 7 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM1/Variable Pulse Generator" , 2 , rtP . PWM1_Period , 2
, ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 5 , rtDW . f4vpteq14c ) ; rtDW . lkdrn04ha3 =
true ; rtDW . n2wn2lgi4k = true ; } } else { if ( rtDW . n2wn2lgi4k ) { if (
( rtP . PWM1_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM1_Period )
|| ( rtP . PWM1_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM1/Variable Pulse Generator" , 2 , rtP . PWM1_Period , 2
, ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. dmpeej2qt1 < 0.0 ) && rtDW . c4mx45ei5j ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 7 ) , 2 , rtB . dmpeej2qt1 , 3 ,
"activeBalancing3/PWM1/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . c4mx45ei5j = false ; }
if ( ( rtDW . imnddva2yd > 0.0 ) && ( rtDW . imnddva2yd == rtP . PWM1_Period
) ) { rtDW . i4itkhygug ++ ; } else { rtDW . i4itkhygug = 1ULL ; rtDW .
imnddva2yd = rtP . PWM1_Period ; rtDW . mlaq1sf05w = ssGetTaskTime ( rtS , 7
) ; } _ssSetVarNextHitTime ( rtS , 5 , ssGetTaskTime ( rtS , 7 ) + rtP .
PWM1_Period ) ; } else if ( rtDW . f4vpteq14c > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 7 ) + ssGetTaskTime ( rtS , 7 ) ) {
_ssSetVarNextHitTime ( rtS , 5 , rtDW . f4vpteq14c ) ; } rtDW . lkdrn04ha3 =
true ; rtDW . n2wn2lgi4k = true ; } } if ( ssIsSampleHit ( rtS , 4 , 0 ) ) {
if ( rtDW . cwj4t5csvl ) { dc = rtB . o2kdszic3h ; if ( ( rtP . PWM2_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM2_Period ) || ( rtP .
PWM2_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM2/Variable Pulse Generator" , 2 , rtP . PWM2_Period , 2
, ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM2_Period + ssGetTaskTime ( rtS , 4 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 4 ) + ssGetTaskTime ( rtS , 4 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing3/PWM2/Variable Pulse Generator" , 2 , rtB . o2kdszic3h , 2 ,
rtP . PWM2_Period , 2 , ssGetTaskTime ( rtS , 4 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . nqrddpnaqi ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
4 ) , 2 , rtB . o2kdszic3h , 3 ,
"activeBalancing3/PWM2/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . nqrddpnaqi = false ; } }
if ( ( rtDW . cukktpbdau > 0.0 ) && ( rtDW . cukktpbdau == rtP . PWM2_Period
) ) { rtDW . fzl1x30105 ++ ; } else { rtDW . fzl1x30105 = 1ULL ; rtDW .
cukktpbdau = rtP . PWM2_Period ; rtDW . gvyq4tdih4 = ssGetTaskTime ( rtS , 4
) ; } rtDW . bv3ta2c31d = rtDW . cukktpbdau * ( real_T ) rtDW . fzl1x30105 +
rtDW . gvyq4tdih4 ; if ( rtDW . bv3ta2c31d - ( dc * rtP . PWM2_Period +
ssGetTaskTime ( rtS , 4 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
4 ) ) { _ssSetVarNextHitTime ( rtS , 2 , ssGetTaskTime ( rtS , 4 ) + dc * rtP
. PWM2_Period ) ; rtDW . cwj4t5csvl = false ; rtDW . cgi440wi10 = false ; }
else if ( ( rtDW . bv3ta2c31d - ( dc * rtP . PWM2_Period + ssGetTaskTime (
rtS , 4 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 4 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM2/Variable Pulse Generator" , 2 , rtP . PWM2_Period , 2
, ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 2 , rtDW . bv3ta2c31d ) ; rtDW . cwj4t5csvl =
true ; rtDW . cgi440wi10 = true ; } } else { if ( rtDW . cgi440wi10 ) { if (
( rtP . PWM2_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM2_Period )
|| ( rtP . PWM2_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM2/Variable Pulse Generator" , 2 , rtP . PWM2_Period , 2
, ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. o2kdszic3h < 0.0 ) && rtDW . lvplimut2k ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 4 ) , 2 , rtB . o2kdszic3h , 3 ,
"activeBalancing3/PWM2/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . lvplimut2k = false ; }
if ( ( rtDW . cukktpbdau > 0.0 ) && ( rtDW . cukktpbdau == rtP . PWM2_Period
) ) { rtDW . fzl1x30105 ++ ; } else { rtDW . fzl1x30105 = 1ULL ; rtDW .
cukktpbdau = rtP . PWM2_Period ; rtDW . gvyq4tdih4 = ssGetTaskTime ( rtS , 4
) ; } _ssSetVarNextHitTime ( rtS , 2 , ssGetTaskTime ( rtS , 4 ) + rtP .
PWM2_Period ) ; } else if ( rtDW . bv3ta2c31d > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 4 ) + ssGetTaskTime ( rtS , 4 ) ) {
_ssSetVarNextHitTime ( rtS , 2 , rtDW . bv3ta2c31d ) ; } rtDW . cwj4t5csvl =
true ; rtDW . cgi440wi10 = true ; } } if ( ssIsSampleHit ( rtS , 3 , 0 ) ) {
if ( rtDW . b45hsrgxk4 ) { dc = rtB . oj2fro1nlz ; if ( ( rtP . PWM3_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM3_Period ) || ( rtP .
PWM3_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM3/Variable Pulse Generator" , 2 , rtP . PWM3_Period , 2
, ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM3_Period + ssGetTaskTime ( rtS , 3 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 3 ) + ssGetTaskTime ( rtS , 3 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing3/PWM3/Variable Pulse Generator" , 2 , rtB . oj2fro1nlz , 2 ,
rtP . PWM3_Period , 2 , ssGetTaskTime ( rtS , 3 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . j553vsqqsn ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
3 ) , 2 , rtB . oj2fro1nlz , 3 ,
"activeBalancing3/PWM3/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . j553vsqqsn = false ; } }
if ( ( rtDW . h0ir15tiwo > 0.0 ) && ( rtDW . h0ir15tiwo == rtP . PWM3_Period
) ) { rtDW . kuacjottby ++ ; } else { rtDW . kuacjottby = 1ULL ; rtDW .
h0ir15tiwo = rtP . PWM3_Period ; rtDW . nlleqzlpac = ssGetTaskTime ( rtS , 3
) ; } rtDW . hwclgprvm0 = rtDW . h0ir15tiwo * ( real_T ) rtDW . kuacjottby +
rtDW . nlleqzlpac ; if ( rtDW . hwclgprvm0 - ( dc * rtP . PWM3_Period +
ssGetTaskTime ( rtS , 3 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
3 ) ) { _ssSetVarNextHitTime ( rtS , 1 , ssGetTaskTime ( rtS , 3 ) + dc * rtP
. PWM3_Period ) ; rtDW . b45hsrgxk4 = false ; rtDW . ff0qbzbocl = false ; }
else if ( ( rtDW . hwclgprvm0 - ( dc * rtP . PWM3_Period + ssGetTaskTime (
rtS , 3 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 3 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM3/Variable Pulse Generator" , 2 , rtP . PWM3_Period , 2
, ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 1 , rtDW . hwclgprvm0 ) ; rtDW . b45hsrgxk4 =
true ; rtDW . ff0qbzbocl = true ; } } else { if ( rtDW . ff0qbzbocl ) { if (
( rtP . PWM3_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM3_Period )
|| ( rtP . PWM3_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM3/Variable Pulse Generator" , 2 , rtP . PWM3_Period , 2
, ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. oj2fro1nlz < 0.0 ) && rtDW . kevb4e4jpg ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 3 ) , 2 , rtB . oj2fro1nlz , 3 ,
"activeBalancing3/PWM3/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . kevb4e4jpg = false ; }
if ( ( rtDW . h0ir15tiwo > 0.0 ) && ( rtDW . h0ir15tiwo == rtP . PWM3_Period
) ) { rtDW . kuacjottby ++ ; } else { rtDW . kuacjottby = 1ULL ; rtDW .
h0ir15tiwo = rtP . PWM3_Period ; rtDW . nlleqzlpac = ssGetTaskTime ( rtS , 3
) ; } _ssSetVarNextHitTime ( rtS , 1 , ssGetTaskTime ( rtS , 3 ) + rtP .
PWM3_Period ) ; } else if ( rtDW . hwclgprvm0 > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 3 ) + ssGetTaskTime ( rtS , 3 ) ) {
_ssSetVarNextHitTime ( rtS , 1 , rtDW . hwclgprvm0 ) ; } rtDW . b45hsrgxk4 =
true ; rtDW . ff0qbzbocl = true ; } } if ( ssIsSampleHit ( rtS , 2 , 0 ) ) {
if ( rtDW . d0uk2u5ily ) { dc = rtB . g00batsh4u ; if ( ( rtP . PWM4_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM4_Period ) || ( rtP .
PWM4_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM4/Variable Pulse Generator" , 2 , rtP . PWM4_Period , 2
, ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM4_Period + ssGetTaskTime ( rtS , 2 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 2 ) + ssGetTaskTime ( rtS , 2 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing3/PWM4/Variable Pulse Generator" , 2 , rtB . g00batsh4u , 2 ,
rtP . PWM4_Period , 2 , ssGetTaskTime ( rtS , 2 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . hykritwrbg ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
2 ) , 2 , rtB . g00batsh4u , 3 ,
"activeBalancing3/PWM4/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . hykritwrbg = false ; } }
if ( ( rtDW . mk2k513iba > 0.0 ) && ( rtDW . mk2k513iba == rtP . PWM4_Period
) ) { rtDW . dtdzggbusy ++ ; } else { rtDW . dtdzggbusy = 1ULL ; rtDW .
mk2k513iba = rtP . PWM4_Period ; rtDW . dul0uayr5l = ssGetTaskTime ( rtS , 2
) ; } rtDW . dp1esyh3gc = rtDW . mk2k513iba * ( real_T ) rtDW . dtdzggbusy +
rtDW . dul0uayr5l ; if ( rtDW . dp1esyh3gc - ( dc * rtP . PWM4_Period +
ssGetTaskTime ( rtS , 2 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
2 ) ) { _ssSetVarNextHitTime ( rtS , 0 , ssGetTaskTime ( rtS , 2 ) + dc * rtP
. PWM4_Period ) ; rtDW . d0uk2u5ily = false ; rtDW . opghe0hhiz = false ; }
else if ( ( rtDW . dp1esyh3gc - ( dc * rtP . PWM4_Period + ssGetTaskTime (
rtS , 2 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 2 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM4/Variable Pulse Generator" , 2 , rtP . PWM4_Period , 2
, ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 0 , rtDW . dp1esyh3gc ) ; rtDW . d0uk2u5ily =
true ; rtDW . opghe0hhiz = true ; } } else { if ( rtDW . opghe0hhiz ) { if (
( rtP . PWM4_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM4_Period )
|| ( rtP . PWM4_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing3/PWM4/Variable Pulse Generator" , 2 , rtP . PWM4_Period , 2
, ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. g00batsh4u < 0.0 ) && rtDW . aznjkggrjt ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 2 ) , 2 , rtB . g00batsh4u , 3 ,
"activeBalancing3/PWM4/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . aznjkggrjt = false ; }
if ( ( rtDW . mk2k513iba > 0.0 ) && ( rtDW . mk2k513iba == rtP . PWM4_Period
) ) { rtDW . dtdzggbusy ++ ; } else { rtDW . dtdzggbusy = 1ULL ; rtDW .
mk2k513iba = rtP . PWM4_Period ; rtDW . dul0uayr5l = ssGetTaskTime ( rtS , 2
) ; } _ssSetVarNextHitTime ( rtS , 0 , ssGetTaskTime ( rtS , 2 ) + rtP .
PWM4_Period ) ; } else if ( rtDW . dp1esyh3gc > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 2 ) + ssGetTaskTime ( rtS , 2 ) ) {
_ssSetVarNextHitTime ( rtS , 0 , rtDW . dp1esyh3gc ) ; } rtDW . d0uk2u5ily =
true ; rtDW . opghe0hhiz = true ; } } UNUSED_PARAMETER ( tid ) ; } void
MdlUpdateTID8 ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void
MdlDerivatives ( void ) { XDis * _rtXdis ; XDot * _rtXdot ; _rtXdis = ( (
XDis * ) ssGetContStateDisabled ( rtS ) ) ; _rtXdot = ( ( XDot * ) ssGetdX (
rtS ) ) ; _rtXdot -> btwaflzkr2 = 0.0 ; _rtXdot -> btwaflzkr2 += rtP .
Currentfilter_A * rtX . btwaflzkr2 ; _rtXdot -> btwaflzkr2 += rtB .
pch3fntlad ; if ( _rtXdis -> cwzgk12fex ) { _rtXdot -> cwzgk12fex = 0.0 ; }
else { _rtXdot -> cwzgk12fex = rtB . pch3fntlad ; } _rtXdot -> p2dwfugebo =
rtB . aqgrfvolcg ; _rtXdot -> gzwgpg3i32 = 0.0 ; _rtXdot -> gzwgpg3i32 += rtP
. BAL_A * rtX . gzwgpg3i32 ; _rtXdot -> gzwgpg3i32 += rtB . pch3fntlad ;
_rtXdot -> ieqye3wyr3 = 0.0 ; _rtXdot -> ieqye3wyr3 += rtP .
Currentfilter_A_hazdhojaym * rtX . ieqye3wyr3 ; _rtXdot -> ieqye3wyr3 += rtB
. a1xkvgib3c ; if ( _rtXdis -> edarxfgg3m ) { _rtXdot -> edarxfgg3m = 0.0 ; }
else { _rtXdot -> edarxfgg3m = rtB . a1xkvgib3c ; } _rtXdot -> n1mefgeo42 =
rtB . hjnfpefc4k ; _rtXdot -> kwkmxprem3 = 0.0 ; _rtXdot -> kwkmxprem3 += rtP
. BAL_A_cudqa1u03y * rtX . kwkmxprem3 ; _rtXdot -> kwkmxprem3 += rtB .
a1xkvgib3c ; _rtXdot -> g0ii5xynxb = 0.0 ; _rtXdot -> g0ii5xynxb += rtP .
Currentfilter_A_pyl0ygpghg * rtX . g0ii5xynxb ; _rtXdot -> g0ii5xynxb += rtB
. gu2lxqjoee ; if ( _rtXdis -> hytl13jcro ) { _rtXdot -> hytl13jcro = 0.0 ; }
else { _rtXdot -> hytl13jcro = rtB . gu2lxqjoee ; } _rtXdot -> daazrzvjzg =
rtB . jxi4eauchh ; _rtXdot -> kmijbaomfh = 0.0 ; _rtXdot -> kmijbaomfh += rtP
. BAL_A_n35zxahhei * rtX . kmijbaomfh ; _rtXdot -> kmijbaomfh += rtB .
gu2lxqjoee ; _rtXdot -> e3mceh2nlv = 0.0 ; _rtXdot -> e3mceh2nlv += rtP .
Currentfilter_A_bsszjj1hem * rtX . e3mceh2nlv ; _rtXdot -> e3mceh2nlv += rtB
. fntfm0klq3 ; if ( _rtXdis -> hqm1okddyw ) { _rtXdot -> hqm1okddyw = 0.0 ; }
else { _rtXdot -> hqm1okddyw = rtB . fntfm0klq3 ; } _rtXdot -> abk5ytngnj =
rtB . kz5y1t5h5o ; _rtXdot -> kskuxricdl = 0.0 ; _rtXdot -> kskuxricdl += rtP
. BAL_A_jgidwk4hmh * rtX . kskuxricdl ; _rtXdot -> kskuxricdl += rtB .
fntfm0klq3 ; _rtXdot -> lx3xuxie2j = 0.0 ; _rtXdot -> lx3xuxie2j += rtP .
Currentfilter_A_o3r40a2fs0 * rtX . lx3xuxie2j ; _rtXdot -> lx3xuxie2j += rtB
. otjjwnfbam ; if ( _rtXdis -> brizaijzew ) { _rtXdot -> brizaijzew = 0.0 ; }
else { _rtXdot -> brizaijzew = rtB . otjjwnfbam ; } _rtXdot -> jjfpdr1zyr =
rtB . pzkcy4pfea ; _rtXdot -> imz4v0p4of = 0.0 ; _rtXdot -> imz4v0p4of += rtP
. BAL_A_oad34lr4nf * rtX . imz4v0p4of ; _rtXdot -> imz4v0p4of += rtB .
otjjwnfbam ; { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; real_T *
sfcndX_fx = ( real_T * ) & ( ( XDot * ) ssGetdX ( rtS ) ) -> lwbwvxj00j [ 0 ]
; ssSetdX ( rts , sfcndX_fx ) ; sfcnDerivatives ( rts ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } } void MdlProjection ( void
) { { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnProjection ( rts ) ;
if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } } void
MdlZeroCrossings ( void ) { ZCV * _rtZCSV ; _rtZCSV = ( ( ZCV * )
ssGetSolverZcSignalVector ( rtS ) ) ; _rtZCSV -> dpon5t3zds = rtB .
lssfzuya44 - rtP . Constant_Value ; switch ( rtDW . ndyjjzoyah ) { case 1 :
_rtZCSV -> h12uqoqmiq = 0.0 ; _rtZCSV -> klvhdymfwp = rtP . inti_UpperSat -
rtP . inti_LowerSat ; break ; case 2 : _rtZCSV -> h12uqoqmiq = rtP .
inti_LowerSat - rtP . inti_UpperSat ; _rtZCSV -> klvhdymfwp = 0.0 ; break ;
default : _rtZCSV -> h12uqoqmiq = rtX . cwzgk12fex - rtP . inti_UpperSat ;
_rtZCSV -> klvhdymfwp = rtX . cwzgk12fex - rtP . inti_LowerSat ; break ; } if
( ( rtDW . ndyjjzoyah == 3 ) || ( rtDW . ndyjjzoyah == 4 ) ) { _rtZCSV ->
jqp2i1ve4i = rtB . pch3fntlad ; } else { _rtZCSV -> jqp2i1ve4i = 0.0 ; }
_rtZCSV -> icvrclk4au = rtB . mpjucudbtk - rtB . hitd4jbxxo ; _rtZCSV ->
afddasuzac = rtB . mpjucudbtk - rtP . Constant9_Value ; _rtZCSV -> kc4y1yee3p
= rtB . g3cnit1gts - rtB . cgbzrrdvnj ; _rtZCSV -> c3ixazwym1 = rtB .
mpjucudbtk - rtB . j04p5reu3p ; _rtZCSV -> loaosuz0go = rtB . mpjucudbtk -
rtB . cklmpkcmxr ; _rtZCSV -> duvffkgaqs = rtB . lssfzuya44 - rtP .
Constant_Value_efypwvyyax ; _rtZCSV -> m4ux3bcx3x = rtB . apptu0x5zl - rtP .
Saturation_UpperSat ; _rtZCSV -> g5g4l0y42j = rtB . apptu0x5zl - rtP .
Saturation_LowerSat ; _rtZCSV -> nkfuqbe0ew = rtB . bjzh2zswrf - rtP .
Constant1_Value ; _rtZCSV -> b4gicyjgcf = rtB . bjzh2zswrf - rtB . htgwxujgfn
; _rtZCSV -> nqhf1ryrfa = rtB . fd3qiys2ps - rtP . Constant_Value_pbqzqfbpnm
; switch ( rtDW . pngsgibtfq ) { case 1 : _rtZCSV -> l5lfpvrvuy = 0.0 ;
_rtZCSV -> ge1opwpogo = rtP . inti_UpperSat_itldayqrxp - rtP .
inti_LowerSat_lz3gh0icex ; break ; case 2 : _rtZCSV -> l5lfpvrvuy = rtP .
inti_LowerSat_lz3gh0icex - rtP . inti_UpperSat_itldayqrxp ; _rtZCSV ->
ge1opwpogo = 0.0 ; break ; default : _rtZCSV -> l5lfpvrvuy = rtX . edarxfgg3m
- rtP . inti_UpperSat_itldayqrxp ; _rtZCSV -> ge1opwpogo = rtX . edarxfgg3m -
rtP . inti_LowerSat_lz3gh0icex ; break ; } if ( ( rtDW . pngsgibtfq == 3 ) ||
( rtDW . pngsgibtfq == 4 ) ) { _rtZCSV -> parudjb3ad = rtB . a1xkvgib3c ; }
else { _rtZCSV -> parudjb3ad = 0.0 ; } _rtZCSV -> a3xmp4xhja = rtB .
pse0v0upak - rtB . olx2nutnfv ; _rtZCSV -> k2acyyht0h = rtB . pse0v0upak -
rtP . Constant9_Value_bfo0fnc5l1 ; _rtZCSV -> lfxejjfiae = rtB . iadrygzp4x -
rtB . j1vwznyubj ; _rtZCSV -> immgmtvdhe = rtB . pse0v0upak - rtB .
me3a54u35r ; _rtZCSV -> jb1rvtaper = rtB . pse0v0upak - rtB . fj5f5uf5pw ;
_rtZCSV -> jxgaj2ldm0 = rtB . fd3qiys2ps - rtP . Constant_Value_hu3rmuppbn ;
_rtZCSV -> mtl5u0lk3w = rtB . nqwiqvxip0 - rtP .
Saturation_UpperSat_lxx4j3fnoa ; _rtZCSV -> fa2kp2l4x5 = rtB . nqwiqvxip0 -
rtP . Saturation_LowerSat_kwi433xk5g ; _rtZCSV -> dinys3acfp = rtB .
dawtfnjz3t - rtP . Constant1_Value_jelmmtr1rj ; _rtZCSV -> fqu4g4bwdc = rtB .
dawtfnjz3t - rtB . f2scb5rf13 ; _rtZCSV -> kslios301p = rtB . lnjfdccy2h -
rtP . Constant_Value_bksqnhysc0 ; switch ( rtDW . cbhsw3xyhw ) { case 1 :
_rtZCSV -> edj4fsz5jj = 0.0 ; _rtZCSV -> bxboupuav2 = rtP .
inti_UpperSat_nowwhgaxwk - rtP . inti_LowerSat_cwekkzbyq1 ; break ; case 2 :
_rtZCSV -> edj4fsz5jj = rtP . inti_LowerSat_cwekkzbyq1 - rtP .
inti_UpperSat_nowwhgaxwk ; _rtZCSV -> bxboupuav2 = 0.0 ; break ; default :
_rtZCSV -> edj4fsz5jj = rtX . hytl13jcro - rtP . inti_UpperSat_nowwhgaxwk ;
_rtZCSV -> bxboupuav2 = rtX . hytl13jcro - rtP . inti_LowerSat_cwekkzbyq1 ;
break ; } if ( ( rtDW . cbhsw3xyhw == 3 ) || ( rtDW . cbhsw3xyhw == 4 ) ) {
_rtZCSV -> ftsh5pehvr = rtB . gu2lxqjoee ; } else { _rtZCSV -> ftsh5pehvr =
0.0 ; } _rtZCSV -> n1u2yvuukx = rtB . olt2mencvc - rtB . dsgitwjsjs ; _rtZCSV
-> eeniiexdz4 = rtB . olt2mencvc - rtP . Constant9_Value_nhyzz1ckmw ; _rtZCSV
-> iinseslf21 = rtB . bjsmudeh15 - rtB . fwpjmaqmyl ; _rtZCSV -> byeoj1g00g =
rtB . olt2mencvc - rtB . fbim3ivtyq ; _rtZCSV -> fz2sfbu2li = rtB .
olt2mencvc - rtB . inr0z52r4v ; _rtZCSV -> dxjap1y2hu = rtB . lnjfdccy2h -
rtP . Constant_Value_owtewy0ssm ; _rtZCSV -> pj5afrzsk1 = rtB . iacqlbe2tg -
rtP . Saturation_UpperSat_blj3ug4rzx ; _rtZCSV -> fda2am4ddo = rtB .
iacqlbe2tg - rtP . Saturation_LowerSat_o0i20janpw ; _rtZCSV -> jqptvkklyb =
rtB . ctz0crt1lg - rtP . Constant1_Value_jj3f5fu3xp ; _rtZCSV -> lmsx3qxry2 =
rtB . ctz0crt1lg - rtB . ebcqidfawa ; _rtZCSV -> f3iezawgro = rtB .
pmwqhxrjfr - rtP . Constant_Value_kedzfrfegv ; switch ( rtDW . nfdtmpqmjl ) {
case 1 : _rtZCSV -> ctsjyrsrwf = 0.0 ; _rtZCSV -> blxyuqpo0t = rtP .
inti_UpperSat_itde10ibkj - rtP . inti_LowerSat_nb1wwuftgl ; break ; case 2 :
_rtZCSV -> ctsjyrsrwf = rtP . inti_LowerSat_nb1wwuftgl - rtP .
inti_UpperSat_itde10ibkj ; _rtZCSV -> blxyuqpo0t = 0.0 ; break ; default :
_rtZCSV -> ctsjyrsrwf = rtX . hqm1okddyw - rtP . inti_UpperSat_itde10ibkj ;
_rtZCSV -> blxyuqpo0t = rtX . hqm1okddyw - rtP . inti_LowerSat_nb1wwuftgl ;
break ; } if ( ( rtDW . nfdtmpqmjl == 3 ) || ( rtDW . nfdtmpqmjl == 4 ) ) {
_rtZCSV -> bozmxnbwx0 = rtB . fntfm0klq3 ; } else { _rtZCSV -> bozmxnbwx0 =
0.0 ; } _rtZCSV -> n2sobzq5kv = rtB . h3gzco2fqa - rtB . bvviu2o2gh ; _rtZCSV
-> ihjgtx03o3 = rtB . h3gzco2fqa - rtP . Constant9_Value_ffsooduwum ; _rtZCSV
-> bfcuy22y45 = rtB . lfgqqylnmm - rtB . oocd2yqorm ; _rtZCSV -> ax1nsihfjd =
rtB . h3gzco2fqa - rtB . aprnkbzhsq ; _rtZCSV -> fumtwk3ksm = rtB .
h3gzco2fqa - rtB . fmzs5132om ; _rtZCSV -> gdbo3gtvxr = rtB . pmwqhxrjfr -
rtP . Constant_Value_opaksbgo21 ; _rtZCSV -> ntdwmivoif = rtB . e0au3fw2j3 -
rtP . Saturation_UpperSat_c0l2pkijii ; _rtZCSV -> lb1sh0efu4 = rtB .
e0au3fw2j3 - rtP . Saturation_LowerSat_g1ovkjgj1x ; _rtZCSV -> d3s2st3bgc =
rtB . bs00yavsbm - rtP . Constant1_Value_myhrse5szs ; _rtZCSV -> d0h3iumb2c =
rtB . bs00yavsbm - rtB . orwu5t0tyg ; _rtZCSV -> nulp2ugcrt = rtB .
hjgu4nxp5v - rtP . Constant_Value_epq2rsx4ba ; switch ( rtDW . blabp2utic ) {
case 1 : _rtZCSV -> pwpsfaf2h0 = 0.0 ; _rtZCSV -> a1rqeng10c = rtP .
inti_UpperSat_ff0nysnmjy - rtP . inti_LowerSat_hzpmw3xl5s ; break ; case 2 :
_rtZCSV -> pwpsfaf2h0 = rtP . inti_LowerSat_hzpmw3xl5s - rtP .
inti_UpperSat_ff0nysnmjy ; _rtZCSV -> a1rqeng10c = 0.0 ; break ; default :
_rtZCSV -> pwpsfaf2h0 = rtX . brizaijzew - rtP . inti_UpperSat_ff0nysnmjy ;
_rtZCSV -> a1rqeng10c = rtX . brizaijzew - rtP . inti_LowerSat_hzpmw3xl5s ;
break ; } if ( ( rtDW . blabp2utic == 3 ) || ( rtDW . blabp2utic == 4 ) ) {
_rtZCSV -> etitv5r1sa = rtB . otjjwnfbam ; } else { _rtZCSV -> etitv5r1sa =
0.0 ; } _rtZCSV -> dvvojtxfl0 = rtB . e42dsovuoz - rtB . cngflnzqr2 ; _rtZCSV
-> aicckewnqd = rtB . e42dsovuoz - rtP . Constant9_Value_bcezbzp4a1 ; _rtZCSV
-> ha2ftbblio = rtB . nwootfl0wl - rtB . ermmdxeqvq ; _rtZCSV -> kx1tvjophx =
rtB . e42dsovuoz - rtB . bcqp5bw5m5 ; _rtZCSV -> eeoq0zfn5c = rtB .
e42dsovuoz - rtB . mymfehhqyf ; _rtZCSV -> pn2bszjmi0 = rtB . hjgu4nxp5v -
rtP . Constant_Value_h45zreb2fb ; _rtZCSV -> pcq1wfk3g4 = rtB . f5toqxhshz -
rtP . Saturation_UpperSat_dr1jmbb0we ; _rtZCSV -> ebs50zws43 = rtB .
f5toqxhshz - rtP . Saturation_LowerSat_haspwmkdbs ; _rtZCSV -> nq2n4hq1vx =
rtB . gy2pn1xoxf - rtP . Constant1_Value_h1thd4w1zg ; _rtZCSV -> gb5vqnkthp =
rtB . gy2pn1xoxf - rtB . neo3wgh5k0 ; { SimStruct * rts = ssGetSFunction (
rtS , 0 ) ; ssSetNonsampledZCs ( rts , & ( ( ( ZCV * )
ssGetSolverZcSignalVector ( rtS ) ) -> dt132ajetl [ 0 ] ) ) ;
sfcnZeroCrossings ( rts ) ; if ( ssGetErrorStatus ( rts ) != ( NULL ) )
return ; } _rtZCSV -> ktxcx52jqi = rtB . mharr3pkm3 - rtP .
Saturation_UpperSat_aqwzuangfk ; _rtZCSV -> hdeanbf5bj = rtB . mharr3pkm3 -
rtP . Saturation_LowerSat_bcd3czsgyq ; _rtZCSV -> cifrbym2j5 = rtB .
cszbfywqst - rtP . Saturation_UpperSat_i3x3oscagf ; _rtZCSV -> kwcqgahbhx =
rtB . cszbfywqst - rtP . Saturation_LowerSat_gnz45aadu0 ; _rtZCSV ->
g332hceh05 = rtB . i2s0aqv5oj ; _rtZCSV -> afehf4h1gc = rtB . mnn2sdpcg2 -
rtP . Saturation_UpperSat_pcz043fnep ; _rtZCSV -> jw0tis5o2a = rtB .
mnn2sdpcg2 - rtP . Saturation_LowerSat_b05y2t0vvl ; _rtZCSV -> nlhita2tjm =
rtB . jkh0lpzdyl ; _rtZCSV -> d4pswc0ibx = rtB . ccjxi5v2q0 - rtP .
Saturation_UpperSat_luxvjfmfd3 ; _rtZCSV -> ad0wx4ny25 = rtB . ccjxi5v2q0 -
rtP . Saturation_LowerSat_mqcesji40p ; _rtZCSV -> kame3an42b = rtB .
bmkbfj44hc - rtP . Saturation_UpperSat_p4wbgcsokm ; _rtZCSV -> dwu5vwjndy =
rtB . bmkbfj44hc - rtP . Saturation_LowerSat_gdbbvpyvzg ; _rtZCSV ->
h31sbmogo5 = rtB . mgwtedhsbf ; _rtZCSV -> f5it25ggpi = rtB . gsugcfegmq ;
_rtZCSV -> lnxt5cpz0j = rtB . nh3tyegvgp ; _rtZCSV -> gs24r0gq3p = rtB .
hjlmg51yd0 ; _rtZCSV -> jsvaru1iar = rtB . pch3fntlad ; _rtZCSV -> i1ho113ysj
= rtB . pch3fntlad - rtP . Constant_Value_ogegtmkzv0 ; _rtZCSV -> h2e4epdjes
= rtB . a1xkvgib3c ; _rtZCSV -> necoxhezuu = rtB . a1xkvgib3c - rtP .
Constant_Value_h5irp45zuu ; _rtZCSV -> brgayjstgx = rtB . gu2lxqjoee ;
_rtZCSV -> dagytij501 = rtB . gu2lxqjoee - rtP . Constant_Value_k5pwul1wle ;
_rtZCSV -> a5adlyl4bb = rtB . fntfm0klq3 ; _rtZCSV -> prio0gcowu = rtB .
fntfm0klq3 - rtP . Constant_Value_pp4lg2cwxs ; _rtZCSV -> f25eellwxd = rtB .
otjjwnfbam ; _rtZCSV -> j13ozua51f = rtB . otjjwnfbam - rtP .
Constant_Value_khiqevv1tc ; } void MdlTerminate ( void ) { { SimStruct * rts
= ssGetSFunction ( rtS , 0 ) ; sfcnTerminate ( rts ) ; } { if ( rtDW .
kefwpubmhm . AQHandles ) { sdiTerminateStreaming ( & rtDW . kefwpubmhm .
AQHandles ) ; } } { if ( rtDW . pvibdkum0b . AQHandles ) {
sdiTerminateStreaming ( & rtDW . pvibdkum0b . AQHandles ) ; } } { if ( rtDW .
a1aeuz3o44 . AQHandles ) { sdiTerminateStreaming ( & rtDW . a1aeuz3o44 .
AQHandles ) ; } } { if ( rtDW . m5pgrgp4cg . AQHandles ) {
sdiTerminateStreaming ( & rtDW . m5pgrgp4cg . AQHandles ) ; } } { if ( rtDW .
oee5uekymg . AQHandles ) { sdiTerminateStreaming ( & rtDW . oee5uekymg .
AQHandles ) ; } } { if ( rtDW . jrgeolpedl . AQHandles ) {
sdiTerminateStreaming ( & rtDW . jrgeolpedl . AQHandles ) ; } } { if ( rtDW .
l4br0owshy . AQHandles ) { sdiTerminateStreaming ( & rtDW . l4br0owshy .
AQHandles ) ; } } { if ( rtDW . eqbzffk253 . AQHandles ) {
sdiTerminateStreaming ( & rtDW . eqbzffk253 . AQHandles ) ; } } { if ( rtDW .
m1fwuqpiaf . AQHandles ) { sdiTerminateStreaming ( & rtDW . m1fwuqpiaf .
AQHandles ) ; } } } static void mr_activeBalancing3_cacheDataAsMxArray (
mxArray * destArray , mwIndex i , int j , const void * srcData , size_t
numBytes ) ; static void mr_activeBalancing3_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) {
mxArray * newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void mr_activeBalancing3_restoreDataFromMxArray (
void * destData , const mxArray * srcArray , mwIndex i , int j , size_t
numBytes ) ; static void mr_activeBalancing3_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) {
memcpy ( ( uint8_T * ) destData , ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) , numBytes ) ; } static void
mr_activeBalancing3_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) ; static void
mr_activeBalancing3_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_activeBalancing3_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_activeBalancing3_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_activeBalancing3_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_activeBalancing3_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_activeBalancing3_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void mr_activeBalancing3_restoreDataFromMxArrayWithOffset
( void * destData , const mxArray * srcArray , mwIndex i , int j , mwIndex
offset , size_t numBytes ) { const uint8_T * varData = ( const uint8_T * )
mxGetData ( mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T *
) destData , ( const uint8_T * ) & varData [ offset * numBytes ] , numBytes )
; } static void mr_activeBalancing3_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void mr_activeBalancing3_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
{ mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_activeBalancing3_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_activeBalancing3_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_activeBalancing3_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "rtB" , "rtDW" , "rtPrevZCX" , }
; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_activeBalancing3_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & (
rtB ) , sizeof ( rtB ) ) ; { static const char * rtdwDataFieldNames [ 142 ] =
{ "rtDW.mwtjai2xzq" , "rtDW.abnasr53i2" , "rtDW.puhqb53xlf" ,
"rtDW.cgtn4vtk4v" , "rtDW.e5chgaqzdi" , "rtDW.br1vosysg0" , "rtDW.bw2f200uhe"
, "rtDW.h1kn4wxczz" , "rtDW.fwi0pu3glv" , "rtDW.m35jm4htkc" ,
"rtDW.ep01khxy3s" , "rtDW.fnsfdleb5s" , "rtDW.mg0udjzg3z" , "rtDW.esnkvscczq"
, "rtDW.o2neiszzpu" , "rtDW.h21d2fqnwl" , "rtDW.f4vpteq14c" ,
"rtDW.mlaq1sf05w" , "rtDW.imnddva2yd" , "rtDW.bv3ta2c31d" , "rtDW.gvyq4tdih4"
, "rtDW.cukktpbdau" , "rtDW.hwclgprvm0" , "rtDW.nlleqzlpac" ,
"rtDW.h0ir15tiwo" , "rtDW.dp1esyh3gc" , "rtDW.dul0uayr5l" , "rtDW.mk2k513iba"
, "rtDW.gil1dfunsb" , "rtDW.oxz1dp4rtp" , "rtDW.i4itkhygug" ,
"rtDW.fzl1x30105" , "rtDW.kuacjottby" , "rtDW.dtdzggbusy" , "rtDW.pipgbkjgsg"
, "rtDW.mjabmoou2z" , "rtDW.apw4epat2u" , "rtDW.fid4f0juyg" ,
"rtDW.a12tj2tqvt" , "rtDW.lb53h134aw" , "rtDW.badooczfnm" , "rtDW.ndyjjzoyah"
, "rtDW.iv0bm1cwdz" , "rtDW.pngsgibtfq" , "rtDW.ewtqwav4k3" ,
"rtDW.cbhsw3xyhw" , "rtDW.g5hpe50c5f" , "rtDW.nfdtmpqmjl" , "rtDW.gxhonuhkhs"
, "rtDW.blabp2utic" , "rtDW.hdt4znz2bx" , "rtDW.imyqo2srel" ,
"rtDW.c3pj1kxqrj" , "rtDW.py5uw1xsam" , "rtDW.o2st5ljikx" , "rtDW.cqvf2g25lz"
, "rtDW.h4owravycx" , "rtDW.dgvo4khvek" , "rtDW.ehr4lffvuj" ,
"rtDW.pavtbhl4x1" , "rtDW.ctdq2e5yzh" , "rtDW.eucrjtmh5k" , "rtDW.ev0agwtynm"
, "rtDW.lg5hzw2ze0" , "rtDW.gglvg5yhwg" , "rtDW.bhkajjcc0s" ,
"rtDW.bw1ne04erh" , "rtDW.lk5j3i1cks" , "rtDW.oemcgetehw" , "rtDW.mcoopbxhas"
, "rtDW.hfhq12age4" , "rtDW.odkj4eftfi" , "rtDW.mlgiqc4qhd" ,
"rtDW.o4yhobhacw" , "rtDW.b4xvp05dsp" , "rtDW.obaqwkwqid" , "rtDW.kqhwhpbc2l"
, "rtDW.lptbui3bdr" , "rtDW.hz3s4vrezj" , "rtDW.dhbq4fq1y5" ,
"rtDW.gwmmodqfqo" , "rtDW.flqyr4ponx" , "rtDW.drp1pdx1o2" , "rtDW.mwzj54zeve"
, "rtDW.gh40xceltm" , "rtDW.hxqj0wmr1s" , "rtDW.ayf5sqzvgu" ,
"rtDW.hsuqfg2xm4" , "rtDW.aeubopidzx" , "rtDW.jlwexkwoi3" , "rtDW.nxd2nqjick"
, "rtDW.nkllg3btfs" , "rtDW.hxobozywci" , "rtDW.abeepxeuaz" ,
"rtDW.fsznzndz1h" , "rtDW.pnxsmfjtjg" , "rtDW.kvk4rwajxg" , "rtDW.paol22gume"
, "rtDW.nzxxvc5aaq" , "rtDW.azkim3bav2" , "rtDW.fbtobfkzln" ,
"rtDW.ds2iyglcuj" , "rtDW.gv2gxwgcyr" , "rtDW.og2ibrr5dj" , "rtDW.podpzxkpcc"
, "rtDW.gorulf3t0p" , "rtDW.flctwqyusi" , "rtDW.bshhfd5mls" ,
"rtDW.g11vzlfqpn" , "rtDW.e4xlinrnnb" , "rtDW.bct0r40oxs" , "rtDW.ezdcqawxtb"
, "rtDW.lh3hvz10l4" , "rtDW.b0t15mq1oh" , "rtDW.dx31ootphe" ,
"rtDW.lbbdcegp5z" , "rtDW.cj1yejiuj0" , "rtDW.potnbsja2x" , "rtDW.hyvrqtp0nq"
, "rtDW.f4jvehgaau" , "rtDW.fatdrnikff" , "rtDW.dz22xyy0n2" ,
"rtDW.oklojozd5l" , "rtDW.gutf54om0t" , "rtDW.awriz1pum1" , "rtDW.hwlma5twap"
, "rtDW.lkdrn04ha3" , "rtDW.n2wn2lgi4k" , "rtDW.lptg51m4go" ,
"rtDW.c4mx45ei5j" , "rtDW.cwj4t5csvl" , "rtDW.cgi440wi10" , "rtDW.nqrddpnaqi"
, "rtDW.lvplimut2k" , "rtDW.b45hsrgxk4" , "rtDW.ff0qbzbocl" ,
"rtDW.j553vsqqsn" , "rtDW.kevb4e4jpg" , "rtDW.d0uk2u5ily" , "rtDW.opghe0hhiz"
, "rtDW.hykritwrbg" , "rtDW.aznjkggrjt" , } ; mxArray * rtdwData =
mxCreateStructMatrix ( 1 , 1 , 142 , rtdwDataFieldNames ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 0 , ( const void * )
& ( rtDW . mwtjai2xzq ) , sizeof ( rtDW . mwtjai2xzq ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 1 , ( const void * )
& ( rtDW . abnasr53i2 ) , sizeof ( rtDW . abnasr53i2 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const void * )
& ( rtDW . puhqb53xlf ) , sizeof ( rtDW . puhqb53xlf ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const void * )
& ( rtDW . cgtn4vtk4v ) , sizeof ( rtDW . cgtn4vtk4v ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const void * )
& ( rtDW . e5chgaqzdi ) , sizeof ( rtDW . e5chgaqzdi ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const void * )
& ( rtDW . br1vosysg0 ) , sizeof ( rtDW . br1vosysg0 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const void * )
& ( rtDW . bw2f200uhe ) , sizeof ( rtDW . bw2f200uhe ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const void * )
& ( rtDW . h1kn4wxczz ) , sizeof ( rtDW . h1kn4wxczz ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 8 , ( const void * )
& ( rtDW . fwi0pu3glv ) , sizeof ( rtDW . fwi0pu3glv ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 9 , ( const void * )
& ( rtDW . m35jm4htkc ) , sizeof ( rtDW . m35jm4htkc ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 10 , ( const void * )
& ( rtDW . ep01khxy3s ) , sizeof ( rtDW . ep01khxy3s ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 11 , ( const void * )
& ( rtDW . fnsfdleb5s ) , sizeof ( rtDW . fnsfdleb5s ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 12 , ( const void * )
& ( rtDW . mg0udjzg3z ) , sizeof ( rtDW . mg0udjzg3z ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 13 , ( const void * )
& ( rtDW . esnkvscczq ) , sizeof ( rtDW . esnkvscczq ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 14 , ( const void * )
& ( rtDW . o2neiszzpu ) , sizeof ( rtDW . o2neiszzpu ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 15 , ( const void * )
& ( rtDW . h21d2fqnwl ) , sizeof ( rtDW . h21d2fqnwl ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 16 , ( const void * )
& ( rtDW . f4vpteq14c ) , sizeof ( rtDW . f4vpteq14c ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 17 , ( const void * )
& ( rtDW . mlaq1sf05w ) , sizeof ( rtDW . mlaq1sf05w ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 18 , ( const void * )
& ( rtDW . imnddva2yd ) , sizeof ( rtDW . imnddva2yd ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 19 , ( const void * )
& ( rtDW . bv3ta2c31d ) , sizeof ( rtDW . bv3ta2c31d ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 20 , ( const void * )
& ( rtDW . gvyq4tdih4 ) , sizeof ( rtDW . gvyq4tdih4 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 21 , ( const void * )
& ( rtDW . cukktpbdau ) , sizeof ( rtDW . cukktpbdau ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 22 , ( const void * )
& ( rtDW . hwclgprvm0 ) , sizeof ( rtDW . hwclgprvm0 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 23 , ( const void * )
& ( rtDW . nlleqzlpac ) , sizeof ( rtDW . nlleqzlpac ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 24 , ( const void * )
& ( rtDW . h0ir15tiwo ) , sizeof ( rtDW . h0ir15tiwo ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 25 , ( const void * )
& ( rtDW . dp1esyh3gc ) , sizeof ( rtDW . dp1esyh3gc ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 26 , ( const void * )
& ( rtDW . dul0uayr5l ) , sizeof ( rtDW . dul0uayr5l ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 27 , ( const void * )
& ( rtDW . mk2k513iba ) , sizeof ( rtDW . mk2k513iba ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 28 , ( const void * )
& ( rtDW . gil1dfunsb ) , sizeof ( rtDW . gil1dfunsb ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 29 , ( const void * )
& ( rtDW . oxz1dp4rtp ) , sizeof ( rtDW . oxz1dp4rtp ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 30 , ( const void * )
& ( rtDW . i4itkhygug ) , sizeof ( rtDW . i4itkhygug ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 31 , ( const void * )
& ( rtDW . fzl1x30105 ) , sizeof ( rtDW . fzl1x30105 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 32 , ( const void * )
& ( rtDW . kuacjottby ) , sizeof ( rtDW . kuacjottby ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 33 , ( const void * )
& ( rtDW . dtdzggbusy ) , sizeof ( rtDW . dtdzggbusy ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 34 , ( const void * )
& ( rtDW . pipgbkjgsg ) , sizeof ( rtDW . pipgbkjgsg ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 35 , ( const void * )
& ( rtDW . mjabmoou2z ) , sizeof ( rtDW . mjabmoou2z ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 36 , ( const void * )
& ( rtDW . apw4epat2u ) , sizeof ( rtDW . apw4epat2u ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 37 , ( const void * )
& ( rtDW . fid4f0juyg ) , sizeof ( rtDW . fid4f0juyg ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 38 , ( const void * )
& ( rtDW . a12tj2tqvt ) , sizeof ( rtDW . a12tj2tqvt ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 39 , ( const void * )
& ( rtDW . lb53h134aw ) , sizeof ( rtDW . lb53h134aw ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 40 , ( const void * )
& ( rtDW . badooczfnm ) , sizeof ( rtDW . badooczfnm ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 41 , ( const void * )
& ( rtDW . ndyjjzoyah ) , sizeof ( rtDW . ndyjjzoyah ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 42 , ( const void * )
& ( rtDW . iv0bm1cwdz ) , sizeof ( rtDW . iv0bm1cwdz ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 43 , ( const void * )
& ( rtDW . pngsgibtfq ) , sizeof ( rtDW . pngsgibtfq ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 44 , ( const void * )
& ( rtDW . ewtqwav4k3 ) , sizeof ( rtDW . ewtqwav4k3 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 45 , ( const void * )
& ( rtDW . cbhsw3xyhw ) , sizeof ( rtDW . cbhsw3xyhw ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 46 , ( const void * )
& ( rtDW . g5hpe50c5f ) , sizeof ( rtDW . g5hpe50c5f ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 47 , ( const void * )
& ( rtDW . nfdtmpqmjl ) , sizeof ( rtDW . nfdtmpqmjl ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 48 , ( const void * )
& ( rtDW . gxhonuhkhs ) , sizeof ( rtDW . gxhonuhkhs ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 49 , ( const void * )
& ( rtDW . blabp2utic ) , sizeof ( rtDW . blabp2utic ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 50 , ( const void * )
& ( rtDW . hdt4znz2bx ) , sizeof ( rtDW . hdt4znz2bx ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 51 , ( const void * )
& ( rtDW . imyqo2srel ) , sizeof ( rtDW . imyqo2srel ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 52 , ( const void * )
& ( rtDW . c3pj1kxqrj ) , sizeof ( rtDW . c3pj1kxqrj ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 53 , ( const void * )
& ( rtDW . py5uw1xsam ) , sizeof ( rtDW . py5uw1xsam ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 54 , ( const void * )
& ( rtDW . o2st5ljikx ) , sizeof ( rtDW . o2st5ljikx ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 55 , ( const void * )
& ( rtDW . cqvf2g25lz ) , sizeof ( rtDW . cqvf2g25lz ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 56 , ( const void * )
& ( rtDW . h4owravycx ) , sizeof ( rtDW . h4owravycx ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 57 , ( const void * )
& ( rtDW . dgvo4khvek ) , sizeof ( rtDW . dgvo4khvek ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 58 , ( const void * )
& ( rtDW . ehr4lffvuj ) , sizeof ( rtDW . ehr4lffvuj ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 59 , ( const void * )
& ( rtDW . pavtbhl4x1 ) , sizeof ( rtDW . pavtbhl4x1 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 60 , ( const void * )
& ( rtDW . ctdq2e5yzh ) , sizeof ( rtDW . ctdq2e5yzh ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 61 , ( const void * )
& ( rtDW . eucrjtmh5k ) , sizeof ( rtDW . eucrjtmh5k ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 62 , ( const void * )
& ( rtDW . ev0agwtynm ) , sizeof ( rtDW . ev0agwtynm ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 63 , ( const void * )
& ( rtDW . lg5hzw2ze0 ) , sizeof ( rtDW . lg5hzw2ze0 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 64 , ( const void * )
& ( rtDW . gglvg5yhwg ) , sizeof ( rtDW . gglvg5yhwg ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 65 , ( const void * )
& ( rtDW . bhkajjcc0s ) , sizeof ( rtDW . bhkajjcc0s ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 66 , ( const void * )
& ( rtDW . bw1ne04erh ) , sizeof ( rtDW . bw1ne04erh ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 67 , ( const void * )
& ( rtDW . lk5j3i1cks ) , sizeof ( rtDW . lk5j3i1cks ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 68 , ( const void * )
& ( rtDW . oemcgetehw ) , sizeof ( rtDW . oemcgetehw ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 69 , ( const void * )
& ( rtDW . mcoopbxhas ) , sizeof ( rtDW . mcoopbxhas ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 70 , ( const void * )
& ( rtDW . hfhq12age4 ) , sizeof ( rtDW . hfhq12age4 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 71 , ( const void * )
& ( rtDW . odkj4eftfi ) , sizeof ( rtDW . odkj4eftfi ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 72 , ( const void * )
& ( rtDW . mlgiqc4qhd ) , sizeof ( rtDW . mlgiqc4qhd ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 73 , ( const void * )
& ( rtDW . o4yhobhacw ) , sizeof ( rtDW . o4yhobhacw ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 74 , ( const void * )
& ( rtDW . b4xvp05dsp ) , sizeof ( rtDW . b4xvp05dsp ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 75 , ( const void * )
& ( rtDW . obaqwkwqid ) , sizeof ( rtDW . obaqwkwqid ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 76 , ( const void * )
& ( rtDW . kqhwhpbc2l ) , sizeof ( rtDW . kqhwhpbc2l ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 77 , ( const void * )
& ( rtDW . lptbui3bdr ) , sizeof ( rtDW . lptbui3bdr ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 78 , ( const void * )
& ( rtDW . hz3s4vrezj ) , sizeof ( rtDW . hz3s4vrezj ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 79 , ( const void * )
& ( rtDW . dhbq4fq1y5 ) , sizeof ( rtDW . dhbq4fq1y5 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 80 , ( const void * )
& ( rtDW . gwmmodqfqo ) , sizeof ( rtDW . gwmmodqfqo ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 81 , ( const void * )
& ( rtDW . flqyr4ponx ) , sizeof ( rtDW . flqyr4ponx ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 82 , ( const void * )
& ( rtDW . drp1pdx1o2 ) , sizeof ( rtDW . drp1pdx1o2 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 83 , ( const void * )
& ( rtDW . mwzj54zeve ) , sizeof ( rtDW . mwzj54zeve ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 84 , ( const void * )
& ( rtDW . gh40xceltm ) , sizeof ( rtDW . gh40xceltm ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 85 , ( const void * )
& ( rtDW . hxqj0wmr1s ) , sizeof ( rtDW . hxqj0wmr1s ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 86 , ( const void * )
& ( rtDW . ayf5sqzvgu ) , sizeof ( rtDW . ayf5sqzvgu ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 87 , ( const void * )
& ( rtDW . hsuqfg2xm4 ) , sizeof ( rtDW . hsuqfg2xm4 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 88 , ( const void * )
& ( rtDW . aeubopidzx ) , sizeof ( rtDW . aeubopidzx ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 89 , ( const void * )
& ( rtDW . jlwexkwoi3 ) , sizeof ( rtDW . jlwexkwoi3 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 90 , ( const void * )
& ( rtDW . nxd2nqjick ) , sizeof ( rtDW . nxd2nqjick ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 91 , ( const void * )
& ( rtDW . nkllg3btfs ) , sizeof ( rtDW . nkllg3btfs ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 92 , ( const void * )
& ( rtDW . hxobozywci ) , sizeof ( rtDW . hxobozywci ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 93 , ( const void * )
& ( rtDW . abeepxeuaz ) , sizeof ( rtDW . abeepxeuaz ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 94 , ( const void * )
& ( rtDW . fsznzndz1h ) , sizeof ( rtDW . fsznzndz1h ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 95 , ( const void * )
& ( rtDW . pnxsmfjtjg ) , sizeof ( rtDW . pnxsmfjtjg ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 96 , ( const void * )
& ( rtDW . kvk4rwajxg ) , sizeof ( rtDW . kvk4rwajxg ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 97 , ( const void * )
& ( rtDW . paol22gume ) , sizeof ( rtDW . paol22gume ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 98 , ( const void * )
& ( rtDW . nzxxvc5aaq ) , sizeof ( rtDW . nzxxvc5aaq ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 99 , ( const void * )
& ( rtDW . azkim3bav2 ) , sizeof ( rtDW . azkim3bav2 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 100 , ( const void *
) & ( rtDW . fbtobfkzln ) , sizeof ( rtDW . fbtobfkzln ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 101 , ( const void *
) & ( rtDW . ds2iyglcuj ) , sizeof ( rtDW . ds2iyglcuj ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 102 , ( const void *
) & ( rtDW . gv2gxwgcyr ) , sizeof ( rtDW . gv2gxwgcyr ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 103 , ( const void *
) & ( rtDW . og2ibrr5dj ) , sizeof ( rtDW . og2ibrr5dj ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 104 , ( const void *
) & ( rtDW . podpzxkpcc ) , sizeof ( rtDW . podpzxkpcc ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 105 , ( const void *
) & ( rtDW . gorulf3t0p ) , sizeof ( rtDW . gorulf3t0p ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 106 , ( const void *
) & ( rtDW . flctwqyusi ) , sizeof ( rtDW . flctwqyusi ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 107 , ( const void *
) & ( rtDW . bshhfd5mls ) , sizeof ( rtDW . bshhfd5mls ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 108 , ( const void *
) & ( rtDW . g11vzlfqpn ) , sizeof ( rtDW . g11vzlfqpn ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 109 , ( const void *
) & ( rtDW . e4xlinrnnb ) , sizeof ( rtDW . e4xlinrnnb ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 110 , ( const void *
) & ( rtDW . bct0r40oxs ) , sizeof ( rtDW . bct0r40oxs ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 111 , ( const void *
) & ( rtDW . ezdcqawxtb ) , sizeof ( rtDW . ezdcqawxtb ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 112 , ( const void *
) & ( rtDW . lh3hvz10l4 ) , sizeof ( rtDW . lh3hvz10l4 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 113 , ( const void *
) & ( rtDW . b0t15mq1oh ) , sizeof ( rtDW . b0t15mq1oh ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 114 , ( const void *
) & ( rtDW . dx31ootphe ) , sizeof ( rtDW . dx31ootphe ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 115 , ( const void *
) & ( rtDW . lbbdcegp5z ) , sizeof ( rtDW . lbbdcegp5z ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 116 , ( const void *
) & ( rtDW . cj1yejiuj0 ) , sizeof ( rtDW . cj1yejiuj0 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 117 , ( const void *
) & ( rtDW . potnbsja2x ) , sizeof ( rtDW . potnbsja2x ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 118 , ( const void *
) & ( rtDW . hyvrqtp0nq ) , sizeof ( rtDW . hyvrqtp0nq ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 119 , ( const void *
) & ( rtDW . f4jvehgaau ) , sizeof ( rtDW . f4jvehgaau ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 120 , ( const void *
) & ( rtDW . fatdrnikff ) , sizeof ( rtDW . fatdrnikff ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 121 , ( const void *
) & ( rtDW . dz22xyy0n2 ) , sizeof ( rtDW . dz22xyy0n2 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 122 , ( const void *
) & ( rtDW . oklojozd5l ) , sizeof ( rtDW . oklojozd5l ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 123 , ( const void *
) & ( rtDW . gutf54om0t ) , sizeof ( rtDW . gutf54om0t ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 124 , ( const void *
) & ( rtDW . awriz1pum1 ) , sizeof ( rtDW . awriz1pum1 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 125 , ( const void *
) & ( rtDW . hwlma5twap ) , sizeof ( rtDW . hwlma5twap ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 126 , ( const void *
) & ( rtDW . lkdrn04ha3 ) , sizeof ( rtDW . lkdrn04ha3 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 127 , ( const void *
) & ( rtDW . n2wn2lgi4k ) , sizeof ( rtDW . n2wn2lgi4k ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 128 , ( const void *
) & ( rtDW . lptg51m4go ) , sizeof ( rtDW . lptg51m4go ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 129 , ( const void *
) & ( rtDW . c4mx45ei5j ) , sizeof ( rtDW . c4mx45ei5j ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 130 , ( const void *
) & ( rtDW . cwj4t5csvl ) , sizeof ( rtDW . cwj4t5csvl ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 131 , ( const void *
) & ( rtDW . cgi440wi10 ) , sizeof ( rtDW . cgi440wi10 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 132 , ( const void *
) & ( rtDW . nqrddpnaqi ) , sizeof ( rtDW . nqrddpnaqi ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 133 , ( const void *
) & ( rtDW . lvplimut2k ) , sizeof ( rtDW . lvplimut2k ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 134 , ( const void *
) & ( rtDW . b45hsrgxk4 ) , sizeof ( rtDW . b45hsrgxk4 ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 135 , ( const void *
) & ( rtDW . ff0qbzbocl ) , sizeof ( rtDW . ff0qbzbocl ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 136 , ( const void *
) & ( rtDW . j553vsqqsn ) , sizeof ( rtDW . j553vsqqsn ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 137 , ( const void *
) & ( rtDW . kevb4e4jpg ) , sizeof ( rtDW . kevb4e4jpg ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 138 , ( const void *
) & ( rtDW . d0uk2u5ily ) , sizeof ( rtDW . d0uk2u5ily ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 139 , ( const void *
) & ( rtDW . opghe0hhiz ) , sizeof ( rtDW . opghe0hhiz ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 140 , ( const void *
) & ( rtDW . hykritwrbg ) , sizeof ( rtDW . hykritwrbg ) ) ;
mr_activeBalancing3_cacheDataAsMxArray ( rtdwData , 0 , 141 , ( const void *
) & ( rtDW . aznjkggrjt ) , sizeof ( rtDW . aznjkggrjt ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; }
mr_activeBalancing3_cacheDataAsMxArray ( ssDW , 0 , 2 , ( const void * ) & (
rtPrevZCX ) , sizeof ( rtPrevZCX ) ) ; return ssDW ; } void
mr_activeBalancing3_SetDWork ( const mxArray * ssDW ) { ( void ) ssDW ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtB ) , ssDW , 0
, 0 , sizeof ( rtB ) ) ; { const mxArray * rtdwData = mxGetFieldByNumber (
ssDW , 0 , 1 ) ; mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & (
rtDW . mwtjai2xzq ) , rtdwData , 0 , 0 , sizeof ( rtDW . mwtjai2xzq ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . abnasr53i2
) , rtdwData , 0 , 1 , sizeof ( rtDW . abnasr53i2 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . puhqb53xlf
) , rtdwData , 0 , 2 , sizeof ( rtDW . puhqb53xlf ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . cgtn4vtk4v
) , rtdwData , 0 , 3 , sizeof ( rtDW . cgtn4vtk4v ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . e5chgaqzdi
) , rtdwData , 0 , 4 , sizeof ( rtDW . e5chgaqzdi ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . br1vosysg0
) , rtdwData , 0 , 5 , sizeof ( rtDW . br1vosysg0 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . bw2f200uhe
) , rtdwData , 0 , 6 , sizeof ( rtDW . bw2f200uhe ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . h1kn4wxczz
) , rtdwData , 0 , 7 , sizeof ( rtDW . h1kn4wxczz ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . fwi0pu3glv
) , rtdwData , 0 , 8 , sizeof ( rtDW . fwi0pu3glv ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . m35jm4htkc
) , rtdwData , 0 , 9 , sizeof ( rtDW . m35jm4htkc ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ep01khxy3s
) , rtdwData , 0 , 10 , sizeof ( rtDW . ep01khxy3s ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . fnsfdleb5s
) , rtdwData , 0 , 11 , sizeof ( rtDW . fnsfdleb5s ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . mg0udjzg3z
) , rtdwData , 0 , 12 , sizeof ( rtDW . mg0udjzg3z ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . esnkvscczq
) , rtdwData , 0 , 13 , sizeof ( rtDW . esnkvscczq ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . o2neiszzpu
) , rtdwData , 0 , 14 , sizeof ( rtDW . o2neiszzpu ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . h21d2fqnwl
) , rtdwData , 0 , 15 , sizeof ( rtDW . h21d2fqnwl ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . f4vpteq14c
) , rtdwData , 0 , 16 , sizeof ( rtDW . f4vpteq14c ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . mlaq1sf05w
) , rtdwData , 0 , 17 , sizeof ( rtDW . mlaq1sf05w ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . imnddva2yd
) , rtdwData , 0 , 18 , sizeof ( rtDW . imnddva2yd ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . bv3ta2c31d
) , rtdwData , 0 , 19 , sizeof ( rtDW . bv3ta2c31d ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . gvyq4tdih4
) , rtdwData , 0 , 20 , sizeof ( rtDW . gvyq4tdih4 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . cukktpbdau
) , rtdwData , 0 , 21 , sizeof ( rtDW . cukktpbdau ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hwclgprvm0
) , rtdwData , 0 , 22 , sizeof ( rtDW . hwclgprvm0 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . nlleqzlpac
) , rtdwData , 0 , 23 , sizeof ( rtDW . nlleqzlpac ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . h0ir15tiwo
) , rtdwData , 0 , 24 , sizeof ( rtDW . h0ir15tiwo ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . dp1esyh3gc
) , rtdwData , 0 , 25 , sizeof ( rtDW . dp1esyh3gc ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . dul0uayr5l
) , rtdwData , 0 , 26 , sizeof ( rtDW . dul0uayr5l ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . mk2k513iba
) , rtdwData , 0 , 27 , sizeof ( rtDW . mk2k513iba ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . gil1dfunsb
) , rtdwData , 0 , 28 , sizeof ( rtDW . gil1dfunsb ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . oxz1dp4rtp
) , rtdwData , 0 , 29 , sizeof ( rtDW . oxz1dp4rtp ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . i4itkhygug
) , rtdwData , 0 , 30 , sizeof ( rtDW . i4itkhygug ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . fzl1x30105
) , rtdwData , 0 , 31 , sizeof ( rtDW . fzl1x30105 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . kuacjottby
) , rtdwData , 0 , 32 , sizeof ( rtDW . kuacjottby ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . dtdzggbusy
) , rtdwData , 0 , 33 , sizeof ( rtDW . dtdzggbusy ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . pipgbkjgsg
) , rtdwData , 0 , 34 , sizeof ( rtDW . pipgbkjgsg ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . mjabmoou2z
) , rtdwData , 0 , 35 , sizeof ( rtDW . mjabmoou2z ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . apw4epat2u
) , rtdwData , 0 , 36 , sizeof ( rtDW . apw4epat2u ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . fid4f0juyg
) , rtdwData , 0 , 37 , sizeof ( rtDW . fid4f0juyg ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . a12tj2tqvt
) , rtdwData , 0 , 38 , sizeof ( rtDW . a12tj2tqvt ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . lb53h134aw
) , rtdwData , 0 , 39 , sizeof ( rtDW . lb53h134aw ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . badooczfnm
) , rtdwData , 0 , 40 , sizeof ( rtDW . badooczfnm ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ndyjjzoyah
) , rtdwData , 0 , 41 , sizeof ( rtDW . ndyjjzoyah ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . iv0bm1cwdz
) , rtdwData , 0 , 42 , sizeof ( rtDW . iv0bm1cwdz ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . pngsgibtfq
) , rtdwData , 0 , 43 , sizeof ( rtDW . pngsgibtfq ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ewtqwav4k3
) , rtdwData , 0 , 44 , sizeof ( rtDW . ewtqwav4k3 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . cbhsw3xyhw
) , rtdwData , 0 , 45 , sizeof ( rtDW . cbhsw3xyhw ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . g5hpe50c5f
) , rtdwData , 0 , 46 , sizeof ( rtDW . g5hpe50c5f ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . nfdtmpqmjl
) , rtdwData , 0 , 47 , sizeof ( rtDW . nfdtmpqmjl ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . gxhonuhkhs
) , rtdwData , 0 , 48 , sizeof ( rtDW . gxhonuhkhs ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . blabp2utic
) , rtdwData , 0 , 49 , sizeof ( rtDW . blabp2utic ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hdt4znz2bx
) , rtdwData , 0 , 50 , sizeof ( rtDW . hdt4znz2bx ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . imyqo2srel
) , rtdwData , 0 , 51 , sizeof ( rtDW . imyqo2srel ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . c3pj1kxqrj
) , rtdwData , 0 , 52 , sizeof ( rtDW . c3pj1kxqrj ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . py5uw1xsam
) , rtdwData , 0 , 53 , sizeof ( rtDW . py5uw1xsam ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . o2st5ljikx
) , rtdwData , 0 , 54 , sizeof ( rtDW . o2st5ljikx ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . cqvf2g25lz
) , rtdwData , 0 , 55 , sizeof ( rtDW . cqvf2g25lz ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . h4owravycx
) , rtdwData , 0 , 56 , sizeof ( rtDW . h4owravycx ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . dgvo4khvek
) , rtdwData , 0 , 57 , sizeof ( rtDW . dgvo4khvek ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ehr4lffvuj
) , rtdwData , 0 , 58 , sizeof ( rtDW . ehr4lffvuj ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . pavtbhl4x1
) , rtdwData , 0 , 59 , sizeof ( rtDW . pavtbhl4x1 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ctdq2e5yzh
) , rtdwData , 0 , 60 , sizeof ( rtDW . ctdq2e5yzh ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . eucrjtmh5k
) , rtdwData , 0 , 61 , sizeof ( rtDW . eucrjtmh5k ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ev0agwtynm
) , rtdwData , 0 , 62 , sizeof ( rtDW . ev0agwtynm ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . lg5hzw2ze0
) , rtdwData , 0 , 63 , sizeof ( rtDW . lg5hzw2ze0 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . gglvg5yhwg
) , rtdwData , 0 , 64 , sizeof ( rtDW . gglvg5yhwg ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . bhkajjcc0s
) , rtdwData , 0 , 65 , sizeof ( rtDW . bhkajjcc0s ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . bw1ne04erh
) , rtdwData , 0 , 66 , sizeof ( rtDW . bw1ne04erh ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . lk5j3i1cks
) , rtdwData , 0 , 67 , sizeof ( rtDW . lk5j3i1cks ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . oemcgetehw
) , rtdwData , 0 , 68 , sizeof ( rtDW . oemcgetehw ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . mcoopbxhas
) , rtdwData , 0 , 69 , sizeof ( rtDW . mcoopbxhas ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hfhq12age4
) , rtdwData , 0 , 70 , sizeof ( rtDW . hfhq12age4 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . odkj4eftfi
) , rtdwData , 0 , 71 , sizeof ( rtDW . odkj4eftfi ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . mlgiqc4qhd
) , rtdwData , 0 , 72 , sizeof ( rtDW . mlgiqc4qhd ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . o4yhobhacw
) , rtdwData , 0 , 73 , sizeof ( rtDW . o4yhobhacw ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . b4xvp05dsp
) , rtdwData , 0 , 74 , sizeof ( rtDW . b4xvp05dsp ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . obaqwkwqid
) , rtdwData , 0 , 75 , sizeof ( rtDW . obaqwkwqid ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . kqhwhpbc2l
) , rtdwData , 0 , 76 , sizeof ( rtDW . kqhwhpbc2l ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . lptbui3bdr
) , rtdwData , 0 , 77 , sizeof ( rtDW . lptbui3bdr ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hz3s4vrezj
) , rtdwData , 0 , 78 , sizeof ( rtDW . hz3s4vrezj ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . dhbq4fq1y5
) , rtdwData , 0 , 79 , sizeof ( rtDW . dhbq4fq1y5 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . gwmmodqfqo
) , rtdwData , 0 , 80 , sizeof ( rtDW . gwmmodqfqo ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . flqyr4ponx
) , rtdwData , 0 , 81 , sizeof ( rtDW . flqyr4ponx ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . drp1pdx1o2
) , rtdwData , 0 , 82 , sizeof ( rtDW . drp1pdx1o2 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . mwzj54zeve
) , rtdwData , 0 , 83 , sizeof ( rtDW . mwzj54zeve ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . gh40xceltm
) , rtdwData , 0 , 84 , sizeof ( rtDW . gh40xceltm ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hxqj0wmr1s
) , rtdwData , 0 , 85 , sizeof ( rtDW . hxqj0wmr1s ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ayf5sqzvgu
) , rtdwData , 0 , 86 , sizeof ( rtDW . ayf5sqzvgu ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hsuqfg2xm4
) , rtdwData , 0 , 87 , sizeof ( rtDW . hsuqfg2xm4 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . aeubopidzx
) , rtdwData , 0 , 88 , sizeof ( rtDW . aeubopidzx ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . jlwexkwoi3
) , rtdwData , 0 , 89 , sizeof ( rtDW . jlwexkwoi3 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . nxd2nqjick
) , rtdwData , 0 , 90 , sizeof ( rtDW . nxd2nqjick ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . nkllg3btfs
) , rtdwData , 0 , 91 , sizeof ( rtDW . nkllg3btfs ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hxobozywci
) , rtdwData , 0 , 92 , sizeof ( rtDW . hxobozywci ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . abeepxeuaz
) , rtdwData , 0 , 93 , sizeof ( rtDW . abeepxeuaz ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . fsznzndz1h
) , rtdwData , 0 , 94 , sizeof ( rtDW . fsznzndz1h ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . pnxsmfjtjg
) , rtdwData , 0 , 95 , sizeof ( rtDW . pnxsmfjtjg ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . kvk4rwajxg
) , rtdwData , 0 , 96 , sizeof ( rtDW . kvk4rwajxg ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . paol22gume
) , rtdwData , 0 , 97 , sizeof ( rtDW . paol22gume ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . nzxxvc5aaq
) , rtdwData , 0 , 98 , sizeof ( rtDW . nzxxvc5aaq ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . azkim3bav2
) , rtdwData , 0 , 99 , sizeof ( rtDW . azkim3bav2 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . fbtobfkzln
) , rtdwData , 0 , 100 , sizeof ( rtDW . fbtobfkzln ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ds2iyglcuj
) , rtdwData , 0 , 101 , sizeof ( rtDW . ds2iyglcuj ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . gv2gxwgcyr
) , rtdwData , 0 , 102 , sizeof ( rtDW . gv2gxwgcyr ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . og2ibrr5dj
) , rtdwData , 0 , 103 , sizeof ( rtDW . og2ibrr5dj ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . podpzxkpcc
) , rtdwData , 0 , 104 , sizeof ( rtDW . podpzxkpcc ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . gorulf3t0p
) , rtdwData , 0 , 105 , sizeof ( rtDW . gorulf3t0p ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . flctwqyusi
) , rtdwData , 0 , 106 , sizeof ( rtDW . flctwqyusi ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . bshhfd5mls
) , rtdwData , 0 , 107 , sizeof ( rtDW . bshhfd5mls ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . g11vzlfqpn
) , rtdwData , 0 , 108 , sizeof ( rtDW . g11vzlfqpn ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . e4xlinrnnb
) , rtdwData , 0 , 109 , sizeof ( rtDW . e4xlinrnnb ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . bct0r40oxs
) , rtdwData , 0 , 110 , sizeof ( rtDW . bct0r40oxs ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ezdcqawxtb
) , rtdwData , 0 , 111 , sizeof ( rtDW . ezdcqawxtb ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . lh3hvz10l4
) , rtdwData , 0 , 112 , sizeof ( rtDW . lh3hvz10l4 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . b0t15mq1oh
) , rtdwData , 0 , 113 , sizeof ( rtDW . b0t15mq1oh ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . dx31ootphe
) , rtdwData , 0 , 114 , sizeof ( rtDW . dx31ootphe ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . lbbdcegp5z
) , rtdwData , 0 , 115 , sizeof ( rtDW . lbbdcegp5z ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . cj1yejiuj0
) , rtdwData , 0 , 116 , sizeof ( rtDW . cj1yejiuj0 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . potnbsja2x
) , rtdwData , 0 , 117 , sizeof ( rtDW . potnbsja2x ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hyvrqtp0nq
) , rtdwData , 0 , 118 , sizeof ( rtDW . hyvrqtp0nq ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . f4jvehgaau
) , rtdwData , 0 , 119 , sizeof ( rtDW . f4jvehgaau ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . fatdrnikff
) , rtdwData , 0 , 120 , sizeof ( rtDW . fatdrnikff ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . dz22xyy0n2
) , rtdwData , 0 , 121 , sizeof ( rtDW . dz22xyy0n2 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . oklojozd5l
) , rtdwData , 0 , 122 , sizeof ( rtDW . oklojozd5l ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . gutf54om0t
) , rtdwData , 0 , 123 , sizeof ( rtDW . gutf54om0t ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . awriz1pum1
) , rtdwData , 0 , 124 , sizeof ( rtDW . awriz1pum1 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hwlma5twap
) , rtdwData , 0 , 125 , sizeof ( rtDW . hwlma5twap ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . lkdrn04ha3
) , rtdwData , 0 , 126 , sizeof ( rtDW . lkdrn04ha3 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . n2wn2lgi4k
) , rtdwData , 0 , 127 , sizeof ( rtDW . n2wn2lgi4k ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . lptg51m4go
) , rtdwData , 0 , 128 , sizeof ( rtDW . lptg51m4go ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . c4mx45ei5j
) , rtdwData , 0 , 129 , sizeof ( rtDW . c4mx45ei5j ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . cwj4t5csvl
) , rtdwData , 0 , 130 , sizeof ( rtDW . cwj4t5csvl ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . cgi440wi10
) , rtdwData , 0 , 131 , sizeof ( rtDW . cgi440wi10 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . nqrddpnaqi
) , rtdwData , 0 , 132 , sizeof ( rtDW . nqrddpnaqi ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . lvplimut2k
) , rtdwData , 0 , 133 , sizeof ( rtDW . lvplimut2k ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . b45hsrgxk4
) , rtdwData , 0 , 134 , sizeof ( rtDW . b45hsrgxk4 ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . ff0qbzbocl
) , rtdwData , 0 , 135 , sizeof ( rtDW . ff0qbzbocl ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . j553vsqqsn
) , rtdwData , 0 , 136 , sizeof ( rtDW . j553vsqqsn ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . kevb4e4jpg
) , rtdwData , 0 , 137 , sizeof ( rtDW . kevb4e4jpg ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . d0uk2u5ily
) , rtdwData , 0 , 138 , sizeof ( rtDW . d0uk2u5ily ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . opghe0hhiz
) , rtdwData , 0 , 139 , sizeof ( rtDW . opghe0hhiz ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . hykritwrbg
) , rtdwData , 0 , 140 , sizeof ( rtDW . hykritwrbg ) ) ;
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtDW . aznjkggrjt
) , rtdwData , 0 , 141 , sizeof ( rtDW . aznjkggrjt ) ) ; }
mr_activeBalancing3_restoreDataFromMxArray ( ( void * ) & ( rtPrevZCX ) ,
ssDW , 0 , 2 , sizeof ( rtPrevZCX ) ) ; } mxArray *
mr_activeBalancing3_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 5 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 5 ] = { "S-Function" , "Scope" , "Scope" , "Scope" ,
"S-Function" , } ; static const char * blockPath [ 5 ] = {
"activeBalancing3/powergui/EquivalentModel1/State-Space" ,
"activeBalancing3/SOC %" , "activeBalancing3/Voltage" ,
"activeBalancing3/Scope" ,
"activeBalancing3/powergui/EquivalentModel1/State-Space" , } ; static const
int reason [ 5 ] = { 0 , 0 , 0 , 0 , 2 , } ; for ( subs [ 0 ] = 0 ; subs [ 0
] < 5 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset = mxCalcSingleSubscript
( data , 2 , subs ) ; mxSetCell ( data , offset , mxCreateString ( blockType
[ subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ; offset = mxCalcSingleSubscript ( data ,
2 , subs ) ; mxSetCell ( data , offset , mxCreateString ( blockPath [ subs [
0 ] ] ) ) ; subs [ 1 ] = 2 ; offset = mxCalcSingleSubscript ( data , 2 , subs
) ; mxSetCell ( data , offset , mxCreateDoubleScalar ( ( double ) reason [
subs [ 0 ] ] ) ) ; } } return data ; } void MdlInitializeSizes ( void ) {
ssSetNumContStates ( rtS , 26 ) ; ssSetNumPeriodicContStates ( rtS , 0 ) ;
ssSetNumY ( rtS , 0 ) ; ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough ( rtS
, 0 ) ; ssSetNumSampleTimes ( rtS , 8 ) ; ssSetNumBlocks ( rtS , 780 ) ;
ssSetNumBlockIO ( rtS , 310 ) ; ssSetNumBlockParams ( rtS , 10001 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 , 0.0 ) ;
ssSetSampleTime ( rtS , 1 , 0.0 ) ; ssSetSampleTime ( rtS , 2 , - 2.0 ) ;
ssSetSampleTime ( rtS , 3 , - 2.0 ) ; ssSetSampleTime ( rtS , 4 , - 2.0 ) ;
ssSetSampleTime ( rtS , 5 , - 2.0 ) ; ssSetSampleTime ( rtS , 6 , - 2.0 ) ;
ssSetSampleTime ( rtS , 7 , - 2.0 ) ; ssSetOffsetTime ( rtS , 0 , 0.0 ) ;
ssSetOffsetTime ( rtS , 1 , 1.0 ) ; ssSetOffsetTime ( rtS , 2 , 0.0 ) ;
ssSetOffsetTime ( rtS , 3 , 1.0 ) ; ssSetOffsetTime ( rtS , 4 , 2.0 ) ;
ssSetOffsetTime ( rtS , 5 , 3.0 ) ; ssSetOffsetTime ( rtS , 6 , 4.0 ) ;
ssSetOffsetTime ( rtS , 7 , 5.0 ) ; } void raccel_set_checksum ( ) {
ssSetChecksumVal ( rtS , 0 , 1550680249U ) ; ssSetChecksumVal ( rtS , 1 ,
746654945U ) ; ssSetChecksumVal ( rtS , 2 , 2628067688U ) ; ssSetChecksumVal
( rtS , 3 , 4181925083U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; ( void ) memset ( ( char * ) rtS , 0 ,
sizeof ( SimStruct ) ) ; ( void ) memset ( ( char * ) & mdlInfo , 0 , sizeof
( struct _ssMdlInfo ) ) ; ssSetMdlInfoPtr ( rtS , & mdlInfo ) ;
ssSetExecutionInfo ( rtS , executionInfo ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; } { real_T * x = ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ;
( void ) memset ( ( void * ) x , 0 , sizeof ( X ) ) ; } { void * dwork = (
void * ) & rtDW ; ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork ,
0 , sizeof ( DW ) ) ; } { static DataTypeTransInfo dtInfo ; ( void ) memset (
( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS
, & dtInfo ) ; dtInfo . numDataTypes = 23 ; dtInfo . dataTypeSizes = &
rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = & rtDataTypeNames [ 0 ] ;
dtInfo . BTransTable = & rtBTransTable ; dtInfo . PTransTable = &
rtPTransTable ; dtInfo . dataTypeInfoTable = rtDataTypeInfoTable ; }
activeBalancing3_InitializeDataMapInfo ( ) ; ssSetIsRapidAcceleratorActive (
rtS , true ) ; ssSetRootSS ( rtS , rtS ) ; ssSetVersion ( rtS ,
SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS , "activeBalancing3" ) ;
ssSetPath ( rtS , "activeBalancing3" ) ; ssSetTStart ( rtS , 0.0 ) ;
ssSetTFinal ( rtS , 120.0 ) ; { static RTWLogInfo rt_DataLoggingInfo ;
rt_DataLoggingInfo . loggingInterval = ( NULL ) ; ssSetRTWLogInfo ( rtS , &
rt_DataLoggingInfo ) ; } { { static int_T rt_LoggedStateWidths [ ] = { 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 6 }
; static int_T rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; static int_T
rt_LoggedStateDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 6 } ; static boolean_T
rt_LoggedStateIsVarDims [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static BuiltInDTypeId
rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE } ;
static int_T rt_LoggedStateComplexSignals [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static
RTWPreprocessingFcnPtr rt_LoggingStatePreprocessingFcnPtrs [ ] = { ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) } ; static
const char_T * rt_LoggedStateLabels [ ] = { "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" } ; static const char_T *
rt_LoggedStateBlockNames [ ] = {
"activeBalancing3/Battery1/Model/Current filter" ,
"activeBalancing3/Battery1/Model/int(i)" ,
"activeBalancing3/Battery1/Model/Exp/Integrator2" ,
"activeBalancing3/Battery1/Model/BAL" ,
"activeBalancing3/Battery2/Model/Current filter" ,
"activeBalancing3/Battery2/Model/int(i)" ,
"activeBalancing3/Battery2/Model/Exp/Integrator2" ,
"activeBalancing3/Battery2/Model/BAL" ,
"activeBalancing3/Battery3/Model/Current filter" ,
"activeBalancing3/Battery3/Model/int(i)" ,
"activeBalancing3/Battery3/Model/Exp/Integrator2" ,
"activeBalancing3/Battery3/Model/BAL" ,
"activeBalancing3/Battery4/Model/Current filter" ,
"activeBalancing3/Battery4/Model/int(i)" ,
"activeBalancing3/Battery4/Model/Exp/Integrator2" ,
"activeBalancing3/Battery4/Model/BAL" ,
"activeBalancing3/Battery5/Model/Current filter" ,
"activeBalancing3/Battery5/Model/int(i)" ,
"activeBalancing3/Battery5/Model/Exp/Integrator2" ,
"activeBalancing3/Battery5/Model/BAL" ,
"activeBalancing3/powergui/EquivalentModel1/State-Space" } ; static const
char_T * rt_LoggedStateNames [ ] = { "" , "" , "" , "" , "" , "" , "" , "" ,
"" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" } ; static
boolean_T rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static
RTWLogDataTypeConvert rt_RTWLogDataTypeConvert [ ] = { { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } } ; static int_T
rt_LoggedStateIdxList [ ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 20 } ; static RTWLogSignalInfo
rt_LoggedStateSignalInfo = { 21 , rt_LoggedStateWidths ,
rt_LoggedStateNumDimensions , rt_LoggedStateDimensions ,
rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 21 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . btwaflzkr2 ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtX . cwzgk12fex ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtX . p2dwfugebo ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) & rtX . gzwgpg3i32 ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) & rtX . ieqye3wyr3 ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) & rtX . edarxfgg3m ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) & rtX . n1mefgeo42 ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) & rtX . kwkmxprem3 ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) & rtX . g0ii5xynxb ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtX . hytl13jcro ;
rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) & rtX . daazrzvjzg ;
rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtX . kmijbaomfh ;
rt_LoggedStateSignalPtrs [ 12 ] = ( void * ) & rtX . e3mceh2nlv ;
rt_LoggedStateSignalPtrs [ 13 ] = ( void * ) & rtX . hqm1okddyw ;
rt_LoggedStateSignalPtrs [ 14 ] = ( void * ) & rtX . abk5ytngnj ;
rt_LoggedStateSignalPtrs [ 15 ] = ( void * ) & rtX . kskuxricdl ;
rt_LoggedStateSignalPtrs [ 16 ] = ( void * ) & rtX . lx3xuxie2j ;
rt_LoggedStateSignalPtrs [ 17 ] = ( void * ) & rtX . brizaijzew ;
rt_LoggedStateSignalPtrs [ 18 ] = ( void * ) & rtX . jjfpdr1zyr ;
rt_LoggedStateSignalPtrs [ 19 ] = ( void * ) & rtX . imz4v0p4of ;
rt_LoggedStateSignalPtrs [ 20 ] = ( void * ) & rtX . lwbwvxj00j [ 0 ] ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssJacobianPerturbationBounds jacobianPerturbationBounds ;
ssSetJacobianPerturbationBounds ( rtS , & jacobianPerturbationBounds ) ; } {
static ssSolverInfo slvrInfo ; static struct _ssSFcnModelMethods3 mdlMethods3
; static struct _ssSFcnModelMethods2 mdlMethods2 ; static boolean_T
contStatesDisabled [ 26 ] ; static real_T absTol [ 26 ] = { 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 } ;
static uint8_T absTolControl [ 26 ] = { 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U
, 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U ,
0U , 0U , 0U } ; static real_T contStateJacPerturbBoundMinVec [ 26 ] ; static
real_T contStateJacPerturbBoundMaxVec [ 26 ] ; static uint8_T zcAttributes [
138 ] = { ( ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP )
, ( ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL
) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL )
, ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) } ; static
ssNonContDerivSigInfo nonContDerivSigInfo [ 83 ] = { { 1 * sizeof ( real_T )
, ( char * ) ( & rtB . cpkwdk2p01 ) , ( NULL ) } , { 1 * sizeof ( real_T ) ,
( char * ) ( & rtB . hc4tipfzoi ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . iilivmsrjv ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . mgdng0j5ju ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . palr0v3uue ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ala2ctnapt ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ghpkp3e4ii ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . hwbt4zhehe ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . buretmbzch ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . cjyi1ugvfp ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . kwlwx42yav ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . cxzbwqcn1v ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . nsz3sakdbs ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . gn1ehycyi2 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . hkcf5uul0d ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . c51nh4xf1q ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . deezhakrkc ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . c4edbm3lnu ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . lvnp1e1py5 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . n244nv1bl5 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . psl1pylfxp ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . epmqzfkazx ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . mymfehhqyf ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . dtff1cx0dd ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . bcqp5bw5m5 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . filzxjl5ur ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . cgviec4bkd ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . cpybkyynn4 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . a1pwur2f3n ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . cngflnzqr2 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . n5szlr3nqx ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . aww14lps2o ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . kgz10dnw3h ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . jgxdelnl3s ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . jhzdsfrzpr ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . fmzs5132om ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ammqm2ucfq ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . aprnkbzhsq ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . e0eegacwfw ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . njmqdqum11 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ixwvnfjyht ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . nw2inaond5 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . bvviu2o2gh ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . hmnedoi5ok ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ojebse5nps ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . oipwcmrhbu ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . onxjmnda4f ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . hvbdhrufgk ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . inr0z52r4v ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ivfkkggxvv ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . fbim3ivtyq ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ou3lkm5huj ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . dnc1haqpya ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . bn2cyxj3zl ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . pgstoxbe4q ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . dsgitwjsjs ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . b5ot5krztj ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . nuzd1nehkt ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . kttme4p4ih ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . gukj05tcnp ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . pykujdhald ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . fj5f5uf5pw ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . cl1znduuno ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . me3a54u35r ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . cc2mpg0gqp ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . cfvuxsaes1 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . hr53vp5214 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . mkvq5xwqnm ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . olx2nutnfv ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . mxtffwnyug ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . ptudxy54cl ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . hmuvnzmkyq ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . if50jzplnu ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . jakgot214r ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . cklmpkcmxr ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . bwnprsaklm ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . j04p5reu3p ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . kcf35vodg1 ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . d5jbm0zxii ) , ( NULL ) } , { 1 * sizeof ( boolean_T ) , (
char * ) ( & rtB . iezulznyyl ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . patx3e3lyu ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . hitd4jbxxo ) , ( NULL ) } , { 1 * sizeof ( real_T ) , (
char * ) ( & rtB . ldokaf3uyj ) , ( NULL ) } } ; { int i ; for ( i = 0 ; i <
26 ; ++ i ) { contStateJacPerturbBoundMinVec [ i ] = 0 ;
contStateJacPerturbBoundMaxVec [ i ] = rtGetInf ( ) ; } } ssSetSolverRelTol (
rtS , 0.001 ) ; ssSetStepSize ( rtS , 0.0 ) ; ssSetMinStepSize ( rtS , 0.0 )
; ssSetMaxNumMinSteps ( rtS , - 1 ) ; ssSetMinStepViolatedError ( rtS , 0 ) ;
ssSetMaxStepSize ( rtS , 2.4 ) ; ssSetSolverMaxOrder ( rtS , - 1 ) ;
ssSetSolverRefineFactor ( rtS , 1 ) ; ssSetOutputTimes ( rtS , ( NULL ) ) ;
ssSetNumOutputTimes ( rtS , 0 ) ; ssSetOutputTimesOnly ( rtS , 0 ) ;
ssSetOutputTimesIndex ( rtS , 0 ) ; ssSetZCCacheNeedsReset ( rtS , 1 ) ;
ssSetDerivCacheNeedsReset ( rtS , 0 ) ; ssSetNumNonContDerivSigInfos ( rtS ,
83 ) ; ssSetNonContDerivSigInfos ( rtS , nonContDerivSigInfo ) ;
ssSetSolverInfo ( rtS , & slvrInfo ) ; ssSetSolverName ( rtS , "ode23tb" ) ;
ssSetVariableStepSolver ( rtS , 1 ) ; ssSetSolverConsistencyChecking ( rtS ,
0 ) ; ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ;
ssSetSolverRobustResetMethod ( rtS , 0 ) ; ssSetAbsTolVector ( rtS , absTol )
; ssSetAbsTolControlVector ( rtS , absTolControl ) ;
ssSetSolverAbsTol_Obsolete ( rtS , absTol ) ;
ssSetSolverAbsTolControl_Obsolete ( rtS , absTolControl ) ;
ssSetJacobianPerturbationBoundsMinVec ( rtS , contStateJacPerturbBoundMinVec
) ; ssSetJacobianPerturbationBoundsMaxVec ( rtS ,
contStateJacPerturbBoundMaxVec ) ; ssSetSolverStateProjection ( rtS , 1 ) ; (
void ) memset ( ( void * ) & mdlMethods2 , 0 , sizeof ( mdlMethods2 ) ) ;
ssSetModelMethods2 ( rtS , & mdlMethods2 ) ; ( void ) memset ( ( void * ) &
mdlMethods3 , 0 , sizeof ( mdlMethods3 ) ) ; ssSetModelMethods3 ( rtS , &
mdlMethods3 ) ; ssSetModelProjection ( rtS , MdlProjection ) ;
ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelLogData ( rtS , rt_UpdateTXYLogVars ) ;
ssSetModelLogDataIfInInterval ( rtS , rt_UpdateTXXFYLogVars ) ;
ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetModelDerivatives ( rtS ,
MdlDerivatives ) ; ssSetSolverZcSignalAttrib ( rtS , zcAttributes ) ;
ssSetSolverNumZcSignals ( rtS , 138 ) ; ssSetModelZeroCrossings ( rtS ,
MdlZeroCrossings ) ; ssSetSolverConsecutiveZCsStepRelTol ( rtS ,
2.8421709430404007E-13 ) ; ssSetSolverMaxConsecutiveZCs ( rtS , 1000 ) ;
ssSetSolverConsecutiveZCsError ( rtS , 2 ) ; ssSetSolverMaskedZcDiagnostic (
rtS , 1 ) ; ssSetSolverIgnoredZcDiagnostic ( rtS , 1 ) ;
ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ;
ssSetSolverShapePreserveControl ( rtS , 2 ) ; ssSetTNextTid ( rtS , INT_MIN )
; ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 133 ) ; ssSetContStateDisabled ( rtS ,
contStatesDisabled ) ; ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ; } {
ZCSigState * zc = ( ZCSigState * ) & rtPrevZCX ; ssSetPrevZCSigState ( rtS ,
zc ) ; } { rtPrevZCX . prxdc20lxc = UNINITIALIZED_ZCSIG ; rtPrevZCX .
oizxtz1h42 = UNINITIALIZED_ZCSIG ; rtPrevZCX . dmvlae2fk1 =
UNINITIALIZED_ZCSIG ; rtPrevZCX . hgdvl4elkh = UNINITIALIZED_ZCSIG ;
rtPrevZCX . kdatxxubrk = UNINITIALIZED_ZCSIG ; } ssSetChecksumVal ( rtS , 0 ,
1550680249U ) ; ssSetChecksumVal ( rtS , 1 , 746654945U ) ; ssSetChecksumVal
( rtS , 2 , 2628067688U ) ; ssSetChecksumVal ( rtS , 3 , 4181925083U ) ; {
static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE ; static
RTWExtModeInfo rt_ExtModeInfo ; static const sysRanDType * systemRan [ 66 ] ;
gblRTWExtModeInfo = & rt_ExtModeInfo ; ssSetRTWExtModeInfo ( rtS , &
rt_ExtModeInfo ) ; rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo ,
systemRan ) ; systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = &
rtAlwaysEnabled ; systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = &
rtAlwaysEnabled ; systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = &
rtAlwaysEnabled ; systemRan [ 6 ] = & rtAlwaysEnabled ; systemRan [ 7 ] = &
rtAlwaysEnabled ; systemRan [ 8 ] = & rtAlwaysEnabled ; systemRan [ 9 ] = &
rtAlwaysEnabled ; systemRan [ 10 ] = & rtAlwaysEnabled ; systemRan [ 11 ] = &
rtAlwaysEnabled ; systemRan [ 12 ] = & rtAlwaysEnabled ; systemRan [ 13 ] = &
rtAlwaysEnabled ; systemRan [ 14 ] = & rtAlwaysEnabled ; systemRan [ 15 ] = &
rtAlwaysEnabled ; systemRan [ 16 ] = & rtAlwaysEnabled ; systemRan [ 17 ] = &
rtAlwaysEnabled ; systemRan [ 18 ] = & rtAlwaysEnabled ; systemRan [ 19 ] = &
rtAlwaysEnabled ; systemRan [ 20 ] = & rtAlwaysEnabled ; systemRan [ 21 ] = &
rtAlwaysEnabled ; systemRan [ 22 ] = & rtAlwaysEnabled ; systemRan [ 23 ] = &
rtAlwaysEnabled ; systemRan [ 24 ] = & rtAlwaysEnabled ; systemRan [ 25 ] = &
rtAlwaysEnabled ; systemRan [ 26 ] = & rtAlwaysEnabled ; systemRan [ 27 ] = &
rtAlwaysEnabled ; systemRan [ 28 ] = & rtAlwaysEnabled ; systemRan [ 29 ] = &
rtAlwaysEnabled ; systemRan [ 30 ] = & rtAlwaysEnabled ; systemRan [ 31 ] = &
rtAlwaysEnabled ; systemRan [ 32 ] = & rtAlwaysEnabled ; systemRan [ 33 ] = &
rtAlwaysEnabled ; systemRan [ 34 ] = & rtAlwaysEnabled ; systemRan [ 35 ] = &
rtAlwaysEnabled ; systemRan [ 36 ] = & rtAlwaysEnabled ; systemRan [ 37 ] = &
rtAlwaysEnabled ; systemRan [ 38 ] = & rtAlwaysEnabled ; systemRan [ 39 ] = &
rtAlwaysEnabled ; systemRan [ 40 ] = & rtAlwaysEnabled ; systemRan [ 41 ] = &
rtAlwaysEnabled ; systemRan [ 42 ] = & rtAlwaysEnabled ; systemRan [ 43 ] = &
rtAlwaysEnabled ; systemRan [ 44 ] = & rtAlwaysEnabled ; systemRan [ 45 ] = &
rtAlwaysEnabled ; systemRan [ 46 ] = & rtAlwaysEnabled ; systemRan [ 47 ] = &
rtAlwaysEnabled ; systemRan [ 48 ] = & rtAlwaysEnabled ; systemRan [ 49 ] = &
rtAlwaysEnabled ; systemRan [ 50 ] = & rtAlwaysEnabled ; systemRan [ 51 ] = &
rtAlwaysEnabled ; systemRan [ 52 ] = & rtAlwaysEnabled ; systemRan [ 53 ] = &
rtAlwaysEnabled ; systemRan [ 54 ] = & rtAlwaysEnabled ; systemRan [ 55 ] = &
rtAlwaysEnabled ; systemRan [ 56 ] = & rtAlwaysEnabled ; systemRan [ 57 ] = &
rtAlwaysEnabled ; systemRan [ 58 ] = & rtAlwaysEnabled ; systemRan [ 59 ] = &
rtAlwaysEnabled ; systemRan [ 60 ] = & rtAlwaysEnabled ; systemRan [ 61 ] = &
rtAlwaysEnabled ; systemRan [ 62 ] = & rtAlwaysEnabled ; systemRan [ 63 ] = &
rtAlwaysEnabled ; systemRan [ 64 ] = & rtAlwaysEnabled ; systemRan [ 65 ] = &
rtAlwaysEnabled ; rteiSetModelMappingInfoPtr ( ssGetRTWExtModeInfo ( rtS ) ,
& ssGetModelMappingInfo ( rtS ) ) ; rteiSetChecksumsPtr ( ssGetRTWExtModeInfo
( rtS ) , ssGetChecksums ( rtS ) ) ; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS
) , ssGetTPtr ( rtS ) ) ; } slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_activeBalancing3_GetSimStateDisallowedBlocks ) ;
slsaGetWorkFcnForSimTargetOP ( rtS , mr_activeBalancing3_GetDWork ) ;
slsaSetWorkFcnForSimTargetOP ( rtS , mr_activeBalancing3_SetDWork ) ; rtP .
inti_LowerSat = rtMinusInf ; rtP . Saturation_LowerSat = rtMinusInf ; rtP .
inti_LowerSat_lz3gh0icex = rtMinusInf ; rtP . Saturation_LowerSat_kwi433xk5g
= rtMinusInf ; rtP . inti_LowerSat_cwekkzbyq1 = rtMinusInf ; rtP .
Saturation_LowerSat_o0i20janpw = rtMinusInf ; rtP . inti_LowerSat_nb1wwuftgl
= rtMinusInf ; rtP . Saturation_LowerSat_g1ovkjgj1x = rtMinusInf ; rtP .
inti_LowerSat_hzpmw3xl5s = rtMinusInf ; rtP . Saturation_LowerSat_haspwmkdbs
= rtMinusInf ; rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if (
ssGetErrorStatus ( rtS ) ) { return rtS ; } ssSetNumSFunctions ( rtS , 1 ) ;
{ static SimStruct childSFunctions [ 1 ] ; static SimStruct *
childSFunctionPtrs [ 1 ] ; ( void ) memset ( ( void * ) & childSFunctions [ 0
] , 0 , sizeof ( childSFunctions ) ) ; ssSetSFunctions ( rtS , &
childSFunctionPtrs [ 0 ] ) ; ssSetSFunction ( rtS , 0 , & childSFunctions [ 0
] ) ; { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; static time_T
sfcnPeriod [ 1 ] ; static time_T sfcnOffset [ 1 ] ; static int_T sfcnTsMap [
1 ] ; ( void ) memset ( ( void * ) sfcnPeriod , 0 , sizeof ( time_T ) * 1 ) ;
( void ) memset ( ( void * ) sfcnOffset , 0 , sizeof ( time_T ) * 1 ) ;
ssSetSampleTimePtr ( rts , & sfcnPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rts ,
& sfcnOffset [ 0 ] ) ; ssSetSampleTimeTaskIDPtr ( rts , sfcnTsMap ) ; {
static struct _ssBlkInfo2 _blkInfo2 ; struct _ssBlkInfo2 * blkInfo2 = &
_blkInfo2 ; ssSetBlkInfo2Ptr ( rts , blkInfo2 ) ; } { static struct
_ssPortInfo2 _portInfo2 ; struct _ssPortInfo2 * portInfo2 = & _portInfo2 ;
_ssSetBlkInfo2PortInfo2Ptr ( rts , portInfo2 ) ; } ssSetMdlInfoPtr ( rts ,
ssGetMdlInfoPtr ( rtS ) ) ; { static struct _ssSFcnModelMethods2 methods2 ;
ssSetModelMethods2 ( rts , & methods2 ) ; } { static struct
_ssSFcnModelMethods3 methods3 ; ssSetModelMethods3 ( rts , & methods3 ) ; } {
static struct _ssSFcnModelMethods4 methods4 ; ssSetModelMethods4 ( rts , &
methods4 ) ; } { static struct _ssStatesInfo2 statesInfo2 ; static
ssPeriodicStatesInfo periodicStatesInfo ; static ssJacobianPerturbationBounds
jacPerturbationBounds ; ssSetStatesInfo2 ( rts , & statesInfo2 ) ;
ssSetPeriodicStatesInfo ( rts , & periodicStatesInfo ) ;
ssSetJacobianPerturbationBounds ( rts , & jacPerturbationBounds ) ;
ssSetAbsTolVector ( rts , ssGetAbsTolVector ( rtS ) + 20 ) ;
ssSetAbsTolControlVector ( rts , ssGetAbsTolControlVector ( rtS ) + 20 ) ; }
{ static struct _ssPortInputs inputPortInfo [ 2 ] ; _ssSetNumInputPorts ( rts
, 2 ) ; ssSetPortInfoForInputs ( rts , & inputPortInfo [ 0 ] ) ; { static
struct _ssInPortUnit inputPortUnits [ 2 ] ; _ssSetPortInfo2ForInputUnits (
rts , & inputPortUnits [ 0 ] ) ; } ssSetInputPortUnit ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 1 , 0 ) ; { static struct _ssInPortCoSimAttribute
inputPortCoSimAttribute [ 2 ] ; _ssSetPortInfo2ForInputCoSimAttribute ( rts ,
& inputPortCoSimAttribute [ 0 ] ) ; } ssSetInputPortIsContinuousQuantity (
rts , 0 , 0 ) ; ssSetInputPortIsContinuousQuantity ( rts , 1 , 0 ) ; { static
real_T const * sfcnUPtrs [ 5 ] ; sfcnUPtrs [ 0 ] = & rtB . ipzhuu4ptw ;
sfcnUPtrs [ 1 ] = & rtB . ja533qrntz ; sfcnUPtrs [ 2 ] = & rtB . jlrqkf40e4 ;
sfcnUPtrs [ 3 ] = & rtB . imwf4qbc3k ; sfcnUPtrs [ 4 ] = & rtB . b05wxiklmy ;
ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidth ( rts , 0
, 5 ) ; } { static real_T const * sfcnUPtrs [ 36 ] ; sfcnUPtrs [ 0 ] = & rtB
. hwbt4zhehe ; sfcnUPtrs [ 1 ] = & rtB . kwlwx42yav ; sfcnUPtrs [ 2 ] = & rtB
. cjyi1ugvfp ; sfcnUPtrs [ 3 ] = & rtB . buretmbzch ; sfcnUPtrs [ 4 ] = & rtB
. ighohgvfas ; sfcnUPtrs [ 5 ] = & rtB . etxojvnaot ; sfcnUPtrs [ 6 ] = & rtB
. gwktivfwpd ; sfcnUPtrs [ 7 ] = & rtB . ekw0zt1xfm ; sfcnUPtrs [ 8 ] = & rtB
. cqsienutuc ; sfcnUPtrs [ 9 ] = & rtB . krygur50zl ; sfcnUPtrs [ 10 ] = &
rtB . ghpkp3e4ii ; sfcnUPtrs [ 11 ] = & rtB . ala2ctnapt ; sfcnUPtrs [ 12 ] =
& rtB . palr0v3uue ; sfcnUPtrs [ 13 ] = & rtB . mgdng0j5ju ; sfcnUPtrs [ 14 ]
= & rtB . iilivmsrjv ; sfcnUPtrs [ 15 ] = & rtB . hc4tipfzoi ; sfcnUPtrs [ 16
] = & rtB . cpkwdk2p01 ; sfcnUPtrs [ 17 ] = & rtB . cxzbwqcn1v ; sfcnUPtrs [
18 ] = & rtB . owzswdceo3 ; sfcnUPtrs [ 19 ] = & rtB . lnwt3320xf ; sfcnUPtrs
[ 20 ] = & rtB . f1jzjr5wtp ; sfcnUPtrs [ 21 ] = & rtB . ezdk1hee5n ;
sfcnUPtrs [ 22 ] = & rtB . mhvcgzbyma ; sfcnUPtrs [ 23 ] = & rtB . dcu2acxtfg
; sfcnUPtrs [ 24 ] = & rtB . lnh2z2pbk3 ; sfcnUPtrs [ 25 ] = & rtB .
ovmxhmbhlf ; sfcnUPtrs [ 26 ] = & rtB . g2q1v5iy2d ; sfcnUPtrs [ 27 ] = & rtB
. pbgvg2nezd ; sfcnUPtrs [ 28 ] = & rtB . jzeacrnsxs ; sfcnUPtrs [ 29 ] = &
rtB . klom0nem0m ; sfcnUPtrs [ 30 ] = & rtB . aolyxnh1an ; sfcnUPtrs [ 31 ] =
& rtB . fzhbdpl21m ; sfcnUPtrs [ 32 ] = & rtB . fllp1jvygi ; sfcnUPtrs [ 33 ]
= & rtB . ln3b5mokgm ; sfcnUPtrs [ 34 ] = & rtB . krwk3nllsf ; sfcnUPtrs [ 35
] = & rtB . kxozrd4z5i ; ssSetInputPortSignalPtrs ( rts , 1 , ( InputPtrsType
) & sfcnUPtrs [ 0 ] ) ; _ssSetInputPortNumDimensions ( rts , 1 , 1 ) ;
ssSetInputPortWidth ( rts , 1 , 36 ) ; } } { static struct _ssPortOutputs
outputPortInfo [ 2 ] ; ssSetPortInfoForOutputs ( rts , & outputPortInfo [ 0 ]
) ; _ssSetNumOutputPorts ( rts , 2 ) ; { static struct _ssOutPortUnit
outputPortUnits [ 2 ] ; _ssSetPortInfo2ForOutputUnits ( rts , &
outputPortUnits [ 0 ] ) ; } ssSetOutputPortUnit ( rts , 0 , 0 ) ;
ssSetOutputPortUnit ( rts , 1 , 0 ) ; { static struct
_ssOutPortCoSimAttribute outputPortCoSimAttribute [ 2 ] ;
_ssSetPortInfo2ForOutputCoSimAttribute ( rts , & outputPortCoSimAttribute [ 0
] ) ; } ssSetOutputPortIsContinuousQuantity ( rts , 0 , 0 ) ;
ssSetOutputPortIsContinuousQuantity ( rts , 1 , 0 ) ; {
_ssSetOutputPortNumDimensions ( rts , 0 , 1 ) ; ssSetOutputPortWidth ( rts ,
0 , 7 ) ; ssSetOutputPortSignal ( rts , 0 , ( ( real_T * ) rtB . gzwwnxifap )
) ; } { _ssSetOutputPortNumDimensions ( rts , 1 , 1 ) ; ssSetOutputPortWidth
( rts , 1 , 72 ) ; ssSetOutputPortSignal ( rts , 1 , ( ( real_T * ) rtB .
e4hlm2rw4k ) ) ; } } ssSetContStates ( rts , & rtX . lwbwvxj00j [ 0 ] ) ;
ssSetContStateDisabled ( rts , & ( ( XDis * ) ssGetContStateDisabled ( rtS )
) -> lwbwvxj00j [ 0 ] ) ; { real_T * minVec = & ( ( CXPtMin * )
ssGetJacobianPerturbationBoundsMinVec ( rtS ) ) -> lwbwvxj00j [ 0 ] ; real_T
* maxVec = & ( ( CXPtMax * ) ssGetJacobianPerturbationBoundsMaxVec ( rtS ) )
-> lwbwvxj00j [ 0 ] ; ssSetJacobianPerturbationBoundsMinVec ( rts , minVec )
; ssSetJacobianPerturbationBoundsMaxVec ( rts , maxVec ) ; } ssSetModelName (
rts , "State-Space" ) ; ssSetPath ( rts ,
"activeBalancing3/powergui/EquivalentModel1/State-Space" ) ; if (
ssGetRTModel ( rtS ) == ( NULL ) ) { ssSetParentSS ( rts , rtS ) ;
ssSetRootSS ( rts , ssGetRootSS ( rtS ) ) ; } else { ssSetRTModel ( rts ,
ssGetRTModel ( rtS ) ) ; ssSetParentSS ( rts , ( NULL ) ) ; ssSetRootSS ( rts
, rts ) ; } ssSetVersion ( rts , SIMSTRUCT_VERSION_LEVEL2 ) ; { static
mxArray * sfcnParams [ 10 ] ; ssSetSFcnParamsCount ( rts , 10 ) ;
ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ; ssSetSFcnParam ( rts , 0 ,
( mxArray * ) rtP . StateSpace_P1_Size ) ; ssSetSFcnParam ( rts , 1 , (
mxArray * ) rtP . StateSpace_P2_Size ) ; ssSetSFcnParam ( rts , 2 , ( mxArray
* ) rtP . StateSpace_P3_Size ) ; ssSetSFcnParam ( rts , 3 , ( mxArray * ) rtP
. StateSpace_P4_Size ) ; ssSetSFcnParam ( rts , 4 , ( mxArray * ) rtP .
StateSpace_P5_Size ) ; ssSetSFcnParam ( rts , 5 , ( mxArray * ) rtP .
StateSpace_P6_Size ) ; ssSetSFcnParam ( rts , 6 , ( mxArray * ) rtP .
StateSpace_P7_Size ) ; ssSetSFcnParam ( rts , 7 , ( mxArray * ) rtP .
StateSpace_P8_Size ) ; ssSetSFcnParam ( rts , 8 , ( mxArray * ) rtP .
StateSpace_P9_Size ) ; ssSetSFcnParam ( rts , 9 , ( mxArray * ) rtP .
StateSpace_P10_Size ) ; } ssSetRWork ( rts , ( real_T * ) & rtDW . pipgbkjgsg
[ 0 ] ) ; ssSetIWork ( rts , ( int_T * ) & rtDW . badooczfnm [ 0 ] ) ;
ssSetPWork ( rts , ( void * * ) & rtDW . bl3jeskmlg [ 0 ] ) ; { static struct
_ssDWorkRecord dWorkRecord [ 4 ] ; static struct _ssDWorkAuxRecord
dWorkAuxRecord [ 4 ] ; ssSetSFcnDWork ( rts , dWorkRecord ) ;
ssSetSFcnDWorkAux ( rts , dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 4 ) ;
ssSetDWorkWidth ( rts , 0 , 37 ) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER
) ; ssSetDWorkComplexSignal ( rts , 0 , 0 ) ; ssSetDWork ( rts , 0 , & rtDW .
imyqo2srel [ 0 ] ) ; ssSetDWorkWidth ( rts , 1 , 2 ) ; ssSetDWorkDataType (
rts , 1 , SS_DOUBLE ) ; ssSetDWorkComplexSignal ( rts , 1 , 0 ) ; ssSetDWork
( rts , 1 , & rtDW . pipgbkjgsg [ 0 ] ) ; ssSetDWorkWidth ( rts , 2 , 23 ) ;
ssSetDWorkDataType ( rts , 2 , SS_INTEGER ) ; ssSetDWorkComplexSignal ( rts ,
2 , 0 ) ; ssSetDWork ( rts , 2 , & rtDW . badooczfnm [ 0 ] ) ;
ssSetDWorkWidth ( rts , 3 , 22 ) ; ssSetDWorkDataType ( rts , 3 , SS_POINTER
) ; ssSetDWorkComplexSignal ( rts , 3 , 0 ) ; ssSetDWork ( rts , 3 , & rtDW .
bl3jeskmlg [ 0 ] ) ; } ssSetModeVector ( rts , ( int_T * ) & rtDW .
imyqo2srel [ 0 ] ) ; sfun_spid_contc ( rts ) ; sfcnInitializeSizes ( rts ) ;
sfcnInitializeSampleTimes ( rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ;
ssSetOffsetTime ( rts , 0 , 0.0 ) ; sfcnTsMap [ 0 ] = 0 ;
ssSetNumNonsampledZCs ( rts , 37 ) ; _ssSetInputPortConnected ( rts , 0 , 1 )
; _ssSetInputPortConnected ( rts , 1 , 1 ) ; _ssSetOutputPortConnected ( rts
, 0 , 1 ) ; _ssSetOutputPortConnected ( rts , 1 , 1 ) ;
_ssSetOutputPortBeingMerged ( rts , 0 , 0 ) ; _ssSetOutputPortBeingMerged (
rts , 1 , 0 ) ; ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ;
ssSetInputPortBufferDstPort ( rts , 1 , - 1 ) ; } } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 8 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID8 ( tid ) ; }
