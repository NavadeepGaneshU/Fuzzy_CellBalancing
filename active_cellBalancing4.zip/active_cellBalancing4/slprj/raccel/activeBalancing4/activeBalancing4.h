#ifndef RTW_HEADER_activeBalancing4_h_
#define RTW_HEADER_activeBalancing4_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap_simtarget.h"
#ifndef activeBalancing4_COMMON_INCLUDES_
#define activeBalancing4_COMMON_INCLUDES_
#include <stdlib.h>
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "activeBalancing4_types.h"
#include "multiword_types.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "rt_zcfcn.h"
#include "mwmathutil.h"
#include "rt_defines.h"
#define MODEL_NAME activeBalancing4
#define NSAMPLE_TIMES (10) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (462) 
#define NUM_ZC_EVENTS (8) 
#ifndef NCSTATES
#define NCSTATES (39)   
#elif NCSTATES != 39
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T c5zsuqyizw [ 2 ] ; real_T gz0uq5kqkr [ 101 ] ; }
bsxn3352ub ; typedef struct { real_T outputMFCache [ 606 ] ; real_T
fqm02mu2mr ; real_T k0olm5ygz1 ; real_T mrkoixdcxy ; real_T g5y2ovgmgf ;
real_T p3jvn4gjjg ; real_T h0jr4gcmhz ; real_T drgvtg0vjv ; real_T a42chj0wvi
; real_T mcznvl3xnw ; real_T p0r2azag0g ; real_T fq1y334rj2 ; real_T
nj0k0lpkxt ; real_T gmgyu1za23 ; real_T hg3oaigjwk ; real_T iglwuzsika ;
real_T kf00di3gqm ; real_T l243apzsnw ; real_T ifn5ydjway ; real_T gaxbz4eazu
; real_T n52pjzek12 ; real_T c1l22vg0g3 ; real_T bsbdyhiakj ; real_T
nula5qzpsy ; real_T ojlbfd1f01 ; real_T jatbcbjee2 ; real_T b1idarpp5t ;
real_T esegl2vvhs ; real_T gkqod2z0mi ; real_T nl2mcft0gt ; real_T a0aqqada1w
; real_T othrejmk4n ; real_T o55coy5tot ; real_T nv44crtc44 ; real_T
po53ioprtt ; real_T pmyyss4uxo ; real_T mtw3mahg4k ; real_T dq2lwvzzrg ;
real_T e0yzwp1mzb ; real_T b5plhow0ik ; real_T pqhzrovppf ; real_T frv35kwpm0
; real_T alargmkfao ; real_T deh2tdbovg ; real_T bnmph5cpev ; real_T
gaiiq3ag5u ; real_T m5jzl0c3ow ; real_T kslnv1njp2 ; real_T a2rrzly2nj ;
real_T cgdbtisdum ; real_T c005o3t15s ; real_T pciyqbmld3 ; real_T b411vxpvsm
; real_T flzib234ll ; real_T aojtgbxww0 ; real_T befeauo34y ; real_T
lz4r5vsjh1 ; real_T hgspzwdexg ; real_T arqmlzjrl4 ; real_T n4ii53j0pi ;
real_T a32d4y2ehp ; real_T dzejhg3vfk ; real_T nla5yxcuxf ; real_T nzk1m34skw
; real_T hg2elf4r3m ; real_T itgwqixq2p ; real_T a1q431buft ; real_T
bfmkeli01v ; real_T idgi4oj4mi ; real_T i5uns4zs23 ; real_T czyx3zxlle ;
real_T b2gwj4fubz ; real_T bpligzmo0k ; real_T olfzsyzgug ; real_T fytijtn1qm
; real_T ijwp3irwdu ; real_T kyq4l5giqe ; real_T j41ux1gc4d ; real_T
k0z0bgvani ; real_T g5hkbvjtz4 ; real_T chdzuypdzn ; real_T oi4dn5ko50 ;
real_T corg1fk01c ; real_T inix0uapiw ; real_T ktqlzpn2rg ; real_T jolzvaxect
; real_T nxd3puqj5v ; real_T muhalhj3gd ; real_T mlwnlfftda ; real_T
cvwcsqjiim ; real_T exrixluala ; real_T ixuan5fz50 ; real_T ebcldbyulo ;
real_T p2hxwe1zfu ; real_T iaqlnbjhf1 ; real_T im14ffjmmn ; real_T lms5sy0bav
; real_T a5didxhdqz ; real_T deydb1b0uy ; real_T muxngmbf0e ; real_T
msa01agh2x ; real_T aztqnss3hz ; real_T bvz4ef4xni ; real_T i0lfhlq3lc ;
real_T g1xvhnr3f5 ; real_T agzlujxqfb ; real_T fdzcq5zjwp ; real_T ogkyqhikl5
; real_T iuvcnk5dmp ; real_T flzlebwg5e ; real_T h3sbcd43z2 ; real_T
dkk3fwnmny ; real_T l0cwdgyzlo ; real_T iotsi3yshg ; real_T gcxndupnfr ;
real_T owgcqoig0n ; real_T besqhap1x0 ; real_T njfm3f2grf ; real_T juce2ptz2y
; real_T baqcdaab4w ; real_T lf5xebyb1r ; real_T ppcjroz05k ; real_T
ehmperqua5 ; real_T bqzx2eyzzy ; real_T i5kcdpjhpi ; real_T aaa1drn5lo ;
real_T gjn3v2eu4k ; real_T g201quwjao ; real_T ogryssvt51 ; real_T jo315eteaj
; real_T gl0nhtg1ch ; real_T as0tme1x3l ; real_T pk01kqglup ; real_T
et4oqao0hp ; real_T b3ob2uqqdm ; real_T ecthl1j1o0 ; real_T hhflfdof15 ;
real_T lhhyhpp5gu ; real_T lnjnmhfbjh ; real_T jp2e2ut45b ; real_T dr4em5z1io
; real_T b2ixyft4ic ; real_T dm4nf0b0xz ; real_T g415uib1wr ; real_T
cvzcjmgoyh ; real_T d34ubm25fp ; real_T ggnmpyt3wu ; real_T nqmkidt0nf ;
real_T hvmipewyll ; real_T i0iborr1bn ; real_T i0wi0xfyww ; real_T g4xgxwmrt1
; real_T ipz4zr0egw ; real_T dfuf4q33n1 ; real_T mwcys4j4zs ; real_T
hvabmdtuvh ; real_T dhwyvtmepj ; real_T ivovkyhxrz ; real_T bxzkxne3dq ;
real_T newud24pbl ; real_T cd1qrej531 ; real_T bjlklhbtye ; real_T otte1lhfee
; real_T gw4ubpvz5m ; real_T ja5d4uupyj ; real_T kxpcdql4jz ; real_T
codhkowftx ; real_T fx2apmzawu ; real_T nvr2gta2ze ; real_T ak5ny2xuat ;
real_T jufwanbg3o ; real_T jwjptsm01d ; real_T jwcx5x3uww ; real_T acxnkfdwy1
; real_T aftb2w02md ; real_T apkx5dx1qe ; real_T mmu3qpagt3 ; real_T
bwiu5f3xyy ; real_T nm54nmq004 ; real_T geb23uw5n4 ; real_T bo1fzqwe00 ;
real_T cnd3dqmhap ; real_T eg2jmmryoa ; real_T lizolknie1 ; real_T a2ssj2eqbk
; real_T lo01p0mfxt [ 10 ] ; real_T jqon53xqhn [ 56 ] ; real_T fs4j0t3iiz ;
real_T gp1kmspjlh ; real_T kkv1pr3lrm ; real_T ns2ruilj2v ; real_T eft5k5m2mk
; real_T kx5llxdy1m ; real_T l1byjbqlra ; real_T iwlpqqhwtd ; real_T
ou3yruthi3 ; real_T gfahibyvsv ; real_T iqgkwhugb1 ; real_T ctz5askxrg ;
real_T lffxmmonqb ; real_T ilzwywxync ; real_T ork1qkhic1 ; real_T givksyq1ks
; real_T cizwakiveg ; real_T cyebjd4msb ; real_T lolyh00lpd ; real_T
kgcldxtuqy ; real_T o5jsafr2c3 ; real_T aacglbrseh ; real_T pw5q5s3yxm ;
real_T nehx4sjmhx ; real_T ilnuaaom40 ; real_T d3jd5igxzc ; real_T lpxn0wunpn
; real_T a3i41vp1qh ; real_T jtiok3ecro ; real_T p5n3swm2z3 ; real_T
kocesgc4kq ; real_T ot4gqzqydm ; real_T k4qktqs5bt ; real_T prlvalkk0e ;
real_T d5mhwukqbu ; real_T dpcxxq2cb2 ; real_T m1to4j3fz0 ; real_T fpat1cfbdw
; real_T m2qzirzrwp ; real_T pobsyfwdrr ; real_T hmk2x4i2wb ; real_T
ejoagqctsb ; real_T c3rlj0evqz ; real_T c5g4vefyay ; real_T exxvwq1eca ;
real_T d0hcukp5qd ; real_T k2b4djnq52 ; real_T eutn5sqh40 ; real_T jmd5vm3itb
; real_T pspdcb10ak ; real_T ijb3b30r2i ; real_T fyoud2dfzn ; real_T
gzihj5vvk1 ; real_T kjygkwym52 ; real_T hn5i42dlfu ; real_T ljzepiqdco ;
real_T cjnumo0b2v ; real_T k4bl20stk1 ; real_T c5sjcucfqi ; real_T esg43lx2mr
; real_T dxplqcckv2 ; real_T lzgz2a1hji ; real_T do252u2xbm ; real_T
nlzznjgokl ; real_T icxhoatkpy ; real_T jvqj10bdhd ; real_T djbiardxss ;
real_T byr5s2oy3e ; real_T iztnxsmmfx ; real_T pll3gx4xtu ; real_T ooktbhfuke
; real_T hlf2cr3mg4 ; real_T mpkxn4stei ; real_T l2a4su3opv ; real_T
fzx04ovsv2 ; real_T mphcdthuhz ; real_T d3g3fh43cq ; real_T iilzn0ptvn ;
real_T bpyjvekzcs ; real_T msjbl0lqgu ; real_T ilvfsgymog ; real_T pvsep2b5mx
; real_T p35szvmsnl ; real_T pq5i5vcg3c ; real_T iurpvuxeop ; real_T
idyadmxopc ; real_T prb3bcw1pc ; real_T mrdluoj4iu ; real_T juxu3ykg0j ;
real_T nzvnip1yoj ; real_T izlnv5xggd ; real_T gkbr5qk2mc ; real_T dgspm5jmps
; real_T hbi3ef0eho ; real_T hgecksjb2e ; real_T gsaxgr1si0 ; real_T
opg5acc20j ; real_T gn1iktvu5j ; real_T lroevxw2fw ; real_T mqtt3ijnmc ;
real_T dhgr323ykq ; real_T bybsxhpomg ; real_T izc05dwilh ; real_T j2cbi4uvjv
; real_T cdunewte3y ; real_T f0al1hik1j ; real_T lodc4zy0kf ; real_T
eupsjtfr5a ; real_T hb5phdzryd ; real_T b0w045s1dy ; real_T dcvu5axig4 ;
real_T h3c5qk01el ; real_T anc2sq3mml ; real_T mqa03tpv1s ; real_T bzwbhh42ka
; real_T ojiezq4id3 ; real_T ftx2e5cidi ; real_T ntwxdiuzqj ; real_T
b4ushbvpyk ; real_T oem1fc5toa ; real_T bcww4isw4r ; real_T b5epvnjqmi ;
real_T o1rf1cikyg ; real_T da4ug2cudb ; real_T nahk3q2lwf ; real_T hwoezaq2mj
; real_T iq51ppixmq ; real_T lcbjcuvvbt ; real_T jn3jigbm4f ; real_T
kg5yvb1wjz ; real_T ezyjeovbvi ; real_T nz5qxvxtdb ; real_T bhhrjm3haf ;
real_T acuoed4qri ; real_T iu33mby5ow ; real_T iy0igec4ex ; real_T nhvmldohqo
; real_T fconsse5vt [ 2 ] ; real_T fevj4hbzpr ; real_T jrje30z1er [ 2 ] ;
real_T eedseylcxx ; real_T jdh0wn2p1p [ 2 ] ; real_T ikv3z1vdef ; real_T
jks2jckbmk [ 2 ] ; real_T l2reh15lkf ; real_T fztujntlhv [ 2 ] ; real_T
i20qdjqwof [ 2 ] ; real_T bcxdnmatsv ; real_T ku1fxfiwgl [ 2 ] ; real_T
l4dl2g4o4p ; real_T g2o4t34vui [ 2 ] ; real_T obf4zmf1af ; real_T ahmttm3rdd
; real_T cojxsmfsrh ; real_T mgautzzkuz ; real_T ma44kqgc1u [ 4 ] ; real_T
g2neorilhq [ 4 ] ; real_T gre2qqt31t [ 4 ] ; real_T g2v5eyf0fn [ 4 ] ; real_T
i50k4latrz ; real_T n3yk1z5ay1 ; real_T jhzzujuc41 ; real_T pfrnf2ydxj [ 4 ]
; real_T ayi1laekbu [ 4 ] ; real_T og4zmu0v2n [ 4 ] ; real_T p2dnpj1ive [ 4 ]
; real_T l4aqiuf2c4 ; real_T cs22ftcsml ; real_T cv4nsrlmii ; real_T
d0xiworakl [ 4 ] ; real_T k0aebkl4fh [ 4 ] ; real_T d0ttldw0xr [ 4 ] ; real_T
kmnm3jte0y [ 4 ] ; real_T h0gslfuz00 ; real_T oygxsrsu4c ; real_T is1wchelug
; real_T bpbiu1lihc [ 4 ] ; real_T l2q2yxulmn [ 4 ] ; real_T jmhpv4tqnk [ 4 ]
; real_T d1g5zgedks [ 4 ] ; real_T pnkg5wquv2 ; real_T h0fu0ax1yq ; real_T
jjkxq3xqxm ; real_T ihm1brh0bi [ 4 ] ; real_T kq0pv3jzej [ 4 ] ; real_T
ax4synweyq [ 4 ] ; real_T jt5vlrdpwx [ 4 ] ; real_T pj3ruknygu ; real_T
ibgjdsvsot ; real_T ezq2vhtkgr ; real_T dj5bmh2qmz [ 4 ] ; real_T o5hw5brjet
[ 4 ] ; real_T f5dahsuilz [ 4 ] ; real_T d3zrlcmw3n [ 4 ] ; real_T jaaef2z5gv
; real_T oplbbe4p2q ; real_T nmhnvozqsv ; real_T cmoguppwfc [ 4 ] ; real_T
jbhnyvsbds [ 4 ] ; real_T if5hnihgsu [ 4 ] ; real_T bo4jr3clrs [ 4 ] ; real_T
nz04uf540o ; real_T lvwz4ihgsh ; real_T ob4wdtvizk ; real_T fuv3hvos5j [ 4 ]
; real_T decwo2mz20 [ 4 ] ; real_T btujypzxe1 [ 4 ] ; real_T a50cikqz4s [ 4 ]
; boolean_T levrqdzmuw ; boolean_T lvl2kjehdx ; boolean_T hu2ipo3lca ;
boolean_T jjriozwmwj ; boolean_T hwjzbg4rx2 ; boolean_T oj3yvv3y0h ;
boolean_T kq0scdgfjl ; boolean_T muvs2zmbde ; boolean_T czsttbwlhu ;
boolean_T oc3uk0sbgh ; boolean_T newl3oopdo ; boolean_T nvh2bwltbz ;
boolean_T eekpnfrbtv ; boolean_T f2df1n0xmz ; boolean_T eehigchrn4 ;
boolean_T gk2b4uufar ; boolean_T fibreaa3ri ; boolean_T atzrgflsgx ;
boolean_T hv51mxfmqn ; boolean_T fawiawgoh5 ; boolean_T js2smttmtm ;
boolean_T cbldlnrkrl ; boolean_T erpu4v3yeg ; boolean_T ame4svhan1 ;
boolean_T aowksp0wla ; boolean_T cme3xzwgv0 ; boolean_T ku5eexxo1r ;
boolean_T mzyw4mhc11 ; boolean_T b44kx5qc5j ; boolean_T ovopkjg4yt ;
boolean_T g0q2tc5i24 ; boolean_T cjfw5loxvr ; boolean_T iutvmolvr4 ;
boolean_T cp0who25g2 ; boolean_T erylo4qhmo ; boolean_T hpb3sjmuau ;
boolean_T gdm5q3kphw ; boolean_T agkl53gxjq ; boolean_T fk4jwk4iji ;
boolean_T f0mgvc4qtv ; boolean_T cukuo2c3br ; boolean_T eic4qlkhsy ;
boolean_T kds135p0hu ; boolean_T kqgjchdcds ; boolean_T edxzstui5p ;
boolean_T evet21s24l ; boolean_T malsck44d3 ; boolean_T nwe5vf4a0r ;
boolean_T fxfy52jqlw ; boolean_T nvn1ehmkrx ; boolean_T luugfk3sgm ;
boolean_T hnmfvx1wci ; boolean_T h20jo3vqoy ; boolean_T ksknuspzbv ;
boolean_T n3fyjsfyy0 ; boolean_T hrjctsjkxd ; bsxn3352ub mck0tzoap3 ;
bsxn3352ub bk2qkpodeg ; bsxn3352ub cnchvyey1f ; bsxn3352ub k43q2yzt11 ;
bsxn3352ub cg45csylfj ; bsxn3352ub keklcbv4b5 ; } B ; typedef struct { real_T
ca5hlnq0yv ; real_T capftuiedr ; real_T dausu4yb0r ; real_T nxcbrqbg4s ;
real_T nb3lw1dts4 ; real_T oqfmlletk1 ; real_T b1blljt5i4 ; real_T eude00gfzn
; real_T omhuox45k5 ; real_T l5yuu2mi2t ; real_T oteopngiwv ; real_T
jbkhseznjs ; real_T g0xibfhryj ; real_T dyomnt0iya ; real_T mmeejs3fon ;
real_T cixbj0ezqf ; real_T bchydutg41 ; real_T man13mro5e ; real_T alzjyrx0kg
; real_T aggfvdda1e ; real_T kmgw2sai2b ; real_T aegiye3tn1 ; real_T
k0tqwauzp3 ; real_T nifwcsv1v1 ; real_T grio4yjtpl ; real_T momrzwq4pr ;
real_T hfqfe1a1s5 ; real_T ifbin5pxrr ; real_T k2nrmdtvq3 ; real_T ff25ka4wdp
; real_T cutbprvcd3 ; real_T bt4oyd503e ; real_T azpppdzavz ; real_T
a30dvj5d1n ; real_T gmjjnhltdk ; real_T dtmajsg54k ; real_T magdrvjhlp ;
uint64_T axsolhspww ; uint64_T jkukkxhvxl ; uint64_T dxioy35srz ; uint64_T
klbt1o41jo ; uint64_T bfgv0ou4np ; uint64_T mqmlslbwtt ; uint64_T jqfoucolpw
; real_T bq5fblkvcd [ 2 ] ; void * msq0lqyul4 [ 22 ] ; struct { void *
LoggedData [ 8 ] ; } i4ildvjpls ; struct { void * AQHandles ; } m4a1slsbsw ;
struct { void * AQHandles ; } lb3ykh1ivj ; struct { void * AQHandles ; }
idjooi12be ; struct { void * AQHandles ; } nfq5r1c2nf ; struct { void *
AQHandles ; } l1ntzlm3em ; struct { void * AQHandles ; } cjeepns1kp ; struct
{ void * AQHandles ; } p3mdqwq4kn ; struct { void * AQHandles ; } ad2wzhmkkk
; struct { void * AQHandles ; } cp2sky53da ; struct { void * AQHandles ; }
mlqhgw44yh ; struct { void * AQHandles ; } ozkqasf5op ; struct { void *
AQHandles ; } md2q01fzov ; struct { void * AQHandles ; } btuvwmnygy ; struct
{ void * AQHandles ; } av20b02ile ; struct { void * AQHandles ; } o40s2uuuft
; struct { void * LoggedData [ 8 ] ; } hcsta24sqk ; struct { void *
LoggedData [ 2 ] ; } l2nnlj3okw ; int_T mwvlfj3tnw ; int_T jcfoqfv3fu ; int_T
p20ta3sfdz ; int_T oqj3skvfcq ; int_T aj4yhj42qr ; int_T k4l2ij22e5 ; int_T
gbegstnyrm ; int_T ioqp4ngatr ; int_T lvyvopbaxf [ 23 ] ; int_T klgebljbkk ;
int_T ogvxzirtsf ; int_T j1al2derae ; int_T ebrxkv0tlv ; int_T ia4yvyaqmb ;
int_T kcjz5ym5tp ; int_T gaqc3mhu55 ; int_T pbgnyq5tfg ; int_T cnphafnigh ;
int_T ggeecprz50 ; int_T i3h0yxjcuf ; int_T plgswrux01 ; int_T krsqhbk5nm ;
int_T el3nwtqbps ; int_T bmltxw1qtk ; int_T llohfphikn ; int_T hnnabs4ndc [
29 ] ; int_T dse1mzthll ; int_T dqvqnr2muv ; int_T c4c5mjr1mx ; int_T
bowq5mbaku ; int_T ax3qgrkr55 ; int_T apxa0sqt1p ; int_T b4njscmbvx ; int_T
etyjay2nca ; int_T fdlraqlrof ; int_T omqfuqupyg ; int_T gzlp0sbo4t ; int_T
jr1eyvxvce ; int_T kvvcczrh2h ; int_T oeka1ufi2q ; int_T paz4kgtbji ; int_T
ae04suheli ; int_T iuncllo15x ; int_T nmkbwshj5v ; int_T lpusnuqytr ; int_T
o1g4bix2tx ; int_T molqmdigqy ; int_T doucacjh3z ; boolean_T looo4ud10x ;
boolean_T enb5gffmh1 ; boolean_T oki3ixtrek ; boolean_T bm3shpqfur ;
boolean_T dq13p4klkw ; boolean_T b5qny41bod ; boolean_T fzutpwbhou ;
boolean_T egflmvjdnu ; boolean_T gbgm1nknco ; boolean_T bobvege1xa ;
boolean_T pfgmjz0oxl ; boolean_T c4ju1tonyc ; boolean_T ogpfosulwk ;
boolean_T mo2kznqvft ; boolean_T honn2tdy54 ; boolean_T orbo5xgqzn ;
boolean_T iv2pdg4k2c ; boolean_T h0qayo3umb ; boolean_T ogoto0hwmm ;
boolean_T fui4yx3kuz ; boolean_T aa45yc1et3 ; boolean_T mdxvbvxht5 ;
boolean_T b4svh4uxws ; boolean_T mryeqkmzmt ; boolean_T is4auzynbw ;
boolean_T j0pqa45jfy ; boolean_T oonf3bet4a ; boolean_T kcmxrveuh1 ;
boolean_T eywar50dsx ; boolean_T nkeiblqwmm ; boolean_T n2gaflvouv ;
boolean_T lwbxpyeq51 ; boolean_T bvkagd0qc0 ; boolean_T nccltnyyv2 ;
boolean_T pc2jk1zzjx ; boolean_T nhpvpm5stq ; boolean_T omshgvmyvz ;
boolean_T nowkbmdlih ; boolean_T mif04ihnck ; boolean_T f13aephrpz ;
boolean_T gea0cqh513 ; boolean_T hdkgbo205c ; boolean_T ozxljazjel ;
boolean_T ejk225g2nh ; boolean_T p2nqnwkq04 ; boolean_T citc1qmgco ;
boolean_T j1x1lkik4i ; boolean_T hp3fpshwsf ; boolean_T h4chdtup0e ;
boolean_T m140lfr1yc ; boolean_T nrvhe4sfr2 ; boolean_T dhdzvyusm1 ;
boolean_T hw43gon1bk ; boolean_T jjq0zsbfta ; boolean_T lgtmlehdmv ;
boolean_T ctjashoslt ; boolean_T fjenxspruc ; boolean_T hwzhc3avex ;
boolean_T f3a4hcqytw ; boolean_T gwdixswkyo ; boolean_T mpwatn3jkl ;
boolean_T dqufutohhs ; boolean_T a0bwirjyiu ; boolean_T j31b3jsmjg ;
boolean_T eshqu4qlyj ; boolean_T aiibi55tgx ; boolean_T hb2spknlp1 ;
boolean_T f1xr4ouflt ; boolean_T oo4b1k4vub ; boolean_T dofxxfnf1f ;
boolean_T d1fn42zlc3 ; boolean_T hbgw2vseyr ; boolean_T lt3wgqvpso ;
boolean_T ec4jake2ld ; boolean_T j53kvzldk2 ; boolean_T frexusnuvh ;
boolean_T izbbvtos1d ; boolean_T apdwknz0ig ; boolean_T n2nzegphpi ;
boolean_T kus34kmfe0 ; boolean_T je3xbgadnf ; boolean_T hs5qk4aflp ;
boolean_T bmw4dfcea0 ; boolean_T n3tcjs3cnp ; boolean_T eneedgqyil ;
boolean_T pn3eu4idcy ; boolean_T cassosl0xb ; boolean_T kldwedkv3j ;
boolean_T b5wvicli01 ; boolean_T aex5jpmvuw ; boolean_T ke5obrhhqt ;
boolean_T k5uuyepbrp ; boolean_T a4qh2syf5f ; boolean_T ptyhlovodi ;
boolean_T dimggz5k1i ; boolean_T dgtx3pxebh ; boolean_T nerp2skw04 ;
boolean_T fhpyfq1cbi ; boolean_T fqogqsl1qn ; boolean_T omg5wivauv ;
boolean_T ff1zu2lxej ; boolean_T bxzckcwnmi ; boolean_T n33t0mlcdo ;
boolean_T puzlpon25o ; boolean_T m4qezscalw ; boolean_T ctjzi2o40d ;
boolean_T e3ay5unpbh ; boolean_T bgieyqg154 ; boolean_T ozfvlojj1n ;
boolean_T fgsjlt3z00 ; boolean_T hbjqhzro5y ; boolean_T os10rt4vp3 ;
boolean_T noglx0ol2f ; boolean_T o1s050yt3g ; boolean_T o1qidfzosp ;
boolean_T ngljbafwbt ; boolean_T iknrj0yq2v ; boolean_T l4uscn224x ; } DW ;
typedef struct { real_T plb5id0v2x ; real_T lbkltw2njc ; real_T fzv1e1p3mc ;
real_T fg5c5z2vbx ; real_T bx04s5qbio ; real_T nxoiklb1cp ; real_T b3n5hgntky
; real_T cgxanjfmip ; real_T lfvzsuhskj ; real_T bxy3w4qxj2 ; real_T
chmdgjvbrk ; real_T iximkvmpst ; real_T esshhzn0st ; real_T dqfnkbb0xq ;
real_T ohptd3ifop ; real_T ik2jrqp3yy ; real_T j5rh0u0prg ; real_T cr4uxyxqlm
; real_T f1hbi1sd1q ; real_T kkgf3fitxr ; real_T batnhulphm ; real_T
bnmkr55uji ; real_T lulwdnmna3 ; real_T opnxmo5ky2 ; real_T kec03nv1yd ;
real_T ducd1mygi5 ; real_T a2azuhp5qh ; real_T c4c3igik4x ; real_T jgg0wj1zhe
; real_T mludnzmfko ; real_T fhoa1aghtu ; real_T kxckn4j1uq ; real_T
kyhu5rb2xj [ 7 ] ; } X ; typedef struct { real_T plb5id0v2x ; real_T
lbkltw2njc ; real_T fzv1e1p3mc ; real_T fg5c5z2vbx ; real_T bx04s5qbio ;
real_T nxoiklb1cp ; real_T b3n5hgntky ; real_T cgxanjfmip ; real_T lfvzsuhskj
; real_T bxy3w4qxj2 ; real_T chmdgjvbrk ; real_T iximkvmpst ; real_T
esshhzn0st ; real_T dqfnkbb0xq ; real_T ohptd3ifop ; real_T ik2jrqp3yy ;
real_T j5rh0u0prg ; real_T cr4uxyxqlm ; real_T f1hbi1sd1q ; real_T kkgf3fitxr
; real_T batnhulphm ; real_T bnmkr55uji ; real_T lulwdnmna3 ; real_T
opnxmo5ky2 ; real_T kec03nv1yd ; real_T ducd1mygi5 ; real_T a2azuhp5qh ;
real_T c4c3igik4x ; real_T jgg0wj1zhe ; real_T mludnzmfko ; real_T fhoa1aghtu
; real_T kxckn4j1uq ; real_T kyhu5rb2xj [ 7 ] ; } XDot ; typedef struct {
boolean_T plb5id0v2x ; boolean_T lbkltw2njc ; boolean_T fzv1e1p3mc ;
boolean_T fg5c5z2vbx ; boolean_T bx04s5qbio ; boolean_T nxoiklb1cp ;
boolean_T b3n5hgntky ; boolean_T cgxanjfmip ; boolean_T lfvzsuhskj ;
boolean_T bxy3w4qxj2 ; boolean_T chmdgjvbrk ; boolean_T iximkvmpst ;
boolean_T esshhzn0st ; boolean_T dqfnkbb0xq ; boolean_T ohptd3ifop ;
boolean_T ik2jrqp3yy ; boolean_T j5rh0u0prg ; boolean_T cr4uxyxqlm ;
boolean_T f1hbi1sd1q ; boolean_T kkgf3fitxr ; boolean_T batnhulphm ;
boolean_T bnmkr55uji ; boolean_T lulwdnmna3 ; boolean_T opnxmo5ky2 ;
boolean_T kec03nv1yd ; boolean_T ducd1mygi5 ; boolean_T a2azuhp5qh ;
boolean_T c4c3igik4x ; boolean_T jgg0wj1zhe ; boolean_T mludnzmfko ;
boolean_T fhoa1aghtu ; boolean_T kxckn4j1uq ; boolean_T kyhu5rb2xj [ 7 ] ; }
XDis ; typedef struct { real_T plb5id0v2x ; real_T lbkltw2njc ; real_T
fzv1e1p3mc ; real_T fg5c5z2vbx ; real_T bx04s5qbio ; real_T nxoiklb1cp ;
real_T b3n5hgntky ; real_T cgxanjfmip ; real_T lfvzsuhskj ; real_T bxy3w4qxj2
; real_T chmdgjvbrk ; real_T iximkvmpst ; real_T esshhzn0st ; real_T
dqfnkbb0xq ; real_T ohptd3ifop ; real_T ik2jrqp3yy ; real_T j5rh0u0prg ;
real_T cr4uxyxqlm ; real_T f1hbi1sd1q ; real_T kkgf3fitxr ; real_T batnhulphm
; real_T bnmkr55uji ; real_T lulwdnmna3 ; real_T opnxmo5ky2 ; real_T
kec03nv1yd ; real_T ducd1mygi5 ; real_T a2azuhp5qh ; real_T c4c3igik4x ;
real_T jgg0wj1zhe ; real_T mludnzmfko ; real_T fhoa1aghtu ; real_T kxckn4j1uq
; real_T kyhu5rb2xj [ 7 ] ; } CStateAbsTol ; typedef struct { real_T
plb5id0v2x ; real_T lbkltw2njc ; real_T fzv1e1p3mc ; real_T fg5c5z2vbx ;
real_T bx04s5qbio ; real_T nxoiklb1cp ; real_T b3n5hgntky ; real_T cgxanjfmip
; real_T lfvzsuhskj ; real_T bxy3w4qxj2 ; real_T chmdgjvbrk ; real_T
iximkvmpst ; real_T esshhzn0st ; real_T dqfnkbb0xq ; real_T ohptd3ifop ;
real_T ik2jrqp3yy ; real_T j5rh0u0prg ; real_T cr4uxyxqlm ; real_T f1hbi1sd1q
; real_T kkgf3fitxr ; real_T batnhulphm ; real_T bnmkr55uji ; real_T
lulwdnmna3 ; real_T opnxmo5ky2 ; real_T kec03nv1yd ; real_T ducd1mygi5 ;
real_T a2azuhp5qh ; real_T c4c3igik4x ; real_T jgg0wj1zhe ; real_T mludnzmfko
; real_T fhoa1aghtu ; real_T kxckn4j1uq ; real_T kyhu5rb2xj [ 7 ] ; } CXPtMin
; typedef struct { real_T plb5id0v2x ; real_T lbkltw2njc ; real_T fzv1e1p3mc
; real_T fg5c5z2vbx ; real_T bx04s5qbio ; real_T nxoiklb1cp ; real_T
b3n5hgntky ; real_T cgxanjfmip ; real_T lfvzsuhskj ; real_T bxy3w4qxj2 ;
real_T chmdgjvbrk ; real_T iximkvmpst ; real_T esshhzn0st ; real_T dqfnkbb0xq
; real_T ohptd3ifop ; real_T ik2jrqp3yy ; real_T j5rh0u0prg ; real_T
cr4uxyxqlm ; real_T f1hbi1sd1q ; real_T kkgf3fitxr ; real_T batnhulphm ;
real_T bnmkr55uji ; real_T lulwdnmna3 ; real_T opnxmo5ky2 ; real_T kec03nv1yd
; real_T ducd1mygi5 ; real_T a2azuhp5qh ; real_T c4c3igik4x ; real_T
jgg0wj1zhe ; real_T mludnzmfko ; real_T fhoa1aghtu ; real_T kxckn4j1uq ;
real_T kyhu5rb2xj [ 7 ] ; } CXPtMax ; typedef struct { real_T myhs4pztk3 ;
real_T mh4jcyaxop ; real_T cfjqurvqqo ; real_T putslwjuhy ; real_T pbndtniteq
; real_T ppr3rmmyso ; real_T ilodzpzwbm ; real_T hmxtdlr5un ; real_T
exprgz402h ; real_T ohewfltqq5 ; real_T m1nnc3fw0f ; real_T jvhu0vulox ;
real_T hrwpslja5m ; real_T lq5vehqec2 ; real_T mcki1r02nc ; real_T mm15ri5pc4
; real_T cczx1edrz4 ; real_T jfwddupd2z ; real_T g11hraxjuu ; real_T
mqv31max5g ; real_T bm0q0odbf5 ; real_T nhr5yprh2q ; real_T kfwlgrtdzl ;
real_T emj11a1x4w ; real_T kib1jjahlw ; real_T h43mu0tc5z ; real_T if52ui5e2k
; real_T nkalp3vjms ; real_T eyskbtymkf ; real_T mdgvgifavy ; real_T
ljpu0mfahy ; real_T ezzxdlb0rw ; real_T lqcudbd12v ; real_T dewfaxqcny ;
real_T jpox21jbul ; real_T nsywl14eel ; real_T l3podbdmiq ; real_T hxccwfvktp
; real_T j3wgfclxym ; real_T kwbcm1wtbm ; real_T ogtsqkbvdb ; real_T
arqudvd342 ; real_T fyt4r1dw3l ; real_T bxlkf43a2a ; real_T ixxast5hnw ;
real_T n2cbycjwvl ; real_T gybunfdo1w ; real_T osvvjanfu3 ; real_T f1xtjtow1h
; real_T hnp2hpsfw3 ; real_T jsjxxfswr1 ; real_T iiuwfxed5w ; real_T
ir00qrz4mu ; real_T e5d41peunx ; real_T ntzovf5sch ; real_T owdxjhk3nw ;
real_T f051liw0bt ; real_T h3yeih3o50 ; real_T ij21n3nes4 ; real_T jn1sfcxozu
; real_T fvhxslccjk ; real_T b2nnjiurct ; real_T ealt5wavvm ; real_T
lufdxrumf1 ; real_T pwt4v5mhy1 ; real_T hq32wkpqi1 ; real_T hgbtgb3u42 ;
real_T jsfaw0ar3r ; real_T o5tdefqefq ; real_T f4iwv4z5ps ; real_T lid1yiivho
; real_T n0itomkbtg ; real_T gq0ob0pzay ; real_T jjcwejlqhn ; real_T
c1wy4pcbpd ; real_T lhnmycj1jm ; real_T hix4z4zre2 ; real_T an05053gpk ;
real_T jg4llb22qp ; real_T mdvezsli2f ; real_T kpwzip0qkr ; real_T i0egb05npe
; real_T hbn3wofidd ; real_T lz4mhc2wmw ; real_T psop0at2i2 ; real_T
lvbouetvl0 ; real_T a3knef4jdk ; real_T cx31ocf55v ; real_T nx2sufq3e2 ;
real_T ajtviz0ljq ; real_T kttbuegokb ; real_T ieqm1pyewa ; real_T kgvyryvirg
; real_T blyiqhnnpp ; real_T gqapwmagix ; real_T ojkomtjtef ; real_T
npx2guddge ; real_T oe115a2c12 ; real_T bv3cqfte2u ; real_T iag3mhstj5 ;
real_T gdgqvzqi3s ; real_T mzlm31ndq4 ; real_T nfw1xvjuao ; real_T grbzwslprl
; real_T ga3dcd3mcw ; real_T ghxq40l2ug ; real_T dbj1i5x23t ; real_T
cz3cgc2itr ; real_T gfvbpatl1i ; real_T ekluq2waeq ; real_T bxe3wi2je0 ;
real_T jhbtahrhe1 ; real_T i3ivgql1y0 ; real_T ieenopzuxf ; real_T gr0ssxqm02
; real_T j1tiua0ae0 ; real_T lx2n40xdiy ; real_T izbh05fcoc ; real_T
c12mjtldmy ; real_T p3g4aboekx ; real_T elqdvx0lx1 [ 29 ] ; real_T ma0hzkvaed
; real_T b1lmlptsa3 ; real_T ofirj0ah5o ; real_T d33u4khwsu ; real_T
cangwd1mrq ; real_T j5edej5sxo ; real_T nmwpp4hddc ; real_T igrauynbgq ;
real_T g2u2q14kjv ; real_T hjyxtapflk ; real_T m3ewuq0gh5 ; real_T mlecxmoxbp
; real_T hmsh4hcdfv ; real_T kjry1gqsra ; real_T gdpdxykkmq ; real_T
jaq2voieba ; real_T jvn3wnmrsu ; real_T hughwyjgsh ; real_T dsnjjgktlo ;
real_T lopbnwklqv ; real_T hokz3elyjr ; real_T lf3j4iftqm ; real_T dnpy0xyenl
; real_T kvtgycann2 ; real_T m4rsg0jcnl ; real_T c4hjcvj4tj ; real_T
a2cp4o1ugm ; real_T maw1xh1ohw ; real_T pxibwz53g0 ; real_T le2n03pz5k ;
real_T lctyqcdwpo ; real_T abtohhuzxi ; real_T ppfyovyelw ; real_T mdwl1ho1az
; real_T ipetszo1bd ; real_T iwo0qdo2iq ; real_T lebronrhnr ; real_T
ecsecfgs4w ; real_T pfssuue2ir ; real_T cwcdpbzcel ; real_T pvx0seffxh ;
real_T ejpwmuory4 ; real_T aj1mc1yppx ; real_T hhebecm0fb ; real_T eoqzy3p3sp
; real_T pka3qzbcn3 ; real_T jev55rtigl ; real_T dxtb3xqamz ; } ZCV ; typedef
struct { ZCSigState fyojy5qztg ; ZCSigState ckirjq4irs ; ZCSigState
moi5ujt2m4 ; ZCSigState f03tkcmhr0 ; ZCSigState lunhr2xxb0 ; ZCSigState
kty1ao0csf ; ZCSigState klp5c5oug5 ; ZCSigState p2zcekh3xh ; } PrevZCX ;
typedef struct { rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ; struct P_ {
real_T Battery1_BatType ; real_T Battery2_BatType ; real_T Battery3_BatType ;
real_T Battery4_BatType ; real_T Battery5_BatType ; real_T Battery6_BatType ;
real_T Battery7_BatType ; real_T Battery8_BatType ; real_T PWM_Period ;
real_T PWM1_Period ; real_T PWM3_Period ; real_T PWM5_Period ; real_T
PWM6_Period ; real_T PWM7_Period ; real_T PWM8_Period ; real_T
OutputSamplePoints_Value [ 101 ] ; real_T OutputSamplePoints_Value_dbmmauqiwo
[ 101 ] ; real_T OutputSamplePoints_Value_bs0he10brt [ 101 ] ; real_T
OutputSamplePoints_Value_mkqnjleygm [ 101 ] ; real_T
OutputSamplePoints_Value_mmzz2j1vii [ 101 ] ; real_T
OutputSamplePoints_Value_h5oozv5nnj [ 101 ] ; real_T
OutputSamplePoints_Value_k42vy4v1xv [ 101 ] ; real_T Constant_Value ; real_T
Constant_Value_efypwvyyax ; real_T Constant_Value_ogegtmkzv0 ; real_T
Constant_Value_pbqzqfbpnm ; real_T Constant_Value_hu3rmuppbn ; real_T
Constant_Value_h5irp45zuu ; real_T Constant_Value_bksqnhysc0 ; real_T
Constant_Value_owtewy0ssm ; real_T Constant_Value_k5pwul1wle ; real_T
Constant_Value_kedzfrfegv ; real_T Constant_Value_opaksbgo21 ; real_T
Constant_Value_pp4lg2cwxs ; real_T Constant_Value_epq2rsx4ba ; real_T
Constant_Value_h45zreb2fb ; real_T Constant_Value_khiqevv1tc ; real_T
Constant_Value_crxssz3mu1 ; real_T Constant_Value_hr1h3melx3 ; real_T
Constant_Value_cf12bsal0m ; real_T Constant_Value_ksing41bve ; real_T
Constant_Value_psd4g00i4r ; real_T Constant_Value_gpi13dm1iq ; real_T
Constant_Value_ep2qfgttrh ; real_T Constant_Value_lyegm1i5cg ; real_T
Constant_Value_aujhkhzu0m ; real_T itinit1_InitialCondition ; real_T R2_Gain
; real_T Currentfilter_A ; real_T Currentfilter_C ; real_T
itinit_InitialCondition ; real_T inti_UpperSat ; real_T inti_LowerSat ;
real_T Gain_Gain ; real_T R3_Gain ; real_T Integrator2_IC ; real_T
Saturation_UpperSat ; real_T Saturation_LowerSat ; real_T BAL_A ; real_T
BAL_C ; real_T R1_Gain ; real_T itinit1_InitialCondition_l3j5mkh0dv ; real_T
R2_Gain_jrqfqsl4vo ; real_T Currentfilter_A_hazdhojaym ; real_T
Currentfilter_C_ldprzne4qv ; real_T itinit_InitialCondition_pv4h4vt0ps ;
real_T inti_UpperSat_itldayqrxp ; real_T inti_LowerSat_lz3gh0icex ; real_T
Gain_Gain_ozvwrv1fuy ; real_T R3_Gain_dgx1dntlxw ; real_T
Integrator2_IC_finfcihmmt ; real_T Saturation_UpperSat_lxx4j3fnoa ; real_T
Saturation_LowerSat_kwi433xk5g ; real_T BAL_A_cudqa1u03y ; real_T
BAL_C_pnvzkp4ayj ; real_T R1_Gain_k1h1x1zryv ; real_T
itinit1_InitialCondition_go30gfvhlp ; real_T R2_Gain_fij43s2whq ; real_T
Currentfilter_A_pyl0ygpghg ; real_T Currentfilter_C_hx4sknoziy ; real_T
itinit_InitialCondition_nf4pvnucgc ; real_T inti_UpperSat_nowwhgaxwk ; real_T
inti_LowerSat_cwekkzbyq1 ; real_T Gain_Gain_jbuudt1ftk ; real_T
R3_Gain_de1tgv0zzw ; real_T Integrator2_IC_kqbwod02j2 ; real_T
Saturation_UpperSat_blj3ug4rzx ; real_T Saturation_LowerSat_o0i20janpw ;
real_T BAL_A_n35zxahhei ; real_T BAL_C_ix2bm3qtha ; real_T R1_Gain_elo0441xsu
; real_T itinit1_InitialCondition_ia2mtm2bdv ; real_T R2_Gain_akgkexbqnd ;
real_T Currentfilter_A_bsszjj1hem ; real_T Currentfilter_C_muylregegy ;
real_T itinit_InitialCondition_atlhsczubb ; real_T inti_UpperSat_itde10ibkj ;
real_T inti_LowerSat_nb1wwuftgl ; real_T Gain_Gain_l5lbde12wy ; real_T
R3_Gain_nk0ujvzftk ; real_T Integrator2_IC_gtek0x1of0 ; real_T
Saturation_UpperSat_c0l2pkijii ; real_T Saturation_LowerSat_g1ovkjgj1x ;
real_T BAL_A_jgidwk4hmh ; real_T BAL_C_hfghx3gysd ; real_T R1_Gain_ay3u4mrv4p
; real_T itinit1_InitialCondition_po45v3mmic ; real_T R2_Gain_axv50jbqfg ;
real_T Currentfilter_A_o3r40a2fs0 ; real_T Currentfilter_C_e5mev0pk52 ;
real_T itinit_InitialCondition_mh2yj0opxq ; real_T inti_UpperSat_ff0nysnmjy ;
real_T inti_LowerSat_hzpmw3xl5s ; real_T Gain_Gain_a4qiy5rws3 ; real_T
R3_Gain_hslbhc5rsq ; real_T Integrator2_IC_iw5ohpmyuz ; real_T
Saturation_UpperSat_dr1jmbb0we ; real_T Saturation_LowerSat_haspwmkdbs ;
real_T BAL_A_oad34lr4nf ; real_T BAL_C_cq3wtorxkj ; real_T R1_Gain_bdgjwewy0w
; real_T itinit1_InitialCondition_bfkql3ev41 ; real_T R2_Gain_e5lq5jfqyz ;
real_T Currentfilter_A_n0q2cotnax ; real_T Currentfilter_C_gzd0zmcoyy ;
real_T itinit_InitialCondition_drzgzhkcxo ; real_T inti_UpperSat_cuyg3emce0 ;
real_T inti_LowerSat_l4lrtlmq4a ; real_T Gain_Gain_nfwhezh4mu ; real_T
R3_Gain_ozkjsk4x5h ; real_T Integrator2_IC_emw1ynvfly ; real_T
Saturation_UpperSat_oasdavgelo ; real_T Saturation_LowerSat_hlakhjokuc ;
real_T BAL_A_nrro44ikdu ; real_T BAL_C_c2hdnxiek4 ; real_T R1_Gain_bnqyizdjwz
; real_T itinit1_InitialCondition_ftzthjgsxo ; real_T R2_Gain_ejdzqjxpj5 ;
real_T Currentfilter_A_jhxjqdrxhi ; real_T Currentfilter_C_pwjctgaucg ;
real_T itinit_InitialCondition_j0a3v1ybuu ; real_T inti_UpperSat_p1ksyho442 ;
real_T inti_LowerSat_c2pdzacpit ; real_T Gain_Gain_cpenmhpyrf ; real_T
R3_Gain_eilrq2a1m2 ; real_T Integrator2_IC_pi2b1d0t3y ; real_T
Saturation_UpperSat_e2rewfpeer ; real_T Saturation_LowerSat_btlbcqipab ;
real_T BAL_A_jd4dvguj5h ; real_T BAL_C_nwvwd0ihf1 ; real_T R1_Gain_g4pre24jyp
; real_T itinit1_InitialCondition_auzkchjcmx ; real_T R2_Gain_bn5zry4edp ;
real_T Currentfilter_A_hin2vooinr ; real_T Currentfilter_C_a0gtd4kont ;
real_T itinit_InitialCondition_im5akoh0gb ; real_T inti_UpperSat_gge1msuajg ;
real_T inti_LowerSat_b5bkhbogxv ; real_T Gain_Gain_ot14m0p13e ; real_T
R3_Gain_molbysildp ; real_T Integrator2_IC_m4ngvk5rcj ; real_T
Saturation_UpperSat_pwhhuyqzpe ; real_T Saturation_LowerSat_gq5b2q5hog ;
real_T BAL_A_gvm0uualdo ; real_T BAL_C_bahpumao3b ; real_T R1_Gain_n5on15rj3k
; real_T StateSpace_P1_Size [ 2 ] ; real_T StateSpace_P1 [ 4275 ] ; real_T
StateSpace_P2_Size [ 2 ] ; real_T StateSpace_P2 [ 4 ] ; real_T
StateSpace_P3_Size [ 2 ] ; real_T StateSpace_P3 [ 7 ] ; real_T
StateSpace_P4_Size [ 2 ] ; real_T StateSpace_P4 [ 3705 ] ; real_T
StateSpace_P5_Size [ 2 ] ; real_T StateSpace_P5 [ 56 ] ; real_T
StateSpace_P6_Size [ 2 ] ; real_T StateSpace_P6 [ 28 ] ; real_T
StateSpace_P7_Size [ 2 ] ; real_T StateSpace_P7 [ 28 ] ; real_T
StateSpace_P8_Size [ 2 ] ; real_T StateSpace_P8 [ 28 ] ; real_T
StateSpace_P9_Size [ 2 ] ; real_T StateSpace_P9 ; real_T StateSpace_P10_Size
[ 2 ] ; real_T StateSpace_P10 ; real_T R4_Gain ; real_T
Saturation_UpperSat_pcz043fnep ; real_T Saturation_LowerSat_b05y2t0vvl ;
real_T R4_Gain_ayggl2vp1n ; real_T Saturation_UpperSat_aqwzuangfk ; real_T
Saturation_LowerSat_bcd3czsgyq ; real_T Switch_Threshold ; real_T
R4_Gain_ckkisgzyfx ; real_T Saturation_UpperSat_i3x3oscagf ; real_T
Saturation_LowerSat_gnz45aadu0 ; real_T R4_Gain_nfptou1h22 ; real_T
Saturation_UpperSat_luxvjfmfd3 ; real_T Saturation_LowerSat_mqcesji40p ;
real_T R4_Gain_e51nv5aiyc ; real_T Saturation_UpperSat_p4wbgcsokm ; real_T
Saturation_LowerSat_gdbbvpyvzg ; real_T R4_Gain_l2wha3sgrh ; real_T
Saturation_UpperSat_iofvqb3bhc ; real_T Saturation_LowerSat_ob0aofpwnu ;
real_T R4_Gain_g4hvk30k1k ; real_T Saturation_UpperSat_f2amnkjsa0 ; real_T
Saturation_LowerSat_lbyytgqsae ; real_T R4_Gain_dwzv1lgknn ; real_T
Saturation_UpperSat_dtvs1qra3o ; real_T Saturation_LowerSat_huwlm3xk3n ;
real_T Switch1_Threshold ; real_T Switch2_Threshold ; real_T
Switch3_Threshold ; real_T Switch6_Threshold ; real_T Switch4_Threshold ;
real_T Switch7_Threshold ; real_T Switch5_Threshold ; real_T
Switch9_Threshold ; real_T Switch8_Threshold ; real_T
donotdeletethisgain_Gain ; real_T R_Gain ; real_T
donotdeletethisgain_Gain_o42imifl5k ; real_T R_Gain_g4gmpqe5wx ; real_T
donotdeletethisgain_Gain_fjipbfzkks ; real_T R_Gain_biqz0al5hr ; real_T
donotdeletethisgain_Gain_ave45anr4u ; real_T R_Gain_bq04dmcpzt ; real_T
donotdeletethisgain_Gain_mvbq03z0iq ; real_T R_Gain_mh2yy541ef ; real_T
donotdeletethisgain_Gain_kdw2eb0k3g ; real_T R_Gain_k35mp2rvup ; real_T
donotdeletethisgain_Gain_jquqjrzlip ; real_T R_Gain_chtk1x1i0w ; real_T
donotdeletethisgain_Gain_dywzmacz1o ; real_T R_Gain_cwdppwgit4 ; real_T
Gain4_Gain ; real_T Gain1_Gain ; real_T Gain2_Gain ; real_T
Gain4_Gain_kh00znyazs ; real_T Gain1_Gain_og11bwmhu2 ; real_T
Gain2_Gain_m4x3vq3y1f ; real_T Gain4_Gain_fstjjgzlds ; real_T
Gain1_Gain_anymdqpqln ; real_T Gain2_Gain_jptbha03po ; real_T
Gain4_Gain_n2oajsg4xg ; real_T Gain1_Gain_baecfd2g1g ; real_T
Gain2_Gain_fe3eihrk0b ; real_T Gain4_Gain_j4eqtusam3 ; real_T
Gain1_Gain_dq4vkdpk0h ; real_T Gain2_Gain_of2pa5ka31 ; real_T
Gain4_Gain_l0ptdzkgeb ; real_T Gain1_Gain_c5i2vccxwe ; real_T
Gain2_Gain_jyxvaqqzap ; real_T Gain4_Gain_pdhrsclrmp ; real_T
Gain1_Gain_hhtznyj2s2 ; real_T Gain2_Gain_hm05ohnj0y ; real_T
Gain4_Gain_bbkx0f2eye ; real_T Gain1_Gain_at5pojvma0 ; real_T
Gain2_Gain_plpbrgefjj ; real_T donotdeletethisgain_Gain_jslrw2wpeb ; real_T
donotdeletethisgain_Gain_hwxhghbjtm ; real_T Constant_Value_jorngiczgp ;
real_T Constant1_Value ; real_T Constant12_Value ; real_T Constant9_Value ;
real_T Constant1_Value_ks0gbwvaxk ; real_T Constant2_Value ; real_T
Constant3_Value ; real_T Constant4_Value ; real_T Constant_Value_fzmb45jy2r ;
real_T Constant1_Value_jelmmtr1rj ; real_T Constant12_Value_df3z3yuypl ;
real_T Constant9_Value_bfo0fnc5l1 ; real_T Constant1_Value_jxqfbvs00y ;
real_T Constant2_Value_nbkvr3eqsy ; real_T Constant3_Value_k030zkojhy ;
real_T Constant4_Value_p1xz0cpgth ; real_T Constant_Value_kiu123temw ; real_T
Constant1_Value_jj3f5fu3xp ; real_T Constant12_Value_ktnzmkcekm ; real_T
Constant9_Value_nhyzz1ckmw ; real_T Constant1_Value_gbfcrdkgqa ; real_T
Constant2_Value_gnk2tjoo5o ; real_T Constant3_Value_hat1prtoip ; real_T
Constant4_Value_cmgjzabbd1 ; real_T Constant_Value_em2zyolrnm ; real_T
Constant1_Value_myhrse5szs ; real_T Constant12_Value_jkrk5dvljw ; real_T
Constant9_Value_ffsooduwum ; real_T Constant1_Value_am3al2n15v ; real_T
Constant2_Value_odhbgl2n1s ; real_T Constant3_Value_mujtf1guv4 ; real_T
Constant4_Value_ohbtynzx54 ; real_T Constant_Value_pfu1thap3i ; real_T
Constant1_Value_h1thd4w1zg ; real_T Constant12_Value_oujd2whfki ; real_T
Constant9_Value_bcezbzp4a1 ; real_T Constant1_Value_ny1xdqiske ; real_T
Constant2_Value_ppmjeluned ; real_T Constant3_Value_kuyjih2run ; real_T
Constant4_Value_om2zghpbx3 ; real_T Constant_Value_mnsc2xmcnp ; real_T
Constant1_Value_fcmat31m3p ; real_T Constant12_Value_l40vqppf0r ; real_T
Constant9_Value_khmvv2oadi ; real_T Constant1_Value_mv1dwtlwtz ; real_T
Constant2_Value_hhcyqz43te ; real_T Constant3_Value_fma5g13bsz ; real_T
Constant4_Value_lcmf40k0jk ; real_T Constant_Value_diqvfq2vok ; real_T
Constant1_Value_j1ihyekgnt ; real_T Constant12_Value_frutixtppx ; real_T
Constant9_Value_hbi2xzqgvf ; real_T Constant1_Value_nfwykf0vow ; real_T
Constant2_Value_lwxj2lq0w4 ; real_T Constant3_Value_ouq0slsocc ; real_T
Constant4_Value_jjkyxucjzh ; real_T Constant_Value_avhibee4iu ; real_T
Constant1_Value_mntemyjbjb ; real_T Constant12_Value_gycmvngwdn ; real_T
Constant9_Value_lgn0aviuoi ; real_T Constant1_Value_h3fhvhzpts ; real_T
Constant2_Value_dgpgyrzaqa ; real_T Constant3_Value_fn3ludrege ; real_T
Constant4_Value_oq3sj0rsir ; real_T Constant_Value_e1gwiy1pb3 ; real_T
Constant1_Value_mf4xbwjhdv ; real_T Constant10_Value ; real_T
Constant11_Value ; real_T Constant12_Value_c2qvybcfaa ; real_T
Constant13_Value ; real_T Constant14_Value ; real_T Constant15_Value ; real_T
Constant16_Value ; real_T Constant2_Value_e4jyxae25b ; real_T
Constant3_Value_bkb3mktfvw ; real_T Constant4_Value_fxnxt0eszt ; real_T
Constant5_Value ; real_T Constant6_Value ; real_T Constant7_Value ; real_T
Constant8_Value ; real_T Constant9_Value_crabpzohh2 ; real_T gate_Value ;
real_T gate_Value_e2pzllcxv0 ; real_T gate_Value_jpjtjqpsyx ; real_T
gate_Value_cczcurubvx ; real_T gate_Value_p3h3pv0zwg ; real_T
gate_Value_ahx5cowvm0 ; real_T gate_Value_hob43axlzj ; real_T
gate_Value_odvaswnitz ; real_T gate_Value_hrisjp3q0m ; real_T
gate_Value_ggng0gfgd5 ; real_T gate_Value_ppgtupoipm ; real_T
gate_Value_iwryy13tik ; real_T gate_Value_o02a13bzdb ; real_T
gate_Value_ncgxatpho2 ; } ; extern const real_T activeBalancing4_RGND ;
extern const char * RT_MEMORY_ALLOCATION_ERROR ; extern B rtB ; extern X rtX
; extern DW rtDW ; extern PrevZCX rtPrevZCX ; extern P rtP ; extern mxArray *
mr_activeBalancing4_GetDWork ( ) ; extern void mr_activeBalancing4_SetDWork (
const mxArray * ssDW ) ; extern mxArray *
mr_activeBalancing4_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * activeBalancing4_GetCAPIStaticMap ( void ) ;
extern SimStruct * const rtS ; extern const int_T gblNumToFiles ; extern
const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ; extern
rtInportTUtable * gblInportTUtables ; extern const char * gblInportFileName ;
extern const int_T gblNumRootInportBlks ; extern const int_T
gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ; extern
const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [ ] ;
extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
