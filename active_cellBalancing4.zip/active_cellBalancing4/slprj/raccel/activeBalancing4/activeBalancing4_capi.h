#ifndef RTW_HEADER_activeBalancing4_capi_h
#define RTW_HEADER_activeBalancing4_capi_h
#include "activeBalancing4.h"
extern void activeBalancing4_InitializeDataMapInfo ( void ) ;
#endif
