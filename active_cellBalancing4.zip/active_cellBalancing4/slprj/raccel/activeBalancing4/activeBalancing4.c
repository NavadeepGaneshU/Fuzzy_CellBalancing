#include "rt_logging_mmi.h"
#include "activeBalancing4_capi.h"
#include <math.h>
#include "activeBalancing4.h"
#include "activeBalancing4_private.h"
#include "activeBalancing4_dt.h"
#include "sfcn_loader_c_api.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 9 , & stopRequested ) ; }
rtExtModeShutdown ( 9 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 0 ; int_T gbl_raccel_NumST = 10 ; const char_T
* gbl_raccel_Version = "9.5 (R2021a) 14-Nov-2020" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; const char *
raccelLoadInputsAndAperiodicHitTimes ( SimStruct * S , const char *
inportFileName , int * matFileFormat ) { return rt_RAccelReadInportsMatFile (
S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
const real_T activeBalancing4_RGND = 0.0 ; B rtB ; X rtX ; DW rtDW ; PrevZCX
rtPrevZCX ; static SimStruct model_S ; SimStruct * const rtS = & model_S ;
static void fda4hes5b2 ( const real_T x [ 101 ] , const real_T params [ 3 ] ,
real_T y [ 101 ] ) ; static real_T cgvkp0zasm ( real_T x , const real_T
params [ 3 ] ) ; static void nvjgycdn5t ( const real_T x [ 101 ] , const
real_T params [ 3 ] , real_T y [ 101 ] ) ; static void fda4hes5b2 ( const
real_T x [ 101 ] , const real_T params [ 3 ] , real_T y [ 101 ] ) { real_T a
; real_T b ; real_T c ; real_T x_p ; int32_T i ; a = params [ 0 ] ; b =
params [ 1 ] ; c = params [ 2 ] ; for ( i = 0 ; i < 101 ; i ++ ) { x_p = x [
i ] ; y [ i ] = 0.0 ; if ( ( a != b ) && ( a < x_p ) && ( x_p < b ) ) { y [ i
] = 1.0 / ( b - a ) * ( x_p - a ) ; } if ( ( b != c ) && ( b < x_p ) && ( x_p
< c ) ) { y [ i ] = 1.0 / ( c - b ) * ( c - x_p ) ; } if ( x_p == b ) { y [ i
] = 1.0 ; } } } void nntoyhbqoo ( real_T ldr5fsv2db , real_T jyjw50rcww ,
const real_T hmk0hk3hhl [ 9 ] , const real_T d0rdr2qrjz [ 101 ] , bsxn3352ub
* localB ) { real_T outputMFCache [ 505 ] ; real_T tmp [ 101 ] ; real_T tmp_g
[ 101 ] ; real_T tmp_i [ 101 ] ; real_T tmp_m [ 101 ] ; real_T tmp_p [ 101 ]
; real_T tmp_e [ 3 ] ; real_T mfVal ; real_T x_idx_0 ; real_T x_idx_1 ;
int32_T i ; int32_T sampleID ; static const real_T b [ 3 ] = { 0.04167 , 0.25
, 0.4583 } ; static const real_T c [ 3 ] = { 0.2917 , 0.5 , 0.7083 } ; static
const int8_T d [ 9 ] = { 1 , 4 , 2 , 2 , 5 , 3 , 3 , 3 , 3 } ; localB ->
c5zsuqyizw [ 0 ] = ldr5fsv2db ; localB -> c5zsuqyizw [ 1 ] = jyjw50rcww ;
fda4hes5b2 ( d0rdr2qrjz , b , tmp ) ; fda4hes5b2 ( d0rdr2qrjz , c , tmp_p ) ;
tmp_e [ 0 ] = 0.5417 ; tmp_e [ 1 ] = 0.75 ; tmp_e [ 2 ] = 0.9583 ; fda4hes5b2
( d0rdr2qrjz , tmp_e , tmp_i ) ; tmp_e [ 0 ] = 0.25 ; tmp_e [ 1 ] = 0.375 ;
tmp_e [ 2 ] = 0.5 ; fda4hes5b2 ( d0rdr2qrjz , tmp_e , tmp_m ) ; tmp_e [ 0 ] =
0.5 ; tmp_e [ 1 ] = 0.625 ; tmp_e [ 2 ] = 0.75 ; fda4hes5b2 ( d0rdr2qrjz ,
tmp_e , tmp_g ) ; for ( i = 0 ; i < 101 ; i ++ ) { localB -> gz0uq5kqkr [ i ]
= 0.0 ; outputMFCache [ 5 * i ] = tmp [ i ] ; outputMFCache [ 5 * i + 1 ] =
tmp_p [ i ] ; outputMFCache [ 5 * i + 2 ] = tmp_i [ i ] ; outputMFCache [ 5 *
i + 3 ] = tmp_m [ i ] ; outputMFCache [ 5 * i + 4 ] = tmp_g [ i ] ; } for ( i
= 0 ; i < 9 ; i ++ ) { x_idx_1 = hmk0hk3hhl [ i ] ; for ( sampleID = 0 ;
sampleID < 101 ; sampleID ++ ) { x_idx_0 = outputMFCache [ ( 5 * sampleID + d
[ i ] ) - 1 ] ; if ( ( x_idx_0 > x_idx_1 ) || ( muDoubleScalarIsNaN ( x_idx_0
) && ( ! muDoubleScalarIsNaN ( x_idx_1 ) ) ) ) { mfVal = x_idx_1 ; } else {
mfVal = x_idx_0 ; } x_idx_0 = localB -> gz0uq5kqkr [ sampleID ] ; if ( (
x_idx_0 < mfVal ) || ( muDoubleScalarIsNaN ( x_idx_0 ) && ( !
muDoubleScalarIsNaN ( mfVal ) ) ) ) { localB -> gz0uq5kqkr [ sampleID ] =
mfVal ; } else { localB -> gz0uq5kqkr [ sampleID ] = x_idx_0 ; } } } } static
real_T cgvkp0zasm ( real_T x , const real_T params [ 3 ] ) { real_T y ; y =
0.0 ; if ( ( params [ 0 ] != params [ 1 ] ) && ( params [ 0 ] < x ) && ( x <
params [ 1 ] ) ) { y = 1.0 / ( params [ 1 ] - params [ 0 ] ) * ( x - params [
0 ] ) ; } if ( ( params [ 1 ] != params [ 2 ] ) && ( params [ 1 ] < x ) && (
x < params [ 2 ] ) ) { y = 1.0 / ( params [ 2 ] - params [ 1 ] ) * ( params [
2 ] - x ) ; } if ( x == params [ 1 ] ) { y = 1.0 ; } return y ; } static void
nvjgycdn5t ( const real_T x [ 101 ] , const real_T params [ 3 ] , real_T y [
101 ] ) { real_T a ; real_T b ; real_T c ; real_T x_p ; int32_T i ; a =
params [ 0 ] ; b = params [ 1 ] ; c = params [ 2 ] ; for ( i = 0 ; i < 101 ;
i ++ ) { x_p = x [ i ] ; y [ i ] = 0.0 ; if ( ( a != b ) && ( a < x_p ) && (
x_p < b ) ) { y [ i ] = 1.0 / ( b - a ) * ( x_p - a ) ; } if ( ( b != c ) &&
( b < x_p ) && ( x_p < c ) ) { y [ i ] = 1.0 / ( c - b ) * ( c - x_p ) ; } if
( x_p == b ) { y [ i ] = 1.0 ; } } } void MdlInitialize ( void ) { boolean_T
tmp ; rtDW . ca5hlnq0yv = rtP . itinit1_InitialCondition ; rtX . plb5id0v2x =
0.0 ; rtDW . capftuiedr = rtP . itinit_InitialCondition ; rtDW . mwvlfj3tnw =
1 ; if ( ssIsFirstInitCond ( rtS ) ) { rtX . lbkltw2njc = 0.0 ; tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . mwvlfj3tnw = ! tmp ; }
else { rtDW . mwvlfj3tnw = 1 ; } rtX . nxoiklb1cp = 0.0 ; } rtX . fzv1e1p3mc
= rtP . Integrator2_IC ; rtX . fg5c5z2vbx = 0.0 ; rtDW . dausu4yb0r = rtP .
itinit1_InitialCondition_l3j5mkh0dv ; rtX . bx04s5qbio = 0.0 ; rtDW .
nxcbrqbg4s = rtP . itinit_InitialCondition_pv4h4vt0ps ; rtDW . jcfoqfv3fu = 1
; if ( ssIsFirstInitCond ( rtS ) ) { tmp = slIsRapidAcceleratorSimulating ( )
; if ( tmp ) { tmp = ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW .
jcfoqfv3fu = ! tmp ; } else { rtDW . jcfoqfv3fu = 1 ; } rtX . bxy3w4qxj2 =
0.0 ; } rtX . b3n5hgntky = rtP . Integrator2_IC_finfcihmmt ; rtX . cgxanjfmip
= 0.0 ; rtDW . nb3lw1dts4 = rtP . itinit1_InitialCondition_go30gfvhlp ; rtX .
lfvzsuhskj = 0.0 ; rtDW . oqfmlletk1 = rtP .
itinit_InitialCondition_nf4pvnucgc ; rtDW . p20ta3sfdz = 1 ; if (
ssIsFirstInitCond ( rtS ) ) { tmp = slIsRapidAcceleratorSimulating ( ) ; if (
tmp ) { tmp = ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . p20ta3sfdz =
! tmp ; } else { rtDW . p20ta3sfdz = 1 ; } rtX . dqfnkbb0xq = 0.0 ; } rtX .
chmdgjvbrk = rtP . Integrator2_IC_kqbwod02j2 ; rtX . iximkvmpst = 0.0 ; rtDW
. b1blljt5i4 = rtP . itinit1_InitialCondition_ia2mtm2bdv ; rtX . esshhzn0st =
0.0 ; rtDW . eude00gfzn = rtP . itinit_InitialCondition_atlhsczubb ; rtDW .
oqj3skvfcq = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . oqj3skvfcq = ! tmp ; }
else { rtDW . oqj3skvfcq = 1 ; } rtX . cr4uxyxqlm = 0.0 ; } rtX . ohptd3ifop
= rtP . Integrator2_IC_gtek0x1of0 ; rtX . ik2jrqp3yy = 0.0 ; rtDW .
omhuox45k5 = rtP . itinit1_InitialCondition_po45v3mmic ; rtX . j5rh0u0prg =
0.0 ; rtDW . l5yuu2mi2t = rtP . itinit_InitialCondition_mh2yj0opxq ; rtDW .
aj4yhj42qr = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . aj4yhj42qr = ! tmp ; }
else { rtDW . aj4yhj42qr = 1 ; } rtX . bnmkr55uji = 0.0 ; } rtX . f1hbi1sd1q
= rtP . Integrator2_IC_iw5ohpmyuz ; rtX . kkgf3fitxr = 0.0 ; rtDW .
oteopngiwv = rtP . itinit1_InitialCondition_bfkql3ev41 ; rtX . batnhulphm =
0.0 ; rtDW . jbkhseznjs = rtP . itinit_InitialCondition_drzgzhkcxo ; rtDW .
k4l2ij22e5 = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . k4l2ij22e5 = ! tmp ; }
else { rtDW . k4l2ij22e5 = 1 ; } rtX . ducd1mygi5 = 0.0 ; } rtX . lulwdnmna3
= rtP . Integrator2_IC_emw1ynvfly ; rtX . opnxmo5ky2 = 0.0 ; rtDW .
g0xibfhryj = rtP . itinit1_InitialCondition_ftzthjgsxo ; rtX . kec03nv1yd =
0.0 ; rtDW . dyomnt0iya = rtP . itinit_InitialCondition_j0a3v1ybuu ; rtDW .
gbegstnyrm = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . gbegstnyrm = ! tmp ; }
else { rtDW . gbegstnyrm = 1 ; } rtX . mludnzmfko = 0.0 ; } rtX . a2azuhp5qh
= rtP . Integrator2_IC_pi2b1d0t3y ; rtX . c4c3igik4x = 0.0 ; rtDW .
mmeejs3fon = rtP . itinit1_InitialCondition_auzkchjcmx ; rtX . jgg0wj1zhe =
0.0 ; rtDW . cixbj0ezqf = rtP . itinit_InitialCondition_im5akoh0gb ; rtDW .
ioqp4ngatr = 1 ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . ioqp4ngatr = ! tmp ; }
else { rtDW . ioqp4ngatr = 1 ; } } rtX . fhoa1aghtu = rtP .
Integrator2_IC_m4ngvk5rcj ; rtX . kxckn4j1uq = 0.0 ; { SimStruct * rts =
ssGetSFunction ( rtS , 0 ) ; sfcnInitializeConditions ( rts ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } rtDW . bchydutg41 =
ssGetTaskTime ( rtS , 7 ) ; rtDW . ke5obrhhqt = true ; rtDW . k5uuyepbrp =
true ; rtDW . man13mro5e = ssGetTaskTime ( rtS , 7 ) ; rtDW . alzjyrx0kg = (
rtMinusInf ) ; rtDW . axsolhspww = 0ULL ; rtDW . a4qh2syf5f = true ; rtDW .
ptyhlovodi = true ; rtDW . aggfvdda1e = ssGetTaskTime ( rtS , 8 ) ; rtDW .
dimggz5k1i = true ; rtDW . dgtx3pxebh = true ; rtDW . kmgw2sai2b =
ssGetTaskTime ( rtS , 8 ) ; rtDW . aegiye3tn1 = ( rtMinusInf ) ; rtDW .
jkukkxhvxl = 0ULL ; rtDW . nerp2skw04 = true ; rtDW . fhpyfq1cbi = true ;
rtDW . k0tqwauzp3 = ssGetTaskTime ( rtS , 2 ) ; rtDW . fqogqsl1qn = true ;
rtDW . omg5wivauv = true ; rtDW . nifwcsv1v1 = ssGetTaskTime ( rtS , 2 ) ;
rtDW . grio4yjtpl = ( rtMinusInf ) ; rtDW . dxioy35srz = 0ULL ; rtDW .
ff1zu2lxej = true ; rtDW . bxzckcwnmi = true ; rtDW . momrzwq4pr =
ssGetTaskTime ( rtS , 3 ) ; rtDW . n33t0mlcdo = true ; rtDW . puzlpon25o =
true ; rtDW . hfqfe1a1s5 = ssGetTaskTime ( rtS , 3 ) ; rtDW . ifbin5pxrr = (
rtMinusInf ) ; rtDW . klbt1o41jo = 0ULL ; rtDW . m4qezscalw = true ; rtDW .
ctjzi2o40d = true ; rtDW . k2nrmdtvq3 = ssGetTaskTime ( rtS , 6 ) ; rtDW .
e3ay5unpbh = true ; rtDW . bgieyqg154 = true ; rtDW . ff25ka4wdp =
ssGetTaskTime ( rtS , 6 ) ; rtDW . cutbprvcd3 = ( rtMinusInf ) ; rtDW .
bfgv0ou4np = 0ULL ; rtDW . ozfvlojj1n = true ; rtDW . fgsjlt3z00 = true ;
rtDW . bt4oyd503e = ssGetTaskTime ( rtS , 5 ) ; rtDW . hbjqhzro5y = true ;
rtDW . os10rt4vp3 = true ; rtDW . azpppdzavz = ssGetTaskTime ( rtS , 5 ) ;
rtDW . a30dvj5d1n = ( rtMinusInf ) ; rtDW . mqmlslbwtt = 0ULL ; rtDW .
noglx0ol2f = true ; rtDW . o1s050yt3g = true ; rtDW . gmjjnhltdk =
ssGetTaskTime ( rtS , 4 ) ; rtDW . o1qidfzosp = true ; rtDW . ngljbafwbt =
true ; rtDW . dtmajsg54k = ssGetTaskTime ( rtS , 4 ) ; rtDW . magdrvjhlp = (
rtMinusInf ) ; rtDW . jqfoucolpw = 0ULL ; rtDW . iknrj0yq2v = true ; rtDW .
l4uscn224x = true ; } void MdlEnable ( void ) { _ssSetSampleHit ( rtS , 7 , 1
) ; _ssSetTaskTime ( rtS , 7 , ssGetT ( rtS ) ) ; _ssSetVarNextHitTime ( rtS
, 5 , ssGetT ( rtS ) ) ; ; rtDW . ke5obrhhqt = true ; rtDW . k5uuyepbrp =
true ; rtDW . man13mro5e = ssGetTaskTime ( rtS , 7 ) ; rtDW . alzjyrx0kg = (
rtMinusInf ) ; rtDW . axsolhspww = 0ULL ; _ssSetSampleHit ( rtS , 8 , 1 ) ;
_ssSetTaskTime ( rtS , 8 , ssGetT ( rtS ) ) ; _ssSetVarNextHitTime ( rtS , 6
, ssGetT ( rtS ) ) ; ; rtDW . dimggz5k1i = true ; rtDW . dgtx3pxebh = true ;
rtDW . kmgw2sai2b = ssGetTaskTime ( rtS , 8 ) ; rtDW . aegiye3tn1 = (
rtMinusInf ) ; rtDW . jkukkxhvxl = 0ULL ; _ssSetSampleHit ( rtS , 2 , 1 ) ;
_ssSetTaskTime ( rtS , 2 , ssGetT ( rtS ) ) ; _ssSetVarNextHitTime ( rtS , 0
, ssGetT ( rtS ) ) ; ; rtDW . fqogqsl1qn = true ; rtDW . omg5wivauv = true ;
rtDW . nifwcsv1v1 = ssGetTaskTime ( rtS , 2 ) ; rtDW . grio4yjtpl = (
rtMinusInf ) ; rtDW . dxioy35srz = 0ULL ; _ssSetSampleHit ( rtS , 3 , 1 ) ;
_ssSetTaskTime ( rtS , 3 , ssGetT ( rtS ) ) ; _ssSetVarNextHitTime ( rtS , 1
, ssGetT ( rtS ) ) ; ; rtDW . n33t0mlcdo = true ; rtDW . puzlpon25o = true ;
rtDW . hfqfe1a1s5 = ssGetTaskTime ( rtS , 3 ) ; rtDW . ifbin5pxrr = (
rtMinusInf ) ; rtDW . klbt1o41jo = 0ULL ; _ssSetSampleHit ( rtS , 6 , 1 ) ;
_ssSetTaskTime ( rtS , 6 , ssGetT ( rtS ) ) ; _ssSetVarNextHitTime ( rtS , 4
, ssGetT ( rtS ) ) ; ; rtDW . e3ay5unpbh = true ; rtDW . bgieyqg154 = true ;
rtDW . ff25ka4wdp = ssGetTaskTime ( rtS , 6 ) ; rtDW . cutbprvcd3 = (
rtMinusInf ) ; rtDW . bfgv0ou4np = 0ULL ; _ssSetSampleHit ( rtS , 5 , 1 ) ;
_ssSetTaskTime ( rtS , 5 , ssGetT ( rtS ) ) ; _ssSetVarNextHitTime ( rtS , 3
, ssGetT ( rtS ) ) ; ; rtDW . hbjqhzro5y = true ; rtDW . os10rt4vp3 = true ;
rtDW . azpppdzavz = ssGetTaskTime ( rtS , 5 ) ; rtDW . a30dvj5d1n = (
rtMinusInf ) ; rtDW . mqmlslbwtt = 0ULL ; _ssSetSampleHit ( rtS , 4 , 1 ) ;
_ssSetTaskTime ( rtS , 4 , ssGetT ( rtS ) ) ; _ssSetVarNextHitTime ( rtS , 2
, ssGetT ( rtS ) ) ; ; rtDW . o1qidfzosp = true ; rtDW . ngljbafwbt = true ;
rtDW . dtmajsg54k = ssGetTaskTime ( rtS , 4 ) ; rtDW . magdrvjhlp = (
rtMinusInf ) ; rtDW . jqfoucolpw = 0ULL ; } void MdlStart ( void ) { { bool
externalInputIsInDatasetFormat = false ; void * pISigstreamManager =
rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} { { { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "SOC2" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "<SOC (%)>" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"activeBalancing4/Bus Selector1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "SOC2" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . m4a1slsbsw . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "bc928828-f7de-48f6-9ec8-b6dc569c33a2" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. m4a1slsbsw . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . m4a1slsbsw
. AQHandles , "Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime
( rtDW . m4a1slsbsw . AQHandles , ssGetTaskTime ( rtS , 1 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . m4a1slsbsw . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . m4a1slsbsw . AQHandles ,
loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } } { { { { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"activeBalancing4/Bus Selector1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. lb3ykh1ivj . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"dc40be72-4db7-4137-bbe8-15e107fa0caa" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . lb3ykh1ivj . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . lb3ykh1ivj . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . lb3ykh1ivj .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . lb3ykh1ivj . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . lb3ykh1ivj . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC3" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing4/Bus Selector2" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC3" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. idjooi12be . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"a514b898-4976-4bee-a1ac-8413caef0228" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . idjooi12be . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . idjooi12be . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . idjooi12be .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . idjooi12be . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . idjooi12be . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing4/Bus Selector2"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. nfq5r1c2nf . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"141e062c-9d6d-4d13-9c94-8b4bba7503c3" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . nfq5r1c2nf . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . nfq5r1c2nf . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . nfq5r1c2nf .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . nfq5r1c2nf . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . nfq5r1c2nf . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC4" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing4/Bus Selector3" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC4" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. l1ntzlm3em . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"64e5b82e-3a05-4427-8055-b0dc4a4e5225" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . l1ntzlm3em . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . l1ntzlm3em . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . l1ntzlm3em .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . l1ntzlm3em . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . l1ntzlm3em . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing4/Bus Selector3"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. cjeepns1kp . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"629ccaab-13f8-47b0-b182-ebe006cd73e6" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . cjeepns1kp . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . cjeepns1kp . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . cjeepns1kp .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . cjeepns1kp . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . cjeepns1kp . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC5" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing4/Bus Selector4" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC5" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. p3mdqwq4kn . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"e753d860-6817-4def-9046-bcc29b14f700" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . p3mdqwq4kn . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . p3mdqwq4kn . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . p3mdqwq4kn .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . p3mdqwq4kn . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . p3mdqwq4kn . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing4/Bus Selector4"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ad2wzhmkkk . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"4a575a04-7830-4cab-ba5a-587d9c457182" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . ad2wzhmkkk . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . ad2wzhmkkk . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . ad2wzhmkkk .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . ad2wzhmkkk . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . ad2wzhmkkk . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC6" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing4/Bus Selector5" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC6" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. cp2sky53da . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"787acc7d-a86d-4c04-80cf-1f9aa26e431c" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . cp2sky53da . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . cp2sky53da . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . cp2sky53da .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . cp2sky53da . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . cp2sky53da . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing4/Bus Selector5"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. mlqhgw44yh . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"f8060c0b-1c64-402b-86a2-76b172af87d1" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . mlqhgw44yh . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . mlqhgw44yh . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . mlqhgw44yh .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . mlqhgw44yh . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . mlqhgw44yh . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC7" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing4/Bus Selector6" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC7" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ozkqasf5op . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"c031474f-93a1-4eac-80be-ad3b1962979f" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . ozkqasf5op . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . ozkqasf5op . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . ozkqasf5op .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . ozkqasf5op . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . ozkqasf5op . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing4/Bus Selector6"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. md2q01fzov . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"dedb3efc-2526-4d0d-bd1c-4d59a35bf5ca" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . md2q01fzov . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . md2q01fzov . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . md2q01fzov .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . md2q01fzov . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . md2q01fzov . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC8" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing4/Bus Selector7" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "SOC8" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. btuvwmnygy . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"091b3694-226d-4416-8431-65890fa17a37" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . btuvwmnygy . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . btuvwmnygy . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . btuvwmnygy .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . btuvwmnygy . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . btuvwmnygy . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Voltage (V)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars ( "activeBalancing4/Bus Selector7"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<Voltage (V)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. av20b02ile . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"6557b1a0-c7c9-4ef6-b1c0-052eb135f958" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . av20b02ile . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . av20b02ile . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . av20b02ile .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . av20b02ile . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . av20b02ile . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"SOC1" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "activeBalancing4/Bus Selector" ) ; sdiLabelU blockSID
= sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( ""
) ; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "SOC1" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . o40s2uuuft . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "3030bc16-1ac7-4b16-a924-f1470b0899e9" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. o40s2uuuft . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . o40s2uuuft
. AQHandles , "Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime
( rtDW . o40s2uuuft . AQHandles , ssGetTaskTime ( rtS , 1 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . o40s2uuuft . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . o40s2uuuft . AQHandles ,
loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } } { SimStruct * rts = ssGetSFunction ( rtS
, 0 ) ; sfcnStart ( rts ) ; if ( ssGetErrorStatus ( rts ) != ( NULL ) )
return ; } MdlInitialize ( ) ; MdlEnable ( ) ; } void MdlOutputs ( int_T tid
) { real_T ga5u1ceorf ; real_T dxudqq1xoi ; real_T ivey5iysam ; real_T
mglwtemyk2 ; real_T c0jbv4sysx ; real_T ej0ygnkxr4 ; real_T gkcx3eabtv [ 9 ]
; real_T h03e2sx5pj [ 9 ] ; real_T fhaaypqjak [ 9 ] ; real_T kato2byaio [ 9 ]
; real_T klxmjdyb0g [ 9 ] ; real_T lbz4hcogk1 [ 9 ] ; real_T i1gb02weu2 [ 101
] ; real_T tmp_e [ 101 ] ; real_T tmp_f [ 101 ] ; real_T tmp_g [ 101 ] ;
real_T tmp_i [ 101 ] ; real_T tmp_j [ 101 ] ; real_T tmp_m [ 101 ] ; real_T
ajfnmu1awg [ 10 ] ; real_T inputMFCache [ 8 ] ; real_T inputMFCache_p [ 6 ] ;
real_T tmp_p [ 3 ] ; real_T dSOC5_6 ; real_T dSOC7_8 ; real_T jmuz0todoh ;
real_T k0qu5tzxih ; real_T mVal ; int32_T i ; int32_T inputID ; int8_T b ;
boolean_T tmp ; ZCEventType zcEvent ; static const real_T c [ 3 ] = { 0.8334
, 5.0 , 9.166 } ; static const real_T d [ 3 ] = { 5.834 , 10.0 , 14.17 } ;
static const real_T e [ 3 ] = { 8.333 , 50.0 , 91.67 } ; static const real_T
f [ 3 ] = { 58.33 , 100.0 , 141.7 } ; static const int8_T b_p [ 10 ] = { 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 2 } ; static const int8_T g [ 20 ] = { 1 , 1
, 1 , 2 , 2 , 2 , 3 , 3 , 3 , 4 , 3 , 2 , 1 , 3 , 2 , 1 , 1 , 2 , 3 , 4 } ;
static const real_T b_e [ 3 ] = { 0.04167 , 0.25 , 0.4583 } ; static const
real_T c_p [ 3 ] = { 0.2917 , 0.5 , 0.7083 } ; static const int8_T d_p [ 10 ]
= { 1 , 4 , 2 , 2 , 5 , 3 , 3 , 3 , 3 , 6 } ; static const real_T b_i [ 3 ] =
{ 0.4167 , 2.5 , 4.583 } ; static const real_T c_e [ 3 ] = { 2.917 , 5.0 ,
7.085 } ; static const int8_T f_p [ 18 ] = { 1 , 1 , 1 , 2 , 2 , 2 , 3 , 3 ,
3 , 3 , 2 , 1 , 3 , 2 , 1 , 1 , 2 , 3 } ; rtB . g5y2ovgmgf = 0.0 ; rtB .
g5y2ovgmgf += rtP . Currentfilter_C * rtX . plb5id0v2x ; if ( ssIsSampleHit (
rtS , 1 , 0 ) ) { rtB . fqm02mu2mr = rtDW . ca5hlnq0yv ; rtB . k0olm5ygz1 =
rtP . R2_Gain * rtB . fqm02mu2mr ; rtB . mrkoixdcxy = 1.000001 * rtB .
k0olm5ygz1 * 0.96711798839458663 / 0.9999 ; if ( ssGetIsOkayToUpdateMode (
rtS ) ) { rtDW . looo4ud10x = ( rtB . g5y2ovgmgf > rtP . Constant_Value ) ; }
rtB . p3jvn4gjjg = rtDW . looo4ud10x ; rtB . h0jr4gcmhz = rtDW . capftuiedr ;
} tmp = ssGetIsOkayToUpdateMode ( rtS ) ; if ( tmp ) { zcEvent = rt_ZCFcn (
RISING_ZERO_CROSSING , & rtPrevZCX . fyojy5qztg , ( rtB . p3jvn4gjjg ) ) ; if
( ( zcEvent != NO_ZCEVENT ) || ( rtDW . mwvlfj3tnw != 0 ) ) { rtX .
lbkltw2njc = rtB . h0jr4gcmhz ; ssSetBlockStateForSolverChangedAtMajorStep (
rtS ) ; } if ( rtX . lbkltw2njc >= rtP . inti_UpperSat ) { if ( rtX .
lbkltw2njc != rtP . inti_UpperSat ) { rtX . lbkltw2njc = rtP . inti_UpperSat
; ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . klgebljbkk =
3 ; } else if ( rtX . lbkltw2njc <= rtP . inti_LowerSat ) { if ( rtX .
lbkltw2njc != rtP . inti_LowerSat ) { rtX . lbkltw2njc = rtP . inti_LowerSat
; ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . klgebljbkk =
4 ; } else { if ( rtDW . klgebljbkk != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . klgebljbkk = 0
; } rtB . drgvtg0vjv = rtX . lbkltw2njc ; } else { rtB . drgvtg0vjv = rtX .
lbkltw2njc ; } rtB . a42chj0wvi = rtP . Gain_Gain * rtB . drgvtg0vjv ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . enb5gffmh1 = ( rtB . a42chj0wvi > rtB . k0olm5ygz1 ) ; } rtB .
levrqdzmuw = rtDW . enb5gffmh1 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . oki3ixtrek = ( rtB . a42chj0wvi < rtP . Constant9_Value ) ; } rtB .
lvl2kjehdx = rtDW . oki3ixtrek ; } if ( rtB . levrqdzmuw ) { rtB . mcznvl3xnw
= rtB . k0olm5ygz1 ; } else { if ( rtB . lvl2kjehdx ) { rtB . lvwz4ihgsh =
rtP . Constant9_Value ; } else { rtB . lvwz4ihgsh = rtB . a42chj0wvi ; } rtB
. mcznvl3xnw = rtB . lvwz4ihgsh ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . bm3shpqfur = ( rtB . mrkoixdcxy
<= rtB . mcznvl3xnw ) ; } rtB . hu2ipo3lca = rtDW . bm3shpqfur ; } if ( rtB .
hu2ipo3lca ) { rtB . p0r2azag0g = rtB . k0olm5ygz1 ; } else { rtB .
p0r2azag0g = rtB . mcznvl3xnw ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
fqm02mu2mr / ( rtB . fqm02mu2mr - rtB . p0r2azag0g ) * rtB . p0r2azag0g ;
jmuz0todoh = - rtB . p3jvn4gjjg * 0.00461995246297257 * rtB . g5y2ovgmgf *
rtB . fqm02mu2mr / ( rtB . fqm02mu2mr - rtB . p0r2azag0g ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . fq1y334rj2 = rtP . R3_Gain * rtB .
fqm02mu2mr ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . dq13p4klkw = (
rtB . a42chj0wvi > rtB . fq1y334rj2 ) ; } rtB . jjriozwmwj = rtDW .
dq13p4klkw ; rtB . nj0k0lpkxt = - rtB . fq1y334rj2 * 0.999 * 0.1 * 0.9999 ;
if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . b5qny41bod = ( rtB .
a42chj0wvi < rtB . nj0k0lpkxt ) ; } rtB . hwjzbg4rx2 = rtDW . b5qny41bod ; }
if ( rtB . jjriozwmwj ) { rtB . gmgyu1za23 = rtB . fq1y334rj2 ; } else { if (
rtB . hwjzbg4rx2 ) { rtB . nz04uf540o = rtB . nj0k0lpkxt ; } else { rtB .
nz04uf540o = rtB . a42chj0wvi ; } rtB . gmgyu1za23 = rtB . nz04uf540o ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . fzutpwbhou = ( rtB . g5y2ovgmgf < rtP . Constant_Value_efypwvyyax ) ;
} rtB . hg3oaigjwk = rtDW . fzutpwbhou ; } switch ( ( int32_T ) rtP .
Battery1_BatType ) { case 1 : rtB . a50cikqz4s [ 0 ] = rtP . Constant4_Value
* rtB . gmgyu1za23 ; rtB . a50cikqz4s [ 1 ] = rtP . Constant4_Value * rtB .
g5y2ovgmgf ; rtB . a50cikqz4s [ 2 ] = rtP . Constant4_Value * rtB .
hg3oaigjwk ; rtB . a50cikqz4s [ 3 ] = rtP . Constant4_Value * rtB .
fqm02mu2mr ; rtB . iglwuzsika = - rtB . a50cikqz4s [ 2 ] *
0.00461995246297257 * rtB . a50cikqz4s [ 1 ] * ( 6.2039999999999846 / ( rtB .
a50cikqz4s [ 0 ] + 0.62039999999999851 ) ) ; break ; case 2 : rtB .
btujypzxe1 [ 0 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . gmgyu1za23 ; rtB
. btujypzxe1 [ 1 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . g5y2ovgmgf ;
rtB . btujypzxe1 [ 2 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . hg3oaigjwk
; rtB . btujypzxe1 [ 3 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB .
fqm02mu2mr ; rtB . iglwuzsika = - rtB . btujypzxe1 [ 2 ] *
0.00461995246297257 * rtB . btujypzxe1 [ 1 ] * rtB . btujypzxe1 [ 3 ] / ( rtB
. btujypzxe1 [ 3 ] * 0.1 + rtB . btujypzxe1 [ 0 ] ) ; break ; case 3 : rtB .
decwo2mz20 [ 0 ] = rtP . Constant3_Value * rtB . gmgyu1za23 ; rtB .
decwo2mz20 [ 1 ] = rtP . Constant3_Value * rtB . g5y2ovgmgf ; rtB .
decwo2mz20 [ 2 ] = rtP . Constant3_Value * rtB . hg3oaigjwk ; rtB .
decwo2mz20 [ 3 ] = rtP . Constant3_Value * rtB . fqm02mu2mr ; rtB .
iglwuzsika = - rtB . decwo2mz20 [ 2 ] * 0.00461995246297257 * rtB .
decwo2mz20 [ 1 ] * ( 6.2039999999999846 / ( muDoubleScalarAbs ( rtB .
decwo2mz20 [ 0 ] ) + 0.62039999999999851 ) ) ; break ; default : rtB .
fuv3hvos5j [ 0 ] = rtP . Constant2_Value * rtB . gmgyu1za23 ; rtB .
fuv3hvos5j [ 1 ] = rtP . Constant2_Value * rtB . g5y2ovgmgf ; rtB .
fuv3hvos5j [ 2 ] = rtP . Constant2_Value * rtB . hg3oaigjwk ; rtB .
fuv3hvos5j [ 3 ] = rtP . Constant2_Value * rtB . fqm02mu2mr ; rtB .
iglwuzsika = - rtB . fuv3hvos5j [ 2 ] * 0.00461995246297257 * rtB .
fuv3hvos5j [ 1 ] * ( 6.2039999999999846 / ( muDoubleScalarAbs ( rtB .
fuv3hvos5j [ 0 ] ) + 0.62039999999999851 ) ) ; break ; } rtB . kf00di3gqm =
rtX . fzv1e1p3mc ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . ogvxzirtsf = rtB
. p0r2azag0g >= rtP . Saturation_UpperSat ? 1 : rtB . p0r2azag0g > rtP .
Saturation_LowerSat ? 0 : - 1 ; } rtB . l243apzsnw = rtDW . ogvxzirtsf == 1 ?
rtP . Saturation_UpperSat : rtDW . ogvxzirtsf == - 1 ? rtP .
Saturation_LowerSat : rtB . p0r2azag0g ; switch ( ( int32_T ) rtP .
Battery1_BatType ) { case 1 : rtB . ifn5ydjway = rtB . kf00di3gqm ; break ;
case 2 : rtB . ifn5ydjway = muDoubleScalarExp ( - 10.176991150442477 * rtB .
l243apzsnw ) * 0.310711063328515 ; break ; case 3 : rtB . ifn5ydjway = rtB .
kf00di3gqm ; break ; default : rtB . ifn5ydjway = rtB . kf00di3gqm ; break ;
} rtB . gaxbz4eazu = ( ( ( k0qu5tzxih + jmuz0todoh ) + rtB . iglwuzsika ) +
rtB . ifn5ydjway ) + - 0.0 * rtB . p0r2azag0g ; rtB . n52pjzek12 = rtP .
Constant_Value_jorngiczgp + rtB . gaxbz4eazu ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . egflmvjdnu = ( rtB .
n52pjzek12 > rtP . Constant1_Value ) ; } rtB . oj3yvv3y0h = rtDW . egflmvjdnu
; } rtB . c1l22vg0g3 = 0.0 ; rtB . c1l22vg0g3 += rtP . BAL_C * rtX .
fg5c5z2vbx ; rtB . bsbdyhiakj = rtP . R1_Gain * rtB . c1l22vg0g3 ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . gbgm1nknco = ( rtB . n52pjzek12 < rtB . bsbdyhiakj ) ; } rtB .
kq0scdgfjl = rtDW . gbgm1nknco ; rtB . ojlbfd1f01 = rtDW . dausu4yb0r ; rtB .
jatbcbjee2 = rtP . R2_Gain_jrqfqsl4vo * rtB . ojlbfd1f01 ; rtB . b1idarpp5t =
1.000001 * rtB . jatbcbjee2 * 0.96711798839458663 / 0.9999 ; } if ( rtB .
oj3yvv3y0h ) { rtB . nula5qzpsy = rtP . Constant1_Value ; } else { if ( rtB .
kq0scdgfjl ) { rtB . ob4wdtvizk = rtB . bsbdyhiakj ; } else { rtB .
ob4wdtvizk = rtB . n52pjzek12 ; } rtB . nula5qzpsy = rtB . ob4wdtvizk ; } rtB
. esegl2vvhs = 0.0 ; rtB . esegl2vvhs += rtP . Currentfilter_C_ldprzne4qv *
rtX . bx04s5qbio ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . bobvege1xa = ( rtB . esegl2vvhs >
rtP . Constant_Value_pbqzqfbpnm ) ; } rtB . gkqod2z0mi = rtDW . bobvege1xa ;
rtB . nl2mcft0gt = rtDW . nxcbrqbg4s ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
ckirjq4irs , ( rtB . gkqod2z0mi ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . jcfoqfv3fu != 0 ) ) { rtX . nxoiklb1cp = rtB . nl2mcft0gt ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . nxoiklb1cp
>= rtP . inti_UpperSat_itldayqrxp ) { if ( rtX . nxoiklb1cp != rtP .
inti_UpperSat_itldayqrxp ) { rtX . nxoiklb1cp = rtP .
inti_UpperSat_itldayqrxp ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . j1al2derae = 3 ; } else if ( rtX . nxoiklb1cp <= rtP .
inti_LowerSat_lz3gh0icex ) { if ( rtX . nxoiklb1cp != rtP .
inti_LowerSat_lz3gh0icex ) { rtX . nxoiklb1cp = rtP .
inti_LowerSat_lz3gh0icex ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . j1al2derae = 4 ; } else { if ( rtDW . j1al2derae != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . j1al2derae = 0
; } rtB . a0aqqada1w = rtX . nxoiklb1cp ; } else { rtB . a0aqqada1w = rtX .
nxoiklb1cp ; } rtB . othrejmk4n = rtP . Gain_Gain_ozvwrv1fuy * rtB .
a0aqqada1w ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . pfgmjz0oxl = ( rtB . othrejmk4n >
rtB . jatbcbjee2 ) ; } rtB . muvs2zmbde = rtDW . pfgmjz0oxl ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . c4ju1tonyc = ( rtB . othrejmk4n <
rtP . Constant9_Value_bfo0fnc5l1 ) ; } rtB . czsttbwlhu = rtDW . c4ju1tonyc ;
} if ( rtB . muvs2zmbde ) { rtB . o55coy5tot = rtB . jatbcbjee2 ; } else { if
( rtB . czsttbwlhu ) { rtB . oplbbe4p2q = rtP . Constant9_Value_bfo0fnc5l1 ;
} else { rtB . oplbbe4p2q = rtB . othrejmk4n ; } rtB . o55coy5tot = rtB .
oplbbe4p2q ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . ogpfosulwk = ( rtB . b1idarpp5t <=
rtB . o55coy5tot ) ; } rtB . oc3uk0sbgh = rtDW . ogpfosulwk ; } if ( rtB .
oc3uk0sbgh ) { rtB . nv44crtc44 = rtB . jatbcbjee2 ; } else { rtB .
nv44crtc44 = rtB . o55coy5tot ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
ojlbfd1f01 / ( rtB . ojlbfd1f01 - rtB . nv44crtc44 ) * rtB . nv44crtc44 ;
jmuz0todoh = - rtB . gkqod2z0mi * 0.00461995246297257 * rtB . esegl2vvhs *
rtB . ojlbfd1f01 / ( rtB . ojlbfd1f01 - rtB . nv44crtc44 ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . po53ioprtt = rtP . R3_Gain_dgx1dntlxw
* rtB . ojlbfd1f01 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
mo2kznqvft = ( rtB . othrejmk4n > rtB . po53ioprtt ) ; } rtB . newl3oopdo =
rtDW . mo2kznqvft ; rtB . pmyyss4uxo = - rtB . po53ioprtt * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . honn2tdy54 = ( rtB .
othrejmk4n < rtB . pmyyss4uxo ) ; } rtB . nvh2bwltbz = rtDW . honn2tdy54 ; }
if ( rtB . newl3oopdo ) { rtB . mtw3mahg4k = rtB . po53ioprtt ; } else { if (
rtB . nvh2bwltbz ) { rtB . jaaef2z5gv = rtB . pmyyss4uxo ; } else { rtB .
jaaef2z5gv = rtB . othrejmk4n ; } rtB . mtw3mahg4k = rtB . jaaef2z5gv ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . orbo5xgqzn = ( rtB . esegl2vvhs < rtP . Constant_Value_hu3rmuppbn ) ;
} rtB . dq2lwvzzrg = rtDW . orbo5xgqzn ; } switch ( ( int32_T ) rtP .
Battery2_BatType ) { case 1 : rtB . bo4jr3clrs [ 0 ] = rtP .
Constant4_Value_p1xz0cpgth * rtB . mtw3mahg4k ; rtB . bo4jr3clrs [ 1 ] = rtP
. Constant4_Value_p1xz0cpgth * rtB . esegl2vvhs ; rtB . bo4jr3clrs [ 2 ] =
rtP . Constant4_Value_p1xz0cpgth * rtB . dq2lwvzzrg ; rtB . bo4jr3clrs [ 3 ]
= rtP . Constant4_Value_p1xz0cpgth * rtB . ojlbfd1f01 ; rtB . e0yzwp1mzb = -
rtB . bo4jr3clrs [ 2 ] * 0.00461995246297257 * rtB . bo4jr3clrs [ 1 ] * (
6.2039999999999846 / ( rtB . bo4jr3clrs [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . if5hnihgsu [ 0 ] = rtP . Constant1_Value_jxqfbvs00y *
rtB . mtw3mahg4k ; rtB . if5hnihgsu [ 1 ] = rtP . Constant1_Value_jxqfbvs00y
* rtB . esegl2vvhs ; rtB . if5hnihgsu [ 2 ] = rtP .
Constant1_Value_jxqfbvs00y * rtB . dq2lwvzzrg ; rtB . if5hnihgsu [ 3 ] = rtP
. Constant1_Value_jxqfbvs00y * rtB . ojlbfd1f01 ; rtB . e0yzwp1mzb = - rtB .
if5hnihgsu [ 2 ] * 0.00461995246297257 * rtB . if5hnihgsu [ 1 ] * rtB .
if5hnihgsu [ 3 ] / ( rtB . if5hnihgsu [ 3 ] * 0.1 + rtB . if5hnihgsu [ 0 ] )
; break ; case 3 : rtB . jbhnyvsbds [ 0 ] = rtP . Constant3_Value_k030zkojhy
* rtB . mtw3mahg4k ; rtB . jbhnyvsbds [ 1 ] = rtP .
Constant3_Value_k030zkojhy * rtB . esegl2vvhs ; rtB . jbhnyvsbds [ 2 ] = rtP
. Constant3_Value_k030zkojhy * rtB . dq2lwvzzrg ; rtB . jbhnyvsbds [ 3 ] =
rtP . Constant3_Value_k030zkojhy * rtB . ojlbfd1f01 ; rtB . e0yzwp1mzb = -
rtB . jbhnyvsbds [ 2 ] * 0.00461995246297257 * rtB . jbhnyvsbds [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . jbhnyvsbds [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . cmoguppwfc [ 0 ] = rtP .
Constant2_Value_nbkvr3eqsy * rtB . mtw3mahg4k ; rtB . cmoguppwfc [ 1 ] = rtP
. Constant2_Value_nbkvr3eqsy * rtB . esegl2vvhs ; rtB . cmoguppwfc [ 2 ] =
rtP . Constant2_Value_nbkvr3eqsy * rtB . dq2lwvzzrg ; rtB . cmoguppwfc [ 3 ]
= rtP . Constant2_Value_nbkvr3eqsy * rtB . ojlbfd1f01 ; rtB . e0yzwp1mzb = -
rtB . cmoguppwfc [ 2 ] * 0.00461995246297257 * rtB . cmoguppwfc [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . cmoguppwfc [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . b5plhow0ik = rtX . b3n5hgntky ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . ebrxkv0tlv = rtB . nv44crtc44 >= rtP .
Saturation_UpperSat_lxx4j3fnoa ? 1 : rtB . nv44crtc44 > rtP .
Saturation_LowerSat_kwi433xk5g ? 0 : - 1 ; } rtB . pqhzrovppf = rtDW .
ebrxkv0tlv == 1 ? rtP . Saturation_UpperSat_lxx4j3fnoa : rtDW . ebrxkv0tlv ==
- 1 ? rtP . Saturation_LowerSat_kwi433xk5g : rtB . nv44crtc44 ; switch ( (
int32_T ) rtP . Battery2_BatType ) { case 1 : rtB . frv35kwpm0 = rtB .
b5plhow0ik ; break ; case 2 : rtB . frv35kwpm0 = muDoubleScalarExp ( -
10.176991150442477 * rtB . pqhzrovppf ) * 0.310711063328515 ; break ; case 3
: rtB . frv35kwpm0 = rtB . b5plhow0ik ; break ; default : rtB . frv35kwpm0 =
rtB . b5plhow0ik ; break ; } rtB . alargmkfao = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . e0yzwp1mzb ) + rtB . frv35kwpm0 ) + - 0.0 * rtB . nv44crtc44 ; rtB
. deh2tdbovg = rtP . Constant_Value_fzmb45jy2r + rtB . alargmkfao ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . iv2pdg4k2c = ( rtB . deh2tdbovg > rtP . Constant1_Value_jelmmtr1rj ) ;
} rtB . eekpnfrbtv = rtDW . iv2pdg4k2c ; } rtB . bnmph5cpev = 0.0 ; rtB .
bnmph5cpev += rtP . BAL_C_pnvzkp4ayj * rtX . cgxanjfmip ; rtB . gaiiq3ag5u =
rtP . R1_Gain_k1h1x1zryv * rtB . bnmph5cpev ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . h0qayo3umb = ( rtB .
deh2tdbovg < rtB . gaiiq3ag5u ) ; } rtB . f2df1n0xmz = rtDW . h0qayo3umb ;
rtB . kslnv1njp2 = rtDW . nb3lw1dts4 ; rtB . a2rrzly2nj = rtP .
R2_Gain_fij43s2whq * rtB . kslnv1njp2 ; rtB . cgdbtisdum = 1.000001 * rtB .
a2rrzly2nj * 0.96711798839458663 / 0.9999 ; } if ( rtB . eekpnfrbtv ) { rtB .
m5jzl0c3ow = rtP . Constant1_Value_jelmmtr1rj ; } else { if ( rtB .
f2df1n0xmz ) { rtB . nmhnvozqsv = rtB . gaiiq3ag5u ; } else { rtB .
nmhnvozqsv = rtB . deh2tdbovg ; } rtB . m5jzl0c3ow = rtB . nmhnvozqsv ; } rtB
. c005o3t15s = 0.0 ; rtB . c005o3t15s += rtP . Currentfilter_C_hx4sknoziy *
rtX . lfvzsuhskj ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . ogoto0hwmm = ( rtB . c005o3t15s >
rtP . Constant_Value_bksqnhysc0 ) ; } rtB . pciyqbmld3 = rtDW . ogoto0hwmm ;
rtB . b411vxpvsm = rtDW . oqfmlletk1 ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
moi5ujt2m4 , ( rtB . pciyqbmld3 ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . p20ta3sfdz != 0 ) ) { rtX . bxy3w4qxj2 = rtB . b411vxpvsm ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . bxy3w4qxj2
>= rtP . inti_UpperSat_nowwhgaxwk ) { if ( rtX . bxy3w4qxj2 != rtP .
inti_UpperSat_nowwhgaxwk ) { rtX . bxy3w4qxj2 = rtP .
inti_UpperSat_nowwhgaxwk ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . ia4yvyaqmb = 3 ; } else if ( rtX . bxy3w4qxj2 <= rtP .
inti_LowerSat_cwekkzbyq1 ) { if ( rtX . bxy3w4qxj2 != rtP .
inti_LowerSat_cwekkzbyq1 ) { rtX . bxy3w4qxj2 = rtP .
inti_LowerSat_cwekkzbyq1 ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . ia4yvyaqmb = 4 ; } else { if ( rtDW . ia4yvyaqmb != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . ia4yvyaqmb = 0
; } rtB . flzib234ll = rtX . bxy3w4qxj2 ; } else { rtB . flzib234ll = rtX .
bxy3w4qxj2 ; } rtB . aojtgbxww0 = rtP . Gain_Gain_jbuudt1ftk * rtB .
flzib234ll ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . fui4yx3kuz = ( rtB . aojtgbxww0 >
rtB . a2rrzly2nj ) ; } rtB . eehigchrn4 = rtDW . fui4yx3kuz ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . aa45yc1et3 = ( rtB . aojtgbxww0 <
rtP . Constant9_Value_nhyzz1ckmw ) ; } rtB . gk2b4uufar = rtDW . aa45yc1et3 ;
} if ( rtB . eehigchrn4 ) { rtB . befeauo34y = rtB . a2rrzly2nj ; } else { if
( rtB . gk2b4uufar ) { rtB . ibgjdsvsot = rtP . Constant9_Value_nhyzz1ckmw ;
} else { rtB . ibgjdsvsot = rtB . aojtgbxww0 ; } rtB . befeauo34y = rtB .
ibgjdsvsot ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . mdxvbvxht5 = ( rtB . cgdbtisdum <=
rtB . befeauo34y ) ; } rtB . fibreaa3ri = rtDW . mdxvbvxht5 ; } if ( rtB .
fibreaa3ri ) { rtB . lz4r5vsjh1 = rtB . a2rrzly2nj ; } else { rtB .
lz4r5vsjh1 = rtB . befeauo34y ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
kslnv1njp2 / ( rtB . kslnv1njp2 - rtB . lz4r5vsjh1 ) * rtB . lz4r5vsjh1 ;
jmuz0todoh = - rtB . pciyqbmld3 * 0.00461995246297257 * rtB . c005o3t15s *
rtB . kslnv1njp2 / ( rtB . kslnv1njp2 - rtB . lz4r5vsjh1 ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . hgspzwdexg = rtP . R3_Gain_de1tgv0zzw
* rtB . kslnv1njp2 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
b4svh4uxws = ( rtB . aojtgbxww0 > rtB . hgspzwdexg ) ; } rtB . atzrgflsgx =
rtDW . b4svh4uxws ; rtB . arqmlzjrl4 = - rtB . hgspzwdexg * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . mryeqkmzmt = ( rtB .
aojtgbxww0 < rtB . arqmlzjrl4 ) ; } rtB . hv51mxfmqn = rtDW . mryeqkmzmt ; }
if ( rtB . atzrgflsgx ) { rtB . n4ii53j0pi = rtB . hgspzwdexg ; } else { if (
rtB . hv51mxfmqn ) { rtB . pj3ruknygu = rtB . arqmlzjrl4 ; } else { rtB .
pj3ruknygu = rtB . aojtgbxww0 ; } rtB . n4ii53j0pi = rtB . pj3ruknygu ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . is4auzynbw = ( rtB . c005o3t15s < rtP . Constant_Value_owtewy0ssm ) ;
} rtB . a32d4y2ehp = rtDW . is4auzynbw ; } switch ( ( int32_T ) rtP .
Battery3_BatType ) { case 1 : rtB . d3zrlcmw3n [ 0 ] = rtP .
Constant4_Value_cmgjzabbd1 * rtB . n4ii53j0pi ; rtB . d3zrlcmw3n [ 1 ] = rtP
. Constant4_Value_cmgjzabbd1 * rtB . c005o3t15s ; rtB . d3zrlcmw3n [ 2 ] =
rtP . Constant4_Value_cmgjzabbd1 * rtB . a32d4y2ehp ; rtB . d3zrlcmw3n [ 3 ]
= rtP . Constant4_Value_cmgjzabbd1 * rtB . kslnv1njp2 ; rtB . dzejhg3vfk = -
rtB . d3zrlcmw3n [ 2 ] * 0.00461995246297257 * rtB . d3zrlcmw3n [ 1 ] * (
6.2039999999999846 / ( rtB . d3zrlcmw3n [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . f5dahsuilz [ 0 ] = rtP . Constant1_Value_gbfcrdkgqa *
rtB . n4ii53j0pi ; rtB . f5dahsuilz [ 1 ] = rtP . Constant1_Value_gbfcrdkgqa
* rtB . c005o3t15s ; rtB . f5dahsuilz [ 2 ] = rtP .
Constant1_Value_gbfcrdkgqa * rtB . a32d4y2ehp ; rtB . f5dahsuilz [ 3 ] = rtP
. Constant1_Value_gbfcrdkgqa * rtB . kslnv1njp2 ; rtB . dzejhg3vfk = - rtB .
f5dahsuilz [ 2 ] * 0.00461995246297257 * rtB . f5dahsuilz [ 1 ] * rtB .
f5dahsuilz [ 3 ] / ( rtB . f5dahsuilz [ 3 ] * 0.1 + rtB . f5dahsuilz [ 0 ] )
; break ; case 3 : rtB . o5hw5brjet [ 0 ] = rtP . Constant3_Value_hat1prtoip
* rtB . n4ii53j0pi ; rtB . o5hw5brjet [ 1 ] = rtP .
Constant3_Value_hat1prtoip * rtB . c005o3t15s ; rtB . o5hw5brjet [ 2 ] = rtP
. Constant3_Value_hat1prtoip * rtB . a32d4y2ehp ; rtB . o5hw5brjet [ 3 ] =
rtP . Constant3_Value_hat1prtoip * rtB . kslnv1njp2 ; rtB . dzejhg3vfk = -
rtB . o5hw5brjet [ 2 ] * 0.00461995246297257 * rtB . o5hw5brjet [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . o5hw5brjet [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . dj5bmh2qmz [ 0 ] = rtP .
Constant2_Value_gnk2tjoo5o * rtB . n4ii53j0pi ; rtB . dj5bmh2qmz [ 1 ] = rtP
. Constant2_Value_gnk2tjoo5o * rtB . c005o3t15s ; rtB . dj5bmh2qmz [ 2 ] =
rtP . Constant2_Value_gnk2tjoo5o * rtB . a32d4y2ehp ; rtB . dj5bmh2qmz [ 3 ]
= rtP . Constant2_Value_gnk2tjoo5o * rtB . kslnv1njp2 ; rtB . dzejhg3vfk = -
rtB . dj5bmh2qmz [ 2 ] * 0.00461995246297257 * rtB . dj5bmh2qmz [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . dj5bmh2qmz [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . nla5yxcuxf = rtX . chmdgjvbrk ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . kcjz5ym5tp = rtB . lz4r5vsjh1 >= rtP .
Saturation_UpperSat_blj3ug4rzx ? 1 : rtB . lz4r5vsjh1 > rtP .
Saturation_LowerSat_o0i20janpw ? 0 : - 1 ; } rtB . nzk1m34skw = rtDW .
kcjz5ym5tp == 1 ? rtP . Saturation_UpperSat_blj3ug4rzx : rtDW . kcjz5ym5tp ==
- 1 ? rtP . Saturation_LowerSat_o0i20janpw : rtB . lz4r5vsjh1 ; switch ( (
int32_T ) rtP . Battery3_BatType ) { case 1 : rtB . hg2elf4r3m = rtB .
nla5yxcuxf ; break ; case 2 : rtB . hg2elf4r3m = muDoubleScalarExp ( -
10.176991150442477 * rtB . nzk1m34skw ) * 0.310711063328515 ; break ; case 3
: rtB . hg2elf4r3m = rtB . nla5yxcuxf ; break ; default : rtB . hg2elf4r3m =
rtB . nla5yxcuxf ; break ; } rtB . itgwqixq2p = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . dzejhg3vfk ) + rtB . hg2elf4r3m ) + - 0.0 * rtB . lz4r5vsjh1 ; rtB
. a1q431buft = rtP . Constant_Value_kiu123temw + rtB . itgwqixq2p ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . j0pqa45jfy = ( rtB . a1q431buft > rtP . Constant1_Value_jj3f5fu3xp ) ;
} rtB . fawiawgoh5 = rtDW . j0pqa45jfy ; } rtB . bfmkeli01v = 0.0 ; rtB .
bfmkeli01v += rtP . BAL_C_ix2bm3qtha * rtX . iximkvmpst ; rtB . idgi4oj4mi =
rtP . R1_Gain_elo0441xsu * rtB . bfmkeli01v ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . oonf3bet4a = ( rtB .
a1q431buft < rtB . idgi4oj4mi ) ; } rtB . js2smttmtm = rtDW . oonf3bet4a ;
rtB . czyx3zxlle = rtDW . b1blljt5i4 ; rtB . b2gwj4fubz = rtP .
R2_Gain_akgkexbqnd * rtB . czyx3zxlle ; rtB . bpligzmo0k = 1.000001 * rtB .
b2gwj4fubz * 0.96711798839458663 / 0.9999 ; } if ( rtB . fawiawgoh5 ) { rtB .
i5uns4zs23 = rtP . Constant1_Value_jj3f5fu3xp ; } else { if ( rtB .
js2smttmtm ) { rtB . ezq2vhtkgr = rtB . idgi4oj4mi ; } else { rtB .
ezq2vhtkgr = rtB . a1q431buft ; } rtB . i5uns4zs23 = rtB . ezq2vhtkgr ; } rtB
. olfzsyzgug = 0.0 ; rtB . olfzsyzgug += rtP . Currentfilter_C_muylregegy *
rtX . esshhzn0st ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . kcmxrveuh1 = ( rtB . olfzsyzgug >
rtP . Constant_Value_kedzfrfegv ) ; } rtB . fytijtn1qm = rtDW . kcmxrveuh1 ;
rtB . ijwp3irwdu = rtDW . eude00gfzn ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
f03tkcmhr0 , ( rtB . fytijtn1qm ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . oqj3skvfcq != 0 ) ) { rtX . dqfnkbb0xq = rtB . ijwp3irwdu ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . dqfnkbb0xq
>= rtP . inti_UpperSat_itde10ibkj ) { if ( rtX . dqfnkbb0xq != rtP .
inti_UpperSat_itde10ibkj ) { rtX . dqfnkbb0xq = rtP .
inti_UpperSat_itde10ibkj ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . gaqc3mhu55 = 3 ; } else if ( rtX . dqfnkbb0xq <= rtP .
inti_LowerSat_nb1wwuftgl ) { if ( rtX . dqfnkbb0xq != rtP .
inti_LowerSat_nb1wwuftgl ) { rtX . dqfnkbb0xq = rtP .
inti_LowerSat_nb1wwuftgl ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . gaqc3mhu55 = 4 ; } else { if ( rtDW . gaqc3mhu55 != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . gaqc3mhu55 = 0
; } rtB . kyq4l5giqe = rtX . dqfnkbb0xq ; } else { rtB . kyq4l5giqe = rtX .
dqfnkbb0xq ; } rtB . j41ux1gc4d = rtP . Gain_Gain_l5lbde12wy * rtB .
kyq4l5giqe ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . eywar50dsx = ( rtB . j41ux1gc4d >
rtB . b2gwj4fubz ) ; } rtB . cbldlnrkrl = rtDW . eywar50dsx ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nkeiblqwmm = ( rtB . j41ux1gc4d <
rtP . Constant9_Value_ffsooduwum ) ; } rtB . erpu4v3yeg = rtDW . nkeiblqwmm ;
} if ( rtB . cbldlnrkrl ) { rtB . k0z0bgvani = rtB . b2gwj4fubz ; } else { if
( rtB . erpu4v3yeg ) { rtB . h0fu0ax1yq = rtP . Constant9_Value_ffsooduwum ;
} else { rtB . h0fu0ax1yq = rtB . j41ux1gc4d ; } rtB . k0z0bgvani = rtB .
h0fu0ax1yq ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . n2gaflvouv = ( rtB . bpligzmo0k <=
rtB . k0z0bgvani ) ; } rtB . ame4svhan1 = rtDW . n2gaflvouv ; } if ( rtB .
ame4svhan1 ) { rtB . g5hkbvjtz4 = rtB . b2gwj4fubz ; } else { rtB .
g5hkbvjtz4 = rtB . k0z0bgvani ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
czyx3zxlle / ( rtB . czyx3zxlle - rtB . g5hkbvjtz4 ) * rtB . g5hkbvjtz4 ;
jmuz0todoh = - rtB . fytijtn1qm * 0.00461995246297257 * rtB . olfzsyzgug *
rtB . czyx3zxlle / ( rtB . czyx3zxlle - rtB . g5hkbvjtz4 ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . chdzuypdzn = rtP . R3_Gain_nk0ujvzftk
* rtB . czyx3zxlle ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
lwbxpyeq51 = ( rtB . j41ux1gc4d > rtB . chdzuypdzn ) ; } rtB . aowksp0wla =
rtDW . lwbxpyeq51 ; rtB . oi4dn5ko50 = - rtB . chdzuypdzn * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . bvkagd0qc0 = ( rtB .
j41ux1gc4d < rtB . oi4dn5ko50 ) ; } rtB . cme3xzwgv0 = rtDW . bvkagd0qc0 ; }
if ( rtB . aowksp0wla ) { rtB . corg1fk01c = rtB . chdzuypdzn ; } else { if (
rtB . cme3xzwgv0 ) { rtB . pnkg5wquv2 = rtB . oi4dn5ko50 ; } else { rtB .
pnkg5wquv2 = rtB . j41ux1gc4d ; } rtB . corg1fk01c = rtB . pnkg5wquv2 ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . nccltnyyv2 = ( rtB . olfzsyzgug < rtP . Constant_Value_opaksbgo21 ) ;
} rtB . inix0uapiw = rtDW . nccltnyyv2 ; } switch ( ( int32_T ) rtP .
Battery4_BatType ) { case 1 : rtB . jt5vlrdpwx [ 0 ] = rtP .
Constant4_Value_ohbtynzx54 * rtB . corg1fk01c ; rtB . jt5vlrdpwx [ 1 ] = rtP
. Constant4_Value_ohbtynzx54 * rtB . olfzsyzgug ; rtB . jt5vlrdpwx [ 2 ] =
rtP . Constant4_Value_ohbtynzx54 * rtB . inix0uapiw ; rtB . jt5vlrdpwx [ 3 ]
= rtP . Constant4_Value_ohbtynzx54 * rtB . czyx3zxlle ; rtB . ktqlzpn2rg = -
rtB . jt5vlrdpwx [ 2 ] * 0.00461995246297257 * rtB . jt5vlrdpwx [ 1 ] * (
6.2039999999999846 / ( rtB . jt5vlrdpwx [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . ax4synweyq [ 0 ] = rtP . Constant1_Value_am3al2n15v *
rtB . corg1fk01c ; rtB . ax4synweyq [ 1 ] = rtP . Constant1_Value_am3al2n15v
* rtB . olfzsyzgug ; rtB . ax4synweyq [ 2 ] = rtP .
Constant1_Value_am3al2n15v * rtB . inix0uapiw ; rtB . ax4synweyq [ 3 ] = rtP
. Constant1_Value_am3al2n15v * rtB . czyx3zxlle ; rtB . ktqlzpn2rg = - rtB .
ax4synweyq [ 2 ] * 0.00461995246297257 * rtB . ax4synweyq [ 1 ] * rtB .
ax4synweyq [ 3 ] / ( rtB . ax4synweyq [ 3 ] * 0.1 + rtB . ax4synweyq [ 0 ] )
; break ; case 3 : rtB . kq0pv3jzej [ 0 ] = rtP . Constant3_Value_mujtf1guv4
* rtB . corg1fk01c ; rtB . kq0pv3jzej [ 1 ] = rtP .
Constant3_Value_mujtf1guv4 * rtB . olfzsyzgug ; rtB . kq0pv3jzej [ 2 ] = rtP
. Constant3_Value_mujtf1guv4 * rtB . inix0uapiw ; rtB . kq0pv3jzej [ 3 ] =
rtP . Constant3_Value_mujtf1guv4 * rtB . czyx3zxlle ; rtB . ktqlzpn2rg = -
rtB . kq0pv3jzej [ 2 ] * 0.00461995246297257 * rtB . kq0pv3jzej [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . kq0pv3jzej [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . ihm1brh0bi [ 0 ] = rtP .
Constant2_Value_odhbgl2n1s * rtB . corg1fk01c ; rtB . ihm1brh0bi [ 1 ] = rtP
. Constant2_Value_odhbgl2n1s * rtB . olfzsyzgug ; rtB . ihm1brh0bi [ 2 ] =
rtP . Constant2_Value_odhbgl2n1s * rtB . inix0uapiw ; rtB . ihm1brh0bi [ 3 ]
= rtP . Constant2_Value_odhbgl2n1s * rtB . czyx3zxlle ; rtB . ktqlzpn2rg = -
rtB . ihm1brh0bi [ 2 ] * 0.00461995246297257 * rtB . ihm1brh0bi [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . ihm1brh0bi [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . jolzvaxect = rtX . ohptd3ifop ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . pbgnyq5tfg = rtB . g5hkbvjtz4 >= rtP .
Saturation_UpperSat_c0l2pkijii ? 1 : rtB . g5hkbvjtz4 > rtP .
Saturation_LowerSat_g1ovkjgj1x ? 0 : - 1 ; } rtB . nxd3puqj5v = rtDW .
pbgnyq5tfg == 1 ? rtP . Saturation_UpperSat_c0l2pkijii : rtDW . pbgnyq5tfg ==
- 1 ? rtP . Saturation_LowerSat_g1ovkjgj1x : rtB . g5hkbvjtz4 ; switch ( (
int32_T ) rtP . Battery4_BatType ) { case 1 : rtB . muhalhj3gd = rtB .
jolzvaxect ; break ; case 2 : rtB . muhalhj3gd = muDoubleScalarExp ( -
10.176991150442477 * rtB . nxd3puqj5v ) * 0.310711063328515 ; break ; case 3
: rtB . muhalhj3gd = rtB . jolzvaxect ; break ; default : rtB . muhalhj3gd =
rtB . jolzvaxect ; break ; } rtB . mlwnlfftda = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . ktqlzpn2rg ) + rtB . muhalhj3gd ) + - 0.0 * rtB . g5hkbvjtz4 ; rtB
. cvwcsqjiim = rtP . Constant_Value_em2zyolrnm + rtB . mlwnlfftda ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . pc2jk1zzjx = ( rtB . cvwcsqjiim > rtP . Constant1_Value_myhrse5szs ) ;
} rtB . ku5eexxo1r = rtDW . pc2jk1zzjx ; } rtB . exrixluala = 0.0 ; rtB .
exrixluala += rtP . BAL_C_hfghx3gysd * rtX . ik2jrqp3yy ; rtB . ixuan5fz50 =
rtP . R1_Gain_ay3u4mrv4p * rtB . exrixluala ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nhpvpm5stq = ( rtB .
cvwcsqjiim < rtB . ixuan5fz50 ) ; } rtB . mzyw4mhc11 = rtDW . nhpvpm5stq ;
rtB . p2hxwe1zfu = rtDW . omhuox45k5 ; rtB . iaqlnbjhf1 = rtP .
R2_Gain_axv50jbqfg * rtB . p2hxwe1zfu ; rtB . im14ffjmmn = 1.000001 * rtB .
iaqlnbjhf1 * 0.96711798839458663 / 0.9999 ; } if ( rtB . ku5eexxo1r ) { rtB .
ebcldbyulo = rtP . Constant1_Value_myhrse5szs ; } else { if ( rtB .
mzyw4mhc11 ) { rtB . jjkxq3xqxm = rtB . ixuan5fz50 ; } else { rtB .
jjkxq3xqxm = rtB . cvwcsqjiim ; } rtB . ebcldbyulo = rtB . jjkxq3xqxm ; } rtB
. lms5sy0bav = 0.0 ; rtB . lms5sy0bav += rtP . Currentfilter_C_e5mev0pk52 *
rtX . j5rh0u0prg ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . omshgvmyvz = ( rtB . lms5sy0bav >
rtP . Constant_Value_epq2rsx4ba ) ; } rtB . a5didxhdqz = rtDW . omshgvmyvz ;
rtB . deydb1b0uy = rtDW . l5yuu2mi2t ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
lunhr2xxb0 , ( rtB . a5didxhdqz ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . aj4yhj42qr != 0 ) ) { rtX . cr4uxyxqlm = rtB . deydb1b0uy ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . cr4uxyxqlm
>= rtP . inti_UpperSat_ff0nysnmjy ) { if ( rtX . cr4uxyxqlm != rtP .
inti_UpperSat_ff0nysnmjy ) { rtX . cr4uxyxqlm = rtP .
inti_UpperSat_ff0nysnmjy ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . cnphafnigh = 3 ; } else if ( rtX . cr4uxyxqlm <= rtP .
inti_LowerSat_hzpmw3xl5s ) { if ( rtX . cr4uxyxqlm != rtP .
inti_LowerSat_hzpmw3xl5s ) { rtX . cr4uxyxqlm = rtP .
inti_LowerSat_hzpmw3xl5s ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . cnphafnigh = 4 ; } else { if ( rtDW . cnphafnigh != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . cnphafnigh = 0
; } rtB . muxngmbf0e = rtX . cr4uxyxqlm ; } else { rtB . muxngmbf0e = rtX .
cr4uxyxqlm ; } rtB . msa01agh2x = rtP . Gain_Gain_a4qiy5rws3 * rtB .
muxngmbf0e ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nowkbmdlih = ( rtB . msa01agh2x >
rtB . iaqlnbjhf1 ) ; } rtB . b44kx5qc5j = rtDW . nowkbmdlih ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . mif04ihnck = ( rtB . msa01agh2x <
rtP . Constant9_Value_bcezbzp4a1 ) ; } rtB . ovopkjg4yt = rtDW . mif04ihnck ;
} if ( rtB . b44kx5qc5j ) { rtB . aztqnss3hz = rtB . iaqlnbjhf1 ; } else { if
( rtB . ovopkjg4yt ) { rtB . oygxsrsu4c = rtP . Constant9_Value_bcezbzp4a1 ;
} else { rtB . oygxsrsu4c = rtB . msa01agh2x ; } rtB . aztqnss3hz = rtB .
oygxsrsu4c ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . f13aephrpz = ( rtB . im14ffjmmn <=
rtB . aztqnss3hz ) ; } rtB . g0q2tc5i24 = rtDW . f13aephrpz ; } if ( rtB .
g0q2tc5i24 ) { rtB . bvz4ef4xni = rtB . iaqlnbjhf1 ; } else { rtB .
bvz4ef4xni = rtB . aztqnss3hz ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
p2hxwe1zfu / ( rtB . p2hxwe1zfu - rtB . bvz4ef4xni ) * rtB . bvz4ef4xni ;
jmuz0todoh = - rtB . a5didxhdqz * 0.00461995246297257 * rtB . lms5sy0bav *
rtB . p2hxwe1zfu / ( rtB . p2hxwe1zfu - rtB . bvz4ef4xni ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . i0lfhlq3lc = rtP . R3_Gain_hslbhc5rsq
* rtB . p2hxwe1zfu ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
gea0cqh513 = ( rtB . msa01agh2x > rtB . i0lfhlq3lc ) ; } rtB . cjfw5loxvr =
rtDW . gea0cqh513 ; rtB . g1xvhnr3f5 = - rtB . i0lfhlq3lc * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hdkgbo205c = ( rtB .
msa01agh2x < rtB . g1xvhnr3f5 ) ; } rtB . iutvmolvr4 = rtDW . hdkgbo205c ; }
if ( rtB . cjfw5loxvr ) { rtB . agzlujxqfb = rtB . i0lfhlq3lc ; } else { if (
rtB . iutvmolvr4 ) { rtB . h0gslfuz00 = rtB . g1xvhnr3f5 ; } else { rtB .
h0gslfuz00 = rtB . msa01agh2x ; } rtB . agzlujxqfb = rtB . h0gslfuz00 ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . ozxljazjel = ( rtB . lms5sy0bav < rtP . Constant_Value_h45zreb2fb ) ;
} rtB . fdzcq5zjwp = rtDW . ozxljazjel ; } switch ( ( int32_T ) rtP .
Battery5_BatType ) { case 1 : rtB . d1g5zgedks [ 0 ] = rtP .
Constant4_Value_om2zghpbx3 * rtB . agzlujxqfb ; rtB . d1g5zgedks [ 1 ] = rtP
. Constant4_Value_om2zghpbx3 * rtB . lms5sy0bav ; rtB . d1g5zgedks [ 2 ] =
rtP . Constant4_Value_om2zghpbx3 * rtB . fdzcq5zjwp ; rtB . d1g5zgedks [ 3 ]
= rtP . Constant4_Value_om2zghpbx3 * rtB . p2hxwe1zfu ; rtB . ogkyqhikl5 = -
rtB . d1g5zgedks [ 2 ] * 0.00461995246297257 * rtB . d1g5zgedks [ 1 ] * (
6.2039999999999846 / ( rtB . d1g5zgedks [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . jmhpv4tqnk [ 0 ] = rtP . Constant1_Value_ny1xdqiske *
rtB . agzlujxqfb ; rtB . jmhpv4tqnk [ 1 ] = rtP . Constant1_Value_ny1xdqiske
* rtB . lms5sy0bav ; rtB . jmhpv4tqnk [ 2 ] = rtP .
Constant1_Value_ny1xdqiske * rtB . fdzcq5zjwp ; rtB . jmhpv4tqnk [ 3 ] = rtP
. Constant1_Value_ny1xdqiske * rtB . p2hxwe1zfu ; rtB . ogkyqhikl5 = - rtB .
jmhpv4tqnk [ 2 ] * 0.00461995246297257 * rtB . jmhpv4tqnk [ 1 ] * rtB .
jmhpv4tqnk [ 3 ] / ( rtB . jmhpv4tqnk [ 3 ] * 0.1 + rtB . jmhpv4tqnk [ 0 ] )
; break ; case 3 : rtB . l2q2yxulmn [ 0 ] = rtP . Constant3_Value_kuyjih2run
* rtB . agzlujxqfb ; rtB . l2q2yxulmn [ 1 ] = rtP .
Constant3_Value_kuyjih2run * rtB . lms5sy0bav ; rtB . l2q2yxulmn [ 2 ] = rtP
. Constant3_Value_kuyjih2run * rtB . fdzcq5zjwp ; rtB . l2q2yxulmn [ 3 ] =
rtP . Constant3_Value_kuyjih2run * rtB . p2hxwe1zfu ; rtB . ogkyqhikl5 = -
rtB . l2q2yxulmn [ 2 ] * 0.00461995246297257 * rtB . l2q2yxulmn [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . l2q2yxulmn [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . bpbiu1lihc [ 0 ] = rtP .
Constant2_Value_ppmjeluned * rtB . agzlujxqfb ; rtB . bpbiu1lihc [ 1 ] = rtP
. Constant2_Value_ppmjeluned * rtB . lms5sy0bav ; rtB . bpbiu1lihc [ 2 ] =
rtP . Constant2_Value_ppmjeluned * rtB . fdzcq5zjwp ; rtB . bpbiu1lihc [ 3 ]
= rtP . Constant2_Value_ppmjeluned * rtB . p2hxwe1zfu ; rtB . ogkyqhikl5 = -
rtB . bpbiu1lihc [ 2 ] * 0.00461995246297257 * rtB . bpbiu1lihc [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . bpbiu1lihc [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . iuvcnk5dmp = rtX . f1hbi1sd1q ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . ggeecprz50 = rtB . bvz4ef4xni >= rtP .
Saturation_UpperSat_dr1jmbb0we ? 1 : rtB . bvz4ef4xni > rtP .
Saturation_LowerSat_haspwmkdbs ? 0 : - 1 ; } rtB . flzlebwg5e = rtDW .
ggeecprz50 == 1 ? rtP . Saturation_UpperSat_dr1jmbb0we : rtDW . ggeecprz50 ==
- 1 ? rtP . Saturation_LowerSat_haspwmkdbs : rtB . bvz4ef4xni ; switch ( (
int32_T ) rtP . Battery5_BatType ) { case 1 : rtB . h3sbcd43z2 = rtB .
iuvcnk5dmp ; break ; case 2 : rtB . h3sbcd43z2 = muDoubleScalarExp ( -
10.176991150442477 * rtB . flzlebwg5e ) * 0.310711063328515 ; break ; case 3
: rtB . h3sbcd43z2 = rtB . iuvcnk5dmp ; break ; default : rtB . h3sbcd43z2 =
rtB . iuvcnk5dmp ; break ; } rtB . dkk3fwnmny = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . ogkyqhikl5 ) + rtB . h3sbcd43z2 ) + - 0.0 * rtB . bvz4ef4xni ; rtB
. l0cwdgyzlo = rtP . Constant_Value_pfu1thap3i + rtB . dkk3fwnmny ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . ejk225g2nh = ( rtB . l0cwdgyzlo > rtP . Constant1_Value_h1thd4w1zg ) ;
} rtB . cp0who25g2 = rtDW . ejk225g2nh ; } rtB . iotsi3yshg = 0.0 ; rtB .
iotsi3yshg += rtP . BAL_C_cq3wtorxkj * rtX . kkgf3fitxr ; rtB . gcxndupnfr =
rtP . R1_Gain_bdgjwewy0w * rtB . iotsi3yshg ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . p2nqnwkq04 = ( rtB .
l0cwdgyzlo < rtB . gcxndupnfr ) ; } rtB . erylo4qhmo = rtDW . p2nqnwkq04 ;
rtB . besqhap1x0 = rtDW . oteopngiwv ; rtB . njfm3f2grf = rtP .
R2_Gain_e5lq5jfqyz * rtB . besqhap1x0 ; rtB . juce2ptz2y = 1.000001 * rtB .
njfm3f2grf * 0.96711798839458663 / 0.9999 ; } if ( rtB . cp0who25g2 ) { rtB .
owgcqoig0n = rtP . Constant1_Value_h1thd4w1zg ; } else { if ( rtB .
erylo4qhmo ) { rtB . is1wchelug = rtB . gcxndupnfr ; } else { rtB .
is1wchelug = rtB . l0cwdgyzlo ; } rtB . owgcqoig0n = rtB . is1wchelug ; } rtB
. baqcdaab4w = 0.0 ; rtB . baqcdaab4w += rtP . Currentfilter_C_gzd0zmcoyy *
rtX . batnhulphm ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . citc1qmgco = ( rtB . baqcdaab4w >
rtP . Constant_Value_crxssz3mu1 ) ; } rtB . lf5xebyb1r = rtDW . citc1qmgco ;
rtB . ppcjroz05k = rtDW . jbkhseznjs ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
kty1ao0csf , ( rtB . lf5xebyb1r ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . k4l2ij22e5 != 0 ) ) { rtX . bnmkr55uji = rtB . ppcjroz05k ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . bnmkr55uji
>= rtP . inti_UpperSat_cuyg3emce0 ) { if ( rtX . bnmkr55uji != rtP .
inti_UpperSat_cuyg3emce0 ) { rtX . bnmkr55uji = rtP .
inti_UpperSat_cuyg3emce0 ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . i3h0yxjcuf = 3 ; } else if ( rtX . bnmkr55uji <= rtP .
inti_LowerSat_l4lrtlmq4a ) { if ( rtX . bnmkr55uji != rtP .
inti_LowerSat_l4lrtlmq4a ) { rtX . bnmkr55uji = rtP .
inti_LowerSat_l4lrtlmq4a ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . i3h0yxjcuf = 4 ; } else { if ( rtDW . i3h0yxjcuf != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . i3h0yxjcuf = 0
; } rtB . ehmperqua5 = rtX . bnmkr55uji ; } else { rtB . ehmperqua5 = rtX .
bnmkr55uji ; } rtB . bqzx2eyzzy = rtP . Gain_Gain_nfwhezh4mu * rtB .
ehmperqua5 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . j1x1lkik4i = ( rtB . bqzx2eyzzy >
rtB . njfm3f2grf ) ; } rtB . hpb3sjmuau = rtDW . j1x1lkik4i ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hp3fpshwsf = ( rtB . bqzx2eyzzy <
rtP . Constant9_Value_khmvv2oadi ) ; } rtB . gdm5q3kphw = rtDW . hp3fpshwsf ;
} if ( rtB . hpb3sjmuau ) { rtB . i5kcdpjhpi = rtB . njfm3f2grf ; } else { if
( rtB . gdm5q3kphw ) { rtB . cs22ftcsml = rtP . Constant9_Value_khmvv2oadi ;
} else { rtB . cs22ftcsml = rtB . bqzx2eyzzy ; } rtB . i5kcdpjhpi = rtB .
cs22ftcsml ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . h4chdtup0e = ( rtB . juce2ptz2y <=
rtB . i5kcdpjhpi ) ; } rtB . agkl53gxjq = rtDW . h4chdtup0e ; } if ( rtB .
agkl53gxjq ) { rtB . aaa1drn5lo = rtB . njfm3f2grf ; } else { rtB .
aaa1drn5lo = rtB . i5kcdpjhpi ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
besqhap1x0 / ( rtB . besqhap1x0 - rtB . aaa1drn5lo ) * rtB . aaa1drn5lo ;
jmuz0todoh = - rtB . lf5xebyb1r * 0.00461995246297257 * rtB . baqcdaab4w *
rtB . besqhap1x0 / ( rtB . besqhap1x0 - rtB . aaa1drn5lo ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . gjn3v2eu4k = rtP . R3_Gain_ozkjsk4x5h
* rtB . besqhap1x0 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
m140lfr1yc = ( rtB . bqzx2eyzzy > rtB . gjn3v2eu4k ) ; } rtB . fk4jwk4iji =
rtDW . m140lfr1yc ; rtB . g201quwjao = - rtB . gjn3v2eu4k * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nrvhe4sfr2 = ( rtB .
bqzx2eyzzy < rtB . g201quwjao ) ; } rtB . f0mgvc4qtv = rtDW . nrvhe4sfr2 ; }
if ( rtB . fk4jwk4iji ) { rtB . ogryssvt51 = rtB . gjn3v2eu4k ; } else { if (
rtB . f0mgvc4qtv ) { rtB . l4aqiuf2c4 = rtB . g201quwjao ; } else { rtB .
l4aqiuf2c4 = rtB . bqzx2eyzzy ; } rtB . ogryssvt51 = rtB . l4aqiuf2c4 ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . dhdzvyusm1 = ( rtB . baqcdaab4w < rtP . Constant_Value_hr1h3melx3 ) ;
} rtB . jo315eteaj = rtDW . dhdzvyusm1 ; } switch ( ( int32_T ) rtP .
Battery6_BatType ) { case 1 : rtB . kmnm3jte0y [ 0 ] = rtP .
Constant4_Value_lcmf40k0jk * rtB . ogryssvt51 ; rtB . kmnm3jte0y [ 1 ] = rtP
. Constant4_Value_lcmf40k0jk * rtB . baqcdaab4w ; rtB . kmnm3jte0y [ 2 ] =
rtP . Constant4_Value_lcmf40k0jk * rtB . jo315eteaj ; rtB . kmnm3jte0y [ 3 ]
= rtP . Constant4_Value_lcmf40k0jk * rtB . besqhap1x0 ; rtB . gl0nhtg1ch = -
rtB . kmnm3jte0y [ 2 ] * 0.00461995246297257 * rtB . kmnm3jte0y [ 1 ] * (
6.2039999999999846 / ( rtB . kmnm3jte0y [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . d0ttldw0xr [ 0 ] = rtP . Constant1_Value_mv1dwtlwtz *
rtB . ogryssvt51 ; rtB . d0ttldw0xr [ 1 ] = rtP . Constant1_Value_mv1dwtlwtz
* rtB . baqcdaab4w ; rtB . d0ttldw0xr [ 2 ] = rtP .
Constant1_Value_mv1dwtlwtz * rtB . jo315eteaj ; rtB . d0ttldw0xr [ 3 ] = rtP
. Constant1_Value_mv1dwtlwtz * rtB . besqhap1x0 ; rtB . gl0nhtg1ch = - rtB .
d0ttldw0xr [ 2 ] * 0.00461995246297257 * rtB . d0ttldw0xr [ 1 ] * rtB .
d0ttldw0xr [ 3 ] / ( rtB . d0ttldw0xr [ 3 ] * 0.1 + rtB . d0ttldw0xr [ 0 ] )
; break ; case 3 : rtB . k0aebkl4fh [ 0 ] = rtP . Constant3_Value_fma5g13bsz
* rtB . ogryssvt51 ; rtB . k0aebkl4fh [ 1 ] = rtP .
Constant3_Value_fma5g13bsz * rtB . baqcdaab4w ; rtB . k0aebkl4fh [ 2 ] = rtP
. Constant3_Value_fma5g13bsz * rtB . jo315eteaj ; rtB . k0aebkl4fh [ 3 ] =
rtP . Constant3_Value_fma5g13bsz * rtB . besqhap1x0 ; rtB . gl0nhtg1ch = -
rtB . k0aebkl4fh [ 2 ] * 0.00461995246297257 * rtB . k0aebkl4fh [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . k0aebkl4fh [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . d0xiworakl [ 0 ] = rtP .
Constant2_Value_hhcyqz43te * rtB . ogryssvt51 ; rtB . d0xiworakl [ 1 ] = rtP
. Constant2_Value_hhcyqz43te * rtB . baqcdaab4w ; rtB . d0xiworakl [ 2 ] =
rtP . Constant2_Value_hhcyqz43te * rtB . jo315eteaj ; rtB . d0xiworakl [ 3 ]
= rtP . Constant2_Value_hhcyqz43te * rtB . besqhap1x0 ; rtB . gl0nhtg1ch = -
rtB . d0xiworakl [ 2 ] * 0.00461995246297257 * rtB . d0xiworakl [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . d0xiworakl [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . as0tme1x3l = rtX . lulwdnmna3 ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . plgswrux01 = rtB . aaa1drn5lo >= rtP .
Saturation_UpperSat_oasdavgelo ? 1 : rtB . aaa1drn5lo > rtP .
Saturation_LowerSat_hlakhjokuc ? 0 : - 1 ; } rtB . pk01kqglup = rtDW .
plgswrux01 == 1 ? rtP . Saturation_UpperSat_oasdavgelo : rtDW . plgswrux01 ==
- 1 ? rtP . Saturation_LowerSat_hlakhjokuc : rtB . aaa1drn5lo ; switch ( (
int32_T ) rtP . Battery6_BatType ) { case 1 : rtB . et4oqao0hp = rtB .
as0tme1x3l ; break ; case 2 : rtB . et4oqao0hp = muDoubleScalarExp ( -
10.176991150442477 * rtB . pk01kqglup ) * 0.310711063328515 ; break ; case 3
: rtB . et4oqao0hp = rtB . as0tme1x3l ; break ; default : rtB . et4oqao0hp =
rtB . as0tme1x3l ; break ; } rtB . b3ob2uqqdm = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . gl0nhtg1ch ) + rtB . et4oqao0hp ) + - 0.0 * rtB . aaa1drn5lo ; rtB
. ecthl1j1o0 = rtP . Constant_Value_mnsc2xmcnp + rtB . b3ob2uqqdm ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . hw43gon1bk = ( rtB . ecthl1j1o0 > rtP . Constant1_Value_fcmat31m3p ) ;
} rtB . cukuo2c3br = rtDW . hw43gon1bk ; } rtB . hhflfdof15 = 0.0 ; rtB .
hhflfdof15 += rtP . BAL_C_c2hdnxiek4 * rtX . opnxmo5ky2 ; rtB . lhhyhpp5gu =
rtP . R1_Gain_bnqyizdjwz * rtB . hhflfdof15 ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . jjq0zsbfta = ( rtB .
ecthl1j1o0 < rtB . lhhyhpp5gu ) ; } rtB . eic4qlkhsy = rtDW . jjq0zsbfta ;
rtB . jp2e2ut45b = rtDW . g0xibfhryj ; rtB . dr4em5z1io = rtP .
R2_Gain_ejdzqjxpj5 * rtB . jp2e2ut45b ; rtB . b2ixyft4ic = 1.000001 * rtB .
dr4em5z1io * 0.96711798839458663 / 0.9999 ; } if ( rtB . cukuo2c3br ) { rtB .
lnjnmhfbjh = rtP . Constant1_Value_fcmat31m3p ; } else { if ( rtB .
eic4qlkhsy ) { rtB . cv4nsrlmii = rtB . lhhyhpp5gu ; } else { rtB .
cv4nsrlmii = rtB . ecthl1j1o0 ; } rtB . lnjnmhfbjh = rtB . cv4nsrlmii ; } rtB
. dm4nf0b0xz = 0.0 ; rtB . dm4nf0b0xz += rtP . Currentfilter_C_pwjctgaucg *
rtX . kec03nv1yd ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . lgtmlehdmv = ( rtB . dm4nf0b0xz >
rtP . Constant_Value_ksing41bve ) ; } rtB . g415uib1wr = rtDW . lgtmlehdmv ;
rtB . cvzcjmgoyh = rtDW . dyomnt0iya ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
klp5c5oug5 , ( rtB . g415uib1wr ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . gbegstnyrm != 0 ) ) { rtX . ducd1mygi5 = rtB . cvzcjmgoyh ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . ducd1mygi5
>= rtP . inti_UpperSat_p1ksyho442 ) { if ( rtX . ducd1mygi5 != rtP .
inti_UpperSat_p1ksyho442 ) { rtX . ducd1mygi5 = rtP .
inti_UpperSat_p1ksyho442 ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . krsqhbk5nm = 3 ; } else if ( rtX . ducd1mygi5 <= rtP .
inti_LowerSat_c2pdzacpit ) { if ( rtX . ducd1mygi5 != rtP .
inti_LowerSat_c2pdzacpit ) { rtX . ducd1mygi5 = rtP .
inti_LowerSat_c2pdzacpit ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . krsqhbk5nm = 4 ; } else { if ( rtDW . krsqhbk5nm != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . krsqhbk5nm = 0
; } rtB . d34ubm25fp = rtX . ducd1mygi5 ; } else { rtB . d34ubm25fp = rtX .
ducd1mygi5 ; } rtB . ggnmpyt3wu = rtP . Gain_Gain_cpenmhpyrf * rtB .
d34ubm25fp ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . ctjashoslt = ( rtB . ggnmpyt3wu >
rtB . dr4em5z1io ) ; } rtB . kds135p0hu = rtDW . ctjashoslt ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . fjenxspruc = ( rtB . ggnmpyt3wu <
rtP . Constant9_Value_hbi2xzqgvf ) ; } rtB . kqgjchdcds = rtDW . fjenxspruc ;
} if ( rtB . kds135p0hu ) { rtB . nqmkidt0nf = rtB . dr4em5z1io ; } else { if
( rtB . kqgjchdcds ) { rtB . n3yk1z5ay1 = rtP . Constant9_Value_hbi2xzqgvf ;
} else { rtB . n3yk1z5ay1 = rtB . ggnmpyt3wu ; } rtB . nqmkidt0nf = rtB .
n3yk1z5ay1 ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hwzhc3avex = ( rtB . b2ixyft4ic <=
rtB . nqmkidt0nf ) ; } rtB . edxzstui5p = rtDW . hwzhc3avex ; } if ( rtB .
edxzstui5p ) { rtB . hvmipewyll = rtB . dr4em5z1io ; } else { rtB .
hvmipewyll = rtB . nqmkidt0nf ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
jp2e2ut45b / ( rtB . jp2e2ut45b - rtB . hvmipewyll ) * rtB . hvmipewyll ;
jmuz0todoh = - rtB . g415uib1wr * 0.00461995246297257 * rtB . dm4nf0b0xz *
rtB . jp2e2ut45b / ( rtB . jp2e2ut45b - rtB . hvmipewyll ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . i0iborr1bn = rtP . R3_Gain_eilrq2a1m2
* rtB . jp2e2ut45b ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
f3a4hcqytw = ( rtB . ggnmpyt3wu > rtB . i0iborr1bn ) ; } rtB . evet21s24l =
rtDW . f3a4hcqytw ; rtB . i0wi0xfyww = - rtB . i0iborr1bn * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . gwdixswkyo = ( rtB .
ggnmpyt3wu < rtB . i0wi0xfyww ) ; } rtB . malsck44d3 = rtDW . gwdixswkyo ; }
if ( rtB . evet21s24l ) { rtB . g4xgxwmrt1 = rtB . i0iborr1bn ; } else { if (
rtB . malsck44d3 ) { rtB . i50k4latrz = rtB . i0wi0xfyww ; } else { rtB .
i50k4latrz = rtB . ggnmpyt3wu ; } rtB . g4xgxwmrt1 = rtB . i50k4latrz ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . mpwatn3jkl = ( rtB . dm4nf0b0xz < rtP . Constant_Value_psd4g00i4r ) ;
} rtB . ipz4zr0egw = rtDW . mpwatn3jkl ; } switch ( ( int32_T ) rtP .
Battery7_BatType ) { case 1 : rtB . p2dnpj1ive [ 0 ] = rtP .
Constant4_Value_jjkyxucjzh * rtB . g4xgxwmrt1 ; rtB . p2dnpj1ive [ 1 ] = rtP
. Constant4_Value_jjkyxucjzh * rtB . dm4nf0b0xz ; rtB . p2dnpj1ive [ 2 ] =
rtP . Constant4_Value_jjkyxucjzh * rtB . ipz4zr0egw ; rtB . p2dnpj1ive [ 3 ]
= rtP . Constant4_Value_jjkyxucjzh * rtB . jp2e2ut45b ; rtB . dfuf4q33n1 = -
rtB . p2dnpj1ive [ 2 ] * 0.00461995246297257 * rtB . p2dnpj1ive [ 1 ] * (
6.2039999999999846 / ( rtB . p2dnpj1ive [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . og4zmu0v2n [ 0 ] = rtP . Constant1_Value_nfwykf0vow *
rtB . g4xgxwmrt1 ; rtB . og4zmu0v2n [ 1 ] = rtP . Constant1_Value_nfwykf0vow
* rtB . dm4nf0b0xz ; rtB . og4zmu0v2n [ 2 ] = rtP .
Constant1_Value_nfwykf0vow * rtB . ipz4zr0egw ; rtB . og4zmu0v2n [ 3 ] = rtP
. Constant1_Value_nfwykf0vow * rtB . jp2e2ut45b ; rtB . dfuf4q33n1 = - rtB .
og4zmu0v2n [ 2 ] * 0.00461995246297257 * rtB . og4zmu0v2n [ 1 ] * rtB .
og4zmu0v2n [ 3 ] / ( rtB . og4zmu0v2n [ 3 ] * 0.1 + rtB . og4zmu0v2n [ 0 ] )
; break ; case 3 : rtB . ayi1laekbu [ 0 ] = rtP . Constant3_Value_ouq0slsocc
* rtB . g4xgxwmrt1 ; rtB . ayi1laekbu [ 1 ] = rtP .
Constant3_Value_ouq0slsocc * rtB . dm4nf0b0xz ; rtB . ayi1laekbu [ 2 ] = rtP
. Constant3_Value_ouq0slsocc * rtB . ipz4zr0egw ; rtB . ayi1laekbu [ 3 ] =
rtP . Constant3_Value_ouq0slsocc * rtB . jp2e2ut45b ; rtB . dfuf4q33n1 = -
rtB . ayi1laekbu [ 2 ] * 0.00461995246297257 * rtB . ayi1laekbu [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . ayi1laekbu [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . pfrnf2ydxj [ 0 ] = rtP .
Constant2_Value_lwxj2lq0w4 * rtB . g4xgxwmrt1 ; rtB . pfrnf2ydxj [ 1 ] = rtP
. Constant2_Value_lwxj2lq0w4 * rtB . dm4nf0b0xz ; rtB . pfrnf2ydxj [ 2 ] =
rtP . Constant2_Value_lwxj2lq0w4 * rtB . ipz4zr0egw ; rtB . pfrnf2ydxj [ 3 ]
= rtP . Constant2_Value_lwxj2lq0w4 * rtB . jp2e2ut45b ; rtB . dfuf4q33n1 = -
rtB . pfrnf2ydxj [ 2 ] * 0.00461995246297257 * rtB . pfrnf2ydxj [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . pfrnf2ydxj [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . mwcys4j4zs = rtX . a2azuhp5qh ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . el3nwtqbps = rtB . hvmipewyll >= rtP .
Saturation_UpperSat_e2rewfpeer ? 1 : rtB . hvmipewyll > rtP .
Saturation_LowerSat_btlbcqipab ? 0 : - 1 ; } rtB . hvabmdtuvh = rtDW .
el3nwtqbps == 1 ? rtP . Saturation_UpperSat_e2rewfpeer : rtDW . el3nwtqbps ==
- 1 ? rtP . Saturation_LowerSat_btlbcqipab : rtB . hvmipewyll ; switch ( (
int32_T ) rtP . Battery7_BatType ) { case 1 : rtB . dhwyvtmepj = rtB .
mwcys4j4zs ; break ; case 2 : rtB . dhwyvtmepj = muDoubleScalarExp ( -
10.176991150442477 * rtB . hvabmdtuvh ) * 0.310711063328515 ; break ; case 3
: rtB . dhwyvtmepj = rtB . mwcys4j4zs ; break ; default : rtB . dhwyvtmepj =
rtB . mwcys4j4zs ; break ; } rtB . ivovkyhxrz = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . dfuf4q33n1 ) + rtB . dhwyvtmepj ) + - 0.0 * rtB . hvmipewyll ; rtB
. bxzkxne3dq = rtP . Constant_Value_diqvfq2vok + rtB . ivovkyhxrz ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . dqufutohhs = ( rtB . bxzkxne3dq > rtP . Constant1_Value_j1ihyekgnt ) ;
} rtB . nwe5vf4a0r = rtDW . dqufutohhs ; } rtB . newud24pbl = 0.0 ; rtB .
newud24pbl += rtP . BAL_C_nwvwd0ihf1 * rtX . c4c3igik4x ; rtB . cd1qrej531 =
rtP . R1_Gain_g4pre24jyp * rtB . newud24pbl ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . a0bwirjyiu = ( rtB .
bxzkxne3dq < rtB . cd1qrej531 ) ; } rtB . fxfy52jqlw = rtDW . a0bwirjyiu ;
rtB . otte1lhfee = rtDW . mmeejs3fon ; rtB . gw4ubpvz5m = rtP .
R2_Gain_bn5zry4edp * rtB . otte1lhfee ; rtB . ja5d4uupyj = 1.000001 * rtB .
gw4ubpvz5m * 0.96711798839458663 / 0.9999 ; } if ( rtB . nwe5vf4a0r ) { rtB .
bjlklhbtye = rtP . Constant1_Value_j1ihyekgnt ; } else { if ( rtB .
fxfy52jqlw ) { rtB . jhzzujuc41 = rtB . cd1qrej531 ; } else { rtB .
jhzzujuc41 = rtB . bxzkxne3dq ; } rtB . bjlklhbtye = rtB . jhzzujuc41 ; } rtB
. kxpcdql4jz = 0.0 ; rtB . kxpcdql4jz += rtP . Currentfilter_C_a0gtd4kont *
rtX . jgg0wj1zhe ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . j31b3jsmjg = ( rtB . kxpcdql4jz >
rtP . Constant_Value_ep2qfgttrh ) ; } rtB . codhkowftx = rtDW . j31b3jsmjg ;
rtB . fx2apmzawu = rtDW . cixbj0ezqf ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
p2zcekh3xh , ( rtB . codhkowftx ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . ioqp4ngatr != 0 ) ) { rtX . mludnzmfko = rtB . fx2apmzawu ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . mludnzmfko
>= rtP . inti_UpperSat_gge1msuajg ) { if ( rtX . mludnzmfko != rtP .
inti_UpperSat_gge1msuajg ) { rtX . mludnzmfko = rtP .
inti_UpperSat_gge1msuajg ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . bmltxw1qtk = 3 ; } else if ( rtX . mludnzmfko <= rtP .
inti_LowerSat_b5bkhbogxv ) { if ( rtX . mludnzmfko != rtP .
inti_LowerSat_b5bkhbogxv ) { rtX . mludnzmfko = rtP .
inti_LowerSat_b5bkhbogxv ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . bmltxw1qtk = 4 ; } else { if ( rtDW . bmltxw1qtk != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . bmltxw1qtk = 0
; } rtB . nvr2gta2ze = rtX . mludnzmfko ; } else { rtB . nvr2gta2ze = rtX .
mludnzmfko ; } rtB . ak5ny2xuat = rtP . Gain_Gain_ot14m0p13e * rtB .
nvr2gta2ze ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . eshqu4qlyj = ( rtB . ak5ny2xuat >
rtB . gw4ubpvz5m ) ; } rtB . nvn1ehmkrx = rtDW . eshqu4qlyj ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . aiibi55tgx = ( rtB . ak5ny2xuat <
rtP . Constant9_Value_lgn0aviuoi ) ; } rtB . luugfk3sgm = rtDW . aiibi55tgx ;
} if ( rtB . nvn1ehmkrx ) { rtB . jufwanbg3o = rtB . gw4ubpvz5m ; } else { if
( rtB . luugfk3sgm ) { rtB . cojxsmfsrh = rtP . Constant9_Value_lgn0aviuoi ;
} else { rtB . cojxsmfsrh = rtB . ak5ny2xuat ; } rtB . jufwanbg3o = rtB .
cojxsmfsrh ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hb2spknlp1 = ( rtB . ja5d4uupyj <=
rtB . jufwanbg3o ) ; } rtB . hnmfvx1wci = rtDW . hb2spknlp1 ; } if ( rtB .
hnmfvx1wci ) { rtB . jwjptsm01d = rtB . gw4ubpvz5m ; } else { rtB .
jwjptsm01d = rtB . jufwanbg3o ; } k0qu5tzxih = - 0.00461995246297257 * rtB .
otte1lhfee / ( rtB . otte1lhfee - rtB . jwjptsm01d ) * rtB . jwjptsm01d ;
jmuz0todoh = - rtB . codhkowftx * 0.00461995246297257 * rtB . kxpcdql4jz *
rtB . otte1lhfee / ( rtB . otte1lhfee - rtB . jwjptsm01d ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . jwcx5x3uww = rtP . R3_Gain_molbysildp
* rtB . otte1lhfee ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
f1xr4ouflt = ( rtB . ak5ny2xuat > rtB . jwcx5x3uww ) ; } rtB . h20jo3vqoy =
rtDW . f1xr4ouflt ; rtB . acxnkfdwy1 = - rtB . jwcx5x3uww * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . oo4b1k4vub = ( rtB .
ak5ny2xuat < rtB . acxnkfdwy1 ) ; } rtB . ksknuspzbv = rtDW . oo4b1k4vub ; }
if ( rtB . h20jo3vqoy ) { rtB . aftb2w02md = rtB . jwcx5x3uww ; } else { if (
rtB . ksknuspzbv ) { rtB . ahmttm3rdd = rtB . acxnkfdwy1 ; } else { rtB .
ahmttm3rdd = rtB . ak5ny2xuat ; } rtB . aftb2w02md = rtB . ahmttm3rdd ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . dofxxfnf1f = ( rtB . kxpcdql4jz < rtP . Constant_Value_lyegm1i5cg ) ;
} rtB . apkx5dx1qe = rtDW . dofxxfnf1f ; } switch ( ( int32_T ) rtP .
Battery8_BatType ) { case 1 : rtB . g2v5eyf0fn [ 0 ] = rtP .
Constant4_Value_oq3sj0rsir * rtB . aftb2w02md ; rtB . g2v5eyf0fn [ 1 ] = rtP
. Constant4_Value_oq3sj0rsir * rtB . kxpcdql4jz ; rtB . g2v5eyf0fn [ 2 ] =
rtP . Constant4_Value_oq3sj0rsir * rtB . apkx5dx1qe ; rtB . g2v5eyf0fn [ 3 ]
= rtP . Constant4_Value_oq3sj0rsir * rtB . otte1lhfee ; rtB . mmu3qpagt3 = -
rtB . g2v5eyf0fn [ 2 ] * 0.00461995246297257 * rtB . g2v5eyf0fn [ 1 ] * (
6.2039999999999846 / ( rtB . g2v5eyf0fn [ 0 ] + 0.62039999999999851 ) ) ;
break ; case 2 : rtB . gre2qqt31t [ 0 ] = rtP . Constant1_Value_h3fhvhzpts *
rtB . aftb2w02md ; rtB . gre2qqt31t [ 1 ] = rtP . Constant1_Value_h3fhvhzpts
* rtB . kxpcdql4jz ; rtB . gre2qqt31t [ 2 ] = rtP .
Constant1_Value_h3fhvhzpts * rtB . apkx5dx1qe ; rtB . gre2qqt31t [ 3 ] = rtP
. Constant1_Value_h3fhvhzpts * rtB . otte1lhfee ; rtB . mmu3qpagt3 = - rtB .
gre2qqt31t [ 2 ] * 0.00461995246297257 * rtB . gre2qqt31t [ 1 ] * rtB .
gre2qqt31t [ 3 ] / ( rtB . gre2qqt31t [ 3 ] * 0.1 + rtB . gre2qqt31t [ 0 ] )
; break ; case 3 : rtB . g2neorilhq [ 0 ] = rtP . Constant3_Value_fn3ludrege
* rtB . aftb2w02md ; rtB . g2neorilhq [ 1 ] = rtP .
Constant3_Value_fn3ludrege * rtB . kxpcdql4jz ; rtB . g2neorilhq [ 2 ] = rtP
. Constant3_Value_fn3ludrege * rtB . apkx5dx1qe ; rtB . g2neorilhq [ 3 ] =
rtP . Constant3_Value_fn3ludrege * rtB . otte1lhfee ; rtB . mmu3qpagt3 = -
rtB . g2neorilhq [ 2 ] * 0.00461995246297257 * rtB . g2neorilhq [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . g2neorilhq [ 0 ] ) +
0.62039999999999851 ) ) ; break ; default : rtB . ma44kqgc1u [ 0 ] = rtP .
Constant2_Value_dgpgyrzaqa * rtB . aftb2w02md ; rtB . ma44kqgc1u [ 1 ] = rtP
. Constant2_Value_dgpgyrzaqa * rtB . kxpcdql4jz ; rtB . ma44kqgc1u [ 2 ] =
rtP . Constant2_Value_dgpgyrzaqa * rtB . apkx5dx1qe ; rtB . ma44kqgc1u [ 3 ]
= rtP . Constant2_Value_dgpgyrzaqa * rtB . otte1lhfee ; rtB . mmu3qpagt3 = -
rtB . ma44kqgc1u [ 2 ] * 0.00461995246297257 * rtB . ma44kqgc1u [ 1 ] * (
6.2039999999999846 / ( muDoubleScalarAbs ( rtB . ma44kqgc1u [ 0 ] ) +
0.62039999999999851 ) ) ; break ; } rtB . bwiu5f3xyy = rtX . fhoa1aghtu ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . llohfphikn = rtB . jwjptsm01d >= rtP .
Saturation_UpperSat_pwhhuyqzpe ? 1 : rtB . jwjptsm01d > rtP .
Saturation_LowerSat_gq5b2q5hog ? 0 : - 1 ; } rtB . nm54nmq004 = rtDW .
llohfphikn == 1 ? rtP . Saturation_UpperSat_pwhhuyqzpe : rtDW . llohfphikn ==
- 1 ? rtP . Saturation_LowerSat_gq5b2q5hog : rtB . jwjptsm01d ; switch ( (
int32_T ) rtP . Battery8_BatType ) { case 1 : rtB . geb23uw5n4 = rtB .
bwiu5f3xyy ; break ; case 2 : rtB . geb23uw5n4 = muDoubleScalarExp ( -
10.176991150442477 * rtB . nm54nmq004 ) * 0.310711063328515 ; break ; case 3
: rtB . geb23uw5n4 = rtB . bwiu5f3xyy ; break ; default : rtB . geb23uw5n4 =
rtB . bwiu5f3xyy ; break ; } rtB . bo1fzqwe00 = ( ( ( k0qu5tzxih + jmuz0todoh
) + rtB . mmu3qpagt3 ) + rtB . geb23uw5n4 ) + - 0.0 * rtB . jwjptsm01d ; rtB
. cnd3dqmhap = rtP . Constant_Value_avhibee4iu + rtB . bo1fzqwe00 ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . d1fn42zlc3 = ( rtB . cnd3dqmhap > rtP . Constant1_Value_mntemyjbjb ) ;
} rtB . n3fyjsfyy0 = rtDW . d1fn42zlc3 ; } rtB . eg2jmmryoa = 0.0 ; rtB .
eg2jmmryoa += rtP . BAL_C_bahpumao3b * rtX . kxckn4j1uq ; rtB . lizolknie1 =
rtP . R1_Gain_n5on15rj3k * rtB . eg2jmmryoa ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hbgw2vseyr = ( rtB .
cnd3dqmhap < rtB . lizolknie1 ) ; } rtB . hrjctsjkxd = rtDW . hbgw2vseyr ; }
if ( rtB . n3fyjsfyy0 ) { rtB . a2ssj2eqbk = rtP . Constant1_Value_mntemyjbjb
; } else { if ( rtB . hrjctsjkxd ) { rtB . mgautzzkuz = rtB . lizolknie1 ; }
else { rtB . mgautzzkuz = rtB . cnd3dqmhap ; } rtB . a2ssj2eqbk = rtB .
mgautzzkuz ; } { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnOutputs (
rts , 0 ) ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . fs4j0t3iiz = rtP .
R4_Gain * rtB . fqm02mu2mr ; } rtB . gp1kmspjlh = ( 1.0 - rtB . p0r2azag0g /
rtB . fs4j0t3iiz ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW .
dse1mzthll = rtB . gp1kmspjlh >= rtP . Saturation_UpperSat_pcz043fnep ? 1 :
rtB . gp1kmspjlh > rtP . Saturation_LowerSat_b05y2t0vvl ? 0 : - 1 ; } rtB .
kkv1pr3lrm = rtDW . dse1mzthll == 1 ? rtP . Saturation_UpperSat_pcz043fnep :
rtDW . dse1mzthll == - 1 ? rtP . Saturation_LowerSat_b05y2t0vvl : rtB .
gp1kmspjlh ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . ns2ruilj2v = rtP .
R4_Gain_ayggl2vp1n * rtB . ojlbfd1f01 ; } rtB . eft5k5m2mk = ( 1.0 - rtB .
nv44crtc44 / rtB . ns2ruilj2v ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . dqvqnr2muv = rtB . eft5k5m2mk >= rtP . Saturation_UpperSat_aqwzuangfk
? 1 : rtB . eft5k5m2mk > rtP . Saturation_LowerSat_bcd3czsgyq ? 0 : - 1 ; }
rtB . kx5llxdy1m = rtDW . dqvqnr2muv == 1 ? rtP .
Saturation_UpperSat_aqwzuangfk : rtDW . dqvqnr2muv == - 1 ? rtP .
Saturation_LowerSat_bcd3czsgyq : rtB . eft5k5m2mk ; rtB . l1byjbqlra =
muDoubleScalarAbs ( rtB . kkv1pr3lrm - rtB . kx5llxdy1m ) ; k0qu5tzxih = (
rtB . kkv1pr3lrm + rtB . kx5llxdy1m ) * rtP . Constant6_Value ; rtB .
i20qdjqwof [ 0 ] = rtB . l1byjbqlra ; rtB . i20qdjqwof [ 1 ] = k0qu5tzxih ;
jmuz0todoh = 0.0 ; tmp_p [ 0 ] = - 4.17 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] =
4.17 ; inputMFCache [ 0 ] = cgvkp0zasm ( rtB . i20qdjqwof [ 0 ] , tmp_p ) ;
inputMFCache [ 1 ] = cgvkp0zasm ( rtB . i20qdjqwof [ 0 ] , c ) ; inputMFCache
[ 2 ] = cgvkp0zasm ( rtB . i20qdjqwof [ 0 ] , d ) ; tmp_p [ 0 ] = 0.0 ; tmp_p
[ 1 ] = 0.005 ; tmp_p [ 2 ] = 0.01 ; inputMFCache [ 3 ] = cgvkp0zasm ( rtB .
i20qdjqwof [ 0 ] , tmp_p ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ;
tmp_p [ 2 ] = 41.67 ; inputMFCache [ 4 ] = cgvkp0zasm ( rtB . i20qdjqwof [ 1
] , tmp_p ) ; inputMFCache [ 5 ] = cgvkp0zasm ( rtB . i20qdjqwof [ 1 ] , e )
; inputMFCache [ 6 ] = cgvkp0zasm ( rtB . i20qdjqwof [ 1 ] , f ) ; tmp_p [ 0
] = 0.0 ; tmp_p [ 1 ] = 0.005 ; tmp_p [ 2 ] = 0.01 ; inputMFCache [ 7 ] =
cgvkp0zasm ( rtB . i20qdjqwof [ 1 ] , tmp_p ) ; for ( i = 0 ; i < 10 ; i ++ )
{ b = b_p [ i ] ; dSOC5_6 = ( b == 1 ) ; mVal = inputMFCache [ g [ i ] - 1 ]
; if ( b == 1 ) { if ( ( dSOC5_6 > mVal ) || ( muDoubleScalarIsNaN ( dSOC5_6
) && ( ! muDoubleScalarIsNaN ( mVal ) ) ) ) { dSOC5_6 = mVal ; } } else if (
( dSOC5_6 < mVal ) || ( muDoubleScalarIsNaN ( dSOC5_6 ) && ( !
muDoubleScalarIsNaN ( mVal ) ) ) ) { dSOC5_6 = mVal ; } mVal = inputMFCache [
g [ i + 10 ] + 3 ] ; if ( b == 1 ) { if ( ( dSOC5_6 > mVal ) || (
muDoubleScalarIsNaN ( dSOC5_6 ) && ( ! muDoubleScalarIsNaN ( mVal ) ) ) ) {
dSOC5_6 = mVal ; } } else if ( ( dSOC5_6 < mVal ) || ( muDoubleScalarIsNaN (
dSOC5_6 ) && ( ! muDoubleScalarIsNaN ( mVal ) ) ) ) { dSOC5_6 = mVal ; }
jmuz0todoh += dSOC5_6 ; ajfnmu1awg [ i ] = dSOC5_6 ; } rtB . fztujntlhv [ 0 ]
= rtB . l1byjbqlra ; rtB . fztujntlhv [ 1 ] = k0qu5tzxih ; nvjgycdn5t ( rtP .
OutputSamplePoints_Value_bs0he10brt , b_e , tmp_e ) ; nvjgycdn5t ( rtP .
OutputSamplePoints_Value_bs0he10brt , c_p , tmp_i ) ; tmp_p [ 0 ] = 0.5417 ;
tmp_p [ 1 ] = 0.75 ; tmp_p [ 2 ] = 0.9583 ; nvjgycdn5t ( rtP .
OutputSamplePoints_Value_bs0he10brt , tmp_p , tmp_m ) ; tmp_p [ 0 ] = 0.25 ;
tmp_p [ 1 ] = 0.375 ; tmp_p [ 2 ] = 0.5 ; nvjgycdn5t ( rtP .
OutputSamplePoints_Value_bs0he10brt , tmp_p , tmp_g ) ; tmp_p [ 0 ] = 0.5 ;
tmp_p [ 1 ] = 0.625 ; tmp_p [ 2 ] = 0.75 ; nvjgycdn5t ( rtP .
OutputSamplePoints_Value_bs0he10brt , tmp_p , tmp_j ) ; tmp_p [ 0 ] = 0.0 ;
tmp_p [ 1 ] = 0.005 ; tmp_p [ 2 ] = 0.01 ; nvjgycdn5t ( rtP .
OutputSamplePoints_Value_bs0he10brt , tmp_p , tmp_f ) ; for ( i = 0 ; i < 101
; i ++ ) { i1gb02weu2 [ i ] = 0.0 ; rtB . outputMFCache [ 6 * i ] = tmp_e [ i
] ; rtB . outputMFCache [ 6 * i + 1 ] = tmp_i [ i ] ; rtB . outputMFCache [ 6
* i + 2 ] = tmp_m [ i ] ; rtB . outputMFCache [ 6 * i + 3 ] = tmp_g [ i ] ;
rtB . outputMFCache [ 6 * i + 4 ] = tmp_j [ i ] ; rtB . outputMFCache [ 6 * i
+ 5 ] = tmp_f [ i ] ; } for ( i = 0 ; i < 10 ; i ++ ) { dSOC5_6 = ajfnmu1awg
[ i ] ; for ( inputID = 0 ; inputID < 101 ; inputID ++ ) { dSOC7_8 =
i1gb02weu2 [ inputID ] ; mVal = rtB . outputMFCache [ ( 6 * inputID + d_p [ i
] ) - 1 ] ; if ( ( mVal > dSOC5_6 ) || ( muDoubleScalarIsNaN ( mVal ) && ( !
muDoubleScalarIsNaN ( dSOC5_6 ) ) ) ) { mVal = dSOC5_6 ; } if ( ( dSOC7_8 <
mVal ) || ( muDoubleScalarIsNaN ( dSOC7_8 ) && ( ! muDoubleScalarIsNaN ( mVal
) ) ) ) { dSOC7_8 = mVal ; } i1gb02weu2 [ inputID ] = dSOC7_8 ; } } if (
jmuz0todoh == 0.0 ) { rtB . bcxdnmatsv = 0.5 ; } else { jmuz0todoh = 0.0 ;
mVal = 0.0 ; for ( i = 0 ; i < 101 ; i ++ ) { mVal += i1gb02weu2 [ i ] ; } if
( mVal == 0.0 ) { rtB . bcxdnmatsv = ( rtP .
OutputSamplePoints_Value_bs0he10brt [ 0 ] + rtP .
OutputSamplePoints_Value_bs0he10brt [ 100 ] ) / 2.0 ; } else { for ( i = 0 ;
i < 101 ; i ++ ) { jmuz0todoh += rtP . OutputSamplePoints_Value_bs0he10brt [
i ] * i1gb02weu2 [ i ] ; } rtB . bcxdnmatsv = 1.0 / mVal * jmuz0todoh ; } }
if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . lt3wgqvpso = ( rtB . l1byjbqlra >
rtP . Switch_Threshold ) ; } if ( rtDW . lt3wgqvpso ) { rtB . iwlpqqhwtd =
rtB . bcxdnmatsv ; } else { rtB . iwlpqqhwtd = rtP .
Constant_Value_e1gwiy1pb3 ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB .
ou3yruthi3 = rtP . R4_Gain_ckkisgzyfx * rtB . kslnv1njp2 ; } rtB . gfahibyvsv
= ( 1.0 - rtB . lz4r5vsjh1 / rtB . ou3yruthi3 ) * 100.0 ; if (
ssIsMajorTimeStep ( rtS ) ) { rtDW . c4c5mjr1mx = rtB . gfahibyvsv >= rtP .
Saturation_UpperSat_i3x3oscagf ? 1 : rtB . gfahibyvsv > rtP .
Saturation_LowerSat_gnz45aadu0 ? 0 : - 1 ; } rtB . iqgkwhugb1 = rtDW .
c4c5mjr1mx == 1 ? rtP . Saturation_UpperSat_i3x3oscagf : rtDW . c4c5mjr1mx ==
- 1 ? rtP . Saturation_LowerSat_gnz45aadu0 : rtB . gfahibyvsv ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . ctz5askxrg = rtP . R4_Gain_nfptou1h22
* rtB . czyx3zxlle ; } rtB . lffxmmonqb = ( 1.0 - rtB . g5hkbvjtz4 / rtB .
ctz5askxrg ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . bowq5mbaku =
rtB . lffxmmonqb >= rtP . Saturation_UpperSat_luxvjfmfd3 ? 1 : rtB .
lffxmmonqb > rtP . Saturation_LowerSat_mqcesji40p ? 0 : - 1 ; } rtB .
ilzwywxync = rtDW . bowq5mbaku == 1 ? rtP . Saturation_UpperSat_luxvjfmfd3 :
rtDW . bowq5mbaku == - 1 ? rtP . Saturation_LowerSat_mqcesji40p : rtB .
lffxmmonqb ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . ork1qkhic1 = rtP .
R4_Gain_e51nv5aiyc * rtB . p2hxwe1zfu ; } rtB . givksyq1ks = ( 1.0 - rtB .
bvz4ef4xni / rtB . ork1qkhic1 ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . ax3qgrkr55 = rtB . givksyq1ks >= rtP . Saturation_UpperSat_p4wbgcsokm
? 1 : rtB . givksyq1ks > rtP . Saturation_LowerSat_gdbbvpyvzg ? 0 : - 1 ; }
rtB . cizwakiveg = rtDW . ax3qgrkr55 == 1 ? rtP .
Saturation_UpperSat_p4wbgcsokm : rtDW . ax3qgrkr55 == - 1 ? rtP .
Saturation_LowerSat_gdbbvpyvzg : rtB . givksyq1ks ; if ( ssIsSampleHit ( rtS
, 1 , 0 ) ) { rtB . cyebjd4msb = rtP . R4_Gain_l2wha3sgrh * rtB . besqhap1x0
; } rtB . lolyh00lpd = ( 1.0 - rtB . aaa1drn5lo / rtB . cyebjd4msb ) * 100.0
; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . apxa0sqt1p = rtB . lolyh00lpd >=
rtP . Saturation_UpperSat_iofvqb3bhc ? 1 : rtB . lolyh00lpd > rtP .
Saturation_LowerSat_ob0aofpwnu ? 0 : - 1 ; } rtB . kgcldxtuqy = rtDW .
apxa0sqt1p == 1 ? rtP . Saturation_UpperSat_iofvqb3bhc : rtDW . apxa0sqt1p ==
- 1 ? rtP . Saturation_LowerSat_ob0aofpwnu : rtB . lolyh00lpd ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . o5jsafr2c3 = rtP . R4_Gain_g4hvk30k1k
* rtB . jp2e2ut45b ; } rtB . aacglbrseh = ( 1.0 - rtB . hvmipewyll / rtB .
o5jsafr2c3 ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . b4njscmbvx =
rtB . aacglbrseh >= rtP . Saturation_UpperSat_f2amnkjsa0 ? 1 : rtB .
aacglbrseh > rtP . Saturation_LowerSat_lbyytgqsae ? 0 : - 1 ; } rtB .
pw5q5s3yxm = rtDW . b4njscmbvx == 1 ? rtP . Saturation_UpperSat_f2amnkjsa0 :
rtDW . b4njscmbvx == - 1 ? rtP . Saturation_LowerSat_lbyytgqsae : rtB .
aacglbrseh ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . nehx4sjmhx = rtP .
R4_Gain_dwzv1lgknn * rtB . otte1lhfee ; } rtB . ilnuaaom40 = ( 1.0 - rtB .
jwjptsm01d / rtB . nehx4sjmhx ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . etyjay2nca = rtB . ilnuaaom40 >= rtP . Saturation_UpperSat_dtvs1qra3o
? 1 : rtB . ilnuaaom40 > rtP . Saturation_LowerSat_huwlm3xk3n ? 0 : - 1 ; }
rtB . d3jd5igxzc = rtDW . etyjay2nca == 1 ? rtP .
Saturation_UpperSat_dtvs1qra3o : rtDW . etyjay2nca == - 1 ? rtP .
Saturation_LowerSat_huwlm3xk3n : rtB . ilnuaaom40 ; rtB . iu33mby5ow = 0.0 ;
rtB . iy0igec4ex = 0.0 ; rtB . nhvmldohqo = 0.0 ; jmuz0todoh =
muDoubleScalarAbs ( rtB . kkv1pr3lrm - rtB . kx5llxdy1m ) ; mVal =
muDoubleScalarAbs ( rtB . iqgkwhugb1 - rtB . ilzwywxync ) ; dSOC5_6 =
muDoubleScalarAbs ( rtB . cizwakiveg - rtB . kgcldxtuqy ) ; dSOC7_8 =
muDoubleScalarAbs ( rtB . pw5q5s3yxm - rtB . d3jd5igxzc ) ; if ( ( jmuz0todoh
< 0.01 ) && ( mVal < 0.01 ) ) { rtB . iu33mby5ow = 1.0 ; } if ( ( dSOC5_6 <
0.01 ) && ( dSOC7_8 < 0.01 ) ) { rtB . iy0igec4ex = 1.0 ; } if ( (
muDoubleScalarAbs ( jmuz0todoh - mVal ) < 0.01 ) && ( muDoubleScalarAbs (
dSOC5_6 - dSOC7_8 ) < 0.01 ) ) { rtB . nhvmldohqo = 1.0 ; } rtB . lpxn0wunpn
= rtB . iqgkwhugb1 - rtB . ilzwywxync ; if ( ssGetIsOkayToUpdateMode ( rtS )
) { rtDW . fdlraqlrof = ( rtB . lpxn0wunpn >= 0.0 ) ; } rtB . a3i41vp1qh =
rtDW . fdlraqlrof > 0 ? rtB . lpxn0wunpn : - rtB . lpxn0wunpn ; ga5u1ceorf =
( rtB . iqgkwhugb1 + rtB . ilzwywxync ) * rtP . Constant8_Value ; rtB .
jks2jckbmk [ 0 ] = rtB . a3i41vp1qh ; rtB . jks2jckbmk [ 1 ] = ga5u1ceorf ;
jmuz0todoh = 0.0 ; tmp_p [ 0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] =
2.085 ; inputMFCache_p [ 0 ] = cgvkp0zasm ( rtB . jks2jckbmk [ 0 ] , tmp_p )
; inputMFCache_p [ 1 ] = cgvkp0zasm ( rtB . jks2jckbmk [ 0 ] , b_i ) ;
inputMFCache_p [ 2 ] = cgvkp0zasm ( rtB . jks2jckbmk [ 0 ] , c_e ) ; tmp_p [
0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ; inputMFCache_p [ 3
] = cgvkp0zasm ( rtB . jks2jckbmk [ 1 ] , tmp_p ) ; inputMFCache_p [ 4 ] =
cgvkp0zasm ( rtB . jks2jckbmk [ 1 ] , e ) ; inputMFCache_p [ 5 ] = cgvkp0zasm
( rtB . jks2jckbmk [ 1 ] , f ) ; for ( i = 0 ; i < 9 ; i ++ ) { kato2byaio [
i ] = 1.0 ; mVal = kato2byaio [ i ] ; dSOC5_6 = inputMFCache_p [ f_p [ i ] -
1 ] ; if ( ( mVal > dSOC5_6 ) || ( muDoubleScalarIsNaN ( mVal ) && ( !
muDoubleScalarIsNaN ( dSOC5_6 ) ) ) ) { kato2byaio [ i ] = dSOC5_6 ; } else {
kato2byaio [ i ] = mVal ; } mVal = kato2byaio [ i ] ; dSOC5_6 =
inputMFCache_p [ f_p [ i + 9 ] + 2 ] ; if ( ( mVal > dSOC5_6 ) || (
muDoubleScalarIsNaN ( mVal ) && ( ! muDoubleScalarIsNaN ( dSOC5_6 ) ) ) ) {
kato2byaio [ i ] = dSOC5_6 ; } else { kato2byaio [ i ] = mVal ; } jmuz0todoh
+= kato2byaio [ i ] ; } nntoyhbqoo ( rtB . a3i41vp1qh , ga5u1ceorf ,
kato2byaio , rtP . OutputSamplePoints_Value_mkqnjleygm , & rtB . k43q2yzt11 )
; if ( jmuz0todoh == 0.0 ) { rtB . l2reh15lkf = 0.5 ; } else { jmuz0todoh =
0.0 ; mVal = 0.0 ; for ( i = 0 ; i < 101 ; i ++ ) { mVal += rtB . k43q2yzt11
. gz0uq5kqkr [ i ] ; } if ( mVal == 0.0 ) { rtB . l2reh15lkf = ( rtP .
OutputSamplePoints_Value_mkqnjleygm [ 0 ] + rtP .
OutputSamplePoints_Value_mkqnjleygm [ 100 ] ) / 2.0 ; } else { for ( i = 0 ;
i < 101 ; i ++ ) { jmuz0todoh += rtP . OutputSamplePoints_Value_mkqnjleygm [
i ] * rtB . k43q2yzt11 . gz0uq5kqkr [ i ] ; } rtB . l2reh15lkf = 1.0 / mVal *
jmuz0todoh ; } } if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . ec4jake2ld = ( rtB
. a3i41vp1qh > rtP . Switch1_Threshold ) ; } if ( rtDW . ec4jake2ld ) { rtB .
jtiok3ecro = rtB . l2reh15lkf ; } else { rtB . jtiok3ecro = rtP .
Constant1_Value_mf4xbwjhdv ; } rtB . p5n3swm2z3 = rtB . cizwakiveg - rtB .
kgcldxtuqy ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . omqfuqupyg = (
rtB . p5n3swm2z3 >= 0.0 ) ; } rtB . kocesgc4kq = rtDW . omqfuqupyg > 0 ? rtB
. p5n3swm2z3 : - rtB . p5n3swm2z3 ; dxudqq1xoi = ( rtB . cizwakiveg + rtB .
kgcldxtuqy ) * rtP . Constant7_Value ; rtB . jrje30z1er [ 0 ] = rtB .
kocesgc4kq ; rtB . jrje30z1er [ 1 ] = dxudqq1xoi ; jmuz0todoh = 0.0 ; tmp_p [
0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache_p [ 0
] = cgvkp0zasm ( rtB . jrje30z1er [ 0 ] , tmp_p ) ; inputMFCache_p [ 1 ] =
cgvkp0zasm ( rtB . jrje30z1er [ 0 ] , b_i ) ; inputMFCache_p [ 2 ] =
cgvkp0zasm ( rtB . jrje30z1er [ 0 ] , c_e ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [
1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ; inputMFCache_p [ 3 ] = cgvkp0zasm ( rtB .
jrje30z1er [ 1 ] , tmp_p ) ; inputMFCache_p [ 4 ] = cgvkp0zasm ( rtB .
jrje30z1er [ 1 ] , e ) ; inputMFCache_p [ 5 ] = cgvkp0zasm ( rtB . jrje30z1er
[ 1 ] , f ) ; for ( i = 0 ; i < 9 ; i ++ ) { h03e2sx5pj [ i ] = 1.0 ; mVal =
h03e2sx5pj [ i ] ; dSOC5_6 = inputMFCache_p [ f_p [ i ] - 1 ] ; if ( ( mVal >
dSOC5_6 ) || ( muDoubleScalarIsNaN ( mVal ) && ( ! muDoubleScalarIsNaN (
dSOC5_6 ) ) ) ) { h03e2sx5pj [ i ] = dSOC5_6 ; } else { h03e2sx5pj [ i ] =
mVal ; } mVal = h03e2sx5pj [ i ] ; dSOC5_6 = inputMFCache_p [ f_p [ i + 9 ] +
2 ] ; if ( ( mVal > dSOC5_6 ) || ( muDoubleScalarIsNaN ( mVal ) && ( !
muDoubleScalarIsNaN ( dSOC5_6 ) ) ) ) { h03e2sx5pj [ i ] = dSOC5_6 ; } else {
h03e2sx5pj [ i ] = mVal ; } jmuz0todoh += h03e2sx5pj [ i ] ; } nntoyhbqoo (
rtB . kocesgc4kq , dxudqq1xoi , h03e2sx5pj , rtP .
OutputSamplePoints_Value_h5oozv5nnj , & rtB . bk2qkpodeg ) ; if ( jmuz0todoh
== 0.0 ) { rtB . eedseylcxx = 0.5 ; } else { jmuz0todoh = 0.0 ; mVal = 0.0 ;
for ( i = 0 ; i < 101 ; i ++ ) { mVal += rtB . bk2qkpodeg . gz0uq5kqkr [ i ]
; } if ( mVal == 0.0 ) { rtB . eedseylcxx = ( rtP .
OutputSamplePoints_Value_h5oozv5nnj [ 0 ] + rtP .
OutputSamplePoints_Value_h5oozv5nnj [ 100 ] ) / 2.0 ; } else { for ( i = 0 ;
i < 101 ; i ++ ) { jmuz0todoh += rtP . OutputSamplePoints_Value_h5oozv5nnj [
i ] * rtB . bk2qkpodeg . gz0uq5kqkr [ i ] ; } rtB . eedseylcxx = 1.0 / mVal *
jmuz0todoh ; } } if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . j53kvzldk2 = ( rtB
. kocesgc4kq > rtP . Switch2_Threshold ) ; } if ( rtDW . j53kvzldk2 ) { rtB .
ot4gqzqydm = rtB . eedseylcxx ; } else { rtB . ot4gqzqydm = rtP .
Constant4_Value_fxnxt0eszt ; } rtB . k4qktqs5bt = rtB . pw5q5s3yxm - rtB .
d3jd5igxzc ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . gzlp0sbo4t = (
rtB . k4qktqs5bt >= 0.0 ) ; } rtB . prlvalkk0e = rtDW . gzlp0sbo4t > 0 ? rtB
. k4qktqs5bt : - rtB . k4qktqs5bt ; ivey5iysam = ( rtB . pw5q5s3yxm + rtB .
d3jd5igxzc ) * rtP . Constant9_Value_crabpzohh2 ; rtB . fconsse5vt [ 0 ] =
rtB . prlvalkk0e ; rtB . fconsse5vt [ 1 ] = ivey5iysam ; jmuz0todoh = 0.0 ;
tmp_p [ 0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ;
inputMFCache_p [ 0 ] = cgvkp0zasm ( rtB . fconsse5vt [ 0 ] , tmp_p ) ;
inputMFCache_p [ 1 ] = cgvkp0zasm ( rtB . fconsse5vt [ 0 ] , b_i ) ;
inputMFCache_p [ 2 ] = cgvkp0zasm ( rtB . fconsse5vt [ 0 ] , c_e ) ; tmp_p [
0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ; inputMFCache_p [ 3
] = cgvkp0zasm ( rtB . fconsse5vt [ 1 ] , tmp_p ) ; inputMFCache_p [ 4 ] =
cgvkp0zasm ( rtB . fconsse5vt [ 1 ] , e ) ; inputMFCache_p [ 5 ] = cgvkp0zasm
( rtB . fconsse5vt [ 1 ] , f ) ; for ( i = 0 ; i < 9 ; i ++ ) { gkcx3eabtv [
i ] = 1.0 ; mVal = gkcx3eabtv [ i ] ; dSOC5_6 = inputMFCache_p [ f_p [ i ] -
1 ] ; if ( ( mVal > dSOC5_6 ) || ( muDoubleScalarIsNaN ( mVal ) && ( !
muDoubleScalarIsNaN ( dSOC5_6 ) ) ) ) { gkcx3eabtv [ i ] = dSOC5_6 ; } else {
gkcx3eabtv [ i ] = mVal ; } mVal = gkcx3eabtv [ i ] ; dSOC5_6 =
inputMFCache_p [ f_p [ i + 9 ] + 2 ] ; if ( ( mVal > dSOC5_6 ) || (
muDoubleScalarIsNaN ( mVal ) && ( ! muDoubleScalarIsNaN ( dSOC5_6 ) ) ) ) {
gkcx3eabtv [ i ] = dSOC5_6 ; } else { gkcx3eabtv [ i ] = mVal ; } jmuz0todoh
+= gkcx3eabtv [ i ] ; } nntoyhbqoo ( rtB . prlvalkk0e , ivey5iysam ,
gkcx3eabtv , rtP . OutputSamplePoints_Value_k42vy4v1xv , & rtB . mck0tzoap3 )
; if ( jmuz0todoh == 0.0 ) { rtB . fevj4hbzpr = 0.5 ; } else { jmuz0todoh =
0.0 ; mVal = 0.0 ; for ( i = 0 ; i < 101 ; i ++ ) { mVal += rtB . mck0tzoap3
. gz0uq5kqkr [ i ] ; } if ( mVal == 0.0 ) { rtB . fevj4hbzpr = ( rtP .
OutputSamplePoints_Value_k42vy4v1xv [ 0 ] + rtP .
OutputSamplePoints_Value_k42vy4v1xv [ 100 ] ) / 2.0 ; } else { for ( i = 0 ;
i < 101 ; i ++ ) { jmuz0todoh += rtP . OutputSamplePoints_Value_k42vy4v1xv [
i ] * rtB . mck0tzoap3 . gz0uq5kqkr [ i ] ; } rtB . fevj4hbzpr = 1.0 / mVal *
jmuz0todoh ; } } if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . frexusnuvh = ( rtB
. prlvalkk0e > rtP . Switch3_Threshold ) ; } if ( rtDW . frexusnuvh ) { rtB .
d5mhwukqbu = rtB . fevj4hbzpr ; } else { rtB . d5mhwukqbu = rtP .
Constant5_Value ; } rtB . dpcxxq2cb2 = k0qu5tzxih - ga5u1ceorf ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . jr1eyvxvce = ( rtB . dpcxxq2cb2 >=
0.0 ) ; } rtB . m1to4j3fz0 = rtDW . jr1eyvxvce > 0 ? rtB . dpcxxq2cb2 : - rtB
. dpcxxq2cb2 ; mglwtemyk2 = ( k0qu5tzxih + ga5u1ceorf ) * rtP .
Constant2_Value_e4jyxae25b ; rtB . ku1fxfiwgl [ 0 ] = rtB . m1to4j3fz0 ; rtB
. ku1fxfiwgl [ 1 ] = mglwtemyk2 ; jmuz0todoh = 0.0 ; tmp_p [ 0 ] = - 2.085 ;
tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache_p [ 0 ] = cgvkp0zasm (
rtB . ku1fxfiwgl [ 0 ] , tmp_p ) ; inputMFCache_p [ 1 ] = cgvkp0zasm ( rtB .
ku1fxfiwgl [ 0 ] , b_i ) ; inputMFCache_p [ 2 ] = cgvkp0zasm ( rtB .
ku1fxfiwgl [ 0 ] , c_e ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ; tmp_p
[ 2 ] = 41.67 ; inputMFCache_p [ 3 ] = cgvkp0zasm ( rtB . ku1fxfiwgl [ 1 ] ,
tmp_p ) ; inputMFCache_p [ 4 ] = cgvkp0zasm ( rtB . ku1fxfiwgl [ 1 ] , e ) ;
inputMFCache_p [ 5 ] = cgvkp0zasm ( rtB . ku1fxfiwgl [ 1 ] , f ) ; for ( i =
0 ; i < 9 ; i ++ ) { klxmjdyb0g [ i ] = 1.0 ; mVal = klxmjdyb0g [ i ] ;
dSOC5_6 = inputMFCache_p [ f_p [ i ] - 1 ] ; if ( ( mVal > dSOC5_6 ) || (
muDoubleScalarIsNaN ( mVal ) && ( ! muDoubleScalarIsNaN ( dSOC5_6 ) ) ) ) {
klxmjdyb0g [ i ] = dSOC5_6 ; } else { klxmjdyb0g [ i ] = mVal ; } mVal =
klxmjdyb0g [ i ] ; dSOC5_6 = inputMFCache_p [ f_p [ i + 9 ] + 2 ] ; if ( (
mVal > dSOC5_6 ) || ( muDoubleScalarIsNaN ( mVal ) && ( ! muDoubleScalarIsNaN
( dSOC5_6 ) ) ) ) { klxmjdyb0g [ i ] = dSOC5_6 ; } else { klxmjdyb0g [ i ] =
mVal ; } jmuz0todoh += klxmjdyb0g [ i ] ; } nntoyhbqoo ( rtB . m1to4j3fz0 ,
mglwtemyk2 , klxmjdyb0g , rtP . OutputSamplePoints_Value_dbmmauqiwo , & rtB .
cg45csylfj ) ; if ( jmuz0todoh == 0.0 ) { rtB . l4dl2g4o4p = 0.5 ; } else {
jmuz0todoh = 0.0 ; mVal = 0.0 ; for ( i = 0 ; i < 101 ; i ++ ) { mVal += rtB
. cg45csylfj . gz0uq5kqkr [ i ] ; } if ( mVal == 0.0 ) { rtB . l4dl2g4o4p = (
rtP . OutputSamplePoints_Value_dbmmauqiwo [ 0 ] + rtP .
OutputSamplePoints_Value_dbmmauqiwo [ 100 ] ) / 2.0 ; } else { for ( i = 0 ;
i < 101 ; i ++ ) { jmuz0todoh += rtP . OutputSamplePoints_Value_dbmmauqiwo [
i ] * rtB . cg45csylfj . gz0uq5kqkr [ i ] ; } rtB . l4dl2g4o4p = 1.0 / mVal *
jmuz0todoh ; } } if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . izbbvtos1d = ( rtB
. iu33mby5ow > rtP . Switch6_Threshold ) ; } if ( rtDW . izbbvtos1d ) { rtB .
fpat1cfbdw = rtB . m1to4j3fz0 ; } else { rtB . fpat1cfbdw = rtP .
Constant12_Value_c2qvybcfaa ; } if ( ssIsMajorTimeStep ( rtS ) ) { rtDW .
apdwknz0ig = ( rtB . fpat1cfbdw > rtP . Switch4_Threshold ) ; } if ( rtDW .
apdwknz0ig ) { rtB . m2qzirzrwp = rtB . l4dl2g4o4p ; } else { rtB .
m2qzirzrwp = rtP . Constant10_Value ; } rtB . pobsyfwdrr = dxudqq1xoi -
ivey5iysam ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . kvvcczrh2h = (
rtB . pobsyfwdrr >= 0.0 ) ; } rtB . hmk2x4i2wb = rtDW . kvvcczrh2h > 0 ? rtB
. pobsyfwdrr : - rtB . pobsyfwdrr ; c0jbv4sysx = ( dxudqq1xoi + ivey5iysam )
* rtP . Constant3_Value_bkb3mktfvw ; rtB . jdh0wn2p1p [ 0 ] = rtB .
hmk2x4i2wb ; rtB . jdh0wn2p1p [ 1 ] = c0jbv4sysx ; jmuz0todoh = 0.0 ; tmp_p [
0 ] = - 2.085 ; tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache_p [ 0
] = cgvkp0zasm ( rtB . jdh0wn2p1p [ 0 ] , tmp_p ) ; inputMFCache_p [ 1 ] =
cgvkp0zasm ( rtB . jdh0wn2p1p [ 0 ] , b_i ) ; inputMFCache_p [ 2 ] =
cgvkp0zasm ( rtB . jdh0wn2p1p [ 0 ] , c_e ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [
1 ] = 0.0 ; tmp_p [ 2 ] = 41.67 ; inputMFCache_p [ 3 ] = cgvkp0zasm ( rtB .
jdh0wn2p1p [ 1 ] , tmp_p ) ; inputMFCache_p [ 4 ] = cgvkp0zasm ( rtB .
jdh0wn2p1p [ 1 ] , e ) ; inputMFCache_p [ 5 ] = cgvkp0zasm ( rtB . jdh0wn2p1p
[ 1 ] , f ) ; for ( i = 0 ; i < 9 ; i ++ ) { fhaaypqjak [ i ] = 1.0 ; mVal =
fhaaypqjak [ i ] ; dSOC5_6 = inputMFCache_p [ f_p [ i ] - 1 ] ; if ( ( mVal >
dSOC5_6 ) || ( muDoubleScalarIsNaN ( mVal ) && ( ! muDoubleScalarIsNaN (
dSOC5_6 ) ) ) ) { fhaaypqjak [ i ] = dSOC5_6 ; } else { fhaaypqjak [ i ] =
mVal ; } mVal = fhaaypqjak [ i ] ; dSOC5_6 = inputMFCache_p [ f_p [ i + 9 ] +
2 ] ; if ( ( mVal > dSOC5_6 ) || ( muDoubleScalarIsNaN ( mVal ) && ( !
muDoubleScalarIsNaN ( dSOC5_6 ) ) ) ) { fhaaypqjak [ i ] = dSOC5_6 ; } else {
fhaaypqjak [ i ] = mVal ; } jmuz0todoh += fhaaypqjak [ i ] ; } nntoyhbqoo (
rtB . hmk2x4i2wb , c0jbv4sysx , fhaaypqjak , rtP .
OutputSamplePoints_Value_mmzz2j1vii , & rtB . cnchvyey1f ) ; if ( jmuz0todoh
== 0.0 ) { rtB . ikv3z1vdef = 0.5 ; } else { jmuz0todoh = 0.0 ; mVal = 0.0 ;
for ( i = 0 ; i < 101 ; i ++ ) { mVal += rtB . cnchvyey1f . gz0uq5kqkr [ i ]
; } if ( mVal == 0.0 ) { rtB . ikv3z1vdef = ( rtP .
OutputSamplePoints_Value_mmzz2j1vii [ 0 ] + rtP .
OutputSamplePoints_Value_mmzz2j1vii [ 100 ] ) / 2.0 ; } else { for ( i = 0 ;
i < 101 ; i ++ ) { jmuz0todoh += rtP . OutputSamplePoints_Value_mmzz2j1vii [
i ] * rtB . cnchvyey1f . gz0uq5kqkr [ i ] ; } rtB . ikv3z1vdef = 1.0 / mVal *
jmuz0todoh ; } } if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . n2nzegphpi = ( rtB
. iy0igec4ex > rtP . Switch7_Threshold ) ; } if ( rtDW . n2nzegphpi ) { rtB .
ejoagqctsb = rtB . hmk2x4i2wb ; } else { rtB . ejoagqctsb = rtP .
Constant13_Value ; } if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . kus34kmfe0 = (
rtB . ejoagqctsb > rtP . Switch5_Threshold ) ; } if ( rtDW . kus34kmfe0 ) {
rtB . c3rlj0evqz = rtB . ikv3z1vdef ; } else { rtB . c3rlj0evqz = rtP .
Constant11_Value ; } rtB . c5g4vefyay = mglwtemyk2 - c0jbv4sysx ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . oeka1ufi2q = ( rtB . c5g4vefyay >=
0.0 ) ; } rtB . exxvwq1eca = rtDW . oeka1ufi2q > 0 ? rtB . c5g4vefyay : - rtB
. c5g4vefyay ; ej0ygnkxr4 = ( mglwtemyk2 + c0jbv4sysx ) * rtP .
Constant16_Value ; rtB . g2o4t34vui [ 0 ] = rtB . exxvwq1eca ; rtB .
g2o4t34vui [ 1 ] = ej0ygnkxr4 ; jmuz0todoh = 0.0 ; tmp_p [ 0 ] = - 2.085 ;
tmp_p [ 1 ] = 0.0 ; tmp_p [ 2 ] = 2.085 ; inputMFCache_p [ 0 ] = cgvkp0zasm (
rtB . g2o4t34vui [ 0 ] , tmp_p ) ; inputMFCache_p [ 1 ] = cgvkp0zasm ( rtB .
g2o4t34vui [ 0 ] , b_i ) ; inputMFCache_p [ 2 ] = cgvkp0zasm ( rtB .
g2o4t34vui [ 0 ] , c_e ) ; tmp_p [ 0 ] = - 41.67 ; tmp_p [ 1 ] = 0.0 ; tmp_p
[ 2 ] = 41.67 ; inputMFCache_p [ 3 ] = cgvkp0zasm ( rtB . g2o4t34vui [ 1 ] ,
tmp_p ) ; inputMFCache_p [ 4 ] = cgvkp0zasm ( rtB . g2o4t34vui [ 1 ] , e ) ;
inputMFCache_p [ 5 ] = cgvkp0zasm ( rtB . g2o4t34vui [ 1 ] , f ) ; for ( i =
0 ; i < 9 ; i ++ ) { lbz4hcogk1 [ i ] = 1.0 ; mVal = lbz4hcogk1 [ i ] ;
dSOC5_6 = inputMFCache_p [ f_p [ i ] - 1 ] ; if ( ( mVal > dSOC5_6 ) || (
muDoubleScalarIsNaN ( mVal ) && ( ! muDoubleScalarIsNaN ( dSOC5_6 ) ) ) ) {
lbz4hcogk1 [ i ] = dSOC5_6 ; } else { lbz4hcogk1 [ i ] = mVal ; } mVal =
lbz4hcogk1 [ i ] ; dSOC5_6 = inputMFCache_p [ f_p [ i + 9 ] + 2 ] ; if ( (
mVal > dSOC5_6 ) || ( muDoubleScalarIsNaN ( mVal ) && ( ! muDoubleScalarIsNaN
( dSOC5_6 ) ) ) ) { lbz4hcogk1 [ i ] = dSOC5_6 ; } else { lbz4hcogk1 [ i ] =
mVal ; } jmuz0todoh += lbz4hcogk1 [ i ] ; } nntoyhbqoo ( rtB . exxvwq1eca ,
ej0ygnkxr4 , lbz4hcogk1 , rtP . OutputSamplePoints_Value , & rtB . keklcbv4b5
) ; if ( jmuz0todoh == 0.0 ) { rtB . obf4zmf1af = 0.5 ; } else { jmuz0todoh =
0.0 ; mVal = 0.0 ; for ( i = 0 ; i < 101 ; i ++ ) { mVal += rtB . keklcbv4b5
. gz0uq5kqkr [ i ] ; } if ( mVal == 0.0 ) { rtB . obf4zmf1af = ( rtP .
OutputSamplePoints_Value [ 0 ] + rtP . OutputSamplePoints_Value [ 100 ] ) /
2.0 ; } else { for ( i = 0 ; i < 101 ; i ++ ) { jmuz0todoh += rtP .
OutputSamplePoints_Value [ i ] * rtB . keklcbv4b5 . gz0uq5kqkr [ i ] ; } rtB
. obf4zmf1af = 1.0 / mVal * jmuz0todoh ; } } if ( ssIsMajorTimeStep ( rtS ) )
{ rtDW . je3xbgadnf = ( rtB . nhvmldohqo > rtP . Switch9_Threshold ) ; } if (
rtDW . je3xbgadnf ) { rtB . d0hcukp5qd = rtB . exxvwq1eca ; } else { rtB .
d0hcukp5qd = rtP . Constant15_Value ; } if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . hs5qk4aflp = ( rtB . d0hcukp5qd > rtP . Switch8_Threshold ) ; } if (
rtDW . hs5qk4aflp ) { rtB . k2b4djnq52 = rtB . obf4zmf1af ; } else { rtB .
k2b4djnq52 = rtP . Constant14_Value ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) )
{ { if ( rtDW . m4a1slsbsw . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . m4a1slsbsw . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . kx5llxdy1m + 0 ) ; } } } rtB . eutn5sqh40 = rtP .
donotdeletethisgain_Gain * rtB . lo01p0mfxt [ 2 ] ; rtB . jmd5vm3itb = rtB .
m5jzl0c3ow - rtP . R_Gain * rtB . eutn5sqh40 ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { { if ( rtDW . lb3ykh1ivj . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . lb3ykh1ivj . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . jmd5vm3itb + 0 ) ; } } { if ( rtDW . idjooi12be .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . idjooi12be .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . iqgkwhugb1 + 0 ) ;
} } } rtB . pspdcb10ak = rtP . donotdeletethisgain_Gain_o42imifl5k * rtB .
lo01p0mfxt [ 3 ] ; rtB . ijb3b30r2i = rtB . i5uns4zs23 - rtP .
R_Gain_g4gmpqe5wx * rtB . pspdcb10ak ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . nfq5r1c2nf . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . nfq5r1c2nf . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . ijb3b30r2i + 0 ) ; } } { if ( rtDW . l1ntzlm3em .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . l1ntzlm3em .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . ilzwywxync + 0 ) ;
} } } rtB . fyoud2dfzn = rtP . donotdeletethisgain_Gain_fjipbfzkks * rtB .
lo01p0mfxt [ 4 ] ; rtB . gzihj5vvk1 = rtB . ebcldbyulo - rtP .
R_Gain_biqz0al5hr * rtB . fyoud2dfzn ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . cjeepns1kp . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . cjeepns1kp . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . gzihj5vvk1 + 0 ) ; } } { if ( rtDW . p3mdqwq4kn .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . p3mdqwq4kn .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . cizwakiveg + 0 ) ;
} } } rtB . kjygkwym52 = rtP . donotdeletethisgain_Gain_ave45anr4u * rtB .
lo01p0mfxt [ 5 ] ; rtB . hn5i42dlfu = rtB . owgcqoig0n - rtP .
R_Gain_bq04dmcpzt * rtB . kjygkwym52 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . ad2wzhmkkk . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . ad2wzhmkkk . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . hn5i42dlfu + 0 ) ; } } { if ( rtDW . cp2sky53da .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . cp2sky53da .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . kgcldxtuqy + 0 ) ;
} } } rtB . ljzepiqdco = rtP . donotdeletethisgain_Gain_mvbq03z0iq * rtB .
lo01p0mfxt [ 6 ] ; rtB . cjnumo0b2v = rtB . lnjnmhfbjh - rtP .
R_Gain_mh2yy541ef * rtB . ljzepiqdco ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . mlqhgw44yh . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . mlqhgw44yh . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . cjnumo0b2v + 0 ) ; } } { if ( rtDW . ozkqasf5op .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . ozkqasf5op .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . pw5q5s3yxm + 0 ) ;
} } } rtB . k4bl20stk1 = rtP . donotdeletethisgain_Gain_kdw2eb0k3g * rtB .
lo01p0mfxt [ 7 ] ; rtB . c5sjcucfqi = rtB . bjlklhbtye - rtP .
R_Gain_k35mp2rvup * rtB . k4bl20stk1 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . md2q01fzov . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . md2q01fzov . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . c5sjcucfqi + 0 ) ; } } { if ( rtDW . btuvwmnygy .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . btuvwmnygy .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . d3jd5igxzc + 0 ) ;
} } } rtB . esg43lx2mr = rtP . donotdeletethisgain_Gain_jquqjrzlip * rtB .
lo01p0mfxt [ 8 ] ; rtB . dxplqcckv2 = rtB . a2ssj2eqbk - rtP .
R_Gain_chtk1x1i0w * rtB . esg43lx2mr ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . av20b02ile . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . av20b02ile . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . dxplqcckv2 + 0 ) ; } } { if ( rtDW . o40s2uuuft .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . o40s2uuuft .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . kkv1pr3lrm + 0 ) ;
} } } rtB . lzgz2a1hji = rtP . donotdeletethisgain_Gain_dywzmacz1o * rtB .
lo01p0mfxt [ 1 ] ; rtB . do252u2xbm = rtB . nula5qzpsy - rtP .
R_Gain_cwdppwgit4 * rtB . lzgz2a1hji ; if ( ssGetIsOkayToUpdateMode ( rtS ) )
{ rtDW . paz4kgtbji = ( rtB . lzgz2a1hji >= 0.0 ) ; } rtB . nlzznjgokl = rtDW
. paz4kgtbji > 0 ? rtB . lzgz2a1hji : - rtB . lzgz2a1hji ; if ( ssIsSampleHit
( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
bmw4dfcea0 = ( rtB . lzgz2a1hji < rtP . Constant_Value_ogegtmkzv0 ) ; } rtB .
icxhoatkpy = rtP . Gain4_Gain * ( real_T ) rtDW . bmw4dfcea0 ; } rtB .
jvqj10bdhd = rtB . icxhoatkpy - rtB . kf00di3gqm ; rtB . djbiardxss = rtB .
nlzznjgokl * rtB . jvqj10bdhd ; rtB . byr5s2oy3e = rtP . Gain1_Gain * rtB .
djbiardxss ; rtB . iztnxsmmfx = rtP . Gain2_Gain * rtB . p0r2azag0g ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . ae04suheli = ( rtB . eutn5sqh40 >=
0.0 ) ; } rtB . pll3gx4xtu = rtDW . ae04suheli > 0 ? rtB . eutn5sqh40 : - rtB
. eutn5sqh40 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . n3tcjs3cnp = ( rtB . eutn5sqh40 <
rtP . Constant_Value_h5irp45zuu ) ; } rtB . ooktbhfuke = rtP .
Gain4_Gain_kh00znyazs * ( real_T ) rtDW . n3tcjs3cnp ; } rtB . hlf2cr3mg4 =
rtB . ooktbhfuke - rtB . b5plhow0ik ; rtB . mpkxn4stei = rtB . pll3gx4xtu *
rtB . hlf2cr3mg4 ; rtB . l2a4su3opv = rtP . Gain1_Gain_og11bwmhu2 * rtB .
mpkxn4stei ; rtB . fzx04ovsv2 = rtP . Gain2_Gain_m4x3vq3y1f * rtB .
nv44crtc44 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . iuncllo15x = (
rtB . pspdcb10ak >= 0.0 ) ; } rtB . mphcdthuhz = rtDW . iuncllo15x > 0 ? rtB
. pspdcb10ak : - rtB . pspdcb10ak ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . eneedgqyil = ( rtB . pspdcb10ak
< rtP . Constant_Value_k5pwul1wle ) ; } rtB . d3g3fh43cq = rtP .
Gain4_Gain_fstjjgzlds * ( real_T ) rtDW . eneedgqyil ; } rtB . iilzn0ptvn =
rtB . d3g3fh43cq - rtB . nla5yxcuxf ; rtB . bpyjvekzcs = rtB . mphcdthuhz *
rtB . iilzn0ptvn ; rtB . msjbl0lqgu = rtP . Gain1_Gain_anymdqpqln * rtB .
bpyjvekzcs ; rtB . ilvfsgymog = rtP . Gain2_Gain_jptbha03po * rtB .
lz4r5vsjh1 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nmkbwshj5v = (
rtB . fyoud2dfzn >= 0.0 ) ; } rtB . pvsep2b5mx = rtDW . nmkbwshj5v > 0 ? rtB
. fyoud2dfzn : - rtB . fyoud2dfzn ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . pn3eu4idcy = ( rtB . fyoud2dfzn
< rtP . Constant_Value_pp4lg2cwxs ) ; } rtB . p35szvmsnl = rtP .
Gain4_Gain_n2oajsg4xg * ( real_T ) rtDW . pn3eu4idcy ; } rtB . pq5i5vcg3c =
rtB . p35szvmsnl - rtB . jolzvaxect ; rtB . iurpvuxeop = rtB . pvsep2b5mx *
rtB . pq5i5vcg3c ; rtB . idyadmxopc = rtP . Gain1_Gain_baecfd2g1g * rtB .
iurpvuxeop ; rtB . prb3bcw1pc = rtP . Gain2_Gain_fe3eihrk0b * rtB .
g5hkbvjtz4 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . lpusnuqytr = (
rtB . kjygkwym52 >= 0.0 ) ; } rtB . mrdluoj4iu = rtDW . lpusnuqytr > 0 ? rtB
. kjygkwym52 : - rtB . kjygkwym52 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . cassosl0xb = ( rtB . kjygkwym52
< rtP . Constant_Value_khiqevv1tc ) ; } rtB . juxu3ykg0j = rtP .
Gain4_Gain_j4eqtusam3 * ( real_T ) rtDW . cassosl0xb ; } rtB . nzvnip1yoj =
rtB . juxu3ykg0j - rtB . iuvcnk5dmp ; rtB . izlnv5xggd = rtB . mrdluoj4iu *
rtB . nzvnip1yoj ; rtB . gkbr5qk2mc = rtP . Gain1_Gain_dq4vkdpk0h * rtB .
izlnv5xggd ; rtB . dgspm5jmps = rtP . Gain2_Gain_of2pa5ka31 * rtB .
bvz4ef4xni ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . o1g4bix2tx = (
rtB . ljzepiqdco >= 0.0 ) ; } rtB . hbi3ef0eho = rtDW . o1g4bix2tx > 0 ? rtB
. ljzepiqdco : - rtB . ljzepiqdco ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . kldwedkv3j = ( rtB . ljzepiqdco
< rtP . Constant_Value_cf12bsal0m ) ; } rtB . hgecksjb2e = rtP .
Gain4_Gain_l0ptdzkgeb * ( real_T ) rtDW . kldwedkv3j ; } rtB . gsaxgr1si0 =
rtB . hgecksjb2e - rtB . as0tme1x3l ; rtB . opg5acc20j = rtB . hbi3ef0eho *
rtB . gsaxgr1si0 ; rtB . gn1iktvu5j = rtP . Gain1_Gain_c5i2vccxwe * rtB .
opg5acc20j ; rtB . lroevxw2fw = rtP . Gain2_Gain_jyxvaqqzap * rtB .
aaa1drn5lo ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . molqmdigqy = (
rtB . k4bl20stk1 >= 0.0 ) ; } rtB . mqtt3ijnmc = rtDW . molqmdigqy > 0 ? rtB
. k4bl20stk1 : - rtB . k4bl20stk1 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . b5wvicli01 = ( rtB . k4bl20stk1
< rtP . Constant_Value_gpi13dm1iq ) ; } rtB . dhgr323ykq = rtP .
Gain4_Gain_pdhrsclrmp * ( real_T ) rtDW . b5wvicli01 ; } rtB . bybsxhpomg =
rtB . dhgr323ykq - rtB . mwcys4j4zs ; rtB . izc05dwilh = rtB . mqtt3ijnmc *
rtB . bybsxhpomg ; rtB . j2cbi4uvjv = rtP . Gain1_Gain_hhtznyj2s2 * rtB .
izc05dwilh ; rtB . cdunewte3y = rtP . Gain2_Gain_hm05ohnj0y * rtB .
hvmipewyll ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . doucacjh3z = (
rtB . esg43lx2mr >= 0.0 ) ; } rtB . f0al1hik1j = rtDW . doucacjh3z > 0 ? rtB
. esg43lx2mr : - rtB . esg43lx2mr ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . aex5jpmvuw = ( rtB . esg43lx2mr
< rtP . Constant_Value_aujhkhzu0m ) ; } rtB . lodc4zy0kf = rtP .
Gain4_Gain_bbkx0f2eye * ( real_T ) rtDW . aex5jpmvuw ; } rtB . eupsjtfr5a =
rtB . lodc4zy0kf - rtB . bwiu5f3xyy ; rtB . hb5phdzryd = rtB . f0al1hik1j *
rtB . eupsjtfr5a ; rtB . b0w045s1dy = rtP . Gain1_Gain_at5pojvma0 * rtB .
hb5phdzryd ; rtB . dcvu5axig4 = rtP . Gain2_Gain_plpbrgefjj * rtB .
jwjptsm01d ; if ( ssIsSampleHit ( rtS , 7 , 0 ) ) { if ( ( rtB . m2qzirzrwp *
rtP . PWM_Period + ssGetTaskTime ( rtS , 7 ) <= ssGetTaskTime ( rtS , 7 ) +
2.8421709430404007E-14 ) && rtDW . k5uuyepbrp ) { rtB . h3c5qk01el = 0.0 ;
rtDW . ke5obrhhqt = false ; } else { rtB . h3c5qk01el = rtDW . ke5obrhhqt ; }
} if ( ssIsSampleHit ( rtS , 8 , 0 ) ) { if ( ( rtB . iwlpqqhwtd * rtP .
PWM1_Period + ssGetTaskTime ( rtS , 8 ) <= ssGetTaskTime ( rtS , 8 ) +
2.8421709430404007E-14 ) && rtDW . dgtx3pxebh ) { rtB . anc2sq3mml = 0.0 ;
rtDW . dimggz5k1i = false ; } else { rtB . anc2sq3mml = rtDW . dimggz5k1i ; }
} if ( ssIsSampleHit ( rtS , 2 , 0 ) ) { if ( ( rtB . jtiok3ecro * rtP .
PWM3_Period + ssGetTaskTime ( rtS , 2 ) <= ssGetTaskTime ( rtS , 2 ) +
2.8421709430404007E-14 ) && rtDW . omg5wivauv ) { rtB . mqa03tpv1s = 0.0 ;
rtDW . fqogqsl1qn = false ; } else { rtB . mqa03tpv1s = rtDW . fqogqsl1qn ; }
} if ( ssIsSampleHit ( rtS , 3 , 0 ) ) { if ( ( rtB . k2b4djnq52 * rtP .
PWM5_Period + ssGetTaskTime ( rtS , 3 ) <= ssGetTaskTime ( rtS , 3 ) +
2.8421709430404007E-14 ) && rtDW . puzlpon25o ) { rtB . bzwbhh42ka = 0.0 ;
rtDW . n33t0mlcdo = false ; } else { rtB . bzwbhh42ka = rtDW . n33t0mlcdo ; }
} if ( ssIsSampleHit ( rtS , 6 , 0 ) ) { if ( ( rtB . ot4gqzqydm * rtP .
PWM6_Period + ssGetTaskTime ( rtS , 6 ) <= ssGetTaskTime ( rtS , 6 ) +
2.8421709430404007E-14 ) && rtDW . bgieyqg154 ) { rtB . ojiezq4id3 = 0.0 ;
rtDW . e3ay5unpbh = false ; } else { rtB . ojiezq4id3 = rtDW . e3ay5unpbh ; }
} if ( ssIsSampleHit ( rtS , 5 , 0 ) ) { if ( ( rtB . d5mhwukqbu * rtP .
PWM7_Period + ssGetTaskTime ( rtS , 5 ) <= ssGetTaskTime ( rtS , 5 ) +
2.8421709430404007E-14 ) && rtDW . os10rt4vp3 ) { rtB . ftx2e5cidi = 0.0 ;
rtDW . hbjqhzro5y = false ; } else { rtB . ftx2e5cidi = rtDW . hbjqhzro5y ; }
} if ( ssIsSampleHit ( rtS , 4 , 0 ) ) { if ( ( rtB . c3rlj0evqz * rtP .
PWM8_Period + ssGetTaskTime ( rtS , 4 ) <= ssGetTaskTime ( rtS , 4 ) +
2.8421709430404007E-14 ) && rtDW . ngljbafwbt ) { rtB . ntwxdiuzqj = 0.0 ;
rtDW . o1qidfzosp = false ; } else { rtB . ntwxdiuzqj = rtDW . o1qidfzosp ; }
} rtB . b4ushbvpyk = rtP . donotdeletethisgain_Gain_jslrw2wpeb * rtB .
lo01p0mfxt [ 0 ] ; rtB . oem1fc5toa = rtP .
donotdeletethisgain_Gain_hwxhghbjtm * rtB . lo01p0mfxt [ 9 ] ;
UNUSED_PARAMETER ( tid ) ; } void MdlOutputsTID9 ( int_T tid ) { rtB .
bcww4isw4r = rtP . gate_Value ; rtB . b5epvnjqmi = rtP .
gate_Value_e2pzllcxv0 ; rtB . o1rf1cikyg = rtP . gate_Value_jpjtjqpsyx ; rtB
. da4ug2cudb = rtP . gate_Value_cczcurubvx ; rtB . nahk3q2lwf = rtP .
gate_Value_p3h3pv0zwg ; rtB . hwoezaq2mj = rtP . gate_Value_ahx5cowvm0 ; rtB
. iq51ppixmq = rtP . gate_Value_hob43axlzj ; rtB . lcbjcuvvbt = rtP .
gate_Value_odvaswnitz ; rtB . jn3jigbm4f = rtP . gate_Value_hrisjp3q0m ; rtB
. kg5yvb1wjz = rtP . gate_Value_ggng0gfgd5 ; rtB . ezyjeovbvi = rtP .
gate_Value_ppgtupoipm ; rtB . nz5qxvxtdb = rtP . gate_Value_iwryy13tik ; rtB
. bhhrjm3haf = rtP . gate_Value_o02a13bzdb ; rtB . acuoed4qri = rtP .
gate_Value_ncgxatpho2 ; UNUSED_PARAMETER ( tid ) ; } void MdlUpdate ( int_T
tid ) { XDis * _rtXdis ; real_T dc ; SimStruct * S ; void * diag ; _rtXdis =
( ( XDis * ) ssGetContStateDisabled ( rtS ) ) ; if ( ssIsSampleHit ( rtS , 1
, 0 ) ) { rtDW . ca5hlnq0yv = rtP . Constant12_Value ; rtDW . capftuiedr =
rtB . iztnxsmmfx ; } rtDW . mwvlfj3tnw = 0 ; switch ( rtDW . klgebljbkk ) {
case 3 : if ( rtB . lzgz2a1hji < 0.0 ) { rtDW . klgebljbkk = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . lzgz2a1hji > 0.0 ) { rtDW . klgebljbkk = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
lbkltw2njc = ( ( rtDW . klgebljbkk == 3 ) || ( rtDW . klgebljbkk == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . dausu4yb0r = rtP .
Constant12_Value_df3z3yuypl ; rtDW . nxcbrqbg4s = rtB . fzx04ovsv2 ; } rtDW .
jcfoqfv3fu = 0 ; switch ( rtDW . j1al2derae ) { case 3 : if ( rtB .
eutn5sqh40 < 0.0 ) { rtDW . j1al2derae = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . eutn5sqh40 > 0.0 ) { rtDW . j1al2derae = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
nxoiklb1cp = ( ( rtDW . j1al2derae == 3 ) || ( rtDW . j1al2derae == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . nb3lw1dts4 = rtP .
Constant12_Value_ktnzmkcekm ; rtDW . oqfmlletk1 = rtB . ilvfsgymog ; } rtDW .
p20ta3sfdz = 0 ; switch ( rtDW . ia4yvyaqmb ) { case 3 : if ( rtB .
pspdcb10ak < 0.0 ) { rtDW . ia4yvyaqmb = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . pspdcb10ak > 0.0 ) { rtDW . ia4yvyaqmb = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
bxy3w4qxj2 = ( ( rtDW . ia4yvyaqmb == 3 ) || ( rtDW . ia4yvyaqmb == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . b1blljt5i4 = rtP .
Constant12_Value_jkrk5dvljw ; rtDW . eude00gfzn = rtB . prb3bcw1pc ; } rtDW .
oqj3skvfcq = 0 ; switch ( rtDW . gaqc3mhu55 ) { case 3 : if ( rtB .
fyoud2dfzn < 0.0 ) { rtDW . gaqc3mhu55 = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . fyoud2dfzn > 0.0 ) { rtDW . gaqc3mhu55 = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
dqfnkbb0xq = ( ( rtDW . gaqc3mhu55 == 3 ) || ( rtDW . gaqc3mhu55 == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . omhuox45k5 = rtP .
Constant12_Value_oujd2whfki ; rtDW . l5yuu2mi2t = rtB . dgspm5jmps ; } rtDW .
aj4yhj42qr = 0 ; switch ( rtDW . cnphafnigh ) { case 3 : if ( rtB .
kjygkwym52 < 0.0 ) { rtDW . cnphafnigh = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . kjygkwym52 > 0.0 ) { rtDW . cnphafnigh = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
cr4uxyxqlm = ( ( rtDW . cnphafnigh == 3 ) || ( rtDW . cnphafnigh == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . oteopngiwv = rtP .
Constant12_Value_l40vqppf0r ; rtDW . jbkhseznjs = rtB . lroevxw2fw ; } rtDW .
k4l2ij22e5 = 0 ; switch ( rtDW . i3h0yxjcuf ) { case 3 : if ( rtB .
ljzepiqdco < 0.0 ) { rtDW . i3h0yxjcuf = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . ljzepiqdco > 0.0 ) { rtDW . i3h0yxjcuf = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
bnmkr55uji = ( ( rtDW . i3h0yxjcuf == 3 ) || ( rtDW . i3h0yxjcuf == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . g0xibfhryj = rtP .
Constant12_Value_frutixtppx ; rtDW . dyomnt0iya = rtB . cdunewte3y ; } rtDW .
gbegstnyrm = 0 ; switch ( rtDW . krsqhbk5nm ) { case 3 : if ( rtB .
k4bl20stk1 < 0.0 ) { rtDW . krsqhbk5nm = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . k4bl20stk1 > 0.0 ) { rtDW . krsqhbk5nm = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
ducd1mygi5 = ( ( rtDW . krsqhbk5nm == 3 ) || ( rtDW . krsqhbk5nm == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . mmeejs3fon = rtP .
Constant12_Value_gycmvngwdn ; rtDW . cixbj0ezqf = rtB . dcvu5axig4 ; } rtDW .
ioqp4ngatr = 0 ; switch ( rtDW . bmltxw1qtk ) { case 3 : if ( rtB .
esg43lx2mr < 0.0 ) { rtDW . bmltxw1qtk = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . esg43lx2mr > 0.0 ) { rtDW . bmltxw1qtk = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
mludnzmfko = ( ( rtDW . bmltxw1qtk == 3 ) || ( rtDW . bmltxw1qtk == 4 ) ) ; {
SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnUpdate ( rts , 0 ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } if ( ssIsSampleHit ( rtS ,
7 , 0 ) ) { if ( rtDW . ke5obrhhqt ) { dc = rtB . m2qzirzrwp ; if ( ( rtP .
PWM_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM_Period ) || ( rtP .
PWM_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM/Variable Pulse Generator" , 2 , rtP . PWM_Period , 2 ,
ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM_Period + ssGetTaskTime ( rtS , 7 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 7 ) + ssGetTaskTime ( rtS , 7 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing4/PWM/Variable Pulse Generator" , 2 , rtB . m2qzirzrwp , 2 ,
rtP . PWM_Period , 2 , ssGetTaskTime ( rtS , 7 ) , 2 , 2.8421709430404007E-14
* ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc >
1.0 ) { dc = 1.0 ; if ( rtDW . a4qh2syf5f ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleGreaterThanOne" , 3
, 2 , ssGetTaskTime ( rtS , 7 ) , 2 , rtB . m2qzirzrwp , 3 ,
"activeBalancing4/PWM/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . a4qh2syf5f = false ; } }
if ( ( rtDW . alzjyrx0kg > 0.0 ) && ( rtDW . alzjyrx0kg == rtP . PWM_Period )
) { rtDW . axsolhspww ++ ; } else { rtDW . axsolhspww = 1ULL ; rtDW .
alzjyrx0kg = rtP . PWM_Period ; rtDW . man13mro5e = ssGetTaskTime ( rtS , 7 )
; } rtDW . bchydutg41 = rtDW . alzjyrx0kg * ( real_T ) rtDW . axsolhspww +
rtDW . man13mro5e ; if ( rtDW . bchydutg41 - ( dc * rtP . PWM_Period +
ssGetTaskTime ( rtS , 7 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
7 ) ) { _ssSetVarNextHitTime ( rtS , 5 , ssGetTaskTime ( rtS , 7 ) + dc * rtP
. PWM_Period ) ; rtDW . ke5obrhhqt = false ; rtDW . k5uuyepbrp = false ; }
else if ( ( rtDW . bchydutg41 - ( dc * rtP . PWM_Period + ssGetTaskTime ( rtS
, 7 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 7 ) ) && ( dc > 0.0
) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM/Variable Pulse Generator" , 2 , rtP . PWM_Period , 2 ,
ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 5 , rtDW . bchydutg41 ) ; rtDW . ke5obrhhqt =
true ; rtDW . k5uuyepbrp = true ; } } else { if ( rtDW . k5uuyepbrp ) { if (
( rtP . PWM_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM_Period ) ||
( rtP . PWM_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM/Variable Pulse Generator" , 2 , rtP . PWM_Period , 2 ,
ssGetTaskTime ( rtS , 7 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB .
m2qzirzrwp < 0.0 ) && rtDW . ptyhlovodi ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 7 ) , 2 , rtB . m2qzirzrwp , 3 ,
"activeBalancing4/PWM/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . ptyhlovodi = false ; }
if ( ( rtDW . alzjyrx0kg > 0.0 ) && ( rtDW . alzjyrx0kg == rtP . PWM_Period )
) { rtDW . axsolhspww ++ ; } else { rtDW . axsolhspww = 1ULL ; rtDW .
alzjyrx0kg = rtP . PWM_Period ; rtDW . man13mro5e = ssGetTaskTime ( rtS , 7 )
; } _ssSetVarNextHitTime ( rtS , 5 , ssGetTaskTime ( rtS , 7 ) + rtP .
PWM_Period ) ; } else if ( rtDW . bchydutg41 > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 7 ) + ssGetTaskTime ( rtS , 7 ) ) {
_ssSetVarNextHitTime ( rtS , 5 , rtDW . bchydutg41 ) ; } rtDW . ke5obrhhqt =
true ; rtDW . k5uuyepbrp = true ; } } if ( ssIsSampleHit ( rtS , 8 , 0 ) ) {
if ( rtDW . dimggz5k1i ) { dc = rtB . iwlpqqhwtd ; if ( ( rtP . PWM1_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM1_Period ) || ( rtP .
PWM1_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM1/Variable Pulse Generator" , 2 , rtP . PWM1_Period , 2
, ssGetTaskTime ( rtS , 8 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM1_Period + ssGetTaskTime ( rtS , 8 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 8 ) + ssGetTaskTime ( rtS , 8 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing4/PWM1/Variable Pulse Generator" , 2 , rtB . iwlpqqhwtd , 2 ,
rtP . PWM1_Period , 2 , ssGetTaskTime ( rtS , 8 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 8 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . nerp2skw04 ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
8 ) , 2 , rtB . iwlpqqhwtd , 3 ,
"activeBalancing4/PWM1/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . nerp2skw04 = false ; } }
if ( ( rtDW . aegiye3tn1 > 0.0 ) && ( rtDW . aegiye3tn1 == rtP . PWM1_Period
) ) { rtDW . jkukkxhvxl ++ ; } else { rtDW . jkukkxhvxl = 1ULL ; rtDW .
aegiye3tn1 = rtP . PWM1_Period ; rtDW . kmgw2sai2b = ssGetTaskTime ( rtS , 8
) ; } rtDW . aggfvdda1e = rtDW . aegiye3tn1 * ( real_T ) rtDW . jkukkxhvxl +
rtDW . kmgw2sai2b ; if ( rtDW . aggfvdda1e - ( dc * rtP . PWM1_Period +
ssGetTaskTime ( rtS , 8 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
8 ) ) { _ssSetVarNextHitTime ( rtS , 6 , ssGetTaskTime ( rtS , 8 ) + dc * rtP
. PWM1_Period ) ; rtDW . dimggz5k1i = false ; rtDW . dgtx3pxebh = false ; }
else if ( ( rtDW . aggfvdda1e - ( dc * rtP . PWM1_Period + ssGetTaskTime (
rtS , 8 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 8 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM1/Variable Pulse Generator" , 2 , rtP . PWM1_Period , 2
, ssGetTaskTime ( rtS , 8 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 6 , rtDW . aggfvdda1e ) ; rtDW . dimggz5k1i =
true ; rtDW . dgtx3pxebh = true ; } } else { if ( rtDW . dgtx3pxebh ) { if (
( rtP . PWM1_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM1_Period )
|| ( rtP . PWM1_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM1/Variable Pulse Generator" , 2 , rtP . PWM1_Period , 2
, ssGetTaskTime ( rtS , 8 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. iwlpqqhwtd < 0.0 ) && rtDW . fhpyfq1cbi ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 8 ) , 2 , rtB . iwlpqqhwtd , 3 ,
"activeBalancing4/PWM1/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . fhpyfq1cbi = false ; }
if ( ( rtDW . aegiye3tn1 > 0.0 ) && ( rtDW . aegiye3tn1 == rtP . PWM1_Period
) ) { rtDW . jkukkxhvxl ++ ; } else { rtDW . jkukkxhvxl = 1ULL ; rtDW .
aegiye3tn1 = rtP . PWM1_Period ; rtDW . kmgw2sai2b = ssGetTaskTime ( rtS , 8
) ; } _ssSetVarNextHitTime ( rtS , 6 , ssGetTaskTime ( rtS , 8 ) + rtP .
PWM1_Period ) ; } else if ( rtDW . aggfvdda1e > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 8 ) + ssGetTaskTime ( rtS , 8 ) ) {
_ssSetVarNextHitTime ( rtS , 6 , rtDW . aggfvdda1e ) ; } rtDW . dimggz5k1i =
true ; rtDW . dgtx3pxebh = true ; } } if ( ssIsSampleHit ( rtS , 2 , 0 ) ) {
if ( rtDW . fqogqsl1qn ) { dc = rtB . jtiok3ecro ; if ( ( rtP . PWM3_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM3_Period ) || ( rtP .
PWM3_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM3/Variable Pulse Generator" , 2 , rtP . PWM3_Period , 2
, ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM3_Period + ssGetTaskTime ( rtS , 2 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 2 ) + ssGetTaskTime ( rtS , 2 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing4/PWM3/Variable Pulse Generator" , 2 , rtB . jtiok3ecro , 2 ,
rtP . PWM3_Period , 2 , ssGetTaskTime ( rtS , 2 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . ff1zu2lxej ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
2 ) , 2 , rtB . jtiok3ecro , 3 ,
"activeBalancing4/PWM3/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . ff1zu2lxej = false ; } }
if ( ( rtDW . grio4yjtpl > 0.0 ) && ( rtDW . grio4yjtpl == rtP . PWM3_Period
) ) { rtDW . dxioy35srz ++ ; } else { rtDW . dxioy35srz = 1ULL ; rtDW .
grio4yjtpl = rtP . PWM3_Period ; rtDW . nifwcsv1v1 = ssGetTaskTime ( rtS , 2
) ; } rtDW . k0tqwauzp3 = rtDW . grio4yjtpl * ( real_T ) rtDW . dxioy35srz +
rtDW . nifwcsv1v1 ; if ( rtDW . k0tqwauzp3 - ( dc * rtP . PWM3_Period +
ssGetTaskTime ( rtS , 2 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
2 ) ) { _ssSetVarNextHitTime ( rtS , 0 , ssGetTaskTime ( rtS , 2 ) + dc * rtP
. PWM3_Period ) ; rtDW . fqogqsl1qn = false ; rtDW . omg5wivauv = false ; }
else if ( ( rtDW . k0tqwauzp3 - ( dc * rtP . PWM3_Period + ssGetTaskTime (
rtS , 2 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 2 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM3/Variable Pulse Generator" , 2 , rtP . PWM3_Period , 2
, ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 0 , rtDW . k0tqwauzp3 ) ; rtDW . fqogqsl1qn =
true ; rtDW . omg5wivauv = true ; } } else { if ( rtDW . omg5wivauv ) { if (
( rtP . PWM3_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM3_Period )
|| ( rtP . PWM3_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM3/Variable Pulse Generator" , 2 , rtP . PWM3_Period , 2
, ssGetTaskTime ( rtS , 2 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. jtiok3ecro < 0.0 ) && rtDW . bxzckcwnmi ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 2 ) , 2 , rtB . jtiok3ecro , 3 ,
"activeBalancing4/PWM3/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . bxzckcwnmi = false ; }
if ( ( rtDW . grio4yjtpl > 0.0 ) && ( rtDW . grio4yjtpl == rtP . PWM3_Period
) ) { rtDW . dxioy35srz ++ ; } else { rtDW . dxioy35srz = 1ULL ; rtDW .
grio4yjtpl = rtP . PWM3_Period ; rtDW . nifwcsv1v1 = ssGetTaskTime ( rtS , 2
) ; } _ssSetVarNextHitTime ( rtS , 0 , ssGetTaskTime ( rtS , 2 ) + rtP .
PWM3_Period ) ; } else if ( rtDW . k0tqwauzp3 > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 2 ) + ssGetTaskTime ( rtS , 2 ) ) {
_ssSetVarNextHitTime ( rtS , 0 , rtDW . k0tqwauzp3 ) ; } rtDW . fqogqsl1qn =
true ; rtDW . omg5wivauv = true ; } } if ( ssIsSampleHit ( rtS , 3 , 0 ) ) {
if ( rtDW . n33t0mlcdo ) { dc = rtB . k2b4djnq52 ; if ( ( rtP . PWM5_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM5_Period ) || ( rtP .
PWM5_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM5/Variable Pulse Generator" , 2 , rtP . PWM5_Period , 2
, ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM5_Period + ssGetTaskTime ( rtS , 3 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 3 ) + ssGetTaskTime ( rtS , 3 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing4/PWM5/Variable Pulse Generator" , 2 , rtB . k2b4djnq52 , 2 ,
rtP . PWM5_Period , 2 , ssGetTaskTime ( rtS , 3 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . m4qezscalw ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
3 ) , 2 , rtB . k2b4djnq52 , 3 ,
"activeBalancing4/PWM5/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . m4qezscalw = false ; } }
if ( ( rtDW . ifbin5pxrr > 0.0 ) && ( rtDW . ifbin5pxrr == rtP . PWM5_Period
) ) { rtDW . klbt1o41jo ++ ; } else { rtDW . klbt1o41jo = 1ULL ; rtDW .
ifbin5pxrr = rtP . PWM5_Period ; rtDW . hfqfe1a1s5 = ssGetTaskTime ( rtS , 3
) ; } rtDW . momrzwq4pr = rtDW . ifbin5pxrr * ( real_T ) rtDW . klbt1o41jo +
rtDW . hfqfe1a1s5 ; if ( rtDW . momrzwq4pr - ( dc * rtP . PWM5_Period +
ssGetTaskTime ( rtS , 3 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
3 ) ) { _ssSetVarNextHitTime ( rtS , 1 , ssGetTaskTime ( rtS , 3 ) + dc * rtP
. PWM5_Period ) ; rtDW . n33t0mlcdo = false ; rtDW . puzlpon25o = false ; }
else if ( ( rtDW . momrzwq4pr - ( dc * rtP . PWM5_Period + ssGetTaskTime (
rtS , 3 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 3 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM5/Variable Pulse Generator" , 2 , rtP . PWM5_Period , 2
, ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 1 , rtDW . momrzwq4pr ) ; rtDW . n33t0mlcdo =
true ; rtDW . puzlpon25o = true ; } } else { if ( rtDW . puzlpon25o ) { if (
( rtP . PWM5_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM5_Period )
|| ( rtP . PWM5_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM5/Variable Pulse Generator" , 2 , rtP . PWM5_Period , 2
, ssGetTaskTime ( rtS , 3 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. k2b4djnq52 < 0.0 ) && rtDW . ctjzi2o40d ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 3 ) , 2 , rtB . k2b4djnq52 , 3 ,
"activeBalancing4/PWM5/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . ctjzi2o40d = false ; }
if ( ( rtDW . ifbin5pxrr > 0.0 ) && ( rtDW . ifbin5pxrr == rtP . PWM5_Period
) ) { rtDW . klbt1o41jo ++ ; } else { rtDW . klbt1o41jo = 1ULL ; rtDW .
ifbin5pxrr = rtP . PWM5_Period ; rtDW . hfqfe1a1s5 = ssGetTaskTime ( rtS , 3
) ; } _ssSetVarNextHitTime ( rtS , 1 , ssGetTaskTime ( rtS , 3 ) + rtP .
PWM5_Period ) ; } else if ( rtDW . momrzwq4pr > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 3 ) + ssGetTaskTime ( rtS , 3 ) ) {
_ssSetVarNextHitTime ( rtS , 1 , rtDW . momrzwq4pr ) ; } rtDW . n33t0mlcdo =
true ; rtDW . puzlpon25o = true ; } } if ( ssIsSampleHit ( rtS , 6 , 0 ) ) {
if ( rtDW . e3ay5unpbh ) { dc = rtB . ot4gqzqydm ; if ( ( rtP . PWM6_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM6_Period ) || ( rtP .
PWM6_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM6/Variable Pulse Generator" , 2 , rtP . PWM6_Period , 2
, ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM6_Period + ssGetTaskTime ( rtS , 6 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 6 ) + ssGetTaskTime ( rtS , 6 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing4/PWM6/Variable Pulse Generator" , 2 , rtB . ot4gqzqydm , 2 ,
rtP . PWM6_Period , 2 , ssGetTaskTime ( rtS , 6 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . ozfvlojj1n ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
6 ) , 2 , rtB . ot4gqzqydm , 3 ,
"activeBalancing4/PWM6/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . ozfvlojj1n = false ; } }
if ( ( rtDW . cutbprvcd3 > 0.0 ) && ( rtDW . cutbprvcd3 == rtP . PWM6_Period
) ) { rtDW . bfgv0ou4np ++ ; } else { rtDW . bfgv0ou4np = 1ULL ; rtDW .
cutbprvcd3 = rtP . PWM6_Period ; rtDW . ff25ka4wdp = ssGetTaskTime ( rtS , 6
) ; } rtDW . k2nrmdtvq3 = rtDW . cutbprvcd3 * ( real_T ) rtDW . bfgv0ou4np +
rtDW . ff25ka4wdp ; if ( rtDW . k2nrmdtvq3 - ( dc * rtP . PWM6_Period +
ssGetTaskTime ( rtS , 6 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
6 ) ) { _ssSetVarNextHitTime ( rtS , 4 , ssGetTaskTime ( rtS , 6 ) + dc * rtP
. PWM6_Period ) ; rtDW . e3ay5unpbh = false ; rtDW . bgieyqg154 = false ; }
else if ( ( rtDW . k2nrmdtvq3 - ( dc * rtP . PWM6_Period + ssGetTaskTime (
rtS , 6 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 6 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM6/Variable Pulse Generator" , 2 , rtP . PWM6_Period , 2
, ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 4 , rtDW . k2nrmdtvq3 ) ; rtDW . e3ay5unpbh =
true ; rtDW . bgieyqg154 = true ; } } else { if ( rtDW . bgieyqg154 ) { if (
( rtP . PWM6_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM6_Period )
|| ( rtP . PWM6_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM6/Variable Pulse Generator" , 2 , rtP . PWM6_Period , 2
, ssGetTaskTime ( rtS , 6 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. ot4gqzqydm < 0.0 ) && rtDW . fgsjlt3z00 ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 6 ) , 2 , rtB . ot4gqzqydm , 3 ,
"activeBalancing4/PWM6/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . fgsjlt3z00 = false ; }
if ( ( rtDW . cutbprvcd3 > 0.0 ) && ( rtDW . cutbprvcd3 == rtP . PWM6_Period
) ) { rtDW . bfgv0ou4np ++ ; } else { rtDW . bfgv0ou4np = 1ULL ; rtDW .
cutbprvcd3 = rtP . PWM6_Period ; rtDW . ff25ka4wdp = ssGetTaskTime ( rtS , 6
) ; } _ssSetVarNextHitTime ( rtS , 4 , ssGetTaskTime ( rtS , 6 ) + rtP .
PWM6_Period ) ; } else if ( rtDW . k2nrmdtvq3 > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 6 ) + ssGetTaskTime ( rtS , 6 ) ) {
_ssSetVarNextHitTime ( rtS , 4 , rtDW . k2nrmdtvq3 ) ; } rtDW . e3ay5unpbh =
true ; rtDW . bgieyqg154 = true ; } } if ( ssIsSampleHit ( rtS , 5 , 0 ) ) {
if ( rtDW . hbjqhzro5y ) { dc = rtB . d5mhwukqbu ; if ( ( rtP . PWM7_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM7_Period ) || ( rtP .
PWM7_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM7/Variable Pulse Generator" , 2 , rtP . PWM7_Period , 2
, ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM7_Period + ssGetTaskTime ( rtS , 5 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 5 ) + ssGetTaskTime ( rtS , 5 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing4/PWM7/Variable Pulse Generator" , 2 , rtB . d5mhwukqbu , 2 ,
rtP . PWM7_Period , 2 , ssGetTaskTime ( rtS , 5 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . noglx0ol2f ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
5 ) , 2 , rtB . d5mhwukqbu , 3 ,
"activeBalancing4/PWM7/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . noglx0ol2f = false ; } }
if ( ( rtDW . a30dvj5d1n > 0.0 ) && ( rtDW . a30dvj5d1n == rtP . PWM7_Period
) ) { rtDW . mqmlslbwtt ++ ; } else { rtDW . mqmlslbwtt = 1ULL ; rtDW .
a30dvj5d1n = rtP . PWM7_Period ; rtDW . azpppdzavz = ssGetTaskTime ( rtS , 5
) ; } rtDW . bt4oyd503e = rtDW . a30dvj5d1n * ( real_T ) rtDW . mqmlslbwtt +
rtDW . azpppdzavz ; if ( rtDW . bt4oyd503e - ( dc * rtP . PWM7_Period +
ssGetTaskTime ( rtS , 5 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
5 ) ) { _ssSetVarNextHitTime ( rtS , 3 , ssGetTaskTime ( rtS , 5 ) + dc * rtP
. PWM7_Period ) ; rtDW . hbjqhzro5y = false ; rtDW . os10rt4vp3 = false ; }
else if ( ( rtDW . bt4oyd503e - ( dc * rtP . PWM7_Period + ssGetTaskTime (
rtS , 5 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 5 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM7/Variable Pulse Generator" , 2 , rtP . PWM7_Period , 2
, ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 3 , rtDW . bt4oyd503e ) ; rtDW . hbjqhzro5y =
true ; rtDW . os10rt4vp3 = true ; } } else { if ( rtDW . os10rt4vp3 ) { if (
( rtP . PWM7_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM7_Period )
|| ( rtP . PWM7_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM7/Variable Pulse Generator" , 2 , rtP . PWM7_Period , 2
, ssGetTaskTime ( rtS , 5 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. d5mhwukqbu < 0.0 ) && rtDW . o1s050yt3g ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 5 ) , 2 , rtB . d5mhwukqbu , 3 ,
"activeBalancing4/PWM7/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . o1s050yt3g = false ; }
if ( ( rtDW . a30dvj5d1n > 0.0 ) && ( rtDW . a30dvj5d1n == rtP . PWM7_Period
) ) { rtDW . mqmlslbwtt ++ ; } else { rtDW . mqmlslbwtt = 1ULL ; rtDW .
a30dvj5d1n = rtP . PWM7_Period ; rtDW . azpppdzavz = ssGetTaskTime ( rtS , 5
) ; } _ssSetVarNextHitTime ( rtS , 3 , ssGetTaskTime ( rtS , 5 ) + rtP .
PWM7_Period ) ; } else if ( rtDW . bt4oyd503e > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 5 ) + ssGetTaskTime ( rtS , 5 ) ) {
_ssSetVarNextHitTime ( rtS , 3 , rtDW . bt4oyd503e ) ; } rtDW . hbjqhzro5y =
true ; rtDW . os10rt4vp3 = true ; } } if ( ssIsSampleHit ( rtS , 4 , 0 ) ) {
if ( rtDW . o1qidfzosp ) { dc = rtB . c3rlj0evqz ; if ( ( rtP . PWM8_Period
<= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM8_Period ) || ( rtP .
PWM8_Period == ( rtInf ) ) ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM8/Variable Pulse Generator" , 2 , rtP . PWM8_Period , 2
, ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( dc *
rtP . PWM8_Period + ssGetTaskTime ( rtS , 4 ) <= 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 4 ) + ssGetTaskTime ( rtS , 4 ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvPulseWidthForVPG" , 5 , 3 ,
"activeBalancing4/PWM8/Variable Pulse Generator" , 2 , rtB . c3rlj0evqz , 2 ,
rtP . PWM8_Period , 2 , ssGetTaskTime ( rtS , 4 ) , 2 ,
2.8421709430404007E-14 * ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S
, diag ) ; } if ( dc > 1.0 ) { dc = 1.0 ; if ( rtDW . iknrj0yq2v ) { S = rtS
; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:warnDutyCycleGreaterThanOne" , 3 , 2 , ssGetTaskTime ( rtS ,
4 ) , 2 , rtB . c3rlj0evqz , 3 ,
"activeBalancing4/PWM8/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . iknrj0yq2v = false ; } }
if ( ( rtDW . magdrvjhlp > 0.0 ) && ( rtDW . magdrvjhlp == rtP . PWM8_Period
) ) { rtDW . jqfoucolpw ++ ; } else { rtDW . jqfoucolpw = 1ULL ; rtDW .
magdrvjhlp = rtP . PWM8_Period ; rtDW . dtmajsg54k = ssGetTaskTime ( rtS , 4
) ; } rtDW . gmjjnhltdk = rtDW . magdrvjhlp * ( real_T ) rtDW . jqfoucolpw +
rtDW . dtmajsg54k ; if ( rtDW . gmjjnhltdk - ( dc * rtP . PWM8_Period +
ssGetTaskTime ( rtS , 4 ) ) > 2.8421709430404007E-14 * ssGetTaskTime ( rtS ,
4 ) ) { _ssSetVarNextHitTime ( rtS , 2 , ssGetTaskTime ( rtS , 4 ) + dc * rtP
. PWM8_Period ) ; rtDW . o1qidfzosp = false ; rtDW . ngljbafwbt = false ; }
else if ( ( rtDW . gmjjnhltdk - ( dc * rtP . PWM8_Period + ssGetTaskTime (
rtS , 4 ) ) <= 2.8421709430404007E-14 * ssGetTaskTime ( rtS , 4 ) ) && ( dc >
0.0 ) && ( dc < 1.0 ) ) { S = rtS ; diag = CreateDiagnosticAsVoidPtr (
"Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM8/Variable Pulse Generator" , 2 , rtP . PWM8_Period , 2
, ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } else {
_ssSetVarNextHitTime ( rtS , 2 , rtDW . gmjjnhltdk ) ; rtDW . o1qidfzosp =
true ; rtDW . ngljbafwbt = true ; } } else { if ( rtDW . ngljbafwbt ) { if (
( rtP . PWM8_Period <= 0.0 ) || ( muDoubleScalarIsNaN ( rtP . PWM8_Period )
|| ( rtP . PWM8_Period == ( rtInf ) ) ) ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:InvInputPeriodForVPG" , 3 , 3 ,
"activeBalancing4/PWM8/Variable Pulse Generator" , 2 , rtP . PWM8_Period , 2
, ssGetTaskTime ( rtS , 4 ) ) ; rt_ssSet_slErrMsg ( S , diag ) ; } if ( ( rtB
. c3rlj0evqz < 0.0 ) && rtDW . l4uscn224x ) { S = rtS ; diag =
CreateDiagnosticAsVoidPtr ( "Simulink:blocks:warnDutyCycleLessThanZero" , 3 ,
2 , ssGetTaskTime ( rtS , 4 ) , 2 , rtB . c3rlj0evqz , 3 ,
"activeBalancing4/PWM8/Variable Pulse Generator" ) ;
rt_ssReportDiagnosticAsWarning ( S , diag ) ; rtDW . l4uscn224x = false ; }
if ( ( rtDW . magdrvjhlp > 0.0 ) && ( rtDW . magdrvjhlp == rtP . PWM8_Period
) ) { rtDW . jqfoucolpw ++ ; } else { rtDW . jqfoucolpw = 1ULL ; rtDW .
magdrvjhlp = rtP . PWM8_Period ; rtDW . dtmajsg54k = ssGetTaskTime ( rtS , 4
) ; } _ssSetVarNextHitTime ( rtS , 2 , ssGetTaskTime ( rtS , 4 ) + rtP .
PWM8_Period ) ; } else if ( rtDW . gmjjnhltdk > 2.8421709430404007E-14 *
ssGetTaskTime ( rtS , 4 ) + ssGetTaskTime ( rtS , 4 ) ) {
_ssSetVarNextHitTime ( rtS , 2 , rtDW . gmjjnhltdk ) ; } rtDW . o1qidfzosp =
true ; rtDW . ngljbafwbt = true ; } } UNUSED_PARAMETER ( tid ) ; } void
MdlUpdateTID9 ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void
MdlDerivatives ( void ) { XDis * _rtXdis ; XDot * _rtXdot ; _rtXdis = ( (
XDis * ) ssGetContStateDisabled ( rtS ) ) ; _rtXdot = ( ( XDot * ) ssGetdX (
rtS ) ) ; _rtXdot -> plb5id0v2x = 0.0 ; _rtXdot -> plb5id0v2x += rtP .
Currentfilter_A * rtX . plb5id0v2x ; _rtXdot -> plb5id0v2x += rtB .
lzgz2a1hji ; if ( _rtXdis -> lbkltw2njc ) { _rtXdot -> lbkltw2njc = 0.0 ; }
else { _rtXdot -> lbkltw2njc = rtB . lzgz2a1hji ; } _rtXdot -> fzv1e1p3mc =
rtB . byr5s2oy3e ; _rtXdot -> fg5c5z2vbx = 0.0 ; _rtXdot -> fg5c5z2vbx += rtP
. BAL_A * rtX . fg5c5z2vbx ; _rtXdot -> fg5c5z2vbx += rtB . lzgz2a1hji ;
_rtXdot -> bx04s5qbio = 0.0 ; _rtXdot -> bx04s5qbio += rtP .
Currentfilter_A_hazdhojaym * rtX . bx04s5qbio ; _rtXdot -> bx04s5qbio += rtB
. eutn5sqh40 ; if ( _rtXdis -> nxoiklb1cp ) { _rtXdot -> nxoiklb1cp = 0.0 ; }
else { _rtXdot -> nxoiklb1cp = rtB . eutn5sqh40 ; } _rtXdot -> b3n5hgntky =
rtB . l2a4su3opv ; _rtXdot -> cgxanjfmip = 0.0 ; _rtXdot -> cgxanjfmip += rtP
. BAL_A_cudqa1u03y * rtX . cgxanjfmip ; _rtXdot -> cgxanjfmip += rtB .
eutn5sqh40 ; _rtXdot -> lfvzsuhskj = 0.0 ; _rtXdot -> lfvzsuhskj += rtP .
Currentfilter_A_pyl0ygpghg * rtX . lfvzsuhskj ; _rtXdot -> lfvzsuhskj += rtB
. pspdcb10ak ; if ( _rtXdis -> bxy3w4qxj2 ) { _rtXdot -> bxy3w4qxj2 = 0.0 ; }
else { _rtXdot -> bxy3w4qxj2 = rtB . pspdcb10ak ; } _rtXdot -> chmdgjvbrk =
rtB . msjbl0lqgu ; _rtXdot -> iximkvmpst = 0.0 ; _rtXdot -> iximkvmpst += rtP
. BAL_A_n35zxahhei * rtX . iximkvmpst ; _rtXdot -> iximkvmpst += rtB .
pspdcb10ak ; _rtXdot -> esshhzn0st = 0.0 ; _rtXdot -> esshhzn0st += rtP .
Currentfilter_A_bsszjj1hem * rtX . esshhzn0st ; _rtXdot -> esshhzn0st += rtB
. fyoud2dfzn ; if ( _rtXdis -> dqfnkbb0xq ) { _rtXdot -> dqfnkbb0xq = 0.0 ; }
else { _rtXdot -> dqfnkbb0xq = rtB . fyoud2dfzn ; } _rtXdot -> ohptd3ifop =
rtB . idyadmxopc ; _rtXdot -> ik2jrqp3yy = 0.0 ; _rtXdot -> ik2jrqp3yy += rtP
. BAL_A_jgidwk4hmh * rtX . ik2jrqp3yy ; _rtXdot -> ik2jrqp3yy += rtB .
fyoud2dfzn ; _rtXdot -> j5rh0u0prg = 0.0 ; _rtXdot -> j5rh0u0prg += rtP .
Currentfilter_A_o3r40a2fs0 * rtX . j5rh0u0prg ; _rtXdot -> j5rh0u0prg += rtB
. kjygkwym52 ; if ( _rtXdis -> cr4uxyxqlm ) { _rtXdot -> cr4uxyxqlm = 0.0 ; }
else { _rtXdot -> cr4uxyxqlm = rtB . kjygkwym52 ; } _rtXdot -> f1hbi1sd1q =
rtB . gkbr5qk2mc ; _rtXdot -> kkgf3fitxr = 0.0 ; _rtXdot -> kkgf3fitxr += rtP
. BAL_A_oad34lr4nf * rtX . kkgf3fitxr ; _rtXdot -> kkgf3fitxr += rtB .
kjygkwym52 ; _rtXdot -> batnhulphm = 0.0 ; _rtXdot -> batnhulphm += rtP .
Currentfilter_A_n0q2cotnax * rtX . batnhulphm ; _rtXdot -> batnhulphm += rtB
. ljzepiqdco ; if ( _rtXdis -> bnmkr55uji ) { _rtXdot -> bnmkr55uji = 0.0 ; }
else { _rtXdot -> bnmkr55uji = rtB . ljzepiqdco ; } _rtXdot -> lulwdnmna3 =
rtB . gn1iktvu5j ; _rtXdot -> opnxmo5ky2 = 0.0 ; _rtXdot -> opnxmo5ky2 += rtP
. BAL_A_nrro44ikdu * rtX . opnxmo5ky2 ; _rtXdot -> opnxmo5ky2 += rtB .
ljzepiqdco ; _rtXdot -> kec03nv1yd = 0.0 ; _rtXdot -> kec03nv1yd += rtP .
Currentfilter_A_jhxjqdrxhi * rtX . kec03nv1yd ; _rtXdot -> kec03nv1yd += rtB
. k4bl20stk1 ; if ( _rtXdis -> ducd1mygi5 ) { _rtXdot -> ducd1mygi5 = 0.0 ; }
else { _rtXdot -> ducd1mygi5 = rtB . k4bl20stk1 ; } _rtXdot -> a2azuhp5qh =
rtB . j2cbi4uvjv ; _rtXdot -> c4c3igik4x = 0.0 ; _rtXdot -> c4c3igik4x += rtP
. BAL_A_jd4dvguj5h * rtX . c4c3igik4x ; _rtXdot -> c4c3igik4x += rtB .
k4bl20stk1 ; _rtXdot -> jgg0wj1zhe = 0.0 ; _rtXdot -> jgg0wj1zhe += rtP .
Currentfilter_A_hin2vooinr * rtX . jgg0wj1zhe ; _rtXdot -> jgg0wj1zhe += rtB
. esg43lx2mr ; if ( _rtXdis -> mludnzmfko ) { _rtXdot -> mludnzmfko = 0.0 ; }
else { _rtXdot -> mludnzmfko = rtB . esg43lx2mr ; } _rtXdot -> fhoa1aghtu =
rtB . b0w045s1dy ; _rtXdot -> kxckn4j1uq = 0.0 ; _rtXdot -> kxckn4j1uq += rtP
. BAL_A_gvm0uualdo * rtX . kxckn4j1uq ; _rtXdot -> kxckn4j1uq += rtB .
esg43lx2mr ; { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; real_T *
sfcndX_fx = ( real_T * ) & ( ( XDot * ) ssGetdX ( rtS ) ) -> kyhu5rb2xj [ 0 ]
; ssSetdX ( rts , sfcndX_fx ) ; sfcnDerivatives ( rts ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } } void MdlProjection ( void
) { { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnProjection ( rts ) ;
if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } } void
MdlZeroCrossings ( void ) { ZCV * _rtZCSV ; _rtZCSV = ( ( ZCV * )
ssGetSolverZcSignalVector ( rtS ) ) ; _rtZCSV -> myhs4pztk3 = rtB .
g5y2ovgmgf - rtP . Constant_Value ; switch ( rtDW . klgebljbkk ) { case 1 :
_rtZCSV -> cfjqurvqqo = 0.0 ; _rtZCSV -> putslwjuhy = rtP . inti_UpperSat -
rtP . inti_LowerSat ; break ; case 2 : _rtZCSV -> cfjqurvqqo = rtP .
inti_LowerSat - rtP . inti_UpperSat ; _rtZCSV -> putslwjuhy = 0.0 ; break ;
default : _rtZCSV -> cfjqurvqqo = rtX . lbkltw2njc - rtP . inti_UpperSat ;
_rtZCSV -> putslwjuhy = rtX . lbkltw2njc - rtP . inti_LowerSat ; break ; } if
( ( rtDW . klgebljbkk == 3 ) || ( rtDW . klgebljbkk == 4 ) ) { _rtZCSV ->
pbndtniteq = rtB . lzgz2a1hji ; } else { _rtZCSV -> pbndtniteq = 0.0 ; }
_rtZCSV -> ppr3rmmyso = rtB . a42chj0wvi - rtB . k0olm5ygz1 ; _rtZCSV ->
ilodzpzwbm = rtB . a42chj0wvi - rtP . Constant9_Value ; _rtZCSV -> hmxtdlr5un
= rtB . mrkoixdcxy - rtB . mcznvl3xnw ; _rtZCSV -> exprgz402h = rtB .
a42chj0wvi - rtB . fq1y334rj2 ; _rtZCSV -> ohewfltqq5 = rtB . a42chj0wvi -
rtB . nj0k0lpkxt ; _rtZCSV -> m1nnc3fw0f = rtB . g5y2ovgmgf - rtP .
Constant_Value_efypwvyyax ; _rtZCSV -> jvhu0vulox = rtB . p0r2azag0g - rtP .
Saturation_UpperSat ; _rtZCSV -> hrwpslja5m = rtB . p0r2azag0g - rtP .
Saturation_LowerSat ; _rtZCSV -> lq5vehqec2 = rtB . n52pjzek12 - rtP .
Constant1_Value ; _rtZCSV -> mcki1r02nc = rtB . n52pjzek12 - rtB . bsbdyhiakj
; _rtZCSV -> mm15ri5pc4 = rtB . esegl2vvhs - rtP . Constant_Value_pbqzqfbpnm
; switch ( rtDW . j1al2derae ) { case 1 : _rtZCSV -> jfwddupd2z = 0.0 ;
_rtZCSV -> g11hraxjuu = rtP . inti_UpperSat_itldayqrxp - rtP .
inti_LowerSat_lz3gh0icex ; break ; case 2 : _rtZCSV -> jfwddupd2z = rtP .
inti_LowerSat_lz3gh0icex - rtP . inti_UpperSat_itldayqrxp ; _rtZCSV ->
g11hraxjuu = 0.0 ; break ; default : _rtZCSV -> jfwddupd2z = rtX . nxoiklb1cp
- rtP . inti_UpperSat_itldayqrxp ; _rtZCSV -> g11hraxjuu = rtX . nxoiklb1cp -
rtP . inti_LowerSat_lz3gh0icex ; break ; } if ( ( rtDW . j1al2derae == 3 ) ||
( rtDW . j1al2derae == 4 ) ) { _rtZCSV -> mqv31max5g = rtB . eutn5sqh40 ; }
else { _rtZCSV -> mqv31max5g = 0.0 ; } _rtZCSV -> bm0q0odbf5 = rtB .
othrejmk4n - rtB . jatbcbjee2 ; _rtZCSV -> nhr5yprh2q = rtB . othrejmk4n -
rtP . Constant9_Value_bfo0fnc5l1 ; _rtZCSV -> kfwlgrtdzl = rtB . b1idarpp5t -
rtB . o55coy5tot ; _rtZCSV -> emj11a1x4w = rtB . othrejmk4n - rtB .
po53ioprtt ; _rtZCSV -> kib1jjahlw = rtB . othrejmk4n - rtB . pmyyss4uxo ;
_rtZCSV -> h43mu0tc5z = rtB . esegl2vvhs - rtP . Constant_Value_hu3rmuppbn ;
_rtZCSV -> if52ui5e2k = rtB . nv44crtc44 - rtP .
Saturation_UpperSat_lxx4j3fnoa ; _rtZCSV -> nkalp3vjms = rtB . nv44crtc44 -
rtP . Saturation_LowerSat_kwi433xk5g ; _rtZCSV -> eyskbtymkf = rtB .
deh2tdbovg - rtP . Constant1_Value_jelmmtr1rj ; _rtZCSV -> mdgvgifavy = rtB .
deh2tdbovg - rtB . gaiiq3ag5u ; _rtZCSV -> ljpu0mfahy = rtB . c005o3t15s -
rtP . Constant_Value_bksqnhysc0 ; switch ( rtDW . ia4yvyaqmb ) { case 1 :
_rtZCSV -> lqcudbd12v = 0.0 ; _rtZCSV -> dewfaxqcny = rtP .
inti_UpperSat_nowwhgaxwk - rtP . inti_LowerSat_cwekkzbyq1 ; break ; case 2 :
_rtZCSV -> lqcudbd12v = rtP . inti_LowerSat_cwekkzbyq1 - rtP .
inti_UpperSat_nowwhgaxwk ; _rtZCSV -> dewfaxqcny = 0.0 ; break ; default :
_rtZCSV -> lqcudbd12v = rtX . bxy3w4qxj2 - rtP . inti_UpperSat_nowwhgaxwk ;
_rtZCSV -> dewfaxqcny = rtX . bxy3w4qxj2 - rtP . inti_LowerSat_cwekkzbyq1 ;
break ; } if ( ( rtDW . ia4yvyaqmb == 3 ) || ( rtDW . ia4yvyaqmb == 4 ) ) {
_rtZCSV -> jpox21jbul = rtB . pspdcb10ak ; } else { _rtZCSV -> jpox21jbul =
0.0 ; } _rtZCSV -> nsywl14eel = rtB . aojtgbxww0 - rtB . a2rrzly2nj ; _rtZCSV
-> l3podbdmiq = rtB . aojtgbxww0 - rtP . Constant9_Value_nhyzz1ckmw ; _rtZCSV
-> hxccwfvktp = rtB . cgdbtisdum - rtB . befeauo34y ; _rtZCSV -> j3wgfclxym =
rtB . aojtgbxww0 - rtB . hgspzwdexg ; _rtZCSV -> kwbcm1wtbm = rtB .
aojtgbxww0 - rtB . arqmlzjrl4 ; _rtZCSV -> ogtsqkbvdb = rtB . c005o3t15s -
rtP . Constant_Value_owtewy0ssm ; _rtZCSV -> arqudvd342 = rtB . lz4r5vsjh1 -
rtP . Saturation_UpperSat_blj3ug4rzx ; _rtZCSV -> fyt4r1dw3l = rtB .
lz4r5vsjh1 - rtP . Saturation_LowerSat_o0i20janpw ; _rtZCSV -> bxlkf43a2a =
rtB . a1q431buft - rtP . Constant1_Value_jj3f5fu3xp ; _rtZCSV -> ixxast5hnw =
rtB . a1q431buft - rtB . idgi4oj4mi ; _rtZCSV -> n2cbycjwvl = rtB .
olfzsyzgug - rtP . Constant_Value_kedzfrfegv ; switch ( rtDW . gaqc3mhu55 ) {
case 1 : _rtZCSV -> osvvjanfu3 = 0.0 ; _rtZCSV -> f1xtjtow1h = rtP .
inti_UpperSat_itde10ibkj - rtP . inti_LowerSat_nb1wwuftgl ; break ; case 2 :
_rtZCSV -> osvvjanfu3 = rtP . inti_LowerSat_nb1wwuftgl - rtP .
inti_UpperSat_itde10ibkj ; _rtZCSV -> f1xtjtow1h = 0.0 ; break ; default :
_rtZCSV -> osvvjanfu3 = rtX . dqfnkbb0xq - rtP . inti_UpperSat_itde10ibkj ;
_rtZCSV -> f1xtjtow1h = rtX . dqfnkbb0xq - rtP . inti_LowerSat_nb1wwuftgl ;
break ; } if ( ( rtDW . gaqc3mhu55 == 3 ) || ( rtDW . gaqc3mhu55 == 4 ) ) {
_rtZCSV -> hnp2hpsfw3 = rtB . fyoud2dfzn ; } else { _rtZCSV -> hnp2hpsfw3 =
0.0 ; } _rtZCSV -> jsjxxfswr1 = rtB . j41ux1gc4d - rtB . b2gwj4fubz ; _rtZCSV
-> iiuwfxed5w = rtB . j41ux1gc4d - rtP . Constant9_Value_ffsooduwum ; _rtZCSV
-> ir00qrz4mu = rtB . bpligzmo0k - rtB . k0z0bgvani ; _rtZCSV -> e5d41peunx =
rtB . j41ux1gc4d - rtB . chdzuypdzn ; _rtZCSV -> ntzovf5sch = rtB .
j41ux1gc4d - rtB . oi4dn5ko50 ; _rtZCSV -> owdxjhk3nw = rtB . olfzsyzgug -
rtP . Constant_Value_opaksbgo21 ; _rtZCSV -> f051liw0bt = rtB . g5hkbvjtz4 -
rtP . Saturation_UpperSat_c0l2pkijii ; _rtZCSV -> h3yeih3o50 = rtB .
g5hkbvjtz4 - rtP . Saturation_LowerSat_g1ovkjgj1x ; _rtZCSV -> ij21n3nes4 =
rtB . cvwcsqjiim - rtP . Constant1_Value_myhrse5szs ; _rtZCSV -> jn1sfcxozu =
rtB . cvwcsqjiim - rtB . ixuan5fz50 ; _rtZCSV -> fvhxslccjk = rtB .
lms5sy0bav - rtP . Constant_Value_epq2rsx4ba ; switch ( rtDW . cnphafnigh ) {
case 1 : _rtZCSV -> ealt5wavvm = 0.0 ; _rtZCSV -> lufdxrumf1 = rtP .
inti_UpperSat_ff0nysnmjy - rtP . inti_LowerSat_hzpmw3xl5s ; break ; case 2 :
_rtZCSV -> ealt5wavvm = rtP . inti_LowerSat_hzpmw3xl5s - rtP .
inti_UpperSat_ff0nysnmjy ; _rtZCSV -> lufdxrumf1 = 0.0 ; break ; default :
_rtZCSV -> ealt5wavvm = rtX . cr4uxyxqlm - rtP . inti_UpperSat_ff0nysnmjy ;
_rtZCSV -> lufdxrumf1 = rtX . cr4uxyxqlm - rtP . inti_LowerSat_hzpmw3xl5s ;
break ; } if ( ( rtDW . cnphafnigh == 3 ) || ( rtDW . cnphafnigh == 4 ) ) {
_rtZCSV -> pwt4v5mhy1 = rtB . kjygkwym52 ; } else { _rtZCSV -> pwt4v5mhy1 =
0.0 ; } _rtZCSV -> hq32wkpqi1 = rtB . msa01agh2x - rtB . iaqlnbjhf1 ; _rtZCSV
-> hgbtgb3u42 = rtB . msa01agh2x - rtP . Constant9_Value_bcezbzp4a1 ; _rtZCSV
-> jsfaw0ar3r = rtB . im14ffjmmn - rtB . aztqnss3hz ; _rtZCSV -> o5tdefqefq =
rtB . msa01agh2x - rtB . i0lfhlq3lc ; _rtZCSV -> f4iwv4z5ps = rtB .
msa01agh2x - rtB . g1xvhnr3f5 ; _rtZCSV -> lid1yiivho = rtB . lms5sy0bav -
rtP . Constant_Value_h45zreb2fb ; _rtZCSV -> n0itomkbtg = rtB . bvz4ef4xni -
rtP . Saturation_UpperSat_dr1jmbb0we ; _rtZCSV -> gq0ob0pzay = rtB .
bvz4ef4xni - rtP . Saturation_LowerSat_haspwmkdbs ; _rtZCSV -> jjcwejlqhn =
rtB . l0cwdgyzlo - rtP . Constant1_Value_h1thd4w1zg ; _rtZCSV -> c1wy4pcbpd =
rtB . l0cwdgyzlo - rtB . gcxndupnfr ; _rtZCSV -> lhnmycj1jm = rtB .
baqcdaab4w - rtP . Constant_Value_crxssz3mu1 ; switch ( rtDW . i3h0yxjcuf ) {
case 1 : _rtZCSV -> an05053gpk = 0.0 ; _rtZCSV -> jg4llb22qp = rtP .
inti_UpperSat_cuyg3emce0 - rtP . inti_LowerSat_l4lrtlmq4a ; break ; case 2 :
_rtZCSV -> an05053gpk = rtP . inti_LowerSat_l4lrtlmq4a - rtP .
inti_UpperSat_cuyg3emce0 ; _rtZCSV -> jg4llb22qp = 0.0 ; break ; default :
_rtZCSV -> an05053gpk = rtX . bnmkr55uji - rtP . inti_UpperSat_cuyg3emce0 ;
_rtZCSV -> jg4llb22qp = rtX . bnmkr55uji - rtP . inti_LowerSat_l4lrtlmq4a ;
break ; } if ( ( rtDW . i3h0yxjcuf == 3 ) || ( rtDW . i3h0yxjcuf == 4 ) ) {
_rtZCSV -> mdvezsli2f = rtB . ljzepiqdco ; } else { _rtZCSV -> mdvezsli2f =
0.0 ; } _rtZCSV -> kpwzip0qkr = rtB . bqzx2eyzzy - rtB . njfm3f2grf ; _rtZCSV
-> i0egb05npe = rtB . bqzx2eyzzy - rtP . Constant9_Value_khmvv2oadi ; _rtZCSV
-> hbn3wofidd = rtB . juce2ptz2y - rtB . i5kcdpjhpi ; _rtZCSV -> lz4mhc2wmw =
rtB . bqzx2eyzzy - rtB . gjn3v2eu4k ; _rtZCSV -> psop0at2i2 = rtB .
bqzx2eyzzy - rtB . g201quwjao ; _rtZCSV -> lvbouetvl0 = rtB . baqcdaab4w -
rtP . Constant_Value_hr1h3melx3 ; _rtZCSV -> a3knef4jdk = rtB . aaa1drn5lo -
rtP . Saturation_UpperSat_oasdavgelo ; _rtZCSV -> cx31ocf55v = rtB .
aaa1drn5lo - rtP . Saturation_LowerSat_hlakhjokuc ; _rtZCSV -> nx2sufq3e2 =
rtB . ecthl1j1o0 - rtP . Constant1_Value_fcmat31m3p ; _rtZCSV -> ajtviz0ljq =
rtB . ecthl1j1o0 - rtB . lhhyhpp5gu ; _rtZCSV -> kttbuegokb = rtB .
dm4nf0b0xz - rtP . Constant_Value_ksing41bve ; switch ( rtDW . krsqhbk5nm ) {
case 1 : _rtZCSV -> kgvyryvirg = 0.0 ; _rtZCSV -> blyiqhnnpp = rtP .
inti_UpperSat_p1ksyho442 - rtP . inti_LowerSat_c2pdzacpit ; break ; case 2 :
_rtZCSV -> kgvyryvirg = rtP . inti_LowerSat_c2pdzacpit - rtP .
inti_UpperSat_p1ksyho442 ; _rtZCSV -> blyiqhnnpp = 0.0 ; break ; default :
_rtZCSV -> kgvyryvirg = rtX . ducd1mygi5 - rtP . inti_UpperSat_p1ksyho442 ;
_rtZCSV -> blyiqhnnpp = rtX . ducd1mygi5 - rtP . inti_LowerSat_c2pdzacpit ;
break ; } if ( ( rtDW . krsqhbk5nm == 3 ) || ( rtDW . krsqhbk5nm == 4 ) ) {
_rtZCSV -> gqapwmagix = rtB . k4bl20stk1 ; } else { _rtZCSV -> gqapwmagix =
0.0 ; } _rtZCSV -> ojkomtjtef = rtB . ggnmpyt3wu - rtB . dr4em5z1io ; _rtZCSV
-> npx2guddge = rtB . ggnmpyt3wu - rtP . Constant9_Value_hbi2xzqgvf ; _rtZCSV
-> oe115a2c12 = rtB . b2ixyft4ic - rtB . nqmkidt0nf ; _rtZCSV -> bv3cqfte2u =
rtB . ggnmpyt3wu - rtB . i0iborr1bn ; _rtZCSV -> iag3mhstj5 = rtB .
ggnmpyt3wu - rtB . i0wi0xfyww ; _rtZCSV -> gdgqvzqi3s = rtB . dm4nf0b0xz -
rtP . Constant_Value_psd4g00i4r ; _rtZCSV -> mzlm31ndq4 = rtB . hvmipewyll -
rtP . Saturation_UpperSat_e2rewfpeer ; _rtZCSV -> nfw1xvjuao = rtB .
hvmipewyll - rtP . Saturation_LowerSat_btlbcqipab ; _rtZCSV -> grbzwslprl =
rtB . bxzkxne3dq - rtP . Constant1_Value_j1ihyekgnt ; _rtZCSV -> ga3dcd3mcw =
rtB . bxzkxne3dq - rtB . cd1qrej531 ; _rtZCSV -> ghxq40l2ug = rtB .
kxpcdql4jz - rtP . Constant_Value_ep2qfgttrh ; switch ( rtDW . bmltxw1qtk ) {
case 1 : _rtZCSV -> cz3cgc2itr = 0.0 ; _rtZCSV -> gfvbpatl1i = rtP .
inti_UpperSat_gge1msuajg - rtP . inti_LowerSat_b5bkhbogxv ; break ; case 2 :
_rtZCSV -> cz3cgc2itr = rtP . inti_LowerSat_b5bkhbogxv - rtP .
inti_UpperSat_gge1msuajg ; _rtZCSV -> gfvbpatl1i = 0.0 ; break ; default :
_rtZCSV -> cz3cgc2itr = rtX . mludnzmfko - rtP . inti_UpperSat_gge1msuajg ;
_rtZCSV -> gfvbpatl1i = rtX . mludnzmfko - rtP . inti_LowerSat_b5bkhbogxv ;
break ; } if ( ( rtDW . bmltxw1qtk == 3 ) || ( rtDW . bmltxw1qtk == 4 ) ) {
_rtZCSV -> ekluq2waeq = rtB . esg43lx2mr ; } else { _rtZCSV -> ekluq2waeq =
0.0 ; } _rtZCSV -> bxe3wi2je0 = rtB . ak5ny2xuat - rtB . gw4ubpvz5m ; _rtZCSV
-> jhbtahrhe1 = rtB . ak5ny2xuat - rtP . Constant9_Value_lgn0aviuoi ; _rtZCSV
-> i3ivgql1y0 = rtB . ja5d4uupyj - rtB . jufwanbg3o ; _rtZCSV -> ieenopzuxf =
rtB . ak5ny2xuat - rtB . jwcx5x3uww ; _rtZCSV -> gr0ssxqm02 = rtB .
ak5ny2xuat - rtB . acxnkfdwy1 ; _rtZCSV -> j1tiua0ae0 = rtB . kxpcdql4jz -
rtP . Constant_Value_lyegm1i5cg ; _rtZCSV -> lx2n40xdiy = rtB . jwjptsm01d -
rtP . Saturation_UpperSat_pwhhuyqzpe ; _rtZCSV -> izbh05fcoc = rtB .
jwjptsm01d - rtP . Saturation_LowerSat_gq5b2q5hog ; _rtZCSV -> c12mjtldmy =
rtB . cnd3dqmhap - rtP . Constant1_Value_mntemyjbjb ; _rtZCSV -> p3g4aboekx =
rtB . cnd3dqmhap - rtB . lizolknie1 ; { SimStruct * rts = ssGetSFunction (
rtS , 0 ) ; ssSetNonsampledZCs ( rts , & ( ( ( ZCV * )
ssGetSolverZcSignalVector ( rtS ) ) -> elqdvx0lx1 [ 0 ] ) ) ;
sfcnZeroCrossings ( rts ) ; if ( ssGetErrorStatus ( rts ) != ( NULL ) )
return ; } _rtZCSV -> ma0hzkvaed = rtB . gp1kmspjlh - rtP .
Saturation_UpperSat_pcz043fnep ; _rtZCSV -> b1lmlptsa3 = rtB . gp1kmspjlh -
rtP . Saturation_LowerSat_b05y2t0vvl ; _rtZCSV -> ofirj0ah5o = rtB .
eft5k5m2mk - rtP . Saturation_UpperSat_aqwzuangfk ; _rtZCSV -> d33u4khwsu =
rtB . eft5k5m2mk - rtP . Saturation_LowerSat_bcd3czsgyq ; _rtZCSV ->
cangwd1mrq = rtB . l1byjbqlra - rtP . Switch_Threshold ; _rtZCSV ->
j5edej5sxo = rtB . gfahibyvsv - rtP . Saturation_UpperSat_i3x3oscagf ;
_rtZCSV -> nmwpp4hddc = rtB . gfahibyvsv - rtP .
Saturation_LowerSat_gnz45aadu0 ; _rtZCSV -> igrauynbgq = rtB . lffxmmonqb -
rtP . Saturation_UpperSat_luxvjfmfd3 ; _rtZCSV -> g2u2q14kjv = rtB .
lffxmmonqb - rtP . Saturation_LowerSat_mqcesji40p ; _rtZCSV -> hjyxtapflk =
rtB . givksyq1ks - rtP . Saturation_UpperSat_p4wbgcsokm ; _rtZCSV ->
m3ewuq0gh5 = rtB . givksyq1ks - rtP . Saturation_LowerSat_gdbbvpyvzg ;
_rtZCSV -> mlecxmoxbp = rtB . lolyh00lpd - rtP .
Saturation_UpperSat_iofvqb3bhc ; _rtZCSV -> hmsh4hcdfv = rtB . lolyh00lpd -
rtP . Saturation_LowerSat_ob0aofpwnu ; _rtZCSV -> kjry1gqsra = rtB .
aacglbrseh - rtP . Saturation_UpperSat_f2amnkjsa0 ; _rtZCSV -> gdpdxykkmq =
rtB . aacglbrseh - rtP . Saturation_LowerSat_lbyytgqsae ; _rtZCSV ->
jaq2voieba = rtB . ilnuaaom40 - rtP . Saturation_UpperSat_dtvs1qra3o ;
_rtZCSV -> jvn3wnmrsu = rtB . ilnuaaom40 - rtP .
Saturation_LowerSat_huwlm3xk3n ; _rtZCSV -> hughwyjgsh = rtB . lpxn0wunpn ;
_rtZCSV -> dsnjjgktlo = rtB . a3i41vp1qh - rtP . Switch1_Threshold ; _rtZCSV
-> lopbnwklqv = rtB . p5n3swm2z3 ; _rtZCSV -> hokz3elyjr = rtB . kocesgc4kq -
rtP . Switch2_Threshold ; _rtZCSV -> lf3j4iftqm = rtB . k4qktqs5bt ; _rtZCSV
-> dnpy0xyenl = rtB . prlvalkk0e - rtP . Switch3_Threshold ; _rtZCSV ->
kvtgycann2 = rtB . dpcxxq2cb2 ; _rtZCSV -> m4rsg0jcnl = rtB . iu33mby5ow -
rtP . Switch6_Threshold ; _rtZCSV -> c4hjcvj4tj = rtB . fpat1cfbdw - rtP .
Switch4_Threshold ; _rtZCSV -> a2cp4o1ugm = rtB . pobsyfwdrr ; _rtZCSV ->
maw1xh1ohw = rtB . iy0igec4ex - rtP . Switch7_Threshold ; _rtZCSV ->
pxibwz53g0 = rtB . ejoagqctsb - rtP . Switch5_Threshold ; _rtZCSV ->
le2n03pz5k = rtB . c5g4vefyay ; _rtZCSV -> lctyqcdwpo = rtB . nhvmldohqo -
rtP . Switch9_Threshold ; _rtZCSV -> abtohhuzxi = rtB . d0hcukp5qd - rtP .
Switch8_Threshold ; _rtZCSV -> ppfyovyelw = rtB . lzgz2a1hji ; _rtZCSV ->
mdwl1ho1az = rtB . lzgz2a1hji - rtP . Constant_Value_ogegtmkzv0 ; _rtZCSV ->
ipetszo1bd = rtB . eutn5sqh40 ; _rtZCSV -> iwo0qdo2iq = rtB . eutn5sqh40 -
rtP . Constant_Value_h5irp45zuu ; _rtZCSV -> lebronrhnr = rtB . pspdcb10ak ;
_rtZCSV -> ecsecfgs4w = rtB . pspdcb10ak - rtP . Constant_Value_k5pwul1wle ;
_rtZCSV -> pfssuue2ir = rtB . fyoud2dfzn ; _rtZCSV -> cwcdpbzcel = rtB .
fyoud2dfzn - rtP . Constant_Value_pp4lg2cwxs ; _rtZCSV -> pvx0seffxh = rtB .
kjygkwym52 ; _rtZCSV -> ejpwmuory4 = rtB . kjygkwym52 - rtP .
Constant_Value_khiqevv1tc ; _rtZCSV -> aj1mc1yppx = rtB . ljzepiqdco ;
_rtZCSV -> hhebecm0fb = rtB . ljzepiqdco - rtP . Constant_Value_cf12bsal0m ;
_rtZCSV -> eoqzy3p3sp = rtB . k4bl20stk1 ; _rtZCSV -> pka3qzbcn3 = rtB .
k4bl20stk1 - rtP . Constant_Value_gpi13dm1iq ; _rtZCSV -> jev55rtigl = rtB .
esg43lx2mr ; _rtZCSV -> dxtb3xqamz = rtB . esg43lx2mr - rtP .
Constant_Value_aujhkhzu0m ; } void MdlTerminate ( void ) { { SimStruct * rts
= ssGetSFunction ( rtS , 0 ) ; sfcnTerminate ( rts ) ; } { if ( rtDW .
m4a1slsbsw . AQHandles ) { sdiTerminateStreaming ( & rtDW . m4a1slsbsw .
AQHandles ) ; } } { if ( rtDW . lb3ykh1ivj . AQHandles ) {
sdiTerminateStreaming ( & rtDW . lb3ykh1ivj . AQHandles ) ; } } { if ( rtDW .
idjooi12be . AQHandles ) { sdiTerminateStreaming ( & rtDW . idjooi12be .
AQHandles ) ; } } { if ( rtDW . nfq5r1c2nf . AQHandles ) {
sdiTerminateStreaming ( & rtDW . nfq5r1c2nf . AQHandles ) ; } } { if ( rtDW .
l1ntzlm3em . AQHandles ) { sdiTerminateStreaming ( & rtDW . l1ntzlm3em .
AQHandles ) ; } } { if ( rtDW . cjeepns1kp . AQHandles ) {
sdiTerminateStreaming ( & rtDW . cjeepns1kp . AQHandles ) ; } } { if ( rtDW .
p3mdqwq4kn . AQHandles ) { sdiTerminateStreaming ( & rtDW . p3mdqwq4kn .
AQHandles ) ; } } { if ( rtDW . ad2wzhmkkk . AQHandles ) {
sdiTerminateStreaming ( & rtDW . ad2wzhmkkk . AQHandles ) ; } } { if ( rtDW .
cp2sky53da . AQHandles ) { sdiTerminateStreaming ( & rtDW . cp2sky53da .
AQHandles ) ; } } { if ( rtDW . mlqhgw44yh . AQHandles ) {
sdiTerminateStreaming ( & rtDW . mlqhgw44yh . AQHandles ) ; } } { if ( rtDW .
ozkqasf5op . AQHandles ) { sdiTerminateStreaming ( & rtDW . ozkqasf5op .
AQHandles ) ; } } { if ( rtDW . md2q01fzov . AQHandles ) {
sdiTerminateStreaming ( & rtDW . md2q01fzov . AQHandles ) ; } } { if ( rtDW .
btuvwmnygy . AQHandles ) { sdiTerminateStreaming ( & rtDW . btuvwmnygy .
AQHandles ) ; } } { if ( rtDW . av20b02ile . AQHandles ) {
sdiTerminateStreaming ( & rtDW . av20b02ile . AQHandles ) ; } } { if ( rtDW .
o40s2uuuft . AQHandles ) { sdiTerminateStreaming ( & rtDW . o40s2uuuft .
AQHandles ) ; } } } static void mr_activeBalancing4_cacheDataAsMxArray (
mxArray * destArray , mwIndex i , int j , const void * srcData , size_t
numBytes ) ; static void mr_activeBalancing4_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) {
mxArray * newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void mr_activeBalancing4_restoreDataFromMxArray (
void * destData , const mxArray * srcArray , mwIndex i , int j , size_t
numBytes ) ; static void mr_activeBalancing4_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) {
memcpy ( ( uint8_T * ) destData , ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) , numBytes ) ; } static void
mr_activeBalancing4_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) ; static void
mr_activeBalancing4_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_activeBalancing4_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_activeBalancing4_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_activeBalancing4_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_activeBalancing4_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_activeBalancing4_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void mr_activeBalancing4_restoreDataFromMxArrayWithOffset
( void * destData , const mxArray * srcArray , mwIndex i , int j , mwIndex
offset , size_t numBytes ) { const uint8_T * varData = ( const uint8_T * )
mxGetData ( mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T *
) destData , ( const uint8_T * ) & varData [ offset * numBytes ] , numBytes )
; } static void mr_activeBalancing4_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void mr_activeBalancing4_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
{ mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_activeBalancing4_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_activeBalancing4_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_activeBalancing4_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "rtB" , "rtDW" , "rtPrevZCX" , }
; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_activeBalancing4_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & (
rtB ) , sizeof ( rtB ) ) ; { static const char * rtdwDataFieldNames [ 211 ] =
{ "rtDW.ca5hlnq0yv" , "rtDW.capftuiedr" , "rtDW.dausu4yb0r" ,
"rtDW.nxcbrqbg4s" , "rtDW.nb3lw1dts4" , "rtDW.oqfmlletk1" , "rtDW.b1blljt5i4"
, "rtDW.eude00gfzn" , "rtDW.omhuox45k5" , "rtDW.l5yuu2mi2t" ,
"rtDW.oteopngiwv" , "rtDW.jbkhseznjs" , "rtDW.g0xibfhryj" , "rtDW.dyomnt0iya"
, "rtDW.mmeejs3fon" , "rtDW.cixbj0ezqf" , "rtDW.bchydutg41" ,
"rtDW.man13mro5e" , "rtDW.alzjyrx0kg" , "rtDW.aggfvdda1e" , "rtDW.kmgw2sai2b"
, "rtDW.aegiye3tn1" , "rtDW.k0tqwauzp3" , "rtDW.nifwcsv1v1" ,
"rtDW.grio4yjtpl" , "rtDW.momrzwq4pr" , "rtDW.hfqfe1a1s5" , "rtDW.ifbin5pxrr"
, "rtDW.k2nrmdtvq3" , "rtDW.ff25ka4wdp" , "rtDW.cutbprvcd3" ,
"rtDW.bt4oyd503e" , "rtDW.azpppdzavz" , "rtDW.a30dvj5d1n" , "rtDW.gmjjnhltdk"
, "rtDW.dtmajsg54k" , "rtDW.magdrvjhlp" , "rtDW.axsolhspww" ,
"rtDW.jkukkxhvxl" , "rtDW.dxioy35srz" , "rtDW.klbt1o41jo" , "rtDW.bfgv0ou4np"
, "rtDW.mqmlslbwtt" , "rtDW.jqfoucolpw" , "rtDW.bq5fblkvcd" ,
"rtDW.mwvlfj3tnw" , "rtDW.jcfoqfv3fu" , "rtDW.p20ta3sfdz" , "rtDW.oqj3skvfcq"
, "rtDW.aj4yhj42qr" , "rtDW.k4l2ij22e5" , "rtDW.gbegstnyrm" ,
"rtDW.ioqp4ngatr" , "rtDW.lvyvopbaxf" , "rtDW.klgebljbkk" , "rtDW.ogvxzirtsf"
, "rtDW.j1al2derae" , "rtDW.ebrxkv0tlv" , "rtDW.ia4yvyaqmb" ,
"rtDW.kcjz5ym5tp" , "rtDW.gaqc3mhu55" , "rtDW.pbgnyq5tfg" , "rtDW.cnphafnigh"
, "rtDW.ggeecprz50" , "rtDW.i3h0yxjcuf" , "rtDW.plgswrux01" ,
"rtDW.krsqhbk5nm" , "rtDW.el3nwtqbps" , "rtDW.bmltxw1qtk" , "rtDW.llohfphikn"
, "rtDW.hnnabs4ndc" , "rtDW.dse1mzthll" , "rtDW.dqvqnr2muv" ,
"rtDW.c4c5mjr1mx" , "rtDW.bowq5mbaku" , "rtDW.ax3qgrkr55" , "rtDW.apxa0sqt1p"
, "rtDW.b4njscmbvx" , "rtDW.etyjay2nca" , "rtDW.fdlraqlrof" ,
"rtDW.omqfuqupyg" , "rtDW.gzlp0sbo4t" , "rtDW.jr1eyvxvce" , "rtDW.kvvcczrh2h"
, "rtDW.oeka1ufi2q" , "rtDW.paz4kgtbji" , "rtDW.ae04suheli" ,
"rtDW.iuncllo15x" , "rtDW.nmkbwshj5v" , "rtDW.lpusnuqytr" , "rtDW.o1g4bix2tx"
, "rtDW.molqmdigqy" , "rtDW.doucacjh3z" , "rtDW.looo4ud10x" ,
"rtDW.enb5gffmh1" , "rtDW.oki3ixtrek" , "rtDW.bm3shpqfur" , "rtDW.dq13p4klkw"
, "rtDW.b5qny41bod" , "rtDW.fzutpwbhou" , "rtDW.egflmvjdnu" ,
"rtDW.gbgm1nknco" , "rtDW.bobvege1xa" , "rtDW.pfgmjz0oxl" , "rtDW.c4ju1tonyc"
, "rtDW.ogpfosulwk" , "rtDW.mo2kznqvft" , "rtDW.honn2tdy54" ,
"rtDW.orbo5xgqzn" , "rtDW.iv2pdg4k2c" , "rtDW.h0qayo3umb" , "rtDW.ogoto0hwmm"
, "rtDW.fui4yx3kuz" , "rtDW.aa45yc1et3" , "rtDW.mdxvbvxht5" ,
"rtDW.b4svh4uxws" , "rtDW.mryeqkmzmt" , "rtDW.is4auzynbw" , "rtDW.j0pqa45jfy"
, "rtDW.oonf3bet4a" , "rtDW.kcmxrveuh1" , "rtDW.eywar50dsx" ,
"rtDW.nkeiblqwmm" , "rtDW.n2gaflvouv" , "rtDW.lwbxpyeq51" , "rtDW.bvkagd0qc0"
, "rtDW.nccltnyyv2" , "rtDW.pc2jk1zzjx" , "rtDW.nhpvpm5stq" ,
"rtDW.omshgvmyvz" , "rtDW.nowkbmdlih" , "rtDW.mif04ihnck" , "rtDW.f13aephrpz"
, "rtDW.gea0cqh513" , "rtDW.hdkgbo205c" , "rtDW.ozxljazjel" ,
"rtDW.ejk225g2nh" , "rtDW.p2nqnwkq04" , "rtDW.citc1qmgco" , "rtDW.j1x1lkik4i"
, "rtDW.hp3fpshwsf" , "rtDW.h4chdtup0e" , "rtDW.m140lfr1yc" ,
"rtDW.nrvhe4sfr2" , "rtDW.dhdzvyusm1" , "rtDW.hw43gon1bk" , "rtDW.jjq0zsbfta"
, "rtDW.lgtmlehdmv" , "rtDW.ctjashoslt" , "rtDW.fjenxspruc" ,
"rtDW.hwzhc3avex" , "rtDW.f3a4hcqytw" , "rtDW.gwdixswkyo" , "rtDW.mpwatn3jkl"
, "rtDW.dqufutohhs" , "rtDW.a0bwirjyiu" , "rtDW.j31b3jsmjg" ,
"rtDW.eshqu4qlyj" , "rtDW.aiibi55tgx" , "rtDW.hb2spknlp1" , "rtDW.f1xr4ouflt"
, "rtDW.oo4b1k4vub" , "rtDW.dofxxfnf1f" , "rtDW.d1fn42zlc3" ,
"rtDW.hbgw2vseyr" , "rtDW.lt3wgqvpso" , "rtDW.ec4jake2ld" , "rtDW.j53kvzldk2"
, "rtDW.frexusnuvh" , "rtDW.izbbvtos1d" , "rtDW.apdwknz0ig" ,
"rtDW.n2nzegphpi" , "rtDW.kus34kmfe0" , "rtDW.je3xbgadnf" , "rtDW.hs5qk4aflp"
, "rtDW.bmw4dfcea0" , "rtDW.n3tcjs3cnp" , "rtDW.eneedgqyil" ,
"rtDW.pn3eu4idcy" , "rtDW.cassosl0xb" , "rtDW.kldwedkv3j" , "rtDW.b5wvicli01"
, "rtDW.aex5jpmvuw" , "rtDW.ke5obrhhqt" , "rtDW.k5uuyepbrp" ,
"rtDW.a4qh2syf5f" , "rtDW.ptyhlovodi" , "rtDW.dimggz5k1i" , "rtDW.dgtx3pxebh"
, "rtDW.nerp2skw04" , "rtDW.fhpyfq1cbi" , "rtDW.fqogqsl1qn" ,
"rtDW.omg5wivauv" , "rtDW.ff1zu2lxej" , "rtDW.bxzckcwnmi" , "rtDW.n33t0mlcdo"
, "rtDW.puzlpon25o" , "rtDW.m4qezscalw" , "rtDW.ctjzi2o40d" ,
"rtDW.e3ay5unpbh" , "rtDW.bgieyqg154" , "rtDW.ozfvlojj1n" , "rtDW.fgsjlt3z00"
, "rtDW.hbjqhzro5y" , "rtDW.os10rt4vp3" , "rtDW.noglx0ol2f" ,
"rtDW.o1s050yt3g" , "rtDW.o1qidfzosp" , "rtDW.ngljbafwbt" , "rtDW.iknrj0yq2v"
, "rtDW.l4uscn224x" , } ; mxArray * rtdwData = mxCreateStructMatrix ( 1 , 1 ,
211 , rtdwDataFieldNames ) ; mr_activeBalancing4_cacheDataAsMxArray (
rtdwData , 0 , 0 , ( const void * ) & ( rtDW . ca5hlnq0yv ) , sizeof ( rtDW .
ca5hlnq0yv ) ) ; mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 1 ,
( const void * ) & ( rtDW . capftuiedr ) , sizeof ( rtDW . capftuiedr ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const void * )
& ( rtDW . dausu4yb0r ) , sizeof ( rtDW . dausu4yb0r ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const void * )
& ( rtDW . nxcbrqbg4s ) , sizeof ( rtDW . nxcbrqbg4s ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const void * )
& ( rtDW . nb3lw1dts4 ) , sizeof ( rtDW . nb3lw1dts4 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const void * )
& ( rtDW . oqfmlletk1 ) , sizeof ( rtDW . oqfmlletk1 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const void * )
& ( rtDW . b1blljt5i4 ) , sizeof ( rtDW . b1blljt5i4 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const void * )
& ( rtDW . eude00gfzn ) , sizeof ( rtDW . eude00gfzn ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 8 , ( const void * )
& ( rtDW . omhuox45k5 ) , sizeof ( rtDW . omhuox45k5 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 9 , ( const void * )
& ( rtDW . l5yuu2mi2t ) , sizeof ( rtDW . l5yuu2mi2t ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 10 , ( const void * )
& ( rtDW . oteopngiwv ) , sizeof ( rtDW . oteopngiwv ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 11 , ( const void * )
& ( rtDW . jbkhseznjs ) , sizeof ( rtDW . jbkhseznjs ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 12 , ( const void * )
& ( rtDW . g0xibfhryj ) , sizeof ( rtDW . g0xibfhryj ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 13 , ( const void * )
& ( rtDW . dyomnt0iya ) , sizeof ( rtDW . dyomnt0iya ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 14 , ( const void * )
& ( rtDW . mmeejs3fon ) , sizeof ( rtDW . mmeejs3fon ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 15 , ( const void * )
& ( rtDW . cixbj0ezqf ) , sizeof ( rtDW . cixbj0ezqf ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 16 , ( const void * )
& ( rtDW . bchydutg41 ) , sizeof ( rtDW . bchydutg41 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 17 , ( const void * )
& ( rtDW . man13mro5e ) , sizeof ( rtDW . man13mro5e ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 18 , ( const void * )
& ( rtDW . alzjyrx0kg ) , sizeof ( rtDW . alzjyrx0kg ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 19 , ( const void * )
& ( rtDW . aggfvdda1e ) , sizeof ( rtDW . aggfvdda1e ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 20 , ( const void * )
& ( rtDW . kmgw2sai2b ) , sizeof ( rtDW . kmgw2sai2b ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 21 , ( const void * )
& ( rtDW . aegiye3tn1 ) , sizeof ( rtDW . aegiye3tn1 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 22 , ( const void * )
& ( rtDW . k0tqwauzp3 ) , sizeof ( rtDW . k0tqwauzp3 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 23 , ( const void * )
& ( rtDW . nifwcsv1v1 ) , sizeof ( rtDW . nifwcsv1v1 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 24 , ( const void * )
& ( rtDW . grio4yjtpl ) , sizeof ( rtDW . grio4yjtpl ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 25 , ( const void * )
& ( rtDW . momrzwq4pr ) , sizeof ( rtDW . momrzwq4pr ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 26 , ( const void * )
& ( rtDW . hfqfe1a1s5 ) , sizeof ( rtDW . hfqfe1a1s5 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 27 , ( const void * )
& ( rtDW . ifbin5pxrr ) , sizeof ( rtDW . ifbin5pxrr ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 28 , ( const void * )
& ( rtDW . k2nrmdtvq3 ) , sizeof ( rtDW . k2nrmdtvq3 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 29 , ( const void * )
& ( rtDW . ff25ka4wdp ) , sizeof ( rtDW . ff25ka4wdp ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 30 , ( const void * )
& ( rtDW . cutbprvcd3 ) , sizeof ( rtDW . cutbprvcd3 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 31 , ( const void * )
& ( rtDW . bt4oyd503e ) , sizeof ( rtDW . bt4oyd503e ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 32 , ( const void * )
& ( rtDW . azpppdzavz ) , sizeof ( rtDW . azpppdzavz ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 33 , ( const void * )
& ( rtDW . a30dvj5d1n ) , sizeof ( rtDW . a30dvj5d1n ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 34 , ( const void * )
& ( rtDW . gmjjnhltdk ) , sizeof ( rtDW . gmjjnhltdk ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 35 , ( const void * )
& ( rtDW . dtmajsg54k ) , sizeof ( rtDW . dtmajsg54k ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 36 , ( const void * )
& ( rtDW . magdrvjhlp ) , sizeof ( rtDW . magdrvjhlp ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 37 , ( const void * )
& ( rtDW . axsolhspww ) , sizeof ( rtDW . axsolhspww ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 38 , ( const void * )
& ( rtDW . jkukkxhvxl ) , sizeof ( rtDW . jkukkxhvxl ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 39 , ( const void * )
& ( rtDW . dxioy35srz ) , sizeof ( rtDW . dxioy35srz ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 40 , ( const void * )
& ( rtDW . klbt1o41jo ) , sizeof ( rtDW . klbt1o41jo ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 41 , ( const void * )
& ( rtDW . bfgv0ou4np ) , sizeof ( rtDW . bfgv0ou4np ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 42 , ( const void * )
& ( rtDW . mqmlslbwtt ) , sizeof ( rtDW . mqmlslbwtt ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 43 , ( const void * )
& ( rtDW . jqfoucolpw ) , sizeof ( rtDW . jqfoucolpw ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 44 , ( const void * )
& ( rtDW . bq5fblkvcd ) , sizeof ( rtDW . bq5fblkvcd ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 45 , ( const void * )
& ( rtDW . mwvlfj3tnw ) , sizeof ( rtDW . mwvlfj3tnw ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 46 , ( const void * )
& ( rtDW . jcfoqfv3fu ) , sizeof ( rtDW . jcfoqfv3fu ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 47 , ( const void * )
& ( rtDW . p20ta3sfdz ) , sizeof ( rtDW . p20ta3sfdz ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 48 , ( const void * )
& ( rtDW . oqj3skvfcq ) , sizeof ( rtDW . oqj3skvfcq ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 49 , ( const void * )
& ( rtDW . aj4yhj42qr ) , sizeof ( rtDW . aj4yhj42qr ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 50 , ( const void * )
& ( rtDW . k4l2ij22e5 ) , sizeof ( rtDW . k4l2ij22e5 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 51 , ( const void * )
& ( rtDW . gbegstnyrm ) , sizeof ( rtDW . gbegstnyrm ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 52 , ( const void * )
& ( rtDW . ioqp4ngatr ) , sizeof ( rtDW . ioqp4ngatr ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 53 , ( const void * )
& ( rtDW . lvyvopbaxf ) , sizeof ( rtDW . lvyvopbaxf ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 54 , ( const void * )
& ( rtDW . klgebljbkk ) , sizeof ( rtDW . klgebljbkk ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 55 , ( const void * )
& ( rtDW . ogvxzirtsf ) , sizeof ( rtDW . ogvxzirtsf ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 56 , ( const void * )
& ( rtDW . j1al2derae ) , sizeof ( rtDW . j1al2derae ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 57 , ( const void * )
& ( rtDW . ebrxkv0tlv ) , sizeof ( rtDW . ebrxkv0tlv ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 58 , ( const void * )
& ( rtDW . ia4yvyaqmb ) , sizeof ( rtDW . ia4yvyaqmb ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 59 , ( const void * )
& ( rtDW . kcjz5ym5tp ) , sizeof ( rtDW . kcjz5ym5tp ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 60 , ( const void * )
& ( rtDW . gaqc3mhu55 ) , sizeof ( rtDW . gaqc3mhu55 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 61 , ( const void * )
& ( rtDW . pbgnyq5tfg ) , sizeof ( rtDW . pbgnyq5tfg ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 62 , ( const void * )
& ( rtDW . cnphafnigh ) , sizeof ( rtDW . cnphafnigh ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 63 , ( const void * )
& ( rtDW . ggeecprz50 ) , sizeof ( rtDW . ggeecprz50 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 64 , ( const void * )
& ( rtDW . i3h0yxjcuf ) , sizeof ( rtDW . i3h0yxjcuf ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 65 , ( const void * )
& ( rtDW . plgswrux01 ) , sizeof ( rtDW . plgswrux01 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 66 , ( const void * )
& ( rtDW . krsqhbk5nm ) , sizeof ( rtDW . krsqhbk5nm ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 67 , ( const void * )
& ( rtDW . el3nwtqbps ) , sizeof ( rtDW . el3nwtqbps ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 68 , ( const void * )
& ( rtDW . bmltxw1qtk ) , sizeof ( rtDW . bmltxw1qtk ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 69 , ( const void * )
& ( rtDW . llohfphikn ) , sizeof ( rtDW . llohfphikn ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 70 , ( const void * )
& ( rtDW . hnnabs4ndc ) , sizeof ( rtDW . hnnabs4ndc ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 71 , ( const void * )
& ( rtDW . dse1mzthll ) , sizeof ( rtDW . dse1mzthll ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 72 , ( const void * )
& ( rtDW . dqvqnr2muv ) , sizeof ( rtDW . dqvqnr2muv ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 73 , ( const void * )
& ( rtDW . c4c5mjr1mx ) , sizeof ( rtDW . c4c5mjr1mx ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 74 , ( const void * )
& ( rtDW . bowq5mbaku ) , sizeof ( rtDW . bowq5mbaku ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 75 , ( const void * )
& ( rtDW . ax3qgrkr55 ) , sizeof ( rtDW . ax3qgrkr55 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 76 , ( const void * )
& ( rtDW . apxa0sqt1p ) , sizeof ( rtDW . apxa0sqt1p ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 77 , ( const void * )
& ( rtDW . b4njscmbvx ) , sizeof ( rtDW . b4njscmbvx ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 78 , ( const void * )
& ( rtDW . etyjay2nca ) , sizeof ( rtDW . etyjay2nca ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 79 , ( const void * )
& ( rtDW . fdlraqlrof ) , sizeof ( rtDW . fdlraqlrof ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 80 , ( const void * )
& ( rtDW . omqfuqupyg ) , sizeof ( rtDW . omqfuqupyg ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 81 , ( const void * )
& ( rtDW . gzlp0sbo4t ) , sizeof ( rtDW . gzlp0sbo4t ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 82 , ( const void * )
& ( rtDW . jr1eyvxvce ) , sizeof ( rtDW . jr1eyvxvce ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 83 , ( const void * )
& ( rtDW . kvvcczrh2h ) , sizeof ( rtDW . kvvcczrh2h ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 84 , ( const void * )
& ( rtDW . oeka1ufi2q ) , sizeof ( rtDW . oeka1ufi2q ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 85 , ( const void * )
& ( rtDW . paz4kgtbji ) , sizeof ( rtDW . paz4kgtbji ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 86 , ( const void * )
& ( rtDW . ae04suheli ) , sizeof ( rtDW . ae04suheli ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 87 , ( const void * )
& ( rtDW . iuncllo15x ) , sizeof ( rtDW . iuncllo15x ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 88 , ( const void * )
& ( rtDW . nmkbwshj5v ) , sizeof ( rtDW . nmkbwshj5v ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 89 , ( const void * )
& ( rtDW . lpusnuqytr ) , sizeof ( rtDW . lpusnuqytr ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 90 , ( const void * )
& ( rtDW . o1g4bix2tx ) , sizeof ( rtDW . o1g4bix2tx ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 91 , ( const void * )
& ( rtDW . molqmdigqy ) , sizeof ( rtDW . molqmdigqy ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 92 , ( const void * )
& ( rtDW . doucacjh3z ) , sizeof ( rtDW . doucacjh3z ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 93 , ( const void * )
& ( rtDW . looo4ud10x ) , sizeof ( rtDW . looo4ud10x ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 94 , ( const void * )
& ( rtDW . enb5gffmh1 ) , sizeof ( rtDW . enb5gffmh1 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 95 , ( const void * )
& ( rtDW . oki3ixtrek ) , sizeof ( rtDW . oki3ixtrek ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 96 , ( const void * )
& ( rtDW . bm3shpqfur ) , sizeof ( rtDW . bm3shpqfur ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 97 , ( const void * )
& ( rtDW . dq13p4klkw ) , sizeof ( rtDW . dq13p4klkw ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 98 , ( const void * )
& ( rtDW . b5qny41bod ) , sizeof ( rtDW . b5qny41bod ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 99 , ( const void * )
& ( rtDW . fzutpwbhou ) , sizeof ( rtDW . fzutpwbhou ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 100 , ( const void *
) & ( rtDW . egflmvjdnu ) , sizeof ( rtDW . egflmvjdnu ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 101 , ( const void *
) & ( rtDW . gbgm1nknco ) , sizeof ( rtDW . gbgm1nknco ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 102 , ( const void *
) & ( rtDW . bobvege1xa ) , sizeof ( rtDW . bobvege1xa ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 103 , ( const void *
) & ( rtDW . pfgmjz0oxl ) , sizeof ( rtDW . pfgmjz0oxl ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 104 , ( const void *
) & ( rtDW . c4ju1tonyc ) , sizeof ( rtDW . c4ju1tonyc ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 105 , ( const void *
) & ( rtDW . ogpfosulwk ) , sizeof ( rtDW . ogpfosulwk ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 106 , ( const void *
) & ( rtDW . mo2kznqvft ) , sizeof ( rtDW . mo2kznqvft ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 107 , ( const void *
) & ( rtDW . honn2tdy54 ) , sizeof ( rtDW . honn2tdy54 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 108 , ( const void *
) & ( rtDW . orbo5xgqzn ) , sizeof ( rtDW . orbo5xgqzn ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 109 , ( const void *
) & ( rtDW . iv2pdg4k2c ) , sizeof ( rtDW . iv2pdg4k2c ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 110 , ( const void *
) & ( rtDW . h0qayo3umb ) , sizeof ( rtDW . h0qayo3umb ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 111 , ( const void *
) & ( rtDW . ogoto0hwmm ) , sizeof ( rtDW . ogoto0hwmm ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 112 , ( const void *
) & ( rtDW . fui4yx3kuz ) , sizeof ( rtDW . fui4yx3kuz ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 113 , ( const void *
) & ( rtDW . aa45yc1et3 ) , sizeof ( rtDW . aa45yc1et3 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 114 , ( const void *
) & ( rtDW . mdxvbvxht5 ) , sizeof ( rtDW . mdxvbvxht5 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 115 , ( const void *
) & ( rtDW . b4svh4uxws ) , sizeof ( rtDW . b4svh4uxws ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 116 , ( const void *
) & ( rtDW . mryeqkmzmt ) , sizeof ( rtDW . mryeqkmzmt ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 117 , ( const void *
) & ( rtDW . is4auzynbw ) , sizeof ( rtDW . is4auzynbw ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 118 , ( const void *
) & ( rtDW . j0pqa45jfy ) , sizeof ( rtDW . j0pqa45jfy ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 119 , ( const void *
) & ( rtDW . oonf3bet4a ) , sizeof ( rtDW . oonf3bet4a ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 120 , ( const void *
) & ( rtDW . kcmxrveuh1 ) , sizeof ( rtDW . kcmxrveuh1 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 121 , ( const void *
) & ( rtDW . eywar50dsx ) , sizeof ( rtDW . eywar50dsx ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 122 , ( const void *
) & ( rtDW . nkeiblqwmm ) , sizeof ( rtDW . nkeiblqwmm ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 123 , ( const void *
) & ( rtDW . n2gaflvouv ) , sizeof ( rtDW . n2gaflvouv ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 124 , ( const void *
) & ( rtDW . lwbxpyeq51 ) , sizeof ( rtDW . lwbxpyeq51 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 125 , ( const void *
) & ( rtDW . bvkagd0qc0 ) , sizeof ( rtDW . bvkagd0qc0 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 126 , ( const void *
) & ( rtDW . nccltnyyv2 ) , sizeof ( rtDW . nccltnyyv2 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 127 , ( const void *
) & ( rtDW . pc2jk1zzjx ) , sizeof ( rtDW . pc2jk1zzjx ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 128 , ( const void *
) & ( rtDW . nhpvpm5stq ) , sizeof ( rtDW . nhpvpm5stq ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 129 , ( const void *
) & ( rtDW . omshgvmyvz ) , sizeof ( rtDW . omshgvmyvz ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 130 , ( const void *
) & ( rtDW . nowkbmdlih ) , sizeof ( rtDW . nowkbmdlih ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 131 , ( const void *
) & ( rtDW . mif04ihnck ) , sizeof ( rtDW . mif04ihnck ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 132 , ( const void *
) & ( rtDW . f13aephrpz ) , sizeof ( rtDW . f13aephrpz ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 133 , ( const void *
) & ( rtDW . gea0cqh513 ) , sizeof ( rtDW . gea0cqh513 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 134 , ( const void *
) & ( rtDW . hdkgbo205c ) , sizeof ( rtDW . hdkgbo205c ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 135 , ( const void *
) & ( rtDW . ozxljazjel ) , sizeof ( rtDW . ozxljazjel ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 136 , ( const void *
) & ( rtDW . ejk225g2nh ) , sizeof ( rtDW . ejk225g2nh ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 137 , ( const void *
) & ( rtDW . p2nqnwkq04 ) , sizeof ( rtDW . p2nqnwkq04 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 138 , ( const void *
) & ( rtDW . citc1qmgco ) , sizeof ( rtDW . citc1qmgco ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 139 , ( const void *
) & ( rtDW . j1x1lkik4i ) , sizeof ( rtDW . j1x1lkik4i ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 140 , ( const void *
) & ( rtDW . hp3fpshwsf ) , sizeof ( rtDW . hp3fpshwsf ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 141 , ( const void *
) & ( rtDW . h4chdtup0e ) , sizeof ( rtDW . h4chdtup0e ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 142 , ( const void *
) & ( rtDW . m140lfr1yc ) , sizeof ( rtDW . m140lfr1yc ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 143 , ( const void *
) & ( rtDW . nrvhe4sfr2 ) , sizeof ( rtDW . nrvhe4sfr2 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 144 , ( const void *
) & ( rtDW . dhdzvyusm1 ) , sizeof ( rtDW . dhdzvyusm1 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 145 , ( const void *
) & ( rtDW . hw43gon1bk ) , sizeof ( rtDW . hw43gon1bk ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 146 , ( const void *
) & ( rtDW . jjq0zsbfta ) , sizeof ( rtDW . jjq0zsbfta ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 147 , ( const void *
) & ( rtDW . lgtmlehdmv ) , sizeof ( rtDW . lgtmlehdmv ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 148 , ( const void *
) & ( rtDW . ctjashoslt ) , sizeof ( rtDW . ctjashoslt ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 149 , ( const void *
) & ( rtDW . fjenxspruc ) , sizeof ( rtDW . fjenxspruc ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 150 , ( const void *
) & ( rtDW . hwzhc3avex ) , sizeof ( rtDW . hwzhc3avex ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 151 , ( const void *
) & ( rtDW . f3a4hcqytw ) , sizeof ( rtDW . f3a4hcqytw ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 152 , ( const void *
) & ( rtDW . gwdixswkyo ) , sizeof ( rtDW . gwdixswkyo ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 153 , ( const void *
) & ( rtDW . mpwatn3jkl ) , sizeof ( rtDW . mpwatn3jkl ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 154 , ( const void *
) & ( rtDW . dqufutohhs ) , sizeof ( rtDW . dqufutohhs ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 155 , ( const void *
) & ( rtDW . a0bwirjyiu ) , sizeof ( rtDW . a0bwirjyiu ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 156 , ( const void *
) & ( rtDW . j31b3jsmjg ) , sizeof ( rtDW . j31b3jsmjg ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 157 , ( const void *
) & ( rtDW . eshqu4qlyj ) , sizeof ( rtDW . eshqu4qlyj ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 158 , ( const void *
) & ( rtDW . aiibi55tgx ) , sizeof ( rtDW . aiibi55tgx ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 159 , ( const void *
) & ( rtDW . hb2spknlp1 ) , sizeof ( rtDW . hb2spknlp1 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 160 , ( const void *
) & ( rtDW . f1xr4ouflt ) , sizeof ( rtDW . f1xr4ouflt ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 161 , ( const void *
) & ( rtDW . oo4b1k4vub ) , sizeof ( rtDW . oo4b1k4vub ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 162 , ( const void *
) & ( rtDW . dofxxfnf1f ) , sizeof ( rtDW . dofxxfnf1f ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 163 , ( const void *
) & ( rtDW . d1fn42zlc3 ) , sizeof ( rtDW . d1fn42zlc3 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 164 , ( const void *
) & ( rtDW . hbgw2vseyr ) , sizeof ( rtDW . hbgw2vseyr ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 165 , ( const void *
) & ( rtDW . lt3wgqvpso ) , sizeof ( rtDW . lt3wgqvpso ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 166 , ( const void *
) & ( rtDW . ec4jake2ld ) , sizeof ( rtDW . ec4jake2ld ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 167 , ( const void *
) & ( rtDW . j53kvzldk2 ) , sizeof ( rtDW . j53kvzldk2 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 168 , ( const void *
) & ( rtDW . frexusnuvh ) , sizeof ( rtDW . frexusnuvh ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 169 , ( const void *
) & ( rtDW . izbbvtos1d ) , sizeof ( rtDW . izbbvtos1d ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 170 , ( const void *
) & ( rtDW . apdwknz0ig ) , sizeof ( rtDW . apdwknz0ig ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 171 , ( const void *
) & ( rtDW . n2nzegphpi ) , sizeof ( rtDW . n2nzegphpi ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 172 , ( const void *
) & ( rtDW . kus34kmfe0 ) , sizeof ( rtDW . kus34kmfe0 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 173 , ( const void *
) & ( rtDW . je3xbgadnf ) , sizeof ( rtDW . je3xbgadnf ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 174 , ( const void *
) & ( rtDW . hs5qk4aflp ) , sizeof ( rtDW . hs5qk4aflp ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 175 , ( const void *
) & ( rtDW . bmw4dfcea0 ) , sizeof ( rtDW . bmw4dfcea0 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 176 , ( const void *
) & ( rtDW . n3tcjs3cnp ) , sizeof ( rtDW . n3tcjs3cnp ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 177 , ( const void *
) & ( rtDW . eneedgqyil ) , sizeof ( rtDW . eneedgqyil ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 178 , ( const void *
) & ( rtDW . pn3eu4idcy ) , sizeof ( rtDW . pn3eu4idcy ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 179 , ( const void *
) & ( rtDW . cassosl0xb ) , sizeof ( rtDW . cassosl0xb ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 180 , ( const void *
) & ( rtDW . kldwedkv3j ) , sizeof ( rtDW . kldwedkv3j ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 181 , ( const void *
) & ( rtDW . b5wvicli01 ) , sizeof ( rtDW . b5wvicli01 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 182 , ( const void *
) & ( rtDW . aex5jpmvuw ) , sizeof ( rtDW . aex5jpmvuw ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 183 , ( const void *
) & ( rtDW . ke5obrhhqt ) , sizeof ( rtDW . ke5obrhhqt ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 184 , ( const void *
) & ( rtDW . k5uuyepbrp ) , sizeof ( rtDW . k5uuyepbrp ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 185 , ( const void *
) & ( rtDW . a4qh2syf5f ) , sizeof ( rtDW . a4qh2syf5f ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 186 , ( const void *
) & ( rtDW . ptyhlovodi ) , sizeof ( rtDW . ptyhlovodi ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 187 , ( const void *
) & ( rtDW . dimggz5k1i ) , sizeof ( rtDW . dimggz5k1i ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 188 , ( const void *
) & ( rtDW . dgtx3pxebh ) , sizeof ( rtDW . dgtx3pxebh ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 189 , ( const void *
) & ( rtDW . nerp2skw04 ) , sizeof ( rtDW . nerp2skw04 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 190 , ( const void *
) & ( rtDW . fhpyfq1cbi ) , sizeof ( rtDW . fhpyfq1cbi ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 191 , ( const void *
) & ( rtDW . fqogqsl1qn ) , sizeof ( rtDW . fqogqsl1qn ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 192 , ( const void *
) & ( rtDW . omg5wivauv ) , sizeof ( rtDW . omg5wivauv ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 193 , ( const void *
) & ( rtDW . ff1zu2lxej ) , sizeof ( rtDW . ff1zu2lxej ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 194 , ( const void *
) & ( rtDW . bxzckcwnmi ) , sizeof ( rtDW . bxzckcwnmi ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 195 , ( const void *
) & ( rtDW . n33t0mlcdo ) , sizeof ( rtDW . n33t0mlcdo ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 196 , ( const void *
) & ( rtDW . puzlpon25o ) , sizeof ( rtDW . puzlpon25o ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 197 , ( const void *
) & ( rtDW . m4qezscalw ) , sizeof ( rtDW . m4qezscalw ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 198 , ( const void *
) & ( rtDW . ctjzi2o40d ) , sizeof ( rtDW . ctjzi2o40d ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 199 , ( const void *
) & ( rtDW . e3ay5unpbh ) , sizeof ( rtDW . e3ay5unpbh ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 200 , ( const void *
) & ( rtDW . bgieyqg154 ) , sizeof ( rtDW . bgieyqg154 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 201 , ( const void *
) & ( rtDW . ozfvlojj1n ) , sizeof ( rtDW . ozfvlojj1n ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 202 , ( const void *
) & ( rtDW . fgsjlt3z00 ) , sizeof ( rtDW . fgsjlt3z00 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 203 , ( const void *
) & ( rtDW . hbjqhzro5y ) , sizeof ( rtDW . hbjqhzro5y ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 204 , ( const void *
) & ( rtDW . os10rt4vp3 ) , sizeof ( rtDW . os10rt4vp3 ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 205 , ( const void *
) & ( rtDW . noglx0ol2f ) , sizeof ( rtDW . noglx0ol2f ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 206 , ( const void *
) & ( rtDW . o1s050yt3g ) , sizeof ( rtDW . o1s050yt3g ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 207 , ( const void *
) & ( rtDW . o1qidfzosp ) , sizeof ( rtDW . o1qidfzosp ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 208 , ( const void *
) & ( rtDW . ngljbafwbt ) , sizeof ( rtDW . ngljbafwbt ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 209 , ( const void *
) & ( rtDW . iknrj0yq2v ) , sizeof ( rtDW . iknrj0yq2v ) ) ;
mr_activeBalancing4_cacheDataAsMxArray ( rtdwData , 0 , 210 , ( const void *
) & ( rtDW . l4uscn224x ) , sizeof ( rtDW . l4uscn224x ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; }
mr_activeBalancing4_cacheDataAsMxArray ( ssDW , 0 , 2 , ( const void * ) & (
rtPrevZCX ) , sizeof ( rtPrevZCX ) ) ; return ssDW ; } void
mr_activeBalancing4_SetDWork ( const mxArray * ssDW ) { ( void ) ssDW ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtB ) , ssDW , 0
, 0 , sizeof ( rtB ) ) ; { const mxArray * rtdwData = mxGetFieldByNumber (
ssDW , 0 , 1 ) ; mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & (
rtDW . ca5hlnq0yv ) , rtdwData , 0 , 0 , sizeof ( rtDW . ca5hlnq0yv ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . capftuiedr
) , rtdwData , 0 , 1 , sizeof ( rtDW . capftuiedr ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dausu4yb0r
) , rtdwData , 0 , 2 , sizeof ( rtDW . dausu4yb0r ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nxcbrqbg4s
) , rtdwData , 0 , 3 , sizeof ( rtDW . nxcbrqbg4s ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nb3lw1dts4
) , rtdwData , 0 , 4 , sizeof ( rtDW . nb3lw1dts4 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . oqfmlletk1
) , rtdwData , 0 , 5 , sizeof ( rtDW . oqfmlletk1 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . b1blljt5i4
) , rtdwData , 0 , 6 , sizeof ( rtDW . b1blljt5i4 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . eude00gfzn
) , rtdwData , 0 , 7 , sizeof ( rtDW . eude00gfzn ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . omhuox45k5
) , rtdwData , 0 , 8 , sizeof ( rtDW . omhuox45k5 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . l5yuu2mi2t
) , rtdwData , 0 , 9 , sizeof ( rtDW . l5yuu2mi2t ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . oteopngiwv
) , rtdwData , 0 , 10 , sizeof ( rtDW . oteopngiwv ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . jbkhseznjs
) , rtdwData , 0 , 11 , sizeof ( rtDW . jbkhseznjs ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . g0xibfhryj
) , rtdwData , 0 , 12 , sizeof ( rtDW . g0xibfhryj ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dyomnt0iya
) , rtdwData , 0 , 13 , sizeof ( rtDW . dyomnt0iya ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . mmeejs3fon
) , rtdwData , 0 , 14 , sizeof ( rtDW . mmeejs3fon ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . cixbj0ezqf
) , rtdwData , 0 , 15 , sizeof ( rtDW . cixbj0ezqf ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bchydutg41
) , rtdwData , 0 , 16 , sizeof ( rtDW . bchydutg41 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . man13mro5e
) , rtdwData , 0 , 17 , sizeof ( rtDW . man13mro5e ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . alzjyrx0kg
) , rtdwData , 0 , 18 , sizeof ( rtDW . alzjyrx0kg ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . aggfvdda1e
) , rtdwData , 0 , 19 , sizeof ( rtDW . aggfvdda1e ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . kmgw2sai2b
) , rtdwData , 0 , 20 , sizeof ( rtDW . kmgw2sai2b ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . aegiye3tn1
) , rtdwData , 0 , 21 , sizeof ( rtDW . aegiye3tn1 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . k0tqwauzp3
) , rtdwData , 0 , 22 , sizeof ( rtDW . k0tqwauzp3 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nifwcsv1v1
) , rtdwData , 0 , 23 , sizeof ( rtDW . nifwcsv1v1 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . grio4yjtpl
) , rtdwData , 0 , 24 , sizeof ( rtDW . grio4yjtpl ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . momrzwq4pr
) , rtdwData , 0 , 25 , sizeof ( rtDW . momrzwq4pr ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hfqfe1a1s5
) , rtdwData , 0 , 26 , sizeof ( rtDW . hfqfe1a1s5 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ifbin5pxrr
) , rtdwData , 0 , 27 , sizeof ( rtDW . ifbin5pxrr ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . k2nrmdtvq3
) , rtdwData , 0 , 28 , sizeof ( rtDW . k2nrmdtvq3 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ff25ka4wdp
) , rtdwData , 0 , 29 , sizeof ( rtDW . ff25ka4wdp ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . cutbprvcd3
) , rtdwData , 0 , 30 , sizeof ( rtDW . cutbprvcd3 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bt4oyd503e
) , rtdwData , 0 , 31 , sizeof ( rtDW . bt4oyd503e ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . azpppdzavz
) , rtdwData , 0 , 32 , sizeof ( rtDW . azpppdzavz ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . a30dvj5d1n
) , rtdwData , 0 , 33 , sizeof ( rtDW . a30dvj5d1n ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . gmjjnhltdk
) , rtdwData , 0 , 34 , sizeof ( rtDW . gmjjnhltdk ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dtmajsg54k
) , rtdwData , 0 , 35 , sizeof ( rtDW . dtmajsg54k ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . magdrvjhlp
) , rtdwData , 0 , 36 , sizeof ( rtDW . magdrvjhlp ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . axsolhspww
) , rtdwData , 0 , 37 , sizeof ( rtDW . axsolhspww ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . jkukkxhvxl
) , rtdwData , 0 , 38 , sizeof ( rtDW . jkukkxhvxl ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dxioy35srz
) , rtdwData , 0 , 39 , sizeof ( rtDW . dxioy35srz ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . klbt1o41jo
) , rtdwData , 0 , 40 , sizeof ( rtDW . klbt1o41jo ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bfgv0ou4np
) , rtdwData , 0 , 41 , sizeof ( rtDW . bfgv0ou4np ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . mqmlslbwtt
) , rtdwData , 0 , 42 , sizeof ( rtDW . mqmlslbwtt ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . jqfoucolpw
) , rtdwData , 0 , 43 , sizeof ( rtDW . jqfoucolpw ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bq5fblkvcd
) , rtdwData , 0 , 44 , sizeof ( rtDW . bq5fblkvcd ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . mwvlfj3tnw
) , rtdwData , 0 , 45 , sizeof ( rtDW . mwvlfj3tnw ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . jcfoqfv3fu
) , rtdwData , 0 , 46 , sizeof ( rtDW . jcfoqfv3fu ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . p20ta3sfdz
) , rtdwData , 0 , 47 , sizeof ( rtDW . p20ta3sfdz ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . oqj3skvfcq
) , rtdwData , 0 , 48 , sizeof ( rtDW . oqj3skvfcq ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . aj4yhj42qr
) , rtdwData , 0 , 49 , sizeof ( rtDW . aj4yhj42qr ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . k4l2ij22e5
) , rtdwData , 0 , 50 , sizeof ( rtDW . k4l2ij22e5 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . gbegstnyrm
) , rtdwData , 0 , 51 , sizeof ( rtDW . gbegstnyrm ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ioqp4ngatr
) , rtdwData , 0 , 52 , sizeof ( rtDW . ioqp4ngatr ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . lvyvopbaxf
) , rtdwData , 0 , 53 , sizeof ( rtDW . lvyvopbaxf ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . klgebljbkk
) , rtdwData , 0 , 54 , sizeof ( rtDW . klgebljbkk ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ogvxzirtsf
) , rtdwData , 0 , 55 , sizeof ( rtDW . ogvxzirtsf ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . j1al2derae
) , rtdwData , 0 , 56 , sizeof ( rtDW . j1al2derae ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ebrxkv0tlv
) , rtdwData , 0 , 57 , sizeof ( rtDW . ebrxkv0tlv ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ia4yvyaqmb
) , rtdwData , 0 , 58 , sizeof ( rtDW . ia4yvyaqmb ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . kcjz5ym5tp
) , rtdwData , 0 , 59 , sizeof ( rtDW . kcjz5ym5tp ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . gaqc3mhu55
) , rtdwData , 0 , 60 , sizeof ( rtDW . gaqc3mhu55 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . pbgnyq5tfg
) , rtdwData , 0 , 61 , sizeof ( rtDW . pbgnyq5tfg ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . cnphafnigh
) , rtdwData , 0 , 62 , sizeof ( rtDW . cnphafnigh ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ggeecprz50
) , rtdwData , 0 , 63 , sizeof ( rtDW . ggeecprz50 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . i3h0yxjcuf
) , rtdwData , 0 , 64 , sizeof ( rtDW . i3h0yxjcuf ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . plgswrux01
) , rtdwData , 0 , 65 , sizeof ( rtDW . plgswrux01 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . krsqhbk5nm
) , rtdwData , 0 , 66 , sizeof ( rtDW . krsqhbk5nm ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . el3nwtqbps
) , rtdwData , 0 , 67 , sizeof ( rtDW . el3nwtqbps ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bmltxw1qtk
) , rtdwData , 0 , 68 , sizeof ( rtDW . bmltxw1qtk ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . llohfphikn
) , rtdwData , 0 , 69 , sizeof ( rtDW . llohfphikn ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hnnabs4ndc
) , rtdwData , 0 , 70 , sizeof ( rtDW . hnnabs4ndc ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dse1mzthll
) , rtdwData , 0 , 71 , sizeof ( rtDW . dse1mzthll ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dqvqnr2muv
) , rtdwData , 0 , 72 , sizeof ( rtDW . dqvqnr2muv ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . c4c5mjr1mx
) , rtdwData , 0 , 73 , sizeof ( rtDW . c4c5mjr1mx ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bowq5mbaku
) , rtdwData , 0 , 74 , sizeof ( rtDW . bowq5mbaku ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ax3qgrkr55
) , rtdwData , 0 , 75 , sizeof ( rtDW . ax3qgrkr55 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . apxa0sqt1p
) , rtdwData , 0 , 76 , sizeof ( rtDW . apxa0sqt1p ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . b4njscmbvx
) , rtdwData , 0 , 77 , sizeof ( rtDW . b4njscmbvx ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . etyjay2nca
) , rtdwData , 0 , 78 , sizeof ( rtDW . etyjay2nca ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . fdlraqlrof
) , rtdwData , 0 , 79 , sizeof ( rtDW . fdlraqlrof ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . omqfuqupyg
) , rtdwData , 0 , 80 , sizeof ( rtDW . omqfuqupyg ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . gzlp0sbo4t
) , rtdwData , 0 , 81 , sizeof ( rtDW . gzlp0sbo4t ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . jr1eyvxvce
) , rtdwData , 0 , 82 , sizeof ( rtDW . jr1eyvxvce ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . kvvcczrh2h
) , rtdwData , 0 , 83 , sizeof ( rtDW . kvvcczrh2h ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . oeka1ufi2q
) , rtdwData , 0 , 84 , sizeof ( rtDW . oeka1ufi2q ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . paz4kgtbji
) , rtdwData , 0 , 85 , sizeof ( rtDW . paz4kgtbji ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ae04suheli
) , rtdwData , 0 , 86 , sizeof ( rtDW . ae04suheli ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . iuncllo15x
) , rtdwData , 0 , 87 , sizeof ( rtDW . iuncllo15x ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nmkbwshj5v
) , rtdwData , 0 , 88 , sizeof ( rtDW . nmkbwshj5v ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . lpusnuqytr
) , rtdwData , 0 , 89 , sizeof ( rtDW . lpusnuqytr ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . o1g4bix2tx
) , rtdwData , 0 , 90 , sizeof ( rtDW . o1g4bix2tx ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . molqmdigqy
) , rtdwData , 0 , 91 , sizeof ( rtDW . molqmdigqy ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . doucacjh3z
) , rtdwData , 0 , 92 , sizeof ( rtDW . doucacjh3z ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . looo4ud10x
) , rtdwData , 0 , 93 , sizeof ( rtDW . looo4ud10x ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . enb5gffmh1
) , rtdwData , 0 , 94 , sizeof ( rtDW . enb5gffmh1 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . oki3ixtrek
) , rtdwData , 0 , 95 , sizeof ( rtDW . oki3ixtrek ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bm3shpqfur
) , rtdwData , 0 , 96 , sizeof ( rtDW . bm3shpqfur ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dq13p4klkw
) , rtdwData , 0 , 97 , sizeof ( rtDW . dq13p4klkw ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . b5qny41bod
) , rtdwData , 0 , 98 , sizeof ( rtDW . b5qny41bod ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . fzutpwbhou
) , rtdwData , 0 , 99 , sizeof ( rtDW . fzutpwbhou ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . egflmvjdnu
) , rtdwData , 0 , 100 , sizeof ( rtDW . egflmvjdnu ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . gbgm1nknco
) , rtdwData , 0 , 101 , sizeof ( rtDW . gbgm1nknco ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bobvege1xa
) , rtdwData , 0 , 102 , sizeof ( rtDW . bobvege1xa ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . pfgmjz0oxl
) , rtdwData , 0 , 103 , sizeof ( rtDW . pfgmjz0oxl ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . c4ju1tonyc
) , rtdwData , 0 , 104 , sizeof ( rtDW . c4ju1tonyc ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ogpfosulwk
) , rtdwData , 0 , 105 , sizeof ( rtDW . ogpfosulwk ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . mo2kznqvft
) , rtdwData , 0 , 106 , sizeof ( rtDW . mo2kznqvft ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . honn2tdy54
) , rtdwData , 0 , 107 , sizeof ( rtDW . honn2tdy54 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . orbo5xgqzn
) , rtdwData , 0 , 108 , sizeof ( rtDW . orbo5xgqzn ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . iv2pdg4k2c
) , rtdwData , 0 , 109 , sizeof ( rtDW . iv2pdg4k2c ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . h0qayo3umb
) , rtdwData , 0 , 110 , sizeof ( rtDW . h0qayo3umb ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ogoto0hwmm
) , rtdwData , 0 , 111 , sizeof ( rtDW . ogoto0hwmm ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . fui4yx3kuz
) , rtdwData , 0 , 112 , sizeof ( rtDW . fui4yx3kuz ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . aa45yc1et3
) , rtdwData , 0 , 113 , sizeof ( rtDW . aa45yc1et3 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . mdxvbvxht5
) , rtdwData , 0 , 114 , sizeof ( rtDW . mdxvbvxht5 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . b4svh4uxws
) , rtdwData , 0 , 115 , sizeof ( rtDW . b4svh4uxws ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . mryeqkmzmt
) , rtdwData , 0 , 116 , sizeof ( rtDW . mryeqkmzmt ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . is4auzynbw
) , rtdwData , 0 , 117 , sizeof ( rtDW . is4auzynbw ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . j0pqa45jfy
) , rtdwData , 0 , 118 , sizeof ( rtDW . j0pqa45jfy ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . oonf3bet4a
) , rtdwData , 0 , 119 , sizeof ( rtDW . oonf3bet4a ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . kcmxrveuh1
) , rtdwData , 0 , 120 , sizeof ( rtDW . kcmxrveuh1 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . eywar50dsx
) , rtdwData , 0 , 121 , sizeof ( rtDW . eywar50dsx ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nkeiblqwmm
) , rtdwData , 0 , 122 , sizeof ( rtDW . nkeiblqwmm ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . n2gaflvouv
) , rtdwData , 0 , 123 , sizeof ( rtDW . n2gaflvouv ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . lwbxpyeq51
) , rtdwData , 0 , 124 , sizeof ( rtDW . lwbxpyeq51 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bvkagd0qc0
) , rtdwData , 0 , 125 , sizeof ( rtDW . bvkagd0qc0 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nccltnyyv2
) , rtdwData , 0 , 126 , sizeof ( rtDW . nccltnyyv2 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . pc2jk1zzjx
) , rtdwData , 0 , 127 , sizeof ( rtDW . pc2jk1zzjx ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nhpvpm5stq
) , rtdwData , 0 , 128 , sizeof ( rtDW . nhpvpm5stq ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . omshgvmyvz
) , rtdwData , 0 , 129 , sizeof ( rtDW . omshgvmyvz ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nowkbmdlih
) , rtdwData , 0 , 130 , sizeof ( rtDW . nowkbmdlih ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . mif04ihnck
) , rtdwData , 0 , 131 , sizeof ( rtDW . mif04ihnck ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . f13aephrpz
) , rtdwData , 0 , 132 , sizeof ( rtDW . f13aephrpz ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . gea0cqh513
) , rtdwData , 0 , 133 , sizeof ( rtDW . gea0cqh513 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hdkgbo205c
) , rtdwData , 0 , 134 , sizeof ( rtDW . hdkgbo205c ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ozxljazjel
) , rtdwData , 0 , 135 , sizeof ( rtDW . ozxljazjel ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ejk225g2nh
) , rtdwData , 0 , 136 , sizeof ( rtDW . ejk225g2nh ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . p2nqnwkq04
) , rtdwData , 0 , 137 , sizeof ( rtDW . p2nqnwkq04 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . citc1qmgco
) , rtdwData , 0 , 138 , sizeof ( rtDW . citc1qmgco ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . j1x1lkik4i
) , rtdwData , 0 , 139 , sizeof ( rtDW . j1x1lkik4i ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hp3fpshwsf
) , rtdwData , 0 , 140 , sizeof ( rtDW . hp3fpshwsf ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . h4chdtup0e
) , rtdwData , 0 , 141 , sizeof ( rtDW . h4chdtup0e ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . m140lfr1yc
) , rtdwData , 0 , 142 , sizeof ( rtDW . m140lfr1yc ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nrvhe4sfr2
) , rtdwData , 0 , 143 , sizeof ( rtDW . nrvhe4sfr2 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dhdzvyusm1
) , rtdwData , 0 , 144 , sizeof ( rtDW . dhdzvyusm1 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hw43gon1bk
) , rtdwData , 0 , 145 , sizeof ( rtDW . hw43gon1bk ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . jjq0zsbfta
) , rtdwData , 0 , 146 , sizeof ( rtDW . jjq0zsbfta ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . lgtmlehdmv
) , rtdwData , 0 , 147 , sizeof ( rtDW . lgtmlehdmv ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ctjashoslt
) , rtdwData , 0 , 148 , sizeof ( rtDW . ctjashoslt ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . fjenxspruc
) , rtdwData , 0 , 149 , sizeof ( rtDW . fjenxspruc ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hwzhc3avex
) , rtdwData , 0 , 150 , sizeof ( rtDW . hwzhc3avex ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . f3a4hcqytw
) , rtdwData , 0 , 151 , sizeof ( rtDW . f3a4hcqytw ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . gwdixswkyo
) , rtdwData , 0 , 152 , sizeof ( rtDW . gwdixswkyo ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . mpwatn3jkl
) , rtdwData , 0 , 153 , sizeof ( rtDW . mpwatn3jkl ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dqufutohhs
) , rtdwData , 0 , 154 , sizeof ( rtDW . dqufutohhs ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . a0bwirjyiu
) , rtdwData , 0 , 155 , sizeof ( rtDW . a0bwirjyiu ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . j31b3jsmjg
) , rtdwData , 0 , 156 , sizeof ( rtDW . j31b3jsmjg ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . eshqu4qlyj
) , rtdwData , 0 , 157 , sizeof ( rtDW . eshqu4qlyj ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . aiibi55tgx
) , rtdwData , 0 , 158 , sizeof ( rtDW . aiibi55tgx ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hb2spknlp1
) , rtdwData , 0 , 159 , sizeof ( rtDW . hb2spknlp1 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . f1xr4ouflt
) , rtdwData , 0 , 160 , sizeof ( rtDW . f1xr4ouflt ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . oo4b1k4vub
) , rtdwData , 0 , 161 , sizeof ( rtDW . oo4b1k4vub ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dofxxfnf1f
) , rtdwData , 0 , 162 , sizeof ( rtDW . dofxxfnf1f ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . d1fn42zlc3
) , rtdwData , 0 , 163 , sizeof ( rtDW . d1fn42zlc3 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hbgw2vseyr
) , rtdwData , 0 , 164 , sizeof ( rtDW . hbgw2vseyr ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . lt3wgqvpso
) , rtdwData , 0 , 165 , sizeof ( rtDW . lt3wgqvpso ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ec4jake2ld
) , rtdwData , 0 , 166 , sizeof ( rtDW . ec4jake2ld ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . j53kvzldk2
) , rtdwData , 0 , 167 , sizeof ( rtDW . j53kvzldk2 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . frexusnuvh
) , rtdwData , 0 , 168 , sizeof ( rtDW . frexusnuvh ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . izbbvtos1d
) , rtdwData , 0 , 169 , sizeof ( rtDW . izbbvtos1d ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . apdwknz0ig
) , rtdwData , 0 , 170 , sizeof ( rtDW . apdwknz0ig ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . n2nzegphpi
) , rtdwData , 0 , 171 , sizeof ( rtDW . n2nzegphpi ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . kus34kmfe0
) , rtdwData , 0 , 172 , sizeof ( rtDW . kus34kmfe0 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . je3xbgadnf
) , rtdwData , 0 , 173 , sizeof ( rtDW . je3xbgadnf ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hs5qk4aflp
) , rtdwData , 0 , 174 , sizeof ( rtDW . hs5qk4aflp ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bmw4dfcea0
) , rtdwData , 0 , 175 , sizeof ( rtDW . bmw4dfcea0 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . n3tcjs3cnp
) , rtdwData , 0 , 176 , sizeof ( rtDW . n3tcjs3cnp ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . eneedgqyil
) , rtdwData , 0 , 177 , sizeof ( rtDW . eneedgqyil ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . pn3eu4idcy
) , rtdwData , 0 , 178 , sizeof ( rtDW . pn3eu4idcy ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . cassosl0xb
) , rtdwData , 0 , 179 , sizeof ( rtDW . cassosl0xb ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . kldwedkv3j
) , rtdwData , 0 , 180 , sizeof ( rtDW . kldwedkv3j ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . b5wvicli01
) , rtdwData , 0 , 181 , sizeof ( rtDW . b5wvicli01 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . aex5jpmvuw
) , rtdwData , 0 , 182 , sizeof ( rtDW . aex5jpmvuw ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ke5obrhhqt
) , rtdwData , 0 , 183 , sizeof ( rtDW . ke5obrhhqt ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . k5uuyepbrp
) , rtdwData , 0 , 184 , sizeof ( rtDW . k5uuyepbrp ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . a4qh2syf5f
) , rtdwData , 0 , 185 , sizeof ( rtDW . a4qh2syf5f ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ptyhlovodi
) , rtdwData , 0 , 186 , sizeof ( rtDW . ptyhlovodi ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dimggz5k1i
) , rtdwData , 0 , 187 , sizeof ( rtDW . dimggz5k1i ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . dgtx3pxebh
) , rtdwData , 0 , 188 , sizeof ( rtDW . dgtx3pxebh ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . nerp2skw04
) , rtdwData , 0 , 189 , sizeof ( rtDW . nerp2skw04 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . fhpyfq1cbi
) , rtdwData , 0 , 190 , sizeof ( rtDW . fhpyfq1cbi ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . fqogqsl1qn
) , rtdwData , 0 , 191 , sizeof ( rtDW . fqogqsl1qn ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . omg5wivauv
) , rtdwData , 0 , 192 , sizeof ( rtDW . omg5wivauv ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ff1zu2lxej
) , rtdwData , 0 , 193 , sizeof ( rtDW . ff1zu2lxej ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bxzckcwnmi
) , rtdwData , 0 , 194 , sizeof ( rtDW . bxzckcwnmi ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . n33t0mlcdo
) , rtdwData , 0 , 195 , sizeof ( rtDW . n33t0mlcdo ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . puzlpon25o
) , rtdwData , 0 , 196 , sizeof ( rtDW . puzlpon25o ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . m4qezscalw
) , rtdwData , 0 , 197 , sizeof ( rtDW . m4qezscalw ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ctjzi2o40d
) , rtdwData , 0 , 198 , sizeof ( rtDW . ctjzi2o40d ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . e3ay5unpbh
) , rtdwData , 0 , 199 , sizeof ( rtDW . e3ay5unpbh ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . bgieyqg154
) , rtdwData , 0 , 200 , sizeof ( rtDW . bgieyqg154 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ozfvlojj1n
) , rtdwData , 0 , 201 , sizeof ( rtDW . ozfvlojj1n ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . fgsjlt3z00
) , rtdwData , 0 , 202 , sizeof ( rtDW . fgsjlt3z00 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . hbjqhzro5y
) , rtdwData , 0 , 203 , sizeof ( rtDW . hbjqhzro5y ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . os10rt4vp3
) , rtdwData , 0 , 204 , sizeof ( rtDW . os10rt4vp3 ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . noglx0ol2f
) , rtdwData , 0 , 205 , sizeof ( rtDW . noglx0ol2f ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . o1s050yt3g
) , rtdwData , 0 , 206 , sizeof ( rtDW . o1s050yt3g ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . o1qidfzosp
) , rtdwData , 0 , 207 , sizeof ( rtDW . o1qidfzosp ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . ngljbafwbt
) , rtdwData , 0 , 208 , sizeof ( rtDW . ngljbafwbt ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . iknrj0yq2v
) , rtdwData , 0 , 209 , sizeof ( rtDW . iknrj0yq2v ) ) ;
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtDW . l4uscn224x
) , rtdwData , 0 , 210 , sizeof ( rtDW . l4uscn224x ) ) ; }
mr_activeBalancing4_restoreDataFromMxArray ( ( void * ) & ( rtPrevZCX ) ,
ssDW , 0 , 2 , sizeof ( rtPrevZCX ) ) ; } mxArray *
mr_activeBalancing4_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 5 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 5 ] = { "S-Function" , "Scope" , "Scope" , "Scope" ,
"S-Function" , } ; static const char * blockPath [ 5 ] = {
"activeBalancing4/powergui/EquivalentModel1/State-Space" ,
"activeBalancing4/SOC %" , "activeBalancing4/Voltage" ,
"activeBalancing4/Scope" ,
"activeBalancing4/powergui/EquivalentModel1/State-Space" , } ; static const
int reason [ 5 ] = { 0 , 0 , 0 , 0 , 2 , } ; for ( subs [ 0 ] = 0 ; subs [ 0
] < 5 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset = mxCalcSingleSubscript
( data , 2 , subs ) ; mxSetCell ( data , offset , mxCreateString ( blockType
[ subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ; offset = mxCalcSingleSubscript ( data ,
2 , subs ) ; mxSetCell ( data , offset , mxCreateString ( blockPath [ subs [
0 ] ] ) ) ; subs [ 1 ] = 2 ; offset = mxCalcSingleSubscript ( data , 2 , subs
) ; mxSetCell ( data , offset , mxCreateDoubleScalar ( ( double ) reason [
subs [ 0 ] ] ) ) ; } } return data ; } void MdlInitializeSizes ( void ) {
ssSetNumContStates ( rtS , 39 ) ; ssSetNumPeriodicContStates ( rtS , 0 ) ;
ssSetNumY ( rtS , 0 ) ; ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough ( rtS
, 0 ) ; ssSetNumSampleTimes ( rtS , 9 ) ; ssSetNumBlocks ( rtS , 1050 ) ;
ssSetNumBlockIO ( rtS , 462 ) ; ssSetNumBlockParams ( rtS , 9190 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 , 0.0 ) ;
ssSetSampleTime ( rtS , 1 , 0.0 ) ; ssSetSampleTime ( rtS , 2 , - 2.0 ) ;
ssSetSampleTime ( rtS , 3 , - 2.0 ) ; ssSetSampleTime ( rtS , 4 , - 2.0 ) ;
ssSetSampleTime ( rtS , 5 , - 2.0 ) ; ssSetSampleTime ( rtS , 6 , - 2.0 ) ;
ssSetSampleTime ( rtS , 7 , - 2.0 ) ; ssSetSampleTime ( rtS , 8 , - 2.0 ) ;
ssSetOffsetTime ( rtS , 0 , 0.0 ) ; ssSetOffsetTime ( rtS , 1 , 1.0 ) ;
ssSetOffsetTime ( rtS , 2 , 0.0 ) ; ssSetOffsetTime ( rtS , 3 , 1.0 ) ;
ssSetOffsetTime ( rtS , 4 , 2.0 ) ; ssSetOffsetTime ( rtS , 5 , 3.0 ) ;
ssSetOffsetTime ( rtS , 6 , 4.0 ) ; ssSetOffsetTime ( rtS , 7 , 5.0 ) ;
ssSetOffsetTime ( rtS , 8 , 6.0 ) ; } void raccel_set_checksum ( ) {
ssSetChecksumVal ( rtS , 0 , 1104052515U ) ; ssSetChecksumVal ( rtS , 1 ,
4259764605U ) ; ssSetChecksumVal ( rtS , 2 , 10293365U ) ; ssSetChecksumVal (
rtS , 3 , 4107771868U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; ( void ) memset ( ( char * ) rtS , 0 ,
sizeof ( SimStruct ) ) ; ( void ) memset ( ( char * ) & mdlInfo , 0 , sizeof
( struct _ssMdlInfo ) ) ; ssSetMdlInfoPtr ( rtS , & mdlInfo ) ;
ssSetExecutionInfo ( rtS , executionInfo ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; } { real_T * x = ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ;
( void ) memset ( ( void * ) x , 0 , sizeof ( X ) ) ; } { void * dwork = (
void * ) & rtDW ; ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork ,
0 , sizeof ( DW ) ) ; } { static DataTypeTransInfo dtInfo ; ( void ) memset (
( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS
, & dtInfo ) ; dtInfo . numDataTypes = 27 ; dtInfo . dataTypeSizes = &
rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = & rtDataTypeNames [ 0 ] ;
dtInfo . BTransTable = & rtBTransTable ; dtInfo . PTransTable = &
rtPTransTable ; dtInfo . dataTypeInfoTable = rtDataTypeInfoTable ; }
activeBalancing4_InitializeDataMapInfo ( ) ; ssSetIsRapidAcceleratorActive (
rtS , true ) ; ssSetRootSS ( rtS , rtS ) ; ssSetVersion ( rtS ,
SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS , "activeBalancing4" ) ;
ssSetPath ( rtS , "activeBalancing4" ) ; ssSetTStart ( rtS , 0.0 ) ;
ssSetTFinal ( rtS , 200.0 ) ; { static RTWLogInfo rt_DataLoggingInfo ;
rt_DataLoggingInfo . loggingInterval = ( NULL ) ; ssSetRTWLogInfo ( rtS , &
rt_DataLoggingInfo ) ; } { { static int_T rt_LoggedStateWidths [ ] = { 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 7 } ; static int_T
rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 } ; static int_T rt_LoggedStateDimensions [ ] = { 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 7 } ; static boolean_T
rt_LoggedStateIsVarDims [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 } ; static BuiltInDTypeId rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE } ; static int_T rt_LoggedStateComplexSignals [ ] = { 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static
RTWPreprocessingFcnPtr rt_LoggingStatePreprocessingFcnPtrs [ ] = { ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) } ; static const char_T *
rt_LoggedStateLabels [ ] = { "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" } ; static const char_T * rt_LoggedStateBlockNames [ ] = {
"activeBalancing4/Battery1/Model/Current filter" ,
"activeBalancing4/Battery1/Model/int(i)" ,
"activeBalancing4/Battery1/Model/Exp/Integrator2" ,
"activeBalancing4/Battery1/Model/BAL" ,
"activeBalancing4/Battery2/Model/Current filter" ,
"activeBalancing4/Battery2/Model/int(i)" ,
"activeBalancing4/Battery2/Model/Exp/Integrator2" ,
"activeBalancing4/Battery2/Model/BAL" ,
"activeBalancing4/Battery3/Model/Current filter" ,
"activeBalancing4/Battery3/Model/int(i)" ,
"activeBalancing4/Battery3/Model/Exp/Integrator2" ,
"activeBalancing4/Battery3/Model/BAL" ,
"activeBalancing4/Battery4/Model/Current filter" ,
"activeBalancing4/Battery4/Model/int(i)" ,
"activeBalancing4/Battery4/Model/Exp/Integrator2" ,
"activeBalancing4/Battery4/Model/BAL" ,
"activeBalancing4/Battery5/Model/Current filter" ,
"activeBalancing4/Battery5/Model/int(i)" ,
"activeBalancing4/Battery5/Model/Exp/Integrator2" ,
"activeBalancing4/Battery5/Model/BAL" ,
"activeBalancing4/Battery6/Model/Current filter" ,
"activeBalancing4/Battery6/Model/int(i)" ,
"activeBalancing4/Battery6/Model/Exp/Integrator2" ,
"activeBalancing4/Battery6/Model/BAL" ,
"activeBalancing4/Battery7/Model/Current filter" ,
"activeBalancing4/Battery7/Model/int(i)" ,
"activeBalancing4/Battery7/Model/Exp/Integrator2" ,
"activeBalancing4/Battery7/Model/BAL" ,
"activeBalancing4/Battery8/Model/Current filter" ,
"activeBalancing4/Battery8/Model/int(i)" ,
"activeBalancing4/Battery8/Model/Exp/Integrator2" ,
"activeBalancing4/Battery8/Model/BAL" ,
"activeBalancing4/powergui/EquivalentModel1/State-Space" } ; static const
char_T * rt_LoggedStateNames [ ] = { "" , "" , "" , "" , "" , "" , "" , "" ,
"" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , ""
, "" , "" , "" , "" , "" , "" , "" , "" , "" } ; static boolean_T
rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 } ; static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert [ ] = { { 0
, SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } } ; static int_T rt_LoggedStateIdxList [ ] = { 0 , 1 ,
2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 ,
19 , 20 , 21 , 22 , 23 , 24 , 25 , 26 , 27 , 28 , 29 , 30 , 31 , 32 } ;
static RTWLogSignalInfo rt_LoggedStateSignalInfo = { 33 ,
rt_LoggedStateWidths , rt_LoggedStateNumDimensions , rt_LoggedStateDimensions
, rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 33 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . plb5id0v2x ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtX . lbkltw2njc ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtX . fzv1e1p3mc ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) & rtX . fg5c5z2vbx ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) & rtX . bx04s5qbio ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) & rtX . nxoiklb1cp ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) & rtX . b3n5hgntky ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) & rtX . cgxanjfmip ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) & rtX . lfvzsuhskj ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtX . bxy3w4qxj2 ;
rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) & rtX . chmdgjvbrk ;
rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtX . iximkvmpst ;
rt_LoggedStateSignalPtrs [ 12 ] = ( void * ) & rtX . esshhzn0st ;
rt_LoggedStateSignalPtrs [ 13 ] = ( void * ) & rtX . dqfnkbb0xq ;
rt_LoggedStateSignalPtrs [ 14 ] = ( void * ) & rtX . ohptd3ifop ;
rt_LoggedStateSignalPtrs [ 15 ] = ( void * ) & rtX . ik2jrqp3yy ;
rt_LoggedStateSignalPtrs [ 16 ] = ( void * ) & rtX . j5rh0u0prg ;
rt_LoggedStateSignalPtrs [ 17 ] = ( void * ) & rtX . cr4uxyxqlm ;
rt_LoggedStateSignalPtrs [ 18 ] = ( void * ) & rtX . f1hbi1sd1q ;
rt_LoggedStateSignalPtrs [ 19 ] = ( void * ) & rtX . kkgf3fitxr ;
rt_LoggedStateSignalPtrs [ 20 ] = ( void * ) & rtX . batnhulphm ;
rt_LoggedStateSignalPtrs [ 21 ] = ( void * ) & rtX . bnmkr55uji ;
rt_LoggedStateSignalPtrs [ 22 ] = ( void * ) & rtX . lulwdnmna3 ;
rt_LoggedStateSignalPtrs [ 23 ] = ( void * ) & rtX . opnxmo5ky2 ;
rt_LoggedStateSignalPtrs [ 24 ] = ( void * ) & rtX . kec03nv1yd ;
rt_LoggedStateSignalPtrs [ 25 ] = ( void * ) & rtX . ducd1mygi5 ;
rt_LoggedStateSignalPtrs [ 26 ] = ( void * ) & rtX . a2azuhp5qh ;
rt_LoggedStateSignalPtrs [ 27 ] = ( void * ) & rtX . c4c3igik4x ;
rt_LoggedStateSignalPtrs [ 28 ] = ( void * ) & rtX . jgg0wj1zhe ;
rt_LoggedStateSignalPtrs [ 29 ] = ( void * ) & rtX . mludnzmfko ;
rt_LoggedStateSignalPtrs [ 30 ] = ( void * ) & rtX . fhoa1aghtu ;
rt_LoggedStateSignalPtrs [ 31 ] = ( void * ) & rtX . kxckn4j1uq ;
rt_LoggedStateSignalPtrs [ 32 ] = ( void * ) & rtX . kyhu5rb2xj [ 0 ] ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssJacobianPerturbationBounds jacobianPerturbationBounds ;
ssSetJacobianPerturbationBounds ( rtS , & jacobianPerturbationBounds ) ; } {
static ssSolverInfo slvrInfo ; static struct _ssSFcnModelMethods3 mdlMethods3
; static struct _ssSFcnModelMethods2 mdlMethods2 ; static boolean_T
contStatesDisabled [ 39 ] ; static real_T absTol [ 39 ] = { 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 } ; static uint8_T absTolControl [
39 ] = { 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U
, 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U ,
0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U } ; static real_T
contStateJacPerturbBoundMinVec [ 39 ] ; static real_T
contStateJacPerturbBoundMaxVec [ 39 ] ; static uint8_T zcAttributes [ 197 ] =
{ ( ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) } ; static ssNonContDerivSigInfo nonContDerivSigInfo [ 119 ] =
{ { 1 * sizeof ( real_T ) , ( char * ) ( & rtB . ntwxdiuzqj ) , ( NULL ) } ,
{ 1 * sizeof ( real_T ) , ( char * ) ( & rtB . ftx2e5cidi ) , ( NULL ) } , {
1 * sizeof ( real_T ) , ( char * ) ( & rtB . ojiezq4id3 ) , ( NULL ) } , { 1
* sizeof ( real_T ) , ( char * ) ( & rtB . bzwbhh42ka ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . mqa03tpv1s ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . anc2sq3mml ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . h3c5qk01el ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . lodc4zy0kf ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . dhgr323ykq ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . hgecksjb2e ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . juxu3ykg0j ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . p35szvmsnl ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . d3g3fh43cq ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . ooktbhfuke ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . icxhoatkpy ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . hrjctsjkxd ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . n3fyjsfyy0 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . apkx5dx1qe ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . ksknuspzbv ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . acxnkfdwy1 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . h20jo3vqoy ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . jwcx5x3uww ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . hnmfvx1wci ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . luugfk3sgm ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . nvn1ehmkrx ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . codhkowftx ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . gw4ubpvz5m ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . otte1lhfee ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . fxfy52jqlw ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . nwe5vf4a0r ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . ipz4zr0egw ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . malsck44d3 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . i0wi0xfyww ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . evet21s24l ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . i0iborr1bn ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . edxzstui5p ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . kqgjchdcds ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . kds135p0hu ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . g415uib1wr ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . dr4em5z1io ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . jp2e2ut45b ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . eic4qlkhsy ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . cukuo2c3br ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . jo315eteaj ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . f0mgvc4qtv ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . g201quwjao ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . fk4jwk4iji ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . gjn3v2eu4k ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . agkl53gxjq ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . gdm5q3kphw ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . hpb3sjmuau ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . lf5xebyb1r ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . njfm3f2grf ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . besqhap1x0 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . erylo4qhmo ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . cp0who25g2 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . fdzcq5zjwp ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . iutvmolvr4 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . g1xvhnr3f5 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . cjfw5loxvr ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . i0lfhlq3lc ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . g0q2tc5i24 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . ovopkjg4yt ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . b44kx5qc5j ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . a5didxhdqz ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . iaqlnbjhf1 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . p2hxwe1zfu ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . mzyw4mhc11 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . ku5eexxo1r ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . inix0uapiw ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . cme3xzwgv0 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . oi4dn5ko50 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . aowksp0wla ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . chdzuypdzn ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . ame4svhan1 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . erpu4v3yeg ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . cbldlnrkrl ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . fytijtn1qm ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . b2gwj4fubz ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . czyx3zxlle ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . js2smttmtm ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . fawiawgoh5 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . a32d4y2ehp ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . hv51mxfmqn ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . arqmlzjrl4 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . atzrgflsgx ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . hgspzwdexg ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . fibreaa3ri ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . gk2b4uufar ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . eehigchrn4 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . pciyqbmld3 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . a2rrzly2nj ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . kslnv1njp2 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . f2df1n0xmz ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . eekpnfrbtv ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . dq2lwvzzrg ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . nvh2bwltbz ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . pmyyss4uxo ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . newl3oopdo ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . po53ioprtt ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . oc3uk0sbgh ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . czsttbwlhu ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . muvs2zmbde ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . gkqod2z0mi ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . jatbcbjee2 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . ojlbfd1f01 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . kq0scdgfjl ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . oj3yvv3y0h ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . hg3oaigjwk ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . hwjzbg4rx2 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . nj0k0lpkxt ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . jjriozwmwj ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . fq1y334rj2 ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . hu2ipo3lca ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . lvl2kjehdx ) , ( NULL ) } , { 1 *
sizeof ( boolean_T ) , ( char * ) ( & rtB . levrqdzmuw ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . p3jvn4gjjg ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . k0olm5ygz1 ) , ( NULL ) } , { 1 *
sizeof ( real_T ) , ( char * ) ( & rtB . fqm02mu2mr ) , ( NULL ) } } ; { int
i ; for ( i = 0 ; i < 39 ; ++ i ) { contStateJacPerturbBoundMinVec [ i ] = 0
; contStateJacPerturbBoundMaxVec [ i ] = rtGetInf ( ) ; } } ssSetSolverRelTol
( rtS , 0.001 ) ; ssSetStepSize ( rtS , 0.0 ) ; ssSetMinStepSize ( rtS , 0.0
) ; ssSetMaxNumMinSteps ( rtS , - 1 ) ; ssSetMinStepViolatedError ( rtS , 0 )
; ssSetMaxStepSize ( rtS , 4.0 ) ; ssSetSolverMaxOrder ( rtS , - 1 ) ;
ssSetSolverRefineFactor ( rtS , 1 ) ; ssSetOutputTimes ( rtS , ( NULL ) ) ;
ssSetNumOutputTimes ( rtS , 0 ) ; ssSetOutputTimesOnly ( rtS , 0 ) ;
ssSetOutputTimesIndex ( rtS , 0 ) ; ssSetZCCacheNeedsReset ( rtS , 1 ) ;
ssSetDerivCacheNeedsReset ( rtS , 0 ) ; ssSetNumNonContDerivSigInfos ( rtS ,
119 ) ; ssSetNonContDerivSigInfos ( rtS , nonContDerivSigInfo ) ;
ssSetSolverInfo ( rtS , & slvrInfo ) ; ssSetSolverName ( rtS , "ode23tb" ) ;
ssSetVariableStepSolver ( rtS , 1 ) ; ssSetSolverConsistencyChecking ( rtS ,
0 ) ; ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ;
ssSetSolverRobustResetMethod ( rtS , 0 ) ; ssSetAbsTolVector ( rtS , absTol )
; ssSetAbsTolControlVector ( rtS , absTolControl ) ;
ssSetSolverAbsTol_Obsolete ( rtS , absTol ) ;
ssSetSolverAbsTolControl_Obsolete ( rtS , absTolControl ) ;
ssSetJacobianPerturbationBoundsMinVec ( rtS , contStateJacPerturbBoundMinVec
) ; ssSetJacobianPerturbationBoundsMaxVec ( rtS ,
contStateJacPerturbBoundMaxVec ) ; ssSetSolverStateProjection ( rtS , 1 ) ; (
void ) memset ( ( void * ) & mdlMethods2 , 0 , sizeof ( mdlMethods2 ) ) ;
ssSetModelMethods2 ( rtS , & mdlMethods2 ) ; ( void ) memset ( ( void * ) &
mdlMethods3 , 0 , sizeof ( mdlMethods3 ) ) ; ssSetModelMethods3 ( rtS , &
mdlMethods3 ) ; ssSetModelProjection ( rtS , MdlProjection ) ;
ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelLogData ( rtS , rt_UpdateTXYLogVars ) ;
ssSetModelLogDataIfInInterval ( rtS , rt_UpdateTXXFYLogVars ) ;
ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetModelDerivatives ( rtS ,
MdlDerivatives ) ; ssSetSolverZcSignalAttrib ( rtS , zcAttributes ) ;
ssSetSolverNumZcSignals ( rtS , 197 ) ; ssSetModelZeroCrossings ( rtS ,
MdlZeroCrossings ) ; ssSetSolverConsecutiveZCsStepRelTol ( rtS ,
2.8421709430404007E-13 ) ; ssSetSolverMaxConsecutiveZCs ( rtS , 1000 ) ;
ssSetSolverConsecutiveZCsError ( rtS , 2 ) ; ssSetSolverMaskedZcDiagnostic (
rtS , 1 ) ; ssSetSolverIgnoredZcDiagnostic ( rtS , 1 ) ;
ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ;
ssSetSolverShapePreserveControl ( rtS , 2 ) ; ssSetTNextTid ( rtS , INT_MIN )
; ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 189 ) ; ssSetContStateDisabled ( rtS ,
contStatesDisabled ) ; ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ; } {
ZCSigState * zc = ( ZCSigState * ) & rtPrevZCX ; ssSetPrevZCSigState ( rtS ,
zc ) ; } { rtPrevZCX . fyojy5qztg = UNINITIALIZED_ZCSIG ; rtPrevZCX .
ckirjq4irs = UNINITIALIZED_ZCSIG ; rtPrevZCX . moi5ujt2m4 =
UNINITIALIZED_ZCSIG ; rtPrevZCX . f03tkcmhr0 = UNINITIALIZED_ZCSIG ;
rtPrevZCX . lunhr2xxb0 = UNINITIALIZED_ZCSIG ; rtPrevZCX . kty1ao0csf =
UNINITIALIZED_ZCSIG ; rtPrevZCX . klp5c5oug5 = UNINITIALIZED_ZCSIG ;
rtPrevZCX . p2zcekh3xh = UNINITIALIZED_ZCSIG ; } ssSetChecksumVal ( rtS , 0 ,
1104052515U ) ; ssSetChecksumVal ( rtS , 1 , 4259764605U ) ; ssSetChecksumVal
( rtS , 2 , 10293365U ) ; ssSetChecksumVal ( rtS , 3 , 4107771868U ) ; {
static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE ; static
RTWExtModeInfo rt_ExtModeInfo ; static const sysRanDType * systemRan [ 94 ] ;
gblRTWExtModeInfo = & rt_ExtModeInfo ; ssSetRTWExtModeInfo ( rtS , &
rt_ExtModeInfo ) ; rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo ,
systemRan ) ; systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = &
rtAlwaysEnabled ; systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = &
rtAlwaysEnabled ; systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = &
rtAlwaysEnabled ; systemRan [ 6 ] = & rtAlwaysEnabled ; systemRan [ 7 ] = &
rtAlwaysEnabled ; systemRan [ 8 ] = & rtAlwaysEnabled ; systemRan [ 9 ] = &
rtAlwaysEnabled ; systemRan [ 10 ] = & rtAlwaysEnabled ; systemRan [ 11 ] = &
rtAlwaysEnabled ; systemRan [ 12 ] = & rtAlwaysEnabled ; systemRan [ 13 ] = &
rtAlwaysEnabled ; systemRan [ 14 ] = & rtAlwaysEnabled ; systemRan [ 15 ] = &
rtAlwaysEnabled ; systemRan [ 16 ] = & rtAlwaysEnabled ; systemRan [ 17 ] = &
rtAlwaysEnabled ; systemRan [ 18 ] = & rtAlwaysEnabled ; systemRan [ 19 ] = &
rtAlwaysEnabled ; systemRan [ 20 ] = & rtAlwaysEnabled ; systemRan [ 21 ] = &
rtAlwaysEnabled ; systemRan [ 22 ] = & rtAlwaysEnabled ; systemRan [ 23 ] = &
rtAlwaysEnabled ; systemRan [ 24 ] = & rtAlwaysEnabled ; systemRan [ 25 ] = &
rtAlwaysEnabled ; systemRan [ 26 ] = & rtAlwaysEnabled ; systemRan [ 27 ] = &
rtAlwaysEnabled ; systemRan [ 28 ] = & rtAlwaysEnabled ; systemRan [ 29 ] = &
rtAlwaysEnabled ; systemRan [ 30 ] = & rtAlwaysEnabled ; systemRan [ 31 ] = &
rtAlwaysEnabled ; systemRan [ 32 ] = & rtAlwaysEnabled ; systemRan [ 33 ] = &
rtAlwaysEnabled ; systemRan [ 34 ] = & rtAlwaysEnabled ; systemRan [ 35 ] = &
rtAlwaysEnabled ; systemRan [ 36 ] = & rtAlwaysEnabled ; systemRan [ 37 ] = &
rtAlwaysEnabled ; systemRan [ 38 ] = & rtAlwaysEnabled ; systemRan [ 39 ] = &
rtAlwaysEnabled ; systemRan [ 40 ] = & rtAlwaysEnabled ; systemRan [ 41 ] = &
rtAlwaysEnabled ; systemRan [ 42 ] = & rtAlwaysEnabled ; systemRan [ 43 ] = &
rtAlwaysEnabled ; systemRan [ 44 ] = & rtAlwaysEnabled ; systemRan [ 45 ] = &
rtAlwaysEnabled ; systemRan [ 46 ] = & rtAlwaysEnabled ; systemRan [ 47 ] = &
rtAlwaysEnabled ; systemRan [ 48 ] = & rtAlwaysEnabled ; systemRan [ 49 ] = &
rtAlwaysEnabled ; systemRan [ 50 ] = & rtAlwaysEnabled ; systemRan [ 51 ] = &
rtAlwaysEnabled ; systemRan [ 52 ] = & rtAlwaysEnabled ; systemRan [ 53 ] = &
rtAlwaysEnabled ; systemRan [ 54 ] = & rtAlwaysEnabled ; systemRan [ 55 ] = &
rtAlwaysEnabled ; systemRan [ 56 ] = & rtAlwaysEnabled ; systemRan [ 57 ] = &
rtAlwaysEnabled ; systemRan [ 58 ] = & rtAlwaysEnabled ; systemRan [ 59 ] = &
rtAlwaysEnabled ; systemRan [ 60 ] = & rtAlwaysEnabled ; systemRan [ 61 ] = &
rtAlwaysEnabled ; systemRan [ 62 ] = & rtAlwaysEnabled ; systemRan [ 63 ] = &
rtAlwaysEnabled ; systemRan [ 64 ] = & rtAlwaysEnabled ; systemRan [ 65 ] = &
rtAlwaysEnabled ; systemRan [ 66 ] = & rtAlwaysEnabled ; systemRan [ 67 ] = &
rtAlwaysEnabled ; systemRan [ 68 ] = & rtAlwaysEnabled ; systemRan [ 69 ] = &
rtAlwaysEnabled ; systemRan [ 70 ] = & rtAlwaysEnabled ; systemRan [ 71 ] = &
rtAlwaysEnabled ; systemRan [ 72 ] = & rtAlwaysEnabled ; systemRan [ 73 ] = &
rtAlwaysEnabled ; systemRan [ 74 ] = & rtAlwaysEnabled ; systemRan [ 75 ] = &
rtAlwaysEnabled ; systemRan [ 76 ] = & rtAlwaysEnabled ; systemRan [ 77 ] = &
rtAlwaysEnabled ; systemRan [ 78 ] = & rtAlwaysEnabled ; systemRan [ 79 ] = &
rtAlwaysEnabled ; systemRan [ 80 ] = & rtAlwaysEnabled ; systemRan [ 81 ] = &
rtAlwaysEnabled ; systemRan [ 82 ] = & rtAlwaysEnabled ; systemRan [ 83 ] = &
rtAlwaysEnabled ; systemRan [ 84 ] = & rtAlwaysEnabled ; systemRan [ 85 ] = &
rtAlwaysEnabled ; systemRan [ 86 ] = & rtAlwaysEnabled ; systemRan [ 87 ] = &
rtAlwaysEnabled ; systemRan [ 88 ] = & rtAlwaysEnabled ; systemRan [ 89 ] = &
rtAlwaysEnabled ; systemRan [ 90 ] = & rtAlwaysEnabled ; systemRan [ 91 ] = &
rtAlwaysEnabled ; systemRan [ 92 ] = & rtAlwaysEnabled ; systemRan [ 93 ] = &
rtAlwaysEnabled ; rteiSetModelMappingInfoPtr ( ssGetRTWExtModeInfo ( rtS ) ,
& ssGetModelMappingInfo ( rtS ) ) ; rteiSetChecksumsPtr ( ssGetRTWExtModeInfo
( rtS ) , ssGetChecksums ( rtS ) ) ; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS
) , ssGetTPtr ( rtS ) ) ; } slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_activeBalancing4_GetSimStateDisallowedBlocks ) ;
slsaGetWorkFcnForSimTargetOP ( rtS , mr_activeBalancing4_GetDWork ) ;
slsaSetWorkFcnForSimTargetOP ( rtS , mr_activeBalancing4_SetDWork ) ; rtP .
inti_LowerSat = rtMinusInf ; rtP . Saturation_LowerSat = rtMinusInf ; rtP .
inti_LowerSat_lz3gh0icex = rtMinusInf ; rtP . Saturation_LowerSat_kwi433xk5g
= rtMinusInf ; rtP . inti_LowerSat_cwekkzbyq1 = rtMinusInf ; rtP .
Saturation_LowerSat_o0i20janpw = rtMinusInf ; rtP . inti_LowerSat_nb1wwuftgl
= rtMinusInf ; rtP . Saturation_LowerSat_g1ovkjgj1x = rtMinusInf ; rtP .
inti_LowerSat_hzpmw3xl5s = rtMinusInf ; rtP . Saturation_LowerSat_haspwmkdbs
= rtMinusInf ; rtP . inti_LowerSat_l4lrtlmq4a = rtMinusInf ; rtP .
Saturation_LowerSat_hlakhjokuc = rtMinusInf ; rtP . inti_LowerSat_c2pdzacpit
= rtMinusInf ; rtP . Saturation_LowerSat_btlbcqipab = rtMinusInf ; rtP .
inti_LowerSat_b5bkhbogxv = rtMinusInf ; rtP . Saturation_LowerSat_gq5b2q5hog
= rtMinusInf ; rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if (
ssGetErrorStatus ( rtS ) ) { return rtS ; } ssSetNumSFunctions ( rtS , 1 ) ;
{ static SimStruct childSFunctions [ 1 ] ; static SimStruct *
childSFunctionPtrs [ 1 ] ; ( void ) memset ( ( void * ) & childSFunctions [ 0
] , 0 , sizeof ( childSFunctions ) ) ; ssSetSFunctions ( rtS , &
childSFunctionPtrs [ 0 ] ) ; ssSetSFunction ( rtS , 0 , & childSFunctions [ 0
] ) ; { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; static time_T
sfcnPeriod [ 1 ] ; static time_T sfcnOffset [ 1 ] ; static int_T sfcnTsMap [
1 ] ; ( void ) memset ( ( void * ) sfcnPeriod , 0 , sizeof ( time_T ) * 1 ) ;
( void ) memset ( ( void * ) sfcnOffset , 0 , sizeof ( time_T ) * 1 ) ;
ssSetSampleTimePtr ( rts , & sfcnPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rts ,
& sfcnOffset [ 0 ] ) ; ssSetSampleTimeTaskIDPtr ( rts , sfcnTsMap ) ; {
static struct _ssBlkInfo2 _blkInfo2 ; struct _ssBlkInfo2 * blkInfo2 = &
_blkInfo2 ; ssSetBlkInfo2Ptr ( rts , blkInfo2 ) ; } { static struct
_ssPortInfo2 _portInfo2 ; struct _ssPortInfo2 * portInfo2 = & _portInfo2 ;
_ssSetBlkInfo2PortInfo2Ptr ( rts , portInfo2 ) ; } ssSetMdlInfoPtr ( rts ,
ssGetMdlInfoPtr ( rtS ) ) ; { static struct _ssSFcnModelMethods2 methods2 ;
ssSetModelMethods2 ( rts , & methods2 ) ; } { static struct
_ssSFcnModelMethods3 methods3 ; ssSetModelMethods3 ( rts , & methods3 ) ; } {
static struct _ssSFcnModelMethods4 methods4 ; ssSetModelMethods4 ( rts , &
methods4 ) ; } { static struct _ssStatesInfo2 statesInfo2 ; static
ssPeriodicStatesInfo periodicStatesInfo ; static ssJacobianPerturbationBounds
jacPerturbationBounds ; ssSetStatesInfo2 ( rts , & statesInfo2 ) ;
ssSetPeriodicStatesInfo ( rts , & periodicStatesInfo ) ;
ssSetJacobianPerturbationBounds ( rts , & jacPerturbationBounds ) ;
ssSetAbsTolVector ( rts , ssGetAbsTolVector ( rtS ) + 32 ) ;
ssSetAbsTolControlVector ( rts , ssGetAbsTolControlVector ( rtS ) + 32 ) ; }
{ static struct _ssPortInputs inputPortInfo [ 2 ] ; _ssSetNumInputPorts ( rts
, 2 ) ; ssSetPortInfoForInputs ( rts , & inputPortInfo [ 0 ] ) ; { static
struct _ssInPortUnit inputPortUnits [ 2 ] ; _ssSetPortInfo2ForInputUnits (
rts , & inputPortUnits [ 0 ] ) ; } ssSetInputPortUnit ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 1 , 0 ) ; { static struct _ssInPortCoSimAttribute
inputPortCoSimAttribute [ 2 ] ; _ssSetPortInfo2ForInputCoSimAttribute ( rts ,
& inputPortCoSimAttribute [ 0 ] ) ; } ssSetInputPortIsContinuousQuantity (
rts , 0 , 0 ) ; ssSetInputPortIsContinuousQuantity ( rts , 1 , 0 ) ; { static
real_T const * sfcnUPtrs [ 8 ] ; sfcnUPtrs [ 0 ] = & rtB . nula5qzpsy ;
sfcnUPtrs [ 1 ] = & rtB . m5jzl0c3ow ; sfcnUPtrs [ 2 ] = & rtB . i5uns4zs23 ;
sfcnUPtrs [ 3 ] = & rtB . ebcldbyulo ; sfcnUPtrs [ 4 ] = & rtB . owgcqoig0n ;
sfcnUPtrs [ 5 ] = & rtB . lnjnmhfbjh ; sfcnUPtrs [ 6 ] = & rtB . bjlklhbtye ;
sfcnUPtrs [ 7 ] = & rtB . a2ssj2eqbk ; ssSetInputPortSignalPtrs ( rts , 0 , (
InputPtrsType ) & sfcnUPtrs [ 0 ] ) ; _ssSetInputPortNumDimensions ( rts , 0
, 1 ) ; ssSetInputPortWidth ( rts , 0 , 8 ) ; } { static real_T const *
sfcnUPtrs [ 28 ] ; sfcnUPtrs [ 0 ] = & rtB . anc2sq3mml ; sfcnUPtrs [ 1 ] = &
rtB . h3c5qk01el ; sfcnUPtrs [ 2 ] = ( ( const real_T * ) &
activeBalancing4_RGND ) ; sfcnUPtrs [ 3 ] = ( ( const real_T * ) &
activeBalancing4_RGND ) ; sfcnUPtrs [ 4 ] = & rtB . ojiezq4id3 ; sfcnUPtrs [
5 ] = ( ( const real_T * ) & activeBalancing4_RGND ) ; sfcnUPtrs [ 6 ] = &
rtB . ftx2e5cidi ; sfcnUPtrs [ 7 ] = ( ( const real_T * ) &
activeBalancing4_RGND ) ; sfcnUPtrs [ 8 ] = & rtB . ntwxdiuzqj ; sfcnUPtrs [
9 ] = ( ( const real_T * ) & activeBalancing4_RGND ) ; sfcnUPtrs [ 10 ] = &
rtB . bzwbhh42ka ; sfcnUPtrs [ 11 ] = & rtB . mqa03tpv1s ; sfcnUPtrs [ 12 ] =
( ( const real_T * ) & activeBalancing4_RGND ) ; sfcnUPtrs [ 13 ] = ( ( const
real_T * ) & activeBalancing4_RGND ) ; sfcnUPtrs [ 14 ] = & rtB . bcww4isw4r
; sfcnUPtrs [ 15 ] = & rtB . b5epvnjqmi ; sfcnUPtrs [ 16 ] = & rtB .
lcbjcuvvbt ; sfcnUPtrs [ 17 ] = & rtB . jn3jigbm4f ; sfcnUPtrs [ 18 ] = & rtB
. o1rf1cikyg ; sfcnUPtrs [ 19 ] = & rtB . kg5yvb1wjz ; sfcnUPtrs [ 20 ] = &
rtB . da4ug2cudb ; sfcnUPtrs [ 21 ] = & rtB . ezyjeovbvi ; sfcnUPtrs [ 22 ] =
& rtB . nahk3q2lwf ; sfcnUPtrs [ 23 ] = & rtB . nz5qxvxtdb ; sfcnUPtrs [ 24 ]
= & rtB . hwoezaq2mj ; sfcnUPtrs [ 25 ] = & rtB . iq51ppixmq ; sfcnUPtrs [ 26
] = & rtB . bhhrjm3haf ; sfcnUPtrs [ 27 ] = & rtB . acuoed4qri ;
ssSetInputPortSignalPtrs ( rts , 1 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 1 , 1 ) ; ssSetInputPortWidth ( rts , 1
, 28 ) ; } } { static struct _ssPortOutputs outputPortInfo [ 2 ] ;
ssSetPortInfoForOutputs ( rts , & outputPortInfo [ 0 ] ) ;
_ssSetNumOutputPorts ( rts , 2 ) ; { static struct _ssOutPortUnit
outputPortUnits [ 2 ] ; _ssSetPortInfo2ForOutputUnits ( rts , &
outputPortUnits [ 0 ] ) ; } ssSetOutputPortUnit ( rts , 0 , 0 ) ;
ssSetOutputPortUnit ( rts , 1 , 0 ) ; { static struct
_ssOutPortCoSimAttribute outputPortCoSimAttribute [ 2 ] ;
_ssSetPortInfo2ForOutputCoSimAttribute ( rts , & outputPortCoSimAttribute [ 0
] ) ; } ssSetOutputPortIsContinuousQuantity ( rts , 0 , 0 ) ;
ssSetOutputPortIsContinuousQuantity ( rts , 1 , 0 ) ; {
_ssSetOutputPortNumDimensions ( rts , 0 , 1 ) ; ssSetOutputPortWidth ( rts ,
0 , 10 ) ; ssSetOutputPortSignal ( rts , 0 , ( ( real_T * ) rtB . lo01p0mfxt
) ) ; } { _ssSetOutputPortNumDimensions ( rts , 1 , 1 ) ;
ssSetOutputPortWidth ( rts , 1 , 56 ) ; ssSetOutputPortSignal ( rts , 1 , ( (
real_T * ) rtB . jqon53xqhn ) ) ; } } ssSetContStates ( rts , & rtX .
kyhu5rb2xj [ 0 ] ) ; ssSetContStateDisabled ( rts , & ( ( XDis * )
ssGetContStateDisabled ( rtS ) ) -> kyhu5rb2xj [ 0 ] ) ; { real_T * minVec =
& ( ( CXPtMin * ) ssGetJacobianPerturbationBoundsMinVec ( rtS ) ) ->
kyhu5rb2xj [ 0 ] ; real_T * maxVec = & ( ( CXPtMax * )
ssGetJacobianPerturbationBoundsMaxVec ( rtS ) ) -> kyhu5rb2xj [ 0 ] ;
ssSetJacobianPerturbationBoundsMinVec ( rts , minVec ) ;
ssSetJacobianPerturbationBoundsMaxVec ( rts , maxVec ) ; } ssSetModelName (
rts , "State-Space" ) ; ssSetPath ( rts ,
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) ; if (
ssGetRTModel ( rtS ) == ( NULL ) ) { ssSetParentSS ( rts , rtS ) ;
ssSetRootSS ( rts , ssGetRootSS ( rtS ) ) ; } else { ssSetRTModel ( rts ,
ssGetRTModel ( rtS ) ) ; ssSetParentSS ( rts , ( NULL ) ) ; ssSetRootSS ( rts
, rts ) ; } ssSetVersion ( rts , SIMSTRUCT_VERSION_LEVEL2 ) ; { static
mxArray * sfcnParams [ 10 ] ; ssSetSFcnParamsCount ( rts , 10 ) ;
ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ; ssSetSFcnParam ( rts , 0 ,
( mxArray * ) rtP . StateSpace_P1_Size ) ; ssSetSFcnParam ( rts , 1 , (
mxArray * ) rtP . StateSpace_P2_Size ) ; ssSetSFcnParam ( rts , 2 , ( mxArray
* ) rtP . StateSpace_P3_Size ) ; ssSetSFcnParam ( rts , 3 , ( mxArray * ) rtP
. StateSpace_P4_Size ) ; ssSetSFcnParam ( rts , 4 , ( mxArray * ) rtP .
StateSpace_P5_Size ) ; ssSetSFcnParam ( rts , 5 , ( mxArray * ) rtP .
StateSpace_P6_Size ) ; ssSetSFcnParam ( rts , 6 , ( mxArray * ) rtP .
StateSpace_P7_Size ) ; ssSetSFcnParam ( rts , 7 , ( mxArray * ) rtP .
StateSpace_P8_Size ) ; ssSetSFcnParam ( rts , 8 , ( mxArray * ) rtP .
StateSpace_P9_Size ) ; ssSetSFcnParam ( rts , 9 , ( mxArray * ) rtP .
StateSpace_P10_Size ) ; } ssSetRWork ( rts , ( real_T * ) & rtDW . bq5fblkvcd
[ 0 ] ) ; ssSetIWork ( rts , ( int_T * ) & rtDW . lvyvopbaxf [ 0 ] ) ;
ssSetPWork ( rts , ( void * * ) & rtDW . msq0lqyul4 [ 0 ] ) ; { static struct
_ssDWorkRecord dWorkRecord [ 4 ] ; static struct _ssDWorkAuxRecord
dWorkAuxRecord [ 4 ] ; ssSetSFcnDWork ( rts , dWorkRecord ) ;
ssSetSFcnDWorkAux ( rts , dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 4 ) ;
ssSetDWorkWidth ( rts , 0 , 29 ) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER
) ; ssSetDWorkComplexSignal ( rts , 0 , 0 ) ; ssSetDWork ( rts , 0 , & rtDW .
hnnabs4ndc [ 0 ] ) ; ssSetDWorkWidth ( rts , 1 , 2 ) ; ssSetDWorkDataType (
rts , 1 , SS_DOUBLE ) ; ssSetDWorkComplexSignal ( rts , 1 , 0 ) ; ssSetDWork
( rts , 1 , & rtDW . bq5fblkvcd [ 0 ] ) ; ssSetDWorkWidth ( rts , 2 , 23 ) ;
ssSetDWorkDataType ( rts , 2 , SS_INTEGER ) ; ssSetDWorkComplexSignal ( rts ,
2 , 0 ) ; ssSetDWork ( rts , 2 , & rtDW . lvyvopbaxf [ 0 ] ) ;
ssSetDWorkWidth ( rts , 3 , 22 ) ; ssSetDWorkDataType ( rts , 3 , SS_POINTER
) ; ssSetDWorkComplexSignal ( rts , 3 , 0 ) ; ssSetDWork ( rts , 3 , & rtDW .
msq0lqyul4 [ 0 ] ) ; } ssSetModeVector ( rts , ( int_T * ) & rtDW .
hnnabs4ndc [ 0 ] ) ; sfun_spid_contc ( rts ) ; sfcnInitializeSizes ( rts ) ;
sfcnInitializeSampleTimes ( rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ;
ssSetOffsetTime ( rts , 0 , 0.0 ) ; sfcnTsMap [ 0 ] = 0 ;
ssSetNumNonsampledZCs ( rts , 29 ) ; _ssSetInputPortConnected ( rts , 0 , 1 )
; _ssSetInputPortConnected ( rts , 1 , 1 ) ; _ssSetOutputPortConnected ( rts
, 0 , 1 ) ; _ssSetOutputPortConnected ( rts , 1 , 1 ) ;
_ssSetOutputPortBeingMerged ( rts , 0 , 0 ) ; _ssSetOutputPortBeingMerged (
rts , 1 , 0 ) ; ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ;
ssSetInputPortBufferDstPort ( rts , 1 , - 1 ) ; } } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 9 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID9 ( tid ) ; }
