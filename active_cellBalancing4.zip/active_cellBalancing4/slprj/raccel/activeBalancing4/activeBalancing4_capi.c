#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "activeBalancing4_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#ifndef SS_INT64
#define SS_INT64  25
#endif
#ifndef SS_UINT64
#define SS_UINT64  26
#endif
#else
#include "builtin_typeid_types.h"
#include "activeBalancing4.h"
#include "activeBalancing4_capi.h"
#include "activeBalancing4_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 65 , TARGET_STRING
( "activeBalancing4/Fuzzy Logic  Controller 1234_5678" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 0 } , { 1 , 69 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 12_34" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 2 , 73 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 1_2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 3 , 77 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 3_4" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 4 , 81 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 56_78" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 5 , 85 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 5_6" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 6 , 89 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 7_8" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 7 , 93 , TARGET_STRING (
"activeBalancing4/MATLAB Function" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 ,
0 } , { 8 , 93 , TARGET_STRING ( "activeBalancing4/MATLAB Function" ) ,
TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , { 9 , 93 , TARGET_STRING (
"activeBalancing4/MATLAB Function" ) , TARGET_STRING ( "" ) , 2 , 0 , 0 , 0 ,
0 } , { 10 , 0 , TARGET_STRING ( "activeBalancing4/dSOC Cell1234_5678" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 11 , 0 , TARGET_STRING (
"activeBalancing4/dSOC Cell12_34" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 ,
0 } , { 12 , 0 , TARGET_STRING ( "activeBalancing4/dSOC Cell1_2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 13 , 0 , TARGET_STRING (
"activeBalancing4/dSOC Cell3_4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0
} , { 14 , 0 , TARGET_STRING ( "activeBalancing4/dSOC Cell56_78" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 15 , 0 , TARGET_STRING (
"activeBalancing4/dSOC Cell5_6" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0
} , { 16 , 0 , TARGET_STRING ( "activeBalancing4/dSOC Cell7_8" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 17 , 0 , TARGET_STRING (
"activeBalancing4/Add11" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , {
18 , 0 , TARGET_STRING ( "activeBalancing4/Add13" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 19 , 0 , TARGET_STRING ( "activeBalancing4/Add4" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 20 , 0 , TARGET_STRING (
"activeBalancing4/Add6" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 21
, 0 , TARGET_STRING ( "activeBalancing4/Add7" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 22 , 0 , TARGET_STRING ( "activeBalancing4/Add9" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 23 , 0 , TARGET_STRING (
"activeBalancing4/Switch" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , {
24 , 0 , TARGET_STRING ( "activeBalancing4/Switch1" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 25 , 0 , TARGET_STRING ( "activeBalancing4/Switch2"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 26 , 0 , TARGET_STRING (
"activeBalancing4/Switch3" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , {
27 , 0 , TARGET_STRING ( "activeBalancing4/Switch4" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 28 , 0 , TARGET_STRING ( "activeBalancing4/Switch5"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 29 , 0 , TARGET_STRING (
"activeBalancing4/Switch6" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , {
30 , 0 , TARGET_STRING ( "activeBalancing4/Switch7" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 31 , 0 , TARGET_STRING ( "activeBalancing4/Switch8"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 32 , 0 , TARGET_STRING (
"activeBalancing4/Switch9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , {
33 , 0 , TARGET_STRING (
"activeBalancing4/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 34 , 65 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 1234_5678/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 35 , 67 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 1234_5678/Evaluate Rule Consequents"
) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 36 , 69 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 12_34/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 37 , 71 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 12_34/Evaluate Rule Consequents" )
, TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 38 , 73 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 1_2/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 39 , 77 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 3_4/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 40 , 79 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 3_4/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 41 , 81 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 56_78/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 42 , 83 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 56_78/Evaluate Rule Consequents" )
, TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 43 , 85 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 5_6/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 44 , 87 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 5_6/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 45 , 89 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 7_8/Defuzzify Outputs" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 46 , 91 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 7_8/Evaluate Rule Consequents" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 47 , 0 , TARGET_STRING (
"activeBalancing4/PWM/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 48 , 0 , TARGET_STRING (
"activeBalancing4/PWM1/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 49 , 0 , TARGET_STRING (
"activeBalancing4/PWM3/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 50 , 0 , TARGET_STRING (
"activeBalancing4/PWM5/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 51 , 0 , TARGET_STRING (
"activeBalancing4/PWM6/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 52 , 0 , TARGET_STRING (
"activeBalancing4/PWM7/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 53 , 0 , TARGET_STRING (
"activeBalancing4/PWM8/Variable Pulse Generator" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 54 , 0 , TARGET_STRING (
"activeBalancing4/Voltage Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 55 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 56 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 57 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 58 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 59 , 0 , TARGET_STRING ( "activeBalancing4/Battery1/Model/Fcn6" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 60 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 61 , 0 , TARGET_STRING ( "activeBalancing4/Battery1/Model/Gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 62 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 63 , 0 , TARGET_STRING ( "activeBalancing4/Battery1/Model/R1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 64 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 65 , 0 , TARGET_STRING ( "activeBalancing4/Battery1/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 66 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 67 , 0 , TARGET_STRING ( "activeBalancing4/Battery1/Model/int(i)" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 68 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 69 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 70 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 71 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 72 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 73 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 74 , 0 , TARGET_STRING ( "activeBalancing4/Battery1/Model/Add3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 75 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 76 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 77 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 78 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 79 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 80 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 81 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 82 , 0 , TARGET_STRING ( "activeBalancing4/Battery2/Model/Fcn6" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 83 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 84 , 0 , TARGET_STRING ( "activeBalancing4/Battery2/Model/Gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 85 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 86 , 0 , TARGET_STRING ( "activeBalancing4/Battery2/Model/R1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 87 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 88 , 0 , TARGET_STRING ( "activeBalancing4/Battery2/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 89 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 90 , 0 , TARGET_STRING ( "activeBalancing4/Battery2/Model/int(i)" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 91 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 92 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 93 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 94 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 95 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 96 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 97 , 0 , TARGET_STRING ( "activeBalancing4/Battery2/Model/Add3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 98 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 99 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 100 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 101 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 102 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 103 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 104 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 105 , 0 , TARGET_STRING ( "activeBalancing4/Battery3/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 106 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 107 , 0 , TARGET_STRING ( "activeBalancing4/Battery3/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 108 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 109 , 0 , TARGET_STRING ( "activeBalancing4/Battery3/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 110 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 111 , 0 , TARGET_STRING ( "activeBalancing4/Battery3/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 112 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 113 , 0 , TARGET_STRING ( "activeBalancing4/Battery3/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 114 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 115 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 116 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 117 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 118 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 119 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 120 , 0 , TARGET_STRING ( "activeBalancing4/Battery3/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 121 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 122 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 123 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 124 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 125 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 126 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 127 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 128 , 0 , TARGET_STRING ( "activeBalancing4/Battery4/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 129 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 130 , 0 , TARGET_STRING ( "activeBalancing4/Battery4/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 131 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 132 , 0 , TARGET_STRING ( "activeBalancing4/Battery4/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 133 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 134 , 0 , TARGET_STRING ( "activeBalancing4/Battery4/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 135 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 136 , 0 , TARGET_STRING ( "activeBalancing4/Battery4/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 137 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 138 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 139 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 140 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 141 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 142 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 143 , 0 , TARGET_STRING ( "activeBalancing4/Battery4/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 144 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 145 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 146 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 147 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 148 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 149 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 150 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 151 , 0 , TARGET_STRING ( "activeBalancing4/Battery5/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 152 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 153 , 0 , TARGET_STRING ( "activeBalancing4/Battery5/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 154 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 155 , 0 , TARGET_STRING ( "activeBalancing4/Battery5/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 156 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 157 , 0 , TARGET_STRING ( "activeBalancing4/Battery5/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 158 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 159 , 0 , TARGET_STRING ( "activeBalancing4/Battery5/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 160 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 161 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 162 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 163 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 164 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 165 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 166 , 0 , TARGET_STRING ( "activeBalancing4/Battery5/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 167 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 168 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 169 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 170 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 171 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 172 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 173 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 174 , 0 , TARGET_STRING ( "activeBalancing4/Battery6/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 175 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 176 , 0 , TARGET_STRING ( "activeBalancing4/Battery6/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 177 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 178 , 0 , TARGET_STRING ( "activeBalancing4/Battery6/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 179 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 180 , 0 , TARGET_STRING ( "activeBalancing4/Battery6/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 181 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 182 , 0 , TARGET_STRING ( "activeBalancing4/Battery6/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 183 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 184 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 185 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 186 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 187 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 188 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 189 , 0 , TARGET_STRING ( "activeBalancing4/Battery6/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 190 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 191 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 192 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 193 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 194 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 195 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 196 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 197 , 0 , TARGET_STRING ( "activeBalancing4/Battery7/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 198 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 199 , 0 , TARGET_STRING ( "activeBalancing4/Battery7/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 200 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 201 , 0 , TARGET_STRING ( "activeBalancing4/Battery7/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 202 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 203 , 0 , TARGET_STRING ( "activeBalancing4/Battery7/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 204 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 205 , 0 , TARGET_STRING ( "activeBalancing4/Battery7/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 206 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 207 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 208 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 209 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 210 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 211 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 212 , 0 , TARGET_STRING ( "activeBalancing4/Battery7/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 213 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 214 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 215 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 216 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 217 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 218 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 219 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 220 , 0 , TARGET_STRING ( "activeBalancing4/Battery8/Model/Fcn6"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 221 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 222 , 0 , TARGET_STRING ( "activeBalancing4/Battery8/Model/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 223 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 224 , 0 , TARGET_STRING ( "activeBalancing4/Battery8/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 225 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 226 , 0 , TARGET_STRING ( "activeBalancing4/Battery8/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 227 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 228 , 0 , TARGET_STRING ( "activeBalancing4/Battery8/Model/int(i)"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 229 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 230 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 231 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 232 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 233 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Add" ) , TARGET_STRING ( "Voltage (V)" ) , 0
, 0 , 0 , 0 , 0 } , { 234 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 235 , 0 , TARGET_STRING ( "activeBalancing4/Battery8/Model/Add3"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 236 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 237 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 238 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 239 , 0 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"" ) , 0 , 0 , 2 , 0 , 0 } , { 240 , 0 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"" ) , 1 , 0 , 3 , 0 , 0 } , { 241 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 242 , 2 , TARGET_STRING (
"activeBalancing4/Battery1/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 243 , 4 , TARGET_STRING (
"activeBalancing4/Battery1/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 244 , 3 , TARGET_STRING (
"activeBalancing4/Battery1/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 245 , 1 , TARGET_STRING (
"activeBalancing4/Battery1/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 246 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 247 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 248 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 249 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 250 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 251 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 252 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 253 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 254 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 255 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 256 , 6 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 257 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 258 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 259 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 260 , 7 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 261 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 262 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 263 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 264 , 8 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 265 , 0 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 266 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 267 , 10 , TARGET_STRING (
"activeBalancing4/Battery2/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 268 , 12 , TARGET_STRING (
"activeBalancing4/Battery2/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 269 , 11 , TARGET_STRING (
"activeBalancing4/Battery2/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 270 , 9 , TARGET_STRING (
"activeBalancing4/Battery2/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 271 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 272 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 273 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 274 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 275 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 276 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 277 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 278 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 279 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 280 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 281 , 14 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 282 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 283 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 284 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 285 , 15 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 286 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 287 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 288 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 289 , 16 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 290 , 0 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 291 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 292 , 18 , TARGET_STRING (
"activeBalancing4/Battery3/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 293 , 20 , TARGET_STRING (
"activeBalancing4/Battery3/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 294 , 19 , TARGET_STRING (
"activeBalancing4/Battery3/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 295 , 17 , TARGET_STRING (
"activeBalancing4/Battery3/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 296 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 297 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 298 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 299 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 300 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 301 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 302 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 303 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 304 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 305 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 306 , 22 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 307 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 308 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 309 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 310 , 23 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 311 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 312 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 313 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 314 , 24 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 315 , 0 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 316 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 317 , 26 , TARGET_STRING (
"activeBalancing4/Battery4/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 318 , 28 , TARGET_STRING (
"activeBalancing4/Battery4/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 319 , 27 , TARGET_STRING (
"activeBalancing4/Battery4/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 320 , 25 , TARGET_STRING (
"activeBalancing4/Battery4/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 321 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 322 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 323 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 324 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 325 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 326 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 327 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 328 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 329 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 330 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 331 , 30 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 332 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 333 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 334 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 335 , 31 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 336 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 337 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 338 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 339 , 32 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 340 , 0 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 341 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 342 , 34 , TARGET_STRING (
"activeBalancing4/Battery5/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 343 , 36 , TARGET_STRING (
"activeBalancing4/Battery5/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 344 , 35 , TARGET_STRING (
"activeBalancing4/Battery5/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 345 , 33 , TARGET_STRING (
"activeBalancing4/Battery5/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 346 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 347 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 348 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 349 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 350 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 351 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 352 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 353 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 354 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 355 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 356 , 38 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 357 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 358 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 359 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 360 , 39 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 361 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 362 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 363 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 364 , 40 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 365 , 0 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 366 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 367 , 42 , TARGET_STRING (
"activeBalancing4/Battery6/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 368 , 44 , TARGET_STRING (
"activeBalancing4/Battery6/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 369 , 43 , TARGET_STRING (
"activeBalancing4/Battery6/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 370 , 41 , TARGET_STRING (
"activeBalancing4/Battery6/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 371 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 372 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 373 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 374 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 375 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 376 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 377 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 378 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 379 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 380 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 381 , 46 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 382 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 383 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 384 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 385 , 47 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 386 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 387 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 388 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 389 , 48 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 390 , 0 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 391 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 392 , 50 , TARGET_STRING (
"activeBalancing4/Battery7/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 393 , 52 , TARGET_STRING (
"activeBalancing4/Battery7/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 394 , 51 , TARGET_STRING (
"activeBalancing4/Battery7/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 395 , 49 , TARGET_STRING (
"activeBalancing4/Battery7/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 396 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 397 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 398 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 399 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 400 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 401 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 402 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 403 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 404 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 405 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 406 , 54 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 407 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 408 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 409 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 410 , 55 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 411 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 412 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 413 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 414 , 56 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 415 , 0 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 416 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 417 , 58 , TARGET_STRING (
"activeBalancing4/Battery8/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 4 , 0 , 0 } , { 418 , 60 , TARGET_STRING (
"activeBalancing4/Battery8/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 419 , 59 , TARGET_STRING (
"activeBalancing4/Battery8/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 420 , 57 , TARGET_STRING (
"activeBalancing4/Battery8/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 4 , 0 , 0 } , { 421 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 422 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 423 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 424 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 425 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 426 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 427 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 428 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 429 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 430 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 431 , 62 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 432 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 433 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 434 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 435 , 63 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 436 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 437 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 438 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 439 , 64 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 440 , 0 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 441 , 0 , TARGET_STRING (
"activeBalancing4/M1/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 442 , 0 , TARGET_STRING (
"activeBalancing4/M11/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 443 , 0 , TARGET_STRING (
"activeBalancing4/M12/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 444 , 0 , TARGET_STRING (
"activeBalancing4/M2/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 445 , 0 , TARGET_STRING (
"activeBalancing4/M20/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 446 , 0 , TARGET_STRING (
"activeBalancing4/M21/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 447 , 0 , TARGET_STRING (
"activeBalancing4/M23/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 448 , 0 , TARGET_STRING (
"activeBalancing4/M24/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 449 , 0 , TARGET_STRING (
"activeBalancing4/M25/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 450 , 0 , TARGET_STRING (
"activeBalancing4/M26/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 451 , 0 , TARGET_STRING (
"activeBalancing4/M4/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 452 , 0 , TARGET_STRING (
"activeBalancing4/M5/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 453 , 0 , TARGET_STRING (
"activeBalancing4/M6/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 454 , 0 , TARGET_STRING (
"activeBalancing4/M7/Diode/Model/(gate)" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 2 } , { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static
const rtwCAPI_BlockParameters rtBlockParameters [ ] = { { 455 , TARGET_STRING
( "activeBalancing4/Battery1" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } ,
{ 456 , TARGET_STRING ( "activeBalancing4/Battery2" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 457 , TARGET_STRING (
"activeBalancing4/Battery3" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } , {
458 , TARGET_STRING ( "activeBalancing4/Battery4" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 459 , TARGET_STRING (
"activeBalancing4/Battery5" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } , {
460 , TARGET_STRING ( "activeBalancing4/Battery6" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 461 , TARGET_STRING (
"activeBalancing4/Battery7" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } , {
462 , TARGET_STRING ( "activeBalancing4/Battery8" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 463 , TARGET_STRING ( "activeBalancing4/PWM" )
, TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 464 , TARGET_STRING (
"activeBalancing4/PWM1" ) , TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 465
, TARGET_STRING ( "activeBalancing4/PWM3" ) , TARGET_STRING ( "Period" ) , 0
, 0 , 0 } , { 466 , TARGET_STRING ( "activeBalancing4/PWM5" ) , TARGET_STRING
( "Period" ) , 0 , 0 , 0 } , { 467 , TARGET_STRING ( "activeBalancing4/PWM6"
) , TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 468 , TARGET_STRING (
"activeBalancing4/PWM7" ) , TARGET_STRING ( "Period" ) , 0 , 0 , 0 } , { 469
, TARGET_STRING ( "activeBalancing4/PWM8" ) , TARGET_STRING ( "Period" ) , 0
, 0 , 0 } , { 470 , TARGET_STRING ( "activeBalancing4/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 471 , TARGET_STRING (
"activeBalancing4/Constant1" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
472 , TARGET_STRING ( "activeBalancing4/Constant10" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 473 , TARGET_STRING (
"activeBalancing4/Constant11" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
474 , TARGET_STRING ( "activeBalancing4/Constant12" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 475 , TARGET_STRING (
"activeBalancing4/Constant13" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
476 , TARGET_STRING ( "activeBalancing4/Constant14" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 477 , TARGET_STRING (
"activeBalancing4/Constant15" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
478 , TARGET_STRING ( "activeBalancing4/Constant16" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 479 , TARGET_STRING (
"activeBalancing4/Constant2" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
480 , TARGET_STRING ( "activeBalancing4/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 481 , TARGET_STRING (
"activeBalancing4/Constant4" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
482 , TARGET_STRING ( "activeBalancing4/Constant5" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 483 , TARGET_STRING (
"activeBalancing4/Constant6" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
484 , TARGET_STRING ( "activeBalancing4/Constant7" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 485 , TARGET_STRING (
"activeBalancing4/Constant8" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , {
486 , TARGET_STRING ( "activeBalancing4/Constant9" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 487 , TARGET_STRING ( "activeBalancing4/Switch" )
, TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 488 , TARGET_STRING (
"activeBalancing4/Switch1" ) , TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } ,
{ 489 , TARGET_STRING ( "activeBalancing4/Switch2" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 490 , TARGET_STRING (
"activeBalancing4/Switch3" ) , TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } ,
{ 491 , TARGET_STRING ( "activeBalancing4/Switch4" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 492 , TARGET_STRING (
"activeBalancing4/Switch5" ) , TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } ,
{ 493 , TARGET_STRING ( "activeBalancing4/Switch6" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 494 , TARGET_STRING (
"activeBalancing4/Switch7" ) , TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } ,
{ 495 , TARGET_STRING ( "activeBalancing4/Switch8" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 496 , TARGET_STRING (
"activeBalancing4/Switch9" ) , TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } ,
{ 497 , TARGET_STRING (
"activeBalancing4/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 498 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 1234_5678/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 499 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 12_34/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 500 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 1_2/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 501 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 3_4/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 502 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 56_78/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 503 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 5_6/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 504 , TARGET_STRING (
"activeBalancing4/Fuzzy Logic  Controller 7_8/Output Sample Points" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 505 , TARGET_STRING (
"activeBalancing4/Voltage Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 506 , TARGET_STRING (
"activeBalancing4/Battery1/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 507 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 508 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 509 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 510 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 511 , TARGET_STRING ( "activeBalancing4/Battery1/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 512 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 513 , TARGET_STRING ( "activeBalancing4/Battery1/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 514 , TARGET_STRING (
"activeBalancing4/Battery1/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 515 , TARGET_STRING ( "activeBalancing4/Battery1/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 516 , TARGET_STRING (
"activeBalancing4/Battery1/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 517 , TARGET_STRING ( "activeBalancing4/Battery1/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 518 , TARGET_STRING (
"activeBalancing4/Battery1/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 519 , TARGET_STRING (
"activeBalancing4/Battery1/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 520 , TARGET_STRING (
"activeBalancing4/Battery1/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 521 , TARGET_STRING (
"activeBalancing4/Battery1/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 522 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 523 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 524 , TARGET_STRING (
"activeBalancing4/Battery1/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 525 , TARGET_STRING ( "activeBalancing4/Battery1/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 526 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 527 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 528 , TARGET_STRING (
"activeBalancing4/Battery2/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 529 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 530 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 531 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 532 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 533 , TARGET_STRING ( "activeBalancing4/Battery2/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 534 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 535 , TARGET_STRING ( "activeBalancing4/Battery2/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 536 , TARGET_STRING (
"activeBalancing4/Battery2/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 537 , TARGET_STRING ( "activeBalancing4/Battery2/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 538 , TARGET_STRING (
"activeBalancing4/Battery2/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 539 , TARGET_STRING ( "activeBalancing4/Battery2/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 540 , TARGET_STRING (
"activeBalancing4/Battery2/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 541 , TARGET_STRING (
"activeBalancing4/Battery2/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 542 , TARGET_STRING (
"activeBalancing4/Battery2/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 543 , TARGET_STRING (
"activeBalancing4/Battery2/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 544 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 545 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 546 , TARGET_STRING (
"activeBalancing4/Battery2/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 547 , TARGET_STRING ( "activeBalancing4/Battery2/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 548 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 549 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 550 , TARGET_STRING (
"activeBalancing4/Battery3/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 551 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 552 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 553 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 554 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 555 , TARGET_STRING ( "activeBalancing4/Battery3/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 556 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 557 , TARGET_STRING ( "activeBalancing4/Battery3/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 558 , TARGET_STRING (
"activeBalancing4/Battery3/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 559 , TARGET_STRING ( "activeBalancing4/Battery3/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 560 , TARGET_STRING (
"activeBalancing4/Battery3/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 561 , TARGET_STRING ( "activeBalancing4/Battery3/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 562 , TARGET_STRING (
"activeBalancing4/Battery3/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 563 , TARGET_STRING (
"activeBalancing4/Battery3/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 564 , TARGET_STRING (
"activeBalancing4/Battery3/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 565 , TARGET_STRING (
"activeBalancing4/Battery3/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 566 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 567 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 568 , TARGET_STRING (
"activeBalancing4/Battery3/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 569 , TARGET_STRING ( "activeBalancing4/Battery3/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 570 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 571 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 572 , TARGET_STRING (
"activeBalancing4/Battery4/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 573 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 574 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 575 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 576 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 577 , TARGET_STRING ( "activeBalancing4/Battery4/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 578 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 579 , TARGET_STRING ( "activeBalancing4/Battery4/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 580 , TARGET_STRING (
"activeBalancing4/Battery4/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 581 , TARGET_STRING ( "activeBalancing4/Battery4/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 582 , TARGET_STRING (
"activeBalancing4/Battery4/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 583 , TARGET_STRING ( "activeBalancing4/Battery4/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 584 , TARGET_STRING (
"activeBalancing4/Battery4/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 585 , TARGET_STRING (
"activeBalancing4/Battery4/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 586 , TARGET_STRING (
"activeBalancing4/Battery4/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 587 , TARGET_STRING (
"activeBalancing4/Battery4/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 588 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 589 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 590 , TARGET_STRING (
"activeBalancing4/Battery4/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 591 , TARGET_STRING ( "activeBalancing4/Battery4/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 592 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 593 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 594 , TARGET_STRING (
"activeBalancing4/Battery5/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 595 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 596 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 597 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 598 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 599 , TARGET_STRING ( "activeBalancing4/Battery5/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 600 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 601 , TARGET_STRING ( "activeBalancing4/Battery5/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 602 , TARGET_STRING (
"activeBalancing4/Battery5/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 603 , TARGET_STRING ( "activeBalancing4/Battery5/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 604 , TARGET_STRING (
"activeBalancing4/Battery5/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 605 , TARGET_STRING ( "activeBalancing4/Battery5/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 606 , TARGET_STRING (
"activeBalancing4/Battery5/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 607 , TARGET_STRING (
"activeBalancing4/Battery5/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 608 , TARGET_STRING (
"activeBalancing4/Battery5/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 609 , TARGET_STRING (
"activeBalancing4/Battery5/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 610 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 611 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 612 , TARGET_STRING (
"activeBalancing4/Battery5/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 613 , TARGET_STRING ( "activeBalancing4/Battery5/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 614 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 615 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 616 , TARGET_STRING (
"activeBalancing4/Battery6/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 617 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 618 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 619 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 620 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 621 , TARGET_STRING ( "activeBalancing4/Battery6/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 622 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 623 , TARGET_STRING ( "activeBalancing4/Battery6/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 624 , TARGET_STRING (
"activeBalancing4/Battery6/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 625 , TARGET_STRING ( "activeBalancing4/Battery6/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 626 , TARGET_STRING (
"activeBalancing4/Battery6/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 627 , TARGET_STRING ( "activeBalancing4/Battery6/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 628 , TARGET_STRING (
"activeBalancing4/Battery6/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 629 , TARGET_STRING (
"activeBalancing4/Battery6/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 630 , TARGET_STRING (
"activeBalancing4/Battery6/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 631 , TARGET_STRING (
"activeBalancing4/Battery6/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 632 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 633 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 634 , TARGET_STRING (
"activeBalancing4/Battery6/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 635 , TARGET_STRING ( "activeBalancing4/Battery6/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 636 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 637 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 638 , TARGET_STRING (
"activeBalancing4/Battery7/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 639 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 640 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 641 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 642 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 643 , TARGET_STRING ( "activeBalancing4/Battery7/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 644 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 645 , TARGET_STRING ( "activeBalancing4/Battery7/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 646 , TARGET_STRING (
"activeBalancing4/Battery7/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 647 , TARGET_STRING ( "activeBalancing4/Battery7/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 648 , TARGET_STRING (
"activeBalancing4/Battery7/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 649 , TARGET_STRING ( "activeBalancing4/Battery7/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 650 , TARGET_STRING (
"activeBalancing4/Battery7/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 651 , TARGET_STRING (
"activeBalancing4/Battery7/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 652 , TARGET_STRING (
"activeBalancing4/Battery7/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 653 , TARGET_STRING (
"activeBalancing4/Battery7/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 654 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 655 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 656 , TARGET_STRING (
"activeBalancing4/Battery7/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 657 , TARGET_STRING ( "activeBalancing4/Battery7/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 658 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 659 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 660 , TARGET_STRING (
"activeBalancing4/Battery8/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 661 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 662 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 663 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 664 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 665 , TARGET_STRING ( "activeBalancing4/Battery8/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 666 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 667 , TARGET_STRING ( "activeBalancing4/Battery8/Model/R" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 668 , TARGET_STRING (
"activeBalancing4/Battery8/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 669 , TARGET_STRING ( "activeBalancing4/Battery8/Model/R2" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 670 , TARGET_STRING (
"activeBalancing4/Battery8/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 671 , TARGET_STRING ( "activeBalancing4/Battery8/Model/R4" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 672 , TARGET_STRING (
"activeBalancing4/Battery8/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 673 , TARGET_STRING (
"activeBalancing4/Battery8/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 674 , TARGET_STRING (
"activeBalancing4/Battery8/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 675 , TARGET_STRING (
"activeBalancing4/Battery8/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 676 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 677 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 678 , TARGET_STRING (
"activeBalancing4/Battery8/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 679 , TARGET_STRING ( "activeBalancing4/Battery8/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 680 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 681 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 682 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P1" ) , 0 , 6 , 0 } , { 683 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P2" ) , 0 , 7 , 0 } , { 684 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P3" ) , 0 , 8 , 0 } , { 685 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P4" ) , 0 , 9 , 0 } , { 686 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P5" ) , 0 , 10 , 0 } , { 687 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P6" ) , 0 , 11 , 0 } , { 688 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P7" ) , 0 , 12 , 0 } , { 689 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P8" ) , 0 , 11 , 0 } , { 690 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P9" ) , 0 , 0 , 0 } , { 691 , TARGET_STRING (
"activeBalancing4/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P10" ) , 0 , 0 , 0 } , { 692 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 693 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 694 , TARGET_STRING (
"activeBalancing4/Battery1/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 695 , TARGET_STRING (
"activeBalancing4/Battery1/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 696 , TARGET_STRING (
"activeBalancing4/Battery1/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 697 , TARGET_STRING (
"activeBalancing4/Battery1/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 698 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 699 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 700 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 701 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 702 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 703 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 704 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 705 , TARGET_STRING (
"activeBalancing4/Battery2/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 706 , TARGET_STRING (
"activeBalancing4/Battery2/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 707 , TARGET_STRING (
"activeBalancing4/Battery2/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 708 , TARGET_STRING (
"activeBalancing4/Battery2/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 709 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 710 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 711 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 712 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 713 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 714 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 715 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 716 , TARGET_STRING (
"activeBalancing4/Battery3/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 717 , TARGET_STRING (
"activeBalancing4/Battery3/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 718 , TARGET_STRING (
"activeBalancing4/Battery3/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 719 , TARGET_STRING (
"activeBalancing4/Battery3/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 720 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 721 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 722 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 723 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 724 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 725 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 726 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 727 , TARGET_STRING (
"activeBalancing4/Battery4/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 728 , TARGET_STRING (
"activeBalancing4/Battery4/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 729 , TARGET_STRING (
"activeBalancing4/Battery4/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 730 , TARGET_STRING (
"activeBalancing4/Battery4/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 731 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 732 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 733 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 734 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 735 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 736 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 737 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 738 , TARGET_STRING (
"activeBalancing4/Battery5/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 739 , TARGET_STRING (
"activeBalancing4/Battery5/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 740 , TARGET_STRING (
"activeBalancing4/Battery5/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 741 , TARGET_STRING (
"activeBalancing4/Battery5/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 742 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 743 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 744 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 745 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 746 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 747 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 748 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 749 , TARGET_STRING (
"activeBalancing4/Battery6/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 750 , TARGET_STRING (
"activeBalancing4/Battery6/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 751 , TARGET_STRING (
"activeBalancing4/Battery6/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 752 , TARGET_STRING (
"activeBalancing4/Battery6/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 753 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 754 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 755 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 756 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 757 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 758 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 759 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 760 , TARGET_STRING (
"activeBalancing4/Battery7/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 761 , TARGET_STRING (
"activeBalancing4/Battery7/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 762 , TARGET_STRING (
"activeBalancing4/Battery7/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 763 , TARGET_STRING (
"activeBalancing4/Battery7/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 764 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 765 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 766 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 767 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 768 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 769 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 770 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 771 , TARGET_STRING (
"activeBalancing4/Battery8/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 772 , TARGET_STRING (
"activeBalancing4/Battery8/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 773 , TARGET_STRING (
"activeBalancing4/Battery8/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 774 , TARGET_STRING (
"activeBalancing4/Battery8/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 775 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 776 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 777 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 778 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 779 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 780 , TARGET_STRING (
"activeBalancing4/M1/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 781 , TARGET_STRING ( "activeBalancing4/M11/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 782 , TARGET_STRING (
"activeBalancing4/M12/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 783 , TARGET_STRING ( "activeBalancing4/M2/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 784 , TARGET_STRING (
"activeBalancing4/M20/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 785 , TARGET_STRING ( "activeBalancing4/M21/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 786 , TARGET_STRING (
"activeBalancing4/M23/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 787 , TARGET_STRING ( "activeBalancing4/M24/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 788 , TARGET_STRING (
"activeBalancing4/M25/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 789 , TARGET_STRING ( "activeBalancing4/M26/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 790 , TARGET_STRING (
"activeBalancing4/M4/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 791 , TARGET_STRING ( "activeBalancing4/M5/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 792 , TARGET_STRING (
"activeBalancing4/M6/Diode/Model/(gate)" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 793 , TARGET_STRING ( "activeBalancing4/M7/Diode/Model/(gate)" )
, TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 794 , TARGET_STRING (
"activeBalancing4/Battery1/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 795 , TARGET_STRING (
"activeBalancing4/Battery2/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 796 , TARGET_STRING (
"activeBalancing4/Battery3/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 797 , TARGET_STRING (
"activeBalancing4/Battery4/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 798 , TARGET_STRING (
"activeBalancing4/Battery5/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 799 , TARGET_STRING (
"activeBalancing4/Battery6/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 800 , TARGET_STRING (
"activeBalancing4/Battery7/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 801 , TARGET_STRING (
"activeBalancing4/Battery8/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 } } ; static int_T rt_LoggedStateIdxList [ ] = { - 1 } ; static const
rtwCAPI_Signals rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 , 0 , 0 } } ; static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0 , 0 ,
( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_ModelParameters rtModelParameters [ ] = { { 0 , ( NULL ) , 0 , 0 , 0
} } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . obf4zmf1af , & rtB . l4dl2g4o4p ,
& rtB . bcxdnmatsv , & rtB . l2reh15lkf , & rtB . ikv3z1vdef , & rtB .
eedseylcxx , & rtB . fevj4hbzpr , & rtB . iu33mby5ow , & rtB . iy0igec4ex , &
rtB . nhvmldohqo , & rtB . exxvwq1eca , & rtB . m1to4j3fz0 , & rtB .
l1byjbqlra , & rtB . a3i41vp1qh , & rtB . hmk2x4i2wb , & rtB . kocesgc4kq , &
rtB . prlvalkk0e , & rtB . pobsyfwdrr , & rtB . c5g4vefyay , & rtB .
p5n3swm2z3 , & rtB . k4qktqs5bt , & rtB . lpxn0wunpn , & rtB . dpcxxq2cb2 , &
rtB . iwlpqqhwtd , & rtB . jtiok3ecro , & rtB . ot4gqzqydm , & rtB .
d5mhwukqbu , & rtB . m2qzirzrwp , & rtB . c3rlj0evqz , & rtB . fpat1cfbdw , &
rtB . ejoagqctsb , & rtB . k2b4djnq52 , & rtB . d0hcukp5qd , & rtB .
oem1fc5toa , & rtB . obf4zmf1af , & rtB . keklcbv4b5 . gz0uq5kqkr [ 0 ] , &
rtB . l4dl2g4o4p , & rtB . cg45csylfj . gz0uq5kqkr [ 0 ] , & rtB . bcxdnmatsv
, & rtB . l2reh15lkf , & rtB . k43q2yzt11 . gz0uq5kqkr [ 0 ] , & rtB .
ikv3z1vdef , & rtB . cnchvyey1f . gz0uq5kqkr [ 0 ] , & rtB . eedseylcxx , &
rtB . bk2qkpodeg . gz0uq5kqkr [ 0 ] , & rtB . fevj4hbzpr , & rtB . mck0tzoap3
. gz0uq5kqkr [ 0 ] , & rtB . h3c5qk01el , & rtB . anc2sq3mml , & rtB .
mqa03tpv1s , & rtB . bzwbhh42ka , & rtB . ojiezq4id3 , & rtB . ftx2e5cidi , &
rtB . ntwxdiuzqj , & rtB . b4ushbvpyk , & rtB . lzgz2a1hji , & rtB .
hg3oaigjwk , & rtB . p3jvn4gjjg , & rtB . gp1kmspjlh , & rtB . nj0k0lpkxt , &
rtB . mrkoixdcxy , & rtB . a42chj0wvi , & rtB . iztnxsmmfx , & rtB .
bsbdyhiakj , & rtB . k0olm5ygz1 , & rtB . fq1y334rj2 , & rtB . fs4j0t3iiz , &
rtB . drgvtg0vjv , & rtB . h0jr4gcmhz , & rtB . fqm02mu2mr , & rtB .
hu2ipo3lca , & rtB . kkv1pr3lrm , & rtB . do252u2xbm , & rtB . gaxbz4eazu , &
rtB . n52pjzek12 , & rtB . p0r2azag0g , & rtB . c1l22vg0g3 , & rtB .
g5y2ovgmgf , & rtB . eutn5sqh40 , & rtB . dq2lwvzzrg , & rtB . gkqod2z0mi , &
rtB . eft5k5m2mk , & rtB . pmyyss4uxo , & rtB . b1idarpp5t , & rtB .
othrejmk4n , & rtB . fzx04ovsv2 , & rtB . gaiiq3ag5u , & rtB . jatbcbjee2 , &
rtB . po53ioprtt , & rtB . ns2ruilj2v , & rtB . a0aqqada1w , & rtB .
nl2mcft0gt , & rtB . ojlbfd1f01 , & rtB . oc3uk0sbgh , & rtB . kx5llxdy1m , &
rtB . jmd5vm3itb , & rtB . alargmkfao , & rtB . deh2tdbovg , & rtB .
nv44crtc44 , & rtB . bnmph5cpev , & rtB . esegl2vvhs , & rtB . pspdcb10ak , &
rtB . a32d4y2ehp , & rtB . pciyqbmld3 , & rtB . gfahibyvsv , & rtB .
arqmlzjrl4 , & rtB . cgdbtisdum , & rtB . aojtgbxww0 , & rtB . ilvfsgymog , &
rtB . idgi4oj4mi , & rtB . a2rrzly2nj , & rtB . hgspzwdexg , & rtB .
ou3yruthi3 , & rtB . flzib234ll , & rtB . b411vxpvsm , & rtB . kslnv1njp2 , &
rtB . fibreaa3ri , & rtB . iqgkwhugb1 , & rtB . ijb3b30r2i , & rtB .
itgwqixq2p , & rtB . a1q431buft , & rtB . lz4r5vsjh1 , & rtB . bfmkeli01v , &
rtB . c005o3t15s , & rtB . fyoud2dfzn , & rtB . inix0uapiw , & rtB .
fytijtn1qm , & rtB . lffxmmonqb , & rtB . oi4dn5ko50 , & rtB . bpligzmo0k , &
rtB . j41ux1gc4d , & rtB . prb3bcw1pc , & rtB . ixuan5fz50 , & rtB .
b2gwj4fubz , & rtB . chdzuypdzn , & rtB . ctz5askxrg , & rtB . kyq4l5giqe , &
rtB . ijwp3irwdu , & rtB . czyx3zxlle , & rtB . ame4svhan1 , & rtB .
ilzwywxync , & rtB . gzihj5vvk1 , & rtB . mlwnlfftda , & rtB . cvwcsqjiim , &
rtB . g5hkbvjtz4 , & rtB . exrixluala , & rtB . olfzsyzgug , & rtB .
kjygkwym52 , & rtB . fdzcq5zjwp , & rtB . a5didxhdqz , & rtB . givksyq1ks , &
rtB . g1xvhnr3f5 , & rtB . im14ffjmmn , & rtB . msa01agh2x , & rtB .
dgspm5jmps , & rtB . gcxndupnfr , & rtB . iaqlnbjhf1 , & rtB . i0lfhlq3lc , &
rtB . ork1qkhic1 , & rtB . muxngmbf0e , & rtB . deydb1b0uy , & rtB .
p2hxwe1zfu , & rtB . g0q2tc5i24 , & rtB . cizwakiveg , & rtB . hn5i42dlfu , &
rtB . dkk3fwnmny , & rtB . l0cwdgyzlo , & rtB . bvz4ef4xni , & rtB .
iotsi3yshg , & rtB . lms5sy0bav , & rtB . ljzepiqdco , & rtB . jo315eteaj , &
rtB . lf5xebyb1r , & rtB . lolyh00lpd , & rtB . g201quwjao , & rtB .
juce2ptz2y , & rtB . bqzx2eyzzy , & rtB . lroevxw2fw , & rtB . lhhyhpp5gu , &
rtB . njfm3f2grf , & rtB . gjn3v2eu4k , & rtB . cyebjd4msb , & rtB .
ehmperqua5 , & rtB . ppcjroz05k , & rtB . besqhap1x0 , & rtB . agkl53gxjq , &
rtB . kgcldxtuqy , & rtB . cjnumo0b2v , & rtB . b3ob2uqqdm , & rtB .
ecthl1j1o0 , & rtB . aaa1drn5lo , & rtB . hhflfdof15 , & rtB . baqcdaab4w , &
rtB . k4bl20stk1 , & rtB . ipz4zr0egw , & rtB . g415uib1wr , & rtB .
aacglbrseh , & rtB . i0wi0xfyww , & rtB . b2ixyft4ic , & rtB . ggnmpyt3wu , &
rtB . cdunewte3y , & rtB . cd1qrej531 , & rtB . dr4em5z1io , & rtB .
i0iborr1bn , & rtB . o5jsafr2c3 , & rtB . d34ubm25fp , & rtB . cvzcjmgoyh , &
rtB . jp2e2ut45b , & rtB . edxzstui5p , & rtB . pw5q5s3yxm , & rtB .
c5sjcucfqi , & rtB . ivovkyhxrz , & rtB . bxzkxne3dq , & rtB . hvmipewyll , &
rtB . newud24pbl , & rtB . dm4nf0b0xz , & rtB . esg43lx2mr , & rtB .
apkx5dx1qe , & rtB . codhkowftx , & rtB . ilnuaaom40 , & rtB . acxnkfdwy1 , &
rtB . ja5d4uupyj , & rtB . ak5ny2xuat , & rtB . dcvu5axig4 , & rtB .
lizolknie1 , & rtB . gw4ubpvz5m , & rtB . jwcx5x3uww , & rtB . nehx4sjmhx , &
rtB . nvr2gta2ze , & rtB . fx2apmzawu , & rtB . otte1lhfee , & rtB .
hnmfvx1wci , & rtB . d3jd5igxzc , & rtB . dxplqcckv2 , & rtB . bo1fzqwe00 , &
rtB . cnd3dqmhap , & rtB . jwjptsm01d , & rtB . eg2jmmryoa , & rtB .
kxpcdql4jz , & rtB . lo01p0mfxt [ 0 ] , & rtB . jqon53xqhn [ 0 ] , & rtB .
iglwuzsika , & rtB . btujypzxe1 [ 0 ] , & rtB . fuv3hvos5j [ 0 ] , & rtB .
decwo2mz20 [ 0 ] , & rtB . a50cikqz4s [ 0 ] , & rtB . nlzznjgokl , & rtB .
byr5s2oy3e , & rtB . icxhoatkpy , & rtB . kf00di3gqm , & rtB . ifn5ydjway , &
rtB . djbiardxss , & rtB . l243apzsnw , & rtB . jvqj10bdhd , & rtB .
oj3yvv3y0h , & rtB . kq0scdgfjl , & rtB . ob4wdtvizk , & rtB . nula5qzpsy , &
rtB . levrqdzmuw , & rtB . lvl2kjehdx , & rtB . lvwz4ihgsh , & rtB .
mcznvl3xnw , & rtB . jjriozwmwj , & rtB . hwjzbg4rx2 , & rtB . nz04uf540o , &
rtB . gmgyu1za23 , & rtB . e0yzwp1mzb , & rtB . if5hnihgsu [ 0 ] , & rtB .
cmoguppwfc [ 0 ] , & rtB . jbhnyvsbds [ 0 ] , & rtB . bo4jr3clrs [ 0 ] , &
rtB . pll3gx4xtu , & rtB . l2a4su3opv , & rtB . ooktbhfuke , & rtB .
b5plhow0ik , & rtB . frv35kwpm0 , & rtB . mpkxn4stei , & rtB . pqhzrovppf , &
rtB . hlf2cr3mg4 , & rtB . eekpnfrbtv , & rtB . f2df1n0xmz , & rtB .
nmhnvozqsv , & rtB . m5jzl0c3ow , & rtB . muvs2zmbde , & rtB . czsttbwlhu , &
rtB . oplbbe4p2q , & rtB . o55coy5tot , & rtB . newl3oopdo , & rtB .
nvh2bwltbz , & rtB . jaaef2z5gv , & rtB . mtw3mahg4k , & rtB . dzejhg3vfk , &
rtB . f5dahsuilz [ 0 ] , & rtB . dj5bmh2qmz [ 0 ] , & rtB . o5hw5brjet [ 0 ]
, & rtB . d3zrlcmw3n [ 0 ] , & rtB . mphcdthuhz , & rtB . msjbl0lqgu , & rtB
. d3g3fh43cq , & rtB . nla5yxcuxf , & rtB . hg2elf4r3m , & rtB . bpyjvekzcs ,
& rtB . nzk1m34skw , & rtB . iilzn0ptvn , & rtB . fawiawgoh5 , & rtB .
js2smttmtm , & rtB . ezq2vhtkgr , & rtB . i5uns4zs23 , & rtB . eehigchrn4 , &
rtB . gk2b4uufar , & rtB . ibgjdsvsot , & rtB . befeauo34y , & rtB .
atzrgflsgx , & rtB . hv51mxfmqn , & rtB . pj3ruknygu , & rtB . n4ii53j0pi , &
rtB . ktqlzpn2rg , & rtB . ax4synweyq [ 0 ] , & rtB . ihm1brh0bi [ 0 ] , &
rtB . kq0pv3jzej [ 0 ] , & rtB . jt5vlrdpwx [ 0 ] , & rtB . pvsep2b5mx , &
rtB . idyadmxopc , & rtB . p35szvmsnl , & rtB . jolzvaxect , & rtB .
muhalhj3gd , & rtB . iurpvuxeop , & rtB . nxd3puqj5v , & rtB . pq5i5vcg3c , &
rtB . ku5eexxo1r , & rtB . mzyw4mhc11 , & rtB . jjkxq3xqxm , & rtB .
ebcldbyulo , & rtB . cbldlnrkrl , & rtB . erpu4v3yeg , & rtB . h0fu0ax1yq , &
rtB . k0z0bgvani , & rtB . aowksp0wla , & rtB . cme3xzwgv0 , & rtB .
pnkg5wquv2 , & rtB . corg1fk01c , & rtB . ogkyqhikl5 , & rtB . jmhpv4tqnk [ 0
] , & rtB . bpbiu1lihc [ 0 ] , & rtB . l2q2yxulmn [ 0 ] , & rtB . d1g5zgedks
[ 0 ] , & rtB . mrdluoj4iu , & rtB . gkbr5qk2mc , & rtB . juxu3ykg0j , & rtB
. iuvcnk5dmp , & rtB . h3sbcd43z2 , & rtB . izlnv5xggd , & rtB . flzlebwg5e ,
& rtB . nzvnip1yoj , & rtB . cp0who25g2 , & rtB . erylo4qhmo , & rtB .
is1wchelug , & rtB . owgcqoig0n , & rtB . b44kx5qc5j , & rtB . ovopkjg4yt , &
rtB . oygxsrsu4c , & rtB . aztqnss3hz , & rtB . cjfw5loxvr , & rtB .
iutvmolvr4 , & rtB . h0gslfuz00 , & rtB . agzlujxqfb , & rtB . gl0nhtg1ch , &
rtB . d0ttldw0xr [ 0 ] , & rtB . d0xiworakl [ 0 ] , & rtB . k0aebkl4fh [ 0 ]
, & rtB . kmnm3jte0y [ 0 ] , & rtB . hbi3ef0eho , & rtB . gn1iktvu5j , & rtB
. hgecksjb2e , & rtB . as0tme1x3l , & rtB . et4oqao0hp , & rtB . opg5acc20j ,
& rtB . pk01kqglup , & rtB . gsaxgr1si0 , & rtB . cukuo2c3br , & rtB .
eic4qlkhsy , & rtB . cv4nsrlmii , & rtB . lnjnmhfbjh , & rtB . hpb3sjmuau , &
rtB . gdm5q3kphw , & rtB . cs22ftcsml , & rtB . i5kcdpjhpi , & rtB .
fk4jwk4iji , & rtB . f0mgvc4qtv , & rtB . l4aqiuf2c4 , & rtB . ogryssvt51 , &
rtB . dfuf4q33n1 , & rtB . og4zmu0v2n [ 0 ] , & rtB . pfrnf2ydxj [ 0 ] , &
rtB . ayi1laekbu [ 0 ] , & rtB . p2dnpj1ive [ 0 ] , & rtB . mqtt3ijnmc , &
rtB . j2cbi4uvjv , & rtB . dhgr323ykq , & rtB . mwcys4j4zs , & rtB .
dhwyvtmepj , & rtB . izc05dwilh , & rtB . hvabmdtuvh , & rtB . bybsxhpomg , &
rtB . nwe5vf4a0r , & rtB . fxfy52jqlw , & rtB . jhzzujuc41 , & rtB .
bjlklhbtye , & rtB . kds135p0hu , & rtB . kqgjchdcds , & rtB . n3yk1z5ay1 , &
rtB . nqmkidt0nf , & rtB . evet21s24l , & rtB . malsck44d3 , & rtB .
i50k4latrz , & rtB . g4xgxwmrt1 , & rtB . mmu3qpagt3 , & rtB . gre2qqt31t [ 0
] , & rtB . ma44kqgc1u [ 0 ] , & rtB . g2neorilhq [ 0 ] , & rtB . g2v5eyf0fn
[ 0 ] , & rtB . f0al1hik1j , & rtB . b0w045s1dy , & rtB . lodc4zy0kf , & rtB
. bwiu5f3xyy , & rtB . geb23uw5n4 , & rtB . hb5phdzryd , & rtB . nm54nmq004 ,
& rtB . eupsjtfr5a , & rtB . n3fyjsfyy0 , & rtB . hrjctsjkxd , & rtB .
mgautzzkuz , & rtB . a2ssj2eqbk , & rtB . nvn1ehmkrx , & rtB . luugfk3sgm , &
rtB . cojxsmfsrh , & rtB . jufwanbg3o , & rtB . h20jo3vqoy , & rtB .
ksknuspzbv , & rtB . ahmttm3rdd , & rtB . aftb2w02md , & rtB . bcww4isw4r , &
rtB . b5epvnjqmi , & rtB . lcbjcuvvbt , & rtB . jn3jigbm4f , & rtB .
o1rf1cikyg , & rtB . kg5yvb1wjz , & rtB . da4ug2cudb , & rtB . ezyjeovbvi , &
rtB . nahk3q2lwf , & rtB . nz5qxvxtdb , & rtB . hwoezaq2mj , & rtB .
iq51ppixmq , & rtB . bhhrjm3haf , & rtB . acuoed4qri , & rtP .
Battery1_BatType , & rtP . Battery2_BatType , & rtP . Battery3_BatType , &
rtP . Battery4_BatType , & rtP . Battery5_BatType , & rtP . Battery6_BatType
, & rtP . Battery7_BatType , & rtP . Battery8_BatType , & rtP . PWM_Period ,
& rtP . PWM1_Period , & rtP . PWM3_Period , & rtP . PWM5_Period , & rtP .
PWM6_Period , & rtP . PWM7_Period , & rtP . PWM8_Period , & rtP .
Constant_Value_e1gwiy1pb3 , & rtP . Constant1_Value_mf4xbwjhdv , & rtP .
Constant10_Value , & rtP . Constant11_Value , & rtP .
Constant12_Value_c2qvybcfaa , & rtP . Constant13_Value , & rtP .
Constant14_Value , & rtP . Constant15_Value , & rtP . Constant16_Value , &
rtP . Constant2_Value_e4jyxae25b , & rtP . Constant3_Value_bkb3mktfvw , & rtP
. Constant4_Value_fxnxt0eszt , & rtP . Constant5_Value , & rtP .
Constant6_Value , & rtP . Constant7_Value , & rtP . Constant8_Value , & rtP .
Constant9_Value_crabpzohh2 , & rtP . Switch_Threshold , & rtP .
Switch1_Threshold , & rtP . Switch2_Threshold , & rtP . Switch3_Threshold , &
rtP . Switch4_Threshold , & rtP . Switch5_Threshold , & rtP .
Switch6_Threshold , & rtP . Switch7_Threshold , & rtP . Switch8_Threshold , &
rtP . Switch9_Threshold , & rtP . donotdeletethisgain_Gain_hwxhghbjtm , & rtP
. OutputSamplePoints_Value [ 0 ] , & rtP .
OutputSamplePoints_Value_dbmmauqiwo [ 0 ] , & rtP .
OutputSamplePoints_Value_bs0he10brt [ 0 ] , & rtP .
OutputSamplePoints_Value_mkqnjleygm [ 0 ] , & rtP .
OutputSamplePoints_Value_mmzz2j1vii [ 0 ] , & rtP .
OutputSamplePoints_Value_h5oozv5nnj [ 0 ] , & rtP .
OutputSamplePoints_Value_k42vy4v1xv [ 0 ] , & rtP .
donotdeletethisgain_Gain_jslrw2wpeb , & rtP .
donotdeletethisgain_Gain_dywzmacz1o , & rtP . Constant_Value_jorngiczgp , &
rtP . Constant1_Value , & rtP . Constant12_Value , & rtP . Constant9_Value ,
& rtP . Gain_Gain , & rtP . Gain2_Gain , & rtP . R_Gain_cwdppwgit4 , & rtP .
R1_Gain , & rtP . R2_Gain , & rtP . R3_Gain , & rtP . R4_Gain , & rtP .
inti_UpperSat , & rtP . inti_LowerSat , & rtP . itinit_InitialCondition , &
rtP . itinit1_InitialCondition , & rtP . Saturation_UpperSat_pcz043fnep , &
rtP . Saturation_LowerSat_b05y2t0vvl , & rtP . BAL_A , & rtP . BAL_C , & rtP
. Currentfilter_A , & rtP . Currentfilter_C , & rtP .
donotdeletethisgain_Gain , & rtP . Constant_Value_fzmb45jy2r , & rtP .
Constant1_Value_jelmmtr1rj , & rtP . Constant12_Value_df3z3yuypl , & rtP .
Constant9_Value_bfo0fnc5l1 , & rtP . Gain_Gain_ozvwrv1fuy , & rtP .
Gain2_Gain_m4x3vq3y1f , & rtP . R_Gain , & rtP . R1_Gain_k1h1x1zryv , & rtP .
R2_Gain_jrqfqsl4vo , & rtP . R3_Gain_dgx1dntlxw , & rtP . R4_Gain_ayggl2vp1n
, & rtP . inti_UpperSat_itldayqrxp , & rtP . inti_LowerSat_lz3gh0icex , & rtP
. itinit_InitialCondition_pv4h4vt0ps , & rtP .
itinit1_InitialCondition_l3j5mkh0dv , & rtP . Saturation_UpperSat_aqwzuangfk
, & rtP . Saturation_LowerSat_bcd3czsgyq , & rtP . BAL_A_cudqa1u03y , & rtP .
BAL_C_pnvzkp4ayj , & rtP . Currentfilter_A_hazdhojaym , & rtP .
Currentfilter_C_ldprzne4qv , & rtP . donotdeletethisgain_Gain_o42imifl5k , &
rtP . Constant_Value_kiu123temw , & rtP . Constant1_Value_jj3f5fu3xp , & rtP
. Constant12_Value_ktnzmkcekm , & rtP . Constant9_Value_nhyzz1ckmw , & rtP .
Gain_Gain_jbuudt1ftk , & rtP . Gain2_Gain_jptbha03po , & rtP .
R_Gain_g4gmpqe5wx , & rtP . R1_Gain_elo0441xsu , & rtP . R2_Gain_fij43s2whq ,
& rtP . R3_Gain_de1tgv0zzw , & rtP . R4_Gain_ckkisgzyfx , & rtP .
inti_UpperSat_nowwhgaxwk , & rtP . inti_LowerSat_cwekkzbyq1 , & rtP .
itinit_InitialCondition_nf4pvnucgc , & rtP .
itinit1_InitialCondition_go30gfvhlp , & rtP . Saturation_UpperSat_i3x3oscagf
, & rtP . Saturation_LowerSat_gnz45aadu0 , & rtP . BAL_A_n35zxahhei , & rtP .
BAL_C_ix2bm3qtha , & rtP . Currentfilter_A_pyl0ygpghg , & rtP .
Currentfilter_C_hx4sknoziy , & rtP . donotdeletethisgain_Gain_fjipbfzkks , &
rtP . Constant_Value_em2zyolrnm , & rtP . Constant1_Value_myhrse5szs , & rtP
. Constant12_Value_jkrk5dvljw , & rtP . Constant9_Value_ffsooduwum , & rtP .
Gain_Gain_l5lbde12wy , & rtP . Gain2_Gain_fe3eihrk0b , & rtP .
R_Gain_biqz0al5hr , & rtP . R1_Gain_ay3u4mrv4p , & rtP . R2_Gain_akgkexbqnd ,
& rtP . R3_Gain_nk0ujvzftk , & rtP . R4_Gain_nfptou1h22 , & rtP .
inti_UpperSat_itde10ibkj , & rtP . inti_LowerSat_nb1wwuftgl , & rtP .
itinit_InitialCondition_atlhsczubb , & rtP .
itinit1_InitialCondition_ia2mtm2bdv , & rtP . Saturation_UpperSat_luxvjfmfd3
, & rtP . Saturation_LowerSat_mqcesji40p , & rtP . BAL_A_jgidwk4hmh , & rtP .
BAL_C_hfghx3gysd , & rtP . Currentfilter_A_bsszjj1hem , & rtP .
Currentfilter_C_muylregegy , & rtP . donotdeletethisgain_Gain_ave45anr4u , &
rtP . Constant_Value_pfu1thap3i , & rtP . Constant1_Value_h1thd4w1zg , & rtP
. Constant12_Value_oujd2whfki , & rtP . Constant9_Value_bcezbzp4a1 , & rtP .
Gain_Gain_a4qiy5rws3 , & rtP . Gain2_Gain_of2pa5ka31 , & rtP .
R_Gain_bq04dmcpzt , & rtP . R1_Gain_bdgjwewy0w , & rtP . R2_Gain_axv50jbqfg ,
& rtP . R3_Gain_hslbhc5rsq , & rtP . R4_Gain_e51nv5aiyc , & rtP .
inti_UpperSat_ff0nysnmjy , & rtP . inti_LowerSat_hzpmw3xl5s , & rtP .
itinit_InitialCondition_mh2yj0opxq , & rtP .
itinit1_InitialCondition_po45v3mmic , & rtP . Saturation_UpperSat_p4wbgcsokm
, & rtP . Saturation_LowerSat_gdbbvpyvzg , & rtP . BAL_A_oad34lr4nf , & rtP .
BAL_C_cq3wtorxkj , & rtP . Currentfilter_A_o3r40a2fs0 , & rtP .
Currentfilter_C_e5mev0pk52 , & rtP . donotdeletethisgain_Gain_mvbq03z0iq , &
rtP . Constant_Value_mnsc2xmcnp , & rtP . Constant1_Value_fcmat31m3p , & rtP
. Constant12_Value_l40vqppf0r , & rtP . Constant9_Value_khmvv2oadi , & rtP .
Gain_Gain_nfwhezh4mu , & rtP . Gain2_Gain_jyxvaqqzap , & rtP .
R_Gain_mh2yy541ef , & rtP . R1_Gain_bnqyizdjwz , & rtP . R2_Gain_e5lq5jfqyz ,
& rtP . R3_Gain_ozkjsk4x5h , & rtP . R4_Gain_l2wha3sgrh , & rtP .
inti_UpperSat_cuyg3emce0 , & rtP . inti_LowerSat_l4lrtlmq4a , & rtP .
itinit_InitialCondition_drzgzhkcxo , & rtP .
itinit1_InitialCondition_bfkql3ev41 , & rtP . Saturation_UpperSat_iofvqb3bhc
, & rtP . Saturation_LowerSat_ob0aofpwnu , & rtP . BAL_A_nrro44ikdu , & rtP .
BAL_C_c2hdnxiek4 , & rtP . Currentfilter_A_n0q2cotnax , & rtP .
Currentfilter_C_gzd0zmcoyy , & rtP . donotdeletethisgain_Gain_kdw2eb0k3g , &
rtP . Constant_Value_diqvfq2vok , & rtP . Constant1_Value_j1ihyekgnt , & rtP
. Constant12_Value_frutixtppx , & rtP . Constant9_Value_hbi2xzqgvf , & rtP .
Gain_Gain_cpenmhpyrf , & rtP . Gain2_Gain_hm05ohnj0y , & rtP .
R_Gain_k35mp2rvup , & rtP . R1_Gain_g4pre24jyp , & rtP . R2_Gain_ejdzqjxpj5 ,
& rtP . R3_Gain_eilrq2a1m2 , & rtP . R4_Gain_g4hvk30k1k , & rtP .
inti_UpperSat_p1ksyho442 , & rtP . inti_LowerSat_c2pdzacpit , & rtP .
itinit_InitialCondition_j0a3v1ybuu , & rtP .
itinit1_InitialCondition_ftzthjgsxo , & rtP . Saturation_UpperSat_f2amnkjsa0
, & rtP . Saturation_LowerSat_lbyytgqsae , & rtP . BAL_A_jd4dvguj5h , & rtP .
BAL_C_nwvwd0ihf1 , & rtP . Currentfilter_A_jhxjqdrxhi , & rtP .
Currentfilter_C_pwjctgaucg , & rtP . donotdeletethisgain_Gain_jquqjrzlip , &
rtP . Constant_Value_avhibee4iu , & rtP . Constant1_Value_mntemyjbjb , & rtP
. Constant12_Value_gycmvngwdn , & rtP . Constant9_Value_lgn0aviuoi , & rtP .
Gain_Gain_ot14m0p13e , & rtP . Gain2_Gain_plpbrgefjj , & rtP .
R_Gain_chtk1x1i0w , & rtP . R1_Gain_n5on15rj3k , & rtP . R2_Gain_bn5zry4edp ,
& rtP . R3_Gain_molbysildp , & rtP . R4_Gain_dwzv1lgknn , & rtP .
inti_UpperSat_gge1msuajg , & rtP . inti_LowerSat_b5bkhbogxv , & rtP .
itinit_InitialCondition_im5akoh0gb , & rtP .
itinit1_InitialCondition_auzkchjcmx , & rtP . Saturation_UpperSat_dtvs1qra3o
, & rtP . Saturation_LowerSat_huwlm3xk3n , & rtP . BAL_A_gvm0uualdo , & rtP .
BAL_C_bahpumao3b , & rtP . Currentfilter_A_hin2vooinr , & rtP .
Currentfilter_C_a0gtd4kont , & rtP . StateSpace_P1 [ 0 ] , & rtP .
StateSpace_P2 [ 0 ] , & rtP . StateSpace_P3 [ 0 ] , & rtP . StateSpace_P4 [ 0
] , & rtP . StateSpace_P5 [ 0 ] , & rtP . StateSpace_P6 [ 0 ] , & rtP .
StateSpace_P7 [ 0 ] , & rtP . StateSpace_P8 [ 0 ] , & rtP . StateSpace_P9 , &
rtP . StateSpace_P10 , & rtP . Constant_Value , & rtP .
Constant_Value_efypwvyyax , & rtP . Constant1_Value_ks0gbwvaxk , & rtP .
Constant2_Value , & rtP . Constant3_Value , & rtP . Constant4_Value , & rtP .
Gain1_Gain , & rtP . Gain4_Gain , & rtP . Integrator2_IC , & rtP .
Saturation_UpperSat , & rtP . Saturation_LowerSat , & rtP .
Constant_Value_pbqzqfbpnm , & rtP . Constant_Value_hu3rmuppbn , & rtP .
Constant1_Value_jxqfbvs00y , & rtP . Constant2_Value_nbkvr3eqsy , & rtP .
Constant3_Value_k030zkojhy , & rtP . Constant4_Value_p1xz0cpgth , & rtP .
Gain1_Gain_og11bwmhu2 , & rtP . Gain4_Gain_kh00znyazs , & rtP .
Integrator2_IC_finfcihmmt , & rtP . Saturation_UpperSat_lxx4j3fnoa , & rtP .
Saturation_LowerSat_kwi433xk5g , & rtP . Constant_Value_bksqnhysc0 , & rtP .
Constant_Value_owtewy0ssm , & rtP . Constant1_Value_gbfcrdkgqa , & rtP .
Constant2_Value_gnk2tjoo5o , & rtP . Constant3_Value_hat1prtoip , & rtP .
Constant4_Value_cmgjzabbd1 , & rtP . Gain1_Gain_anymdqpqln , & rtP .
Gain4_Gain_fstjjgzlds , & rtP . Integrator2_IC_kqbwod02j2 , & rtP .
Saturation_UpperSat_blj3ug4rzx , & rtP . Saturation_LowerSat_o0i20janpw , &
rtP . Constant_Value_kedzfrfegv , & rtP . Constant_Value_opaksbgo21 , & rtP .
Constant1_Value_am3al2n15v , & rtP . Constant2_Value_odhbgl2n1s , & rtP .
Constant3_Value_mujtf1guv4 , & rtP . Constant4_Value_ohbtynzx54 , & rtP .
Gain1_Gain_baecfd2g1g , & rtP . Gain4_Gain_n2oajsg4xg , & rtP .
Integrator2_IC_gtek0x1of0 , & rtP . Saturation_UpperSat_c0l2pkijii , & rtP .
Saturation_LowerSat_g1ovkjgj1x , & rtP . Constant_Value_epq2rsx4ba , & rtP .
Constant_Value_h45zreb2fb , & rtP . Constant1_Value_ny1xdqiske , & rtP .
Constant2_Value_ppmjeluned , & rtP . Constant3_Value_kuyjih2run , & rtP .
Constant4_Value_om2zghpbx3 , & rtP . Gain1_Gain_dq4vkdpk0h , & rtP .
Gain4_Gain_j4eqtusam3 , & rtP . Integrator2_IC_iw5ohpmyuz , & rtP .
Saturation_UpperSat_dr1jmbb0we , & rtP . Saturation_LowerSat_haspwmkdbs , &
rtP . Constant_Value_crxssz3mu1 , & rtP . Constant_Value_hr1h3melx3 , & rtP .
Constant1_Value_mv1dwtlwtz , & rtP . Constant2_Value_hhcyqz43te , & rtP .
Constant3_Value_fma5g13bsz , & rtP . Constant4_Value_lcmf40k0jk , & rtP .
Gain1_Gain_c5i2vccxwe , & rtP . Gain4_Gain_l0ptdzkgeb , & rtP .
Integrator2_IC_emw1ynvfly , & rtP . Saturation_UpperSat_oasdavgelo , & rtP .
Saturation_LowerSat_hlakhjokuc , & rtP . Constant_Value_ksing41bve , & rtP .
Constant_Value_psd4g00i4r , & rtP . Constant1_Value_nfwykf0vow , & rtP .
Constant2_Value_lwxj2lq0w4 , & rtP . Constant3_Value_ouq0slsocc , & rtP .
Constant4_Value_jjkyxucjzh , & rtP . Gain1_Gain_hhtznyj2s2 , & rtP .
Gain4_Gain_pdhrsclrmp , & rtP . Integrator2_IC_pi2b1d0t3y , & rtP .
Saturation_UpperSat_e2rewfpeer , & rtP . Saturation_LowerSat_btlbcqipab , &
rtP . Constant_Value_ep2qfgttrh , & rtP . Constant_Value_lyegm1i5cg , & rtP .
Constant1_Value_h3fhvhzpts , & rtP . Constant2_Value_dgpgyrzaqa , & rtP .
Constant3_Value_fn3ludrege , & rtP . Constant4_Value_oq3sj0rsir , & rtP .
Gain1_Gain_at5pojvma0 , & rtP . Gain4_Gain_bbkx0f2eye , & rtP .
Integrator2_IC_m4ngvk5rcj , & rtP . Saturation_UpperSat_pwhhuyqzpe , & rtP .
Saturation_LowerSat_gq5b2q5hog , & rtP . gate_Value , & rtP .
gate_Value_e2pzllcxv0 , & rtP . gate_Value_odvaswnitz , & rtP .
gate_Value_hrisjp3q0m , & rtP . gate_Value_jpjtjqpsyx , & rtP .
gate_Value_ggng0gfgd5 , & rtP . gate_Value_cczcurubvx , & rtP .
gate_Value_ppgtupoipm , & rtP . gate_Value_p3h3pv0zwg , & rtP .
gate_Value_iwryy13tik , & rtP . gate_Value_ahx5cowvm0 , & rtP .
gate_Value_hob43axlzj , & rtP . gate_Value_o02a13bzdb , & rtP .
gate_Value_ncgxatpho2 , & rtP . Constant_Value_ogegtmkzv0 , & rtP .
Constant_Value_h5irp45zuu , & rtP . Constant_Value_k5pwul1wle , & rtP .
Constant_Value_pp4lg2cwxs , & rtP . Constant_Value_khiqevv1tc , & rtP .
Constant_Value_cf12bsal0m , & rtP . Constant_Value_gpi13dm1iq , & rtP .
Constant_Value_aujhkhzu0m , } ; static int32_T * rtVarDimsAddrMap [ ] = { (
NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 , 0 } , {
"unsigned char" , "boolean_T" , 0 , 0 , sizeof ( boolean_T ) , SS_BOOLEAN , 0
, 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 2 , 2 , 0 } , {
rtwCAPI_VECTOR , 4 , 2 , 0 } , { rtwCAPI_VECTOR , 6 , 2 , 0 } , {
rtwCAPI_VECTOR , 8 , 2 , 0 } , { rtwCAPI_VECTOR , 10 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 12 , 2 , 0 } , { rtwCAPI_VECTOR , 14 , 2 , 0 } , {
rtwCAPI_VECTOR , 16 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 18 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 20 , 2 , 0 } , { rtwCAPI_VECTOR , 22 , 2 , 0 } , {
rtwCAPI_VECTOR , 24 , 2 , 0 } } ; static const uint_T rtDimensionArray [ ] =
{ 1 , 1 , 101 , 1 , 10 , 1 , 56 , 1 , 4 , 1 , 1 , 101 , 95 , 45 , 1 , 4 , 7 ,
1 , 95 , 39 , 2 , 28 , 1 , 28 , 28 , 1 } ; static const real_T
rtcapiStoredFloats [ ] = { 0.0 , 1.0 } ; static const rtwCAPI_FixPtMap
rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) , rtwCAPI_FIX_RESERVED , 0 , 0 , 0 }
, } ; static const rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const
void * ) & rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [
0 ] , 0 , 0 } , { ( const void * ) & rtcapiStoredFloats [ 0 ] , ( const void
* ) & rtcapiStoredFloats [ 1 ] , 1 , 0 } , { ( NULL ) , ( NULL ) , 9 , 0 } }
; static rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 455
, rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 347 ,
rtModelParameters , 0 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 1104052515U , 4259764605U , 10293365U , 4107771868U } , ( NULL ) , 0 , 0
, rt_LoggedStateIdxList } ; const rtwCAPI_ModelMappingStaticInfo *
activeBalancing4_GetCAPIStaticMap ( void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void activeBalancing4_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion ( (
* rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void activeBalancing4_host_InitializeDataMapInfo (
activeBalancing4_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
