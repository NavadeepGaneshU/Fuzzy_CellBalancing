#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "activeBalancing4.h"
#define GRTINTERFACE 1
#endif
