# Fuzzy_CellBalancer
Project repository of Fuzzy Cell Balancer. Implementing Li-Ion chemistry based active cell balancing. Current models are designed, simulated and valuated in MATLAB Simulink. 
