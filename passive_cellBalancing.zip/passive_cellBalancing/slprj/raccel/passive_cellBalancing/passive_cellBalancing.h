#ifndef RTW_HEADER_passive_cellBalancing_h_
#define RTW_HEADER_passive_cellBalancing_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap_simtarget.h"
#ifndef passive_cellBalancing_COMMON_INCLUDES_
#define passive_cellBalancing_COMMON_INCLUDES_
#include <stdlib.h>
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "rtwtypes.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "passive_cellBalancing_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rtGetInf.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
#define MODEL_NAME passive_cellBalancing
#define NSAMPLE_TIMES (3) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (66) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (0)   
#elif NCSTATES != 0
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T mjvjriaqf1 ; real_T iwg3uf4gow ; real_T hjevaumr0c ;
real_T onc44lw42c ; real_T lxt4khg2gr ; real_T dcxmkcvwrp ; real_T nwqbfvqhii
; real_T motansc1ll ; real_T lzsueoanmz ; real_T mjiupj41uc ; real_T
hr5m5k25h0 ; real_T acpftwtjmw ; real_T agtjzus4mb ; real_T ax3gewsxiw ;
real_T mum0x2jb0i ; real_T a5hdtqemrb ; real_T el1os0xk3p ; real_T dmmlegxb5k
; real_T gkflp5ycd1 ; real_T dr3dmc1br1 ; real_T om4odxhgrn ; real_T
hohs45nws1 ; real_T lz1jrcy1g1 ; real_T mohby5bkk0 ; real_T ifr4l3aglp ;
real_T hwspvdiqna ; real_T h0ohrdd4jd ; real_T gnfbmjv1kd ; real_T fsajkdm0eh
; real_T kt4i3eakjd ; real_T oawvzp4us4 ; real_T jmflq5t0rg ; real_T
nmhblmw2if ; real_T jus1psarxf ; real_T dzwffk2oci ; real_T joihb0qv3k ;
real_T fdxhchca4n [ 20 ] ; real_T pnhylngzop [ 16 ] ; real_T g0jp2bmgqd ;
real_T jir35ajm40 ; real_T gl1tfdyozx ; real_T c0jlhyxegg ; real_T ggq0mzmget
; real_T f5mbbavims ; real_T hwrfe4inel ; real_T puaah5a5v4 ; real_T
gxiis152id ; real_T j1svqdlmmu ; real_T nedmckl1ap ; real_T fbvg15yoxf ;
real_T bhljgeggu3 ; real_T o4q0knkfhp ; real_T e03bm2zbdm ; real_T mniup0awbm
; real_T nbtiexyflg ; real_T ehmsjwt2y2 ; real_T ldf12bxawt ; real_T
ppovsif5nu ; real_T aggsod1r3b ; real_T jjxxtqfeeb ; real_T cds1qoxtkz ;
real_T gielivfeiq ; real_T jge13amd3n ; real_T cpufh1imvv ; real_T pjbiqezomx
; real_T mtnqnf1tgq ; } B ; typedef struct { real_T akd2jqznao ; real_T
hgr5mesxnb ; real_T mt4lnyabvi ; real_T plmvxjbolt ; real_T ax0ggg2g2u ;
real_T fai3hsvf1n ; real_T dygpf1ihj5 ; real_T h04tbwqhfy ; real_T fcxyycf4fu
; real_T c00p5tpsbl ; real_T chrr3t52id ; real_T gcso21r0zq ; real_T
publma5mit ; real_T gqsgvislof ; real_T lgifnif3a5 ; real_T gwrfs10hrl ;
real_T hwcyuglaof ; real_T erhuzibllh ; real_T egiqzmrt1h ; real_T dwbi4pfdve
; real_T ngguotoe1s ; real_T jzwmczaemy ; real_T bv5z5dog4q ; real_T
nw2cetseby ; struct { void * AS ; void * BS ; void * CS ; void * DS ; void *
DX_COL ; void * BD_COL ; void * TMP1 ; void * TMP2 ; void * XTMP ; void *
SWITCH_STATUS ; void * SWITCH_STATUS_INIT ; void * SW_CHG ; void * G_STATE ;
void * USWLAST ; void * XKM12 ; void * XKP12 ; void * XLAST ; void * ULAST ;
void * IDX_SW_CHG ; void * Y_SWITCH ; void * SWITCH_TYPES ; void * IDX_OUT_SW
; void * SWITCH_TOPO_SAVED_IDX ; void * SWITCH_MAP ; } nopbrmbrmq ; struct {
void * LoggedData [ 4 ] ; } mcginysbcv ; struct { void * LoggedData [ 4 ] ; }
a3ftdsui15 ; struct { void * AQHandles [ 3 ] ; } d0qmjtu0wc ; struct { void *
AQHandles [ 3 ] ; } ogi3lqi4h3 ; struct { void * AQHandles [ 3 ] ; }
gdkxwpsnoh ; struct { void * AQHandles [ 3 ] ; } hbso4bjjpz ; struct { void *
AQHandles ; } ngziftwkrd ; struct { void * AQHandles ; } ejblfx2g3i ; struct
{ void * AQHandles ; } c2ed1fnksn ; struct { void * AQHandles ; } j4poblttty
; struct { void * AQHandles ; } f43wxvhzgt ; struct { void * AQHandles ; }
ghxaxtnllt ; struct { void * AQHandles ; } kt1yw354el ; struct { void *
AQHandles ; } d2ou5um4xo ; struct { void * AQHandles ; } f2agk1lwei ; struct
{ void * AQHandles ; } nyvkm1zm5h ; struct { void * AQHandles ; } nip5y111ia
; struct { void * AQHandles ; } i44rlgscpk ; int_T kigcmuxibu [ 11 ] ; int8_T
hgu1herpdu ; int8_T l2qjsqryqq ; int8_T pdurl3rulw ; int8_T gzqp4ynez5 ;
uint8_T l3kwie4ayw ; uint8_T io1i4lyocz ; uint8_T mxkplkbb4c ; uint8_T
fv1kok2dvs ; uint8_T hmdsgmwt5t ; uint8_T gdrkw3ubvp ; uint8_T keir5gxmdi ;
uint8_T gei4lsz0rp ; uint8_T mvkhilmq5l ; uint8_T b2kal4igyh ; uint8_T
jzijfqoq10 ; uint8_T lhseafldnw ; } DW ; typedef struct {
rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ; struct P_ { real_T
Battery_BatType ; real_T Battery1_BatType ; real_T Battery2_BatType ; real_T
Battery3_BatType ; real_T Saturation_UpperSat ; real_T Saturation_LowerSat ;
real_T Saturation_UpperSat_lxx4j3fnoa ; real_T Saturation_LowerSat_kwi433xk5g
; real_T Saturation_UpperSat_blj3ug4rzx ; real_T
Saturation_LowerSat_o0i20janpw ; real_T Saturation_UpperSat_c3l4zdyanc ;
real_T Saturation_LowerSat_ois5i0qecq ; real_T Constant_Value ; real_T
Constant_Value_efypwvyyax ; real_T Constant_Value_ogegtmkzv0 ; real_T
Constant_Value_pbqzqfbpnm ; real_T Constant_Value_hu3rmuppbn ; real_T
Constant_Value_h5irp45zuu ; real_T Constant_Value_bksqnhysc0 ; real_T
Constant_Value_owtewy0ssm ; real_T Constant_Value_k5pwul1wle ; real_T
Constant_Value_kcr3np2p0u ; real_T Constant_Value_cqdbuv5p1f ; real_T
Constant_Value_nkaxnatvkv ; real_T itinit1_InitialCondition ; real_T R2_Gain
; real_T Currentfilter_NumCoef ; real_T Currentfilter_DenCoef [ 2 ] ; real_T
Currentfilter_InitialStates ; real_T itinit_InitialCondition ; real_T
inti_gainval ; real_T inti_UpperSat ; real_T inti_LowerSat ; real_T Gain_Gain
; real_T R3_Gain ; real_T DiscreteTimeIntegrator_gainval ; real_T
DiscreteTimeIntegrator_IC ; real_T Memory2_InitialCondition ; real_T
itinit1_InitialCondition_l3j5mkh0dv ; real_T R2_Gain_jrqfqsl4vo ; real_T
Currentfilter_NumCoef_iro0wbjjxt ; real_T Currentfilter_DenCoef_l3txc5dehe [
2 ] ; real_T Currentfilter_InitialStates_owagqxfijb ; real_T
itinit_InitialCondition_pv4h4vt0ps ; real_T inti_gainval_cihsr01gna ; real_T
inti_UpperSat_itldayqrxp ; real_T inti_LowerSat_lz3gh0icex ; real_T
Gain_Gain_ozvwrv1fuy ; real_T R3_Gain_dgx1dntlxw ; real_T
DiscreteTimeIntegrator_gainval_gderi0p3qj ; real_T
DiscreteTimeIntegrator_IC_hmtkq2c0dj ; real_T
Memory2_InitialCondition_kg5jloynof ; real_T
itinit1_InitialCondition_go30gfvhlp ; real_T R2_Gain_fij43s2whq ; real_T
Currentfilter_NumCoef_lysterszrx ; real_T Currentfilter_DenCoef_i2hd2zaaxr [
2 ] ; real_T Currentfilter_InitialStates_f33gifoztx ; real_T
itinit_InitialCondition_nf4pvnucgc ; real_T inti_gainval_ev3cmzfwwq ; real_T
inti_UpperSat_nowwhgaxwk ; real_T inti_LowerSat_cwekkzbyq1 ; real_T
Gain_Gain_jbuudt1ftk ; real_T R3_Gain_de1tgv0zzw ; real_T
DiscreteTimeIntegrator_gainval_dnjz2mm3rw ; real_T
DiscreteTimeIntegrator_IC_gkofv4otem ; real_T
Memory2_InitialCondition_pmjxv0kff4 ; real_T
itinit1_InitialCondition_dgjqnmxq2c ; real_T R2_Gain_bawzgornhw ; real_T
Currentfilter_NumCoef_i44m2spe23 ; real_T Currentfilter_DenCoef_ecedmvii5j [
2 ] ; real_T Currentfilter_InitialStates_b3vhzanude ; real_T
itinit_InitialCondition_arquskxlx3 ; real_T inti_gainval_goukxg31nf ; real_T
inti_UpperSat_lz4hujw0ip ; real_T inti_LowerSat_prmo311ajg ; real_T
Gain_Gain_oyd440f2kz ; real_T R3_Gain_dbnoektfcm ; real_T
DiscreteTimeIntegrator_gainval_jfckqwmoq4 ; real_T
DiscreteTimeIntegrator_IC_epy4ipnsuc ; real_T
Memory2_InitialCondition_mn5xrqtpcm ; real_T StateSpace_DS_param [ 400 ] ;
real_T R4_Gain ; real_T Saturation_UpperSat_pcz043fnep ; real_T
Saturation_LowerSat_b05y2t0vvl ; real_T R4_Gain_ayggl2vp1n ; real_T
Saturation_UpperSat_aqwzuangfk ; real_T Saturation_LowerSat_bcd3czsgyq ;
real_T R4_Gain_ckkisgzyfx ; real_T Saturation_UpperSat_i3x3oscagf ; real_T
Saturation_LowerSat_gnz45aadu0 ; real_T R4_Gain_hqvi3z0ayd ; real_T
Saturation_UpperSat_ezdhxfyofu ; real_T Saturation_LowerSat_i2fffiw1vk ;
real_T donotdeletethisgain_Gain ; real_T donotdeletethisgain_Gain_bg3gl2myht
; real_T donotdeletethisgain_Gain_o42imifl5k ; real_T
donotdeletethisgain_Gain_esi3l1j2do ; real_T R_Gain ; real_T
R_Gain_g4gmpqe5wx ; real_T R_Gain_jixg1xytle ; real_T R_Gain_cwdppwgit4 ;
real_T Gain4_Gain ; real_T Gain1_Gain ; real_T Gain2_Gain ; real_T R1_Gain ;
real_T Gain4_Gain_kh00znyazs ; real_T Gain1_Gain_og11bwmhu2 ; real_T
Gain2_Gain_m4x3vq3y1f ; real_T R1_Gain_k1h1x1zryv ; real_T
Gain4_Gain_fstjjgzlds ; real_T Gain1_Gain_anymdqpqln ; real_T
Gain2_Gain_jptbha03po ; real_T R1_Gain_elo0441xsu ; real_T
Gain4_Gain_hul13ajzj3 ; real_T Gain1_Gain_m4axzds55u ; real_T
Gain2_Gain_exz2fvuzmi ; real_T R1_Gain_f1ushaohtw ; real_T
SwitchCurrents_Value [ 16 ] ; real_T Constant_Value_jorngiczgp ; real_T
Constant1_Value ; real_T Constant12_Value ; real_T Constant9_Value ; real_T
Constant1_Value_ks0gbwvaxk ; real_T Constant2_Value ; real_T Constant3_Value
; real_T Constant4_Value ; real_T Constant_Value_fzmb45jy2r ; real_T
Constant1_Value_jelmmtr1rj ; real_T Constant12_Value_df3z3yuypl ; real_T
Constant9_Value_bfo0fnc5l1 ; real_T Constant1_Value_jxqfbvs00y ; real_T
Constant2_Value_nbkvr3eqsy ; real_T Constant3_Value_k030zkojhy ; real_T
Constant4_Value_p1xz0cpgth ; real_T Constant_Value_kiu123temw ; real_T
Constant1_Value_jj3f5fu3xp ; real_T Constant12_Value_ktnzmkcekm ; real_T
Constant9_Value_nhyzz1ckmw ; real_T Constant1_Value_gbfcrdkgqa ; real_T
Constant2_Value_gnk2tjoo5o ; real_T Constant3_Value_hat1prtoip ; real_T
Constant4_Value_cmgjzabbd1 ; real_T Constant_Value_lfzq4ua142 ; real_T
Constant1_Value_mvsbgtlkyx ; real_T Constant12_Value_bncp0krrox ; real_T
Constant9_Value_mgshhdhohr ; real_T Constant1_Value_olpeyohdie ; real_T
Constant2_Value_mxw2f5zdvz ; real_T Constant3_Value_jcwsxsesu4 ; real_T
Constant4_Value_g4yqznci4m ; real_T Constant_Value_eczelweelu ; real_T
Constant1_Value_hdj1qeobnu ; real_T Constant2_Value_ct4fvdp3kc ; real_T
Constant3_Value_cddtuuqxak ; } ; extern const char *
RT_MEMORY_ALLOCATION_ERROR ; extern B rtB ; extern DW rtDW ; extern P rtP ;
extern mxArray * mr_passive_cellBalancing_GetDWork ( ) ; extern void
mr_passive_cellBalancing_SetDWork ( const mxArray * ssDW ) ; extern mxArray *
mr_passive_cellBalancing_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * passive_cellBalancing_GetCAPIStaticMap (
void ) ; extern SimStruct * const rtS ; extern const int_T gblNumToFiles ;
extern const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ;
extern rtInportTUtable * gblInportTUtables ; extern const char *
gblInportFileName ; extern const int_T gblNumRootInportBlks ; extern const
int_T gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ;
extern const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [
] ; extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
