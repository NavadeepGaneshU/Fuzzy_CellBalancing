#include "rt_logging_mmi.h"
#include "passive_cellBalancing_capi.h"
#include <math.h>
#include "passive_cellBalancing.h"
#include "passive_cellBalancing_private.h"
#include "passive_cellBalancing_dt.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 2 , & stopRequested ) ; }
rtExtModeShutdown ( 2 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 0 ; int_T gbl_raccel_NumST = 3 ; const char_T
* gbl_raccel_Version = "9.5 (R2021a) 14-Nov-2020" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 } ; const char * raccelLoadInputsAndAperiodicHitTimes (
SimStruct * S , const char * inportFileName , int * matFileFormat ) { return
rt_RAccelReadInportsMatFile ( S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
B rtB ; DW rtDW ; static SimStruct model_S ; SimStruct * const rtS = &
model_S ; void MdlInitialize ( void ) { boolean_T tmp ; rtDW . publma5mit =
rtP . itinit1_InitialCondition ; rtDW . akd2jqznao = rtP .
Currentfilter_InitialStates ; rtDW . gqsgvislof = rtP .
itinit_InitialCondition ; rtDW . hgu1herpdu = 2 ; rtDW . l3kwie4ayw = 1U ; if
( ssIsFirstInitCond ( rtS ) ) { tmp = slIsRapidAcceleratorSimulating ( ) ; if
( tmp ) { tmp = ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . l3kwie4ayw
= ( uint8_T ) ! tmp ; } else { rtDW . l3kwie4ayw = 1U ; } } rtDW . mt4lnyabvi
= rtP . DiscreteTimeIntegrator_IC ; rtDW . lgifnif3a5 = rtP .
Memory2_InitialCondition ; rtDW . gwrfs10hrl = rtP .
itinit1_InitialCondition_l3j5mkh0dv ; rtDW . plmvxjbolt = rtP .
Currentfilter_InitialStates_owagqxfijb ; rtDW . hwcyuglaof = rtP .
itinit_InitialCondition_pv4h4vt0ps ; rtDW . l2qjsqryqq = 2 ; rtDW .
fv1kok2dvs = 1U ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . fv1kok2dvs = ( uint8_T ) !
tmp ; } else { rtDW . fv1kok2dvs = 1U ; } } rtDW . fai3hsvf1n = rtP .
DiscreteTimeIntegrator_IC_hmtkq2c0dj ; rtDW . erhuzibllh = rtP .
Memory2_InitialCondition_kg5jloynof ; rtDW . egiqzmrt1h = rtP .
itinit1_InitialCondition_go30gfvhlp ; rtDW . dygpf1ihj5 = rtP .
Currentfilter_InitialStates_f33gifoztx ; rtDW . dwbi4pfdve = rtP .
itinit_InitialCondition_nf4pvnucgc ; rtDW . pdurl3rulw = 2 ; rtDW .
keir5gxmdi = 1U ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . keir5gxmdi = ( uint8_T ) !
tmp ; } else { rtDW . keir5gxmdi = 1U ; } } rtDW . fcxyycf4fu = rtP .
DiscreteTimeIntegrator_IC_gkofv4otem ; rtDW . ngguotoe1s = rtP .
Memory2_InitialCondition_pmjxv0kff4 ; rtDW . jzwmczaemy = rtP .
itinit1_InitialCondition_dgjqnmxq2c ; rtDW . c00p5tpsbl = rtP .
Currentfilter_InitialStates_b3vhzanude ; rtDW . bv5z5dog4q = rtP .
itinit_InitialCondition_arquskxlx3 ; rtDW . gzqp4ynez5 = 2 ; rtDW .
b2kal4igyh = 1U ; if ( ssIsFirstInitCond ( rtS ) ) { tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . b2kal4igyh = ( uint8_T ) !
tmp ; } else { rtDW . b2kal4igyh = 1U ; } } rtDW . gcso21r0zq = rtP .
DiscreteTimeIntegrator_IC_epy4ipnsuc ; rtDW . nw2cetseby = rtP .
Memory2_InitialCondition_mn5xrqtpcm ; { int32_T i , j ; real_T * Ds = (
real_T * ) rtDW . nopbrmbrmq . DS ; for ( i = 0 ; i < 20 ; i ++ ) { for ( j =
0 ; j < 20 ; j ++ ) Ds [ i * 20 + j ] = ( rtP . StateSpace_DS_param [ i + j *
20 ] ) ; } { int_T * switch_status = ( int_T * ) rtDW . nopbrmbrmq .
SWITCH_STATUS ; int_T * gState = ( int_T * ) rtDW . nopbrmbrmq . G_STATE ;
real_T * yswitch = ( real_T * ) rtDW . nopbrmbrmq . Y_SWITCH ; int_T *
switchTypes = ( int_T * ) rtDW . nopbrmbrmq . SWITCH_TYPES ; int_T * idxOutSw
= ( int_T * ) rtDW . nopbrmbrmq . IDX_OUT_SW ; int_T * switch_status_init = (
int_T * ) rtDW . nopbrmbrmq . SWITCH_STATUS_INIT ; switch_status [ 0 ] = 0 ;
switch_status_init [ 0 ] = 0 ; gState [ 0 ] = ( int_T ) 0.0 ; yswitch [ 0 ] =
1 / 0.1 ; switchTypes [ 0 ] = ( int_T ) 1.0 ; idxOutSw [ 0 ] = ( ( int_T )
0.0 ) - 1 ; switch_status [ 1 ] = 0 ; switch_status_init [ 1 ] = 0 ; gState [
1 ] = ( int_T ) 0.0 ; yswitch [ 1 ] = 1 / 0.1 ; switchTypes [ 1 ] = ( int_T )
1.0 ; idxOutSw [ 1 ] = ( ( int_T ) 0.0 ) - 1 ; switch_status [ 2 ] = 0 ;
switch_status_init [ 2 ] = 0 ; gState [ 2 ] = ( int_T ) 0.0 ; yswitch [ 2 ] =
1 / 0.1 ; switchTypes [ 2 ] = ( int_T ) 1.0 ; idxOutSw [ 2 ] = ( ( int_T )
0.0 ) - 1 ; switch_status [ 3 ] = 0 ; switch_status_init [ 3 ] = 0 ; gState [
3 ] = ( int_T ) 0.0 ; yswitch [ 3 ] = 1 / 0.1 ; switchTypes [ 3 ] = ( int_T )
1.0 ; idxOutSw [ 3 ] = ( ( int_T ) 0.0 ) - 1 ; switch_status [ 4 ] = 0 ;
switch_status_init [ 4 ] = 0 ; gState [ 4 ] = ( int_T ) 0.0 ; yswitch [ 4 ] =
1 / 8.0 ; switchTypes [ 4 ] = ( int_T ) 1.0 ; idxOutSw [ 4 ] = ( ( int_T )
0.0 ) - 1 ; switch_status [ 5 ] = 0 ; switch_status_init [ 5 ] = 0 ; gState [
5 ] = ( int_T ) 0.0 ; yswitch [ 5 ] = 1 / 8.0 ; switchTypes [ 5 ] = ( int_T )
1.0 ; idxOutSw [ 5 ] = ( ( int_T ) 0.0 ) - 1 ; switch_status [ 6 ] = 0 ;
switch_status_init [ 6 ] = 0 ; gState [ 6 ] = ( int_T ) 0.0 ; yswitch [ 6 ] =
1 / 8.0 ; switchTypes [ 6 ] = ( int_T ) 1.0 ; idxOutSw [ 6 ] = ( ( int_T )
0.0 ) - 1 ; switch_status [ 7 ] = 0 ; switch_status_init [ 7 ] = 0 ; gState [
7 ] = ( int_T ) 0.0 ; yswitch [ 7 ] = 1 / 8.0 ; switchTypes [ 7 ] = ( int_T )
1.0 ; idxOutSw [ 7 ] = ( ( int_T ) 0.0 ) - 1 ; switch_status [ 8 ] = 0 ;
switch_status_init [ 8 ] = 0 ; gState [ 8 ] = ( int_T ) 0.0 ; yswitch [ 8 ] =
1 / 0.01 ; switchTypes [ 8 ] = ( int_T ) 3.0 ; idxOutSw [ 8 ] = ( ( int_T )
0.0 ) - 1 ; switch_status [ 9 ] = 0 ; switch_status_init [ 9 ] = 0 ; gState [
9 ] = ( int_T ) 0.0 ; yswitch [ 9 ] = 1 / 0.01 ; switchTypes [ 9 ] = ( int_T
) 3.0 ; idxOutSw [ 9 ] = ( ( int_T ) 0.0 ) - 1 ; switch_status [ 10 ] = 0 ;
switch_status_init [ 10 ] = 0 ; gState [ 10 ] = ( int_T ) 0.0 ; yswitch [ 10
] = 1 / 0.01 ; switchTypes [ 10 ] = ( int_T ) 3.0 ; idxOutSw [ 10 ] = ( (
int_T ) 0.0 ) - 1 ; switch_status [ 11 ] = 0 ; switch_status_init [ 11 ] = 0
; gState [ 11 ] = ( int_T ) 0.0 ; yswitch [ 11 ] = 1 / 0.01 ; switchTypes [
11 ] = ( int_T ) 3.0 ; idxOutSw [ 11 ] = ( ( int_T ) 0.0 ) - 1 ;
switch_status [ 12 ] = 0 ; switch_status_init [ 12 ] = 0 ; gState [ 12 ] = (
int_T ) 0.0 ; yswitch [ 12 ] = 1 / 0.01 ; switchTypes [ 12 ] = ( int_T ) 3.0
; idxOutSw [ 12 ] = ( ( int_T ) 0.0 ) - 1 ; switch_status [ 13 ] = 0 ;
switch_status_init [ 13 ] = 0 ; gState [ 13 ] = ( int_T ) 0.0 ; yswitch [ 13
] = 1 / 0.01 ; switchTypes [ 13 ] = ( int_T ) 3.0 ; idxOutSw [ 13 ] = ( (
int_T ) 0.0 ) - 1 ; switch_status [ 14 ] = 0 ; switch_status_init [ 14 ] = 0
; gState [ 14 ] = ( int_T ) 0.0 ; yswitch [ 14 ] = 1 / 0.01 ; switchTypes [
14 ] = ( int_T ) 3.0 ; idxOutSw [ 14 ] = ( ( int_T ) 0.0 ) - 1 ;
switch_status [ 15 ] = 0 ; switch_status_init [ 15 ] = 0 ; gState [ 15 ] = (
int_T ) 0.0 ; yswitch [ 15 ] = 1 / 0.01 ; switchTypes [ 15 ] = ( int_T ) 3.0
; idxOutSw [ 15 ] = ( ( int_T ) 0.0 ) - 1 ; } } } void MdlStart ( void ) { {
bool externalInputIsInDatasetFormat = false ; void * pISigstreamManager =
rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} { { { { sdiSignalSourceInfoU srcInfo ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"passive_cellBalancing/Battery1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; const char_T * leafUnits [ 3 ] = { "" , "" , "" } ;
sdiVirtualBusLeafElementInfoU leafElInfo [ 3 ] ; int_T childDimsArray0 [ 1 ]
= { 1 } ; int_T childDimsArray1 [ 1 ] = { 1 } ; int_T childDimsArray2 [ 1 ] =
{ 1 } ; { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 0 ]
. hDataType = hDT ; leafElInfo [ 0 ] . signalName = sdiGetLabelFromChars (
".SOC____" ) ; leafElInfo [ 0 ] . dims . nDims = 1 ; leafElInfo [ 0 ] . dims
. dimensions = childDimsArray0 ; leafElInfo [ 0 ] . dimsMode =
DIMENSIONS_MODE_FIXED ; leafElInfo [ 0 ] . complexity = REAL ; leafElInfo [ 0
] . isLinearInterp = 0 ; leafElInfo [ 0 ] . units = leafUnits [ 0 ] ; } {
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; leafElInfo [ 1 ] . hDataType = hDT ; leafElInfo [ 1 ] .
signalName = sdiGetLabelFromChars ( ".Current__A_" ) ; leafElInfo [ 1 ] .
dims . nDims = 1 ; leafElInfo [ 1 ] . dims . dimensions = childDimsArray1 ;
leafElInfo [ 1 ] . dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 1 ] .
complexity = REAL ; leafElInfo [ 1 ] . isLinearInterp = 0 ; leafElInfo [ 1 ]
. units = leafUnits [ 1 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 2 ]
. hDataType = hDT ; leafElInfo [ 2 ] . signalName = sdiGetLabelFromChars (
".Voltage__V_" ) ; leafElInfo [ 2 ] . dims . nDims = 1 ; leafElInfo [ 2 ] .
dims . dimensions = childDimsArray2 ; leafElInfo [ 2 ] . dimsMode =
DIMENSIONS_MODE_FIXED ; leafElInfo [ 2 ] . complexity = REAL ; leafElInfo [ 2
] . isLinearInterp = 0 ; leafElInfo [ 2 ] . units = leafUnits [ 2 ] ; }
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ;
sdiCreateAsyncQueuesForVirtualBusWithExportSettings ( & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"5f9e33a3-219d-49bb-8f8a-28e406140f0f" , 3 , leafElInfo , & rtDW . d0qmjtu0wc
. AQHandles [ 0 ] , 1 , 0 , "" , "" , "" ) ; slsaCacheDWorkDataForSimTargetOP
( rtS , & rtDW . d0qmjtu0wc . AQHandles [ 0 ] , 3 * sizeof ( & rtDW .
d0qmjtu0wc . AQHandles [ 0 ] ) ) ; if ( rtDW . d0qmjtu0wc . AQHandles [ 0 ] )
{ sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName
= sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars (
"" ) ; sdiSetSignalSampleTimeString ( rtDW . d0qmjtu0wc . AQHandles [ 0 ] ,
"Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW .
d0qmjtu0wc . AQHandles [ 0 ] , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . d0qmjtu0wc . AQHandles [ 0 ] , 1
, 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . d0qmjtu0wc . AQHandles [ 0 ]
, loggedName , origSigName , propName ) ; sdiSetSignalSampleTimeString ( rtDW
. d0qmjtu0wc . AQHandles [ 1 ] , "5e-05" , 5.0E-5 , ssGetTFinal ( rtS ) ) ;
sdiSetRunStartTime ( rtDW . d0qmjtu0wc . AQHandles [ 1 ] , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . d0qmjtu0wc .
AQHandles [ 1 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
d0qmjtu0wc . AQHandles [ 1 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( rtDW . d0qmjtu0wc . AQHandles [ 2 ] ,
"Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW .
d0qmjtu0wc . AQHandles [ 2 ] , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . d0qmjtu0wc . AQHandles [ 2 ] , 1
, 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . d0qmjtu0wc . AQHandles [ 2 ]
, loggedName , origSigName , propName ) ; sdiFreeLabel ( loggedName ) ;
sdiFreeLabel ( origSigName ) ; sdiFreeLabel ( propName ) ; } sdiFreeLabel (
sigName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; sdiFreeName ( leafElInfo [ 0 ] . signalName ) ;
sdiFreeName ( leafElInfo [ 1 ] . signalName ) ; sdiFreeName ( leafElInfo [ 2
] . signalName ) ; } } } } { { { { sdiSignalSourceInfoU srcInfo ; sdiLabelU
sigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "passive_cellBalancing/Battery2" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; const char_T * leafUnits [ 3 ] = { "" , "" , ""
} ; sdiVirtualBusLeafElementInfoU leafElInfo [ 3 ] ; int_T childDimsArray0 [
1 ] = { 1 } ; int_T childDimsArray1 [ 1 ] = { 1 } ; int_T childDimsArray2 [ 1
] = { 1 } ; { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 0 ]
. hDataType = hDT ; leafElInfo [ 0 ] . signalName = sdiGetLabelFromChars (
".SOC____" ) ; leafElInfo [ 0 ] . dims . nDims = 1 ; leafElInfo [ 0 ] . dims
. dimensions = childDimsArray0 ; leafElInfo [ 0 ] . dimsMode =
DIMENSIONS_MODE_FIXED ; leafElInfo [ 0 ] . complexity = REAL ; leafElInfo [ 0
] . isLinearInterp = 0 ; leafElInfo [ 0 ] . units = leafUnits [ 0 ] ; } {
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; leafElInfo [ 1 ] . hDataType = hDT ; leafElInfo [ 1 ] .
signalName = sdiGetLabelFromChars ( ".Current__A_" ) ; leafElInfo [ 1 ] .
dims . nDims = 1 ; leafElInfo [ 1 ] . dims . dimensions = childDimsArray1 ;
leafElInfo [ 1 ] . dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 1 ] .
complexity = REAL ; leafElInfo [ 1 ] . isLinearInterp = 0 ; leafElInfo [ 1 ]
. units = leafUnits [ 1 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 2 ]
. hDataType = hDT ; leafElInfo [ 2 ] . signalName = sdiGetLabelFromChars (
".Voltage__V_" ) ; leafElInfo [ 2 ] . dims . nDims = 1 ; leafElInfo [ 2 ] .
dims . dimensions = childDimsArray2 ; leafElInfo [ 2 ] . dimsMode =
DIMENSIONS_MODE_FIXED ; leafElInfo [ 2 ] . complexity = REAL ; leafElInfo [ 2
] . isLinearInterp = 0 ; leafElInfo [ 2 ] . units = leafUnits [ 2 ] ; }
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ;
sdiCreateAsyncQueuesForVirtualBusWithExportSettings ( & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"6c86ba7b-67d8-43bb-b95b-a62692a26d1d" , 3 , leafElInfo , & rtDW . ogi3lqi4h3
. AQHandles [ 0 ] , 1 , 0 , "" , "" , "" ) ; slsaCacheDWorkDataForSimTargetOP
( rtS , & rtDW . ogi3lqi4h3 . AQHandles [ 0 ] , 3 * sizeof ( & rtDW .
ogi3lqi4h3 . AQHandles [ 0 ] ) ) ; if ( rtDW . ogi3lqi4h3 . AQHandles [ 0 ] )
{ sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName
= sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars (
"" ) ; sdiSetSignalSampleTimeString ( rtDW . ogi3lqi4h3 . AQHandles [ 0 ] ,
"Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW .
ogi3lqi4h3 . AQHandles [ 0 ] , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . ogi3lqi4h3 . AQHandles [ 0 ] , 1
, 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . ogi3lqi4h3 . AQHandles [ 0 ]
, loggedName , origSigName , propName ) ; sdiSetSignalSampleTimeString ( rtDW
. ogi3lqi4h3 . AQHandles [ 1 ] , "5e-05" , 5.0E-5 , ssGetTFinal ( rtS ) ) ;
sdiSetRunStartTime ( rtDW . ogi3lqi4h3 . AQHandles [ 1 ] , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . ogi3lqi4h3 .
AQHandles [ 1 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
ogi3lqi4h3 . AQHandles [ 1 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( rtDW . ogi3lqi4h3 . AQHandles [ 2 ] ,
"Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW .
ogi3lqi4h3 . AQHandles [ 2 ] , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . ogi3lqi4h3 . AQHandles [ 2 ] , 1
, 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . ogi3lqi4h3 . AQHandles [ 2 ]
, loggedName , origSigName , propName ) ; sdiFreeLabel ( loggedName ) ;
sdiFreeLabel ( origSigName ) ; sdiFreeLabel ( propName ) ; } sdiFreeLabel (
sigName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; sdiFreeName ( leafElInfo [ 0 ] . signalName ) ;
sdiFreeName ( leafElInfo [ 1 ] . signalName ) ; sdiFreeName ( leafElInfo [ 2
] . signalName ) ; } } } } { { { { sdiSignalSourceInfoU srcInfo ; sdiLabelU
sigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "passive_cellBalancing/Battery3" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; const char_T * leafUnits [ 3 ] = { "" , "" , ""
} ; sdiVirtualBusLeafElementInfoU leafElInfo [ 3 ] ; int_T childDimsArray0 [
1 ] = { 1 } ; int_T childDimsArray1 [ 1 ] = { 1 } ; int_T childDimsArray2 [ 1
] = { 1 } ; { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 0 ]
. hDataType = hDT ; leafElInfo [ 0 ] . signalName = sdiGetLabelFromChars (
".SOC____" ) ; leafElInfo [ 0 ] . dims . nDims = 1 ; leafElInfo [ 0 ] . dims
. dimensions = childDimsArray0 ; leafElInfo [ 0 ] . dimsMode =
DIMENSIONS_MODE_FIXED ; leafElInfo [ 0 ] . complexity = REAL ; leafElInfo [ 0
] . isLinearInterp = 0 ; leafElInfo [ 0 ] . units = leafUnits [ 0 ] ; } {
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; leafElInfo [ 1 ] . hDataType = hDT ; leafElInfo [ 1 ] .
signalName = sdiGetLabelFromChars ( ".Current__A_" ) ; leafElInfo [ 1 ] .
dims . nDims = 1 ; leafElInfo [ 1 ] . dims . dimensions = childDimsArray1 ;
leafElInfo [ 1 ] . dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 1 ] .
complexity = REAL ; leafElInfo [ 1 ] . isLinearInterp = 0 ; leafElInfo [ 1 ]
. units = leafUnits [ 1 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 2 ]
. hDataType = hDT ; leafElInfo [ 2 ] . signalName = sdiGetLabelFromChars (
".Voltage__V_" ) ; leafElInfo [ 2 ] . dims . nDims = 1 ; leafElInfo [ 2 ] .
dims . dimensions = childDimsArray2 ; leafElInfo [ 2 ] . dimsMode =
DIMENSIONS_MODE_FIXED ; leafElInfo [ 2 ] . complexity = REAL ; leafElInfo [ 2
] . isLinearInterp = 0 ; leafElInfo [ 2 ] . units = leafUnits [ 2 ] ; }
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ;
sdiCreateAsyncQueuesForVirtualBusWithExportSettings ( & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"cd604602-802f-4070-b84a-3bcca05c8bce" , 3 , leafElInfo , & rtDW . gdkxwpsnoh
. AQHandles [ 0 ] , 1 , 0 , "" , "" , "" ) ; slsaCacheDWorkDataForSimTargetOP
( rtS , & rtDW . gdkxwpsnoh . AQHandles [ 0 ] , 3 * sizeof ( & rtDW .
gdkxwpsnoh . AQHandles [ 0 ] ) ) ; if ( rtDW . gdkxwpsnoh . AQHandles [ 0 ] )
{ sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName
= sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars (
"" ) ; sdiSetSignalSampleTimeString ( rtDW . gdkxwpsnoh . AQHandles [ 0 ] ,
"Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW .
gdkxwpsnoh . AQHandles [ 0 ] , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . gdkxwpsnoh . AQHandles [ 0 ] , 1
, 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . gdkxwpsnoh . AQHandles [ 0 ]
, loggedName , origSigName , propName ) ; sdiSetSignalSampleTimeString ( rtDW
. gdkxwpsnoh . AQHandles [ 1 ] , "5e-05" , 5.0E-5 , ssGetTFinal ( rtS ) ) ;
sdiSetRunStartTime ( rtDW . gdkxwpsnoh . AQHandles [ 1 ] , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . gdkxwpsnoh .
AQHandles [ 1 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
gdkxwpsnoh . AQHandles [ 1 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( rtDW . gdkxwpsnoh . AQHandles [ 2 ] ,
"Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW .
gdkxwpsnoh . AQHandles [ 2 ] , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . gdkxwpsnoh . AQHandles [ 2 ] , 1
, 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . gdkxwpsnoh . AQHandles [ 2 ]
, loggedName , origSigName , propName ) ; sdiFreeLabel ( loggedName ) ;
sdiFreeLabel ( origSigName ) ; sdiFreeLabel ( propName ) ; } sdiFreeLabel (
sigName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; sdiFreeName ( leafElInfo [ 0 ] . signalName ) ;
sdiFreeName ( leafElInfo [ 1 ] . signalName ) ; sdiFreeName ( leafElInfo [ 2
] . signalName ) ; } } } } { { { { sdiSignalSourceInfoU srcInfo ; sdiLabelU
sigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "passive_cellBalancing/Battery" ) ; sdiLabelU blockSID
= sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( ""
) ; const char_T * leafUnits [ 3 ] = { "" , "" , "" } ;
sdiVirtualBusLeafElementInfoU leafElInfo [ 3 ] ; int_T childDimsArray0 [ 1 ]
= { 1 } ; int_T childDimsArray1 [ 1 ] = { 1 } ; int_T childDimsArray2 [ 1 ] =
{ 1 } ; { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 0 ]
. hDataType = hDT ; leafElInfo [ 0 ] . signalName = sdiGetLabelFromChars (
".SOC____" ) ; leafElInfo [ 0 ] . dims . nDims = 1 ; leafElInfo [ 0 ] . dims
. dimensions = childDimsArray0 ; leafElInfo [ 0 ] . dimsMode =
DIMENSIONS_MODE_FIXED ; leafElInfo [ 0 ] . complexity = REAL ; leafElInfo [ 0
] . isLinearInterp = 0 ; leafElInfo [ 0 ] . units = leafUnits [ 0 ] ; } {
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; leafElInfo [ 1 ] . hDataType = hDT ; leafElInfo [ 1 ] .
signalName = sdiGetLabelFromChars ( ".Current__A_" ) ; leafElInfo [ 1 ] .
dims . nDims = 1 ; leafElInfo [ 1 ] . dims . dimensions = childDimsArray1 ;
leafElInfo [ 1 ] . dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 1 ] .
complexity = REAL ; leafElInfo [ 1 ] . isLinearInterp = 0 ; leafElInfo [ 1 ]
. units = leafUnits [ 1 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 2 ]
. hDataType = hDT ; leafElInfo [ 2 ] . signalName = sdiGetLabelFromChars (
".Voltage__V_" ) ; leafElInfo [ 2 ] . dims . nDims = 1 ; leafElInfo [ 2 ] .
dims . dimensions = childDimsArray2 ; leafElInfo [ 2 ] . dimsMode =
DIMENSIONS_MODE_FIXED ; leafElInfo [ 2 ] . complexity = REAL ; leafElInfo [ 2
] . isLinearInterp = 0 ; leafElInfo [ 2 ] . units = leafUnits [ 2 ] ; }
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ;
sdiCreateAsyncQueuesForVirtualBusWithExportSettings ( & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"8095d44b-e076-4f09-9b06-e1c3b57ffb72" , 3 , leafElInfo , & rtDW . hbso4bjjpz
. AQHandles [ 0 ] , 1 , 0 , "" , "" , "" ) ; slsaCacheDWorkDataForSimTargetOP
( rtS , & rtDW . hbso4bjjpz . AQHandles [ 0 ] , 3 * sizeof ( & rtDW .
hbso4bjjpz . AQHandles [ 0 ] ) ) ; if ( rtDW . hbso4bjjpz . AQHandles [ 0 ] )
{ sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName
= sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars (
"" ) ; sdiSetSignalSampleTimeString ( rtDW . hbso4bjjpz . AQHandles [ 0 ] ,
"Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW .
hbso4bjjpz . AQHandles [ 0 ] , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . hbso4bjjpz . AQHandles [ 0 ] , 1
, 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . hbso4bjjpz . AQHandles [ 0 ]
, loggedName , origSigName , propName ) ; sdiSetSignalSampleTimeString ( rtDW
. hbso4bjjpz . AQHandles [ 1 ] , "5e-05" , 5.0E-5 , ssGetTFinal ( rtS ) ) ;
sdiSetRunStartTime ( rtDW . hbso4bjjpz . AQHandles [ 1 ] , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . hbso4bjjpz .
AQHandles [ 1 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
hbso4bjjpz . AQHandles [ 1 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( rtDW . hbso4bjjpz . AQHandles [ 2 ] ,
"Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW .
hbso4bjjpz . AQHandles [ 2 ] , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . hbso4bjjpz . AQHandles [ 2 ] , 1
, 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . hbso4bjjpz . AQHandles [ 2 ]
, loggedName , origSigName , propName ) ; sdiFreeLabel ( loggedName ) ;
sdiFreeLabel ( origSigName ) ; sdiFreeLabel ( propName ) ; } sdiFreeLabel (
sigName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; sdiFreeName ( leafElInfo [ 0 ] . signalName ) ;
sdiFreeName ( leafElInfo [ 1 ] . signalName ) ; sdiFreeName ( leafElInfo [ 2
] . signalName ) ; } } } } { { { { sdiSignalSourceInfoU srcInfo ; sdiLabelU
loggedName = sdiGetLabelFromChars ( "<SOC (%)>" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "<SOC (%)>" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"passive_cellBalancing/Bus Selector1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "<SOC (%)>" )
; sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . ngziftwkrd . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "9d0414ef-a727-46ad-bd2e-bacd081e2ffc" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. ngziftwkrd . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . ngziftwkrd
. AQHandles , "Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime
( rtDW . ngziftwkrd . AQHandles , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . ngziftwkrd . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . ngziftwkrd . AQHandles ,
loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } } { { { { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "<Current (A)>" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "<Current (A)>" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"passive_cellBalancing/Bus Selector1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ejblfx2g3i . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"0d25e0ef-cc35-4a6d-92ec-caa8ca01d5d2" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . ejblfx2g3i . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . ejblfx2g3i . AQHandles , "5e-05" ,
5.0E-5 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . ejblfx2g3i .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . ejblfx2g3i . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . ejblfx2g3i . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<SOC (%)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" )
; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "passive_cellBalancing/Bus Selector2" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<SOC (%)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. c2ed1fnksn . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"86a86222-044d-4782-80e9-c71ffdc18842" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . c2ed1fnksn . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . c2ed1fnksn . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . c2ed1fnksn .
AQHandles , ssGetTaskTime ( rtS , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . c2ed1fnksn . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . c2ed1fnksn . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars (
"passive_cellBalancing/Bus Selector2" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. j4poblttty . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"339b2f78-aeed-4e22-8545-04c07c65cca7" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . j4poblttty . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . j4poblttty . AQHandles , "5e-05" ,
5.0E-5 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . j4poblttty .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . j4poblttty . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . j4poblttty . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<SOC (%)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" )
; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "passive_cellBalancing/Bus Selector3" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<SOC (%)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. f43wxvhzgt . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"7153169e-3699-4f7b-b8ea-0bb4a0899ba0" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . f43wxvhzgt . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . f43wxvhzgt . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . f43wxvhzgt .
AQHandles , ssGetTaskTime ( rtS , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . f43wxvhzgt . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . f43wxvhzgt . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars (
"passive_cellBalancing/Bus Selector3" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ghxaxtnllt . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"5fd3b5e2-0181-4b22-b7b7-d276e4b31cd1" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . ghxaxtnllt . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . ghxaxtnllt . AQHandles , "5e-05" ,
5.0E-5 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . ghxaxtnllt .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . ghxaxtnllt . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . ghxaxtnllt . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<SOC (%)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "<SOC (%)>" )
; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "passive_cellBalancing/Bus Selector" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "<SOC (%)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. kt1yw354el . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"896ac942-bb62-447b-b3c2-059443f5d1ef" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . kt1yw354el . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . kt1yw354el . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . kt1yw354el .
AQHandles , ssGetTaskTime ( rtS , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . kt1yw354el . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . kt1yw354el . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiLabelU blockPath = sdiGetLabelFromChars (
"passive_cellBalancing/Bus Selector" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars (
"<Current (A)>" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. d2ou5um4xo . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"62cbee9b-204b-42c3-b26e-36ca8479b24c" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . d2ou5um4xo . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . d2ou5um4xo . AQHandles , "5e-05" ,
5.0E-5 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . d2ou5um4xo .
AQHandles , ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . d2ou5um4xo . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . d2ou5um4xo . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "passive_cellBalancing/From1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . f2agk1lwei . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "87919c50-d089-44e2-85a4-5c3ff9170242" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. f2agk1lwei . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . f2agk1lwei
. AQHandles , "Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime
( rtDW . f2agk1lwei . AQHandles , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . f2agk1lwei . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . f2agk1lwei . AQHandles ,
loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } } { { { { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"passive_cellBalancing/From2" ) ; sdiLabelU blockSID = sdiGetLabelFromChars (
"" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ;
sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1
; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. nyvkm1zm5h . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"f23400b7-cce5-458e-914c-7424472d61f0" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . nyvkm1zm5h . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . nyvkm1zm5h . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . nyvkm1zm5h .
AQHandles , ssGetTaskTime ( rtS , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . nyvkm1zm5h . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . nyvkm1zm5h . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } { { { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "passive_cellBalancing/From3" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . nip5y111ia . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "15d92e5f-bb4c-4b80-a752-32dfe793abf6" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. nip5y111ia . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . nip5y111ia
. AQHandles , "Continuous" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime
( rtDW . nip5y111ia . AQHandles , ssGetTaskTime ( rtS , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . nip5y111ia . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . nip5y111ia . AQHandles ,
loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } } { { { { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars ( "passive_cellBalancing/From"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. i44rlgscpk . AQHandles = sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"2d126a75-4d2c-4f1a-b489-eb47395a11d0" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW . i44rlgscpk . AQHandles )
{ sdiSetSignalSampleTimeString ( rtDW . i44rlgscpk . AQHandles , "Continuous"
, 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetRunStartTime ( rtDW . i44rlgscpk .
AQHandles , ssGetTaskTime ( rtS , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . i44rlgscpk . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . i44rlgscpk . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } } } rtDW .
io1i4lyocz = 0U ; rtDW . mxkplkbb4c = 0U ; rtDW . hmdsgmwt5t = 0U ; rtDW .
gdrkw3ubvp = 0U ; rtDW . gei4lsz0rp = 0U ; rtDW . mvkhilmq5l = 0U ; rtDW .
jzijfqoq10 = 0U ; rtDW . lhseafldnw = 0U ; { rtDW . nopbrmbrmq . DS = (
real_T * ) calloc ( 20 * 20 , sizeof ( real_T ) ) ; rtDW . nopbrmbrmq .
DX_COL = ( real_T * ) calloc ( 20 , sizeof ( real_T ) ) ; rtDW . nopbrmbrmq .
TMP2 = ( real_T * ) calloc ( 20 , sizeof ( real_T ) ) ; rtDW . nopbrmbrmq .
SWITCH_STATUS = ( int_T * ) calloc ( 16 , sizeof ( int_T ) ) ; rtDW .
nopbrmbrmq . SW_CHG = ( int_T * ) calloc ( 16 , sizeof ( int_T ) ) ; rtDW .
nopbrmbrmq . G_STATE = ( int_T * ) calloc ( 16 , sizeof ( int_T ) ) ; rtDW .
nopbrmbrmq . Y_SWITCH = ( real_T * ) calloc ( 16 , sizeof ( real_T ) ) ; rtDW
. nopbrmbrmq . SWITCH_TYPES = ( int_T * ) calloc ( 16 , sizeof ( int_T ) ) ;
rtDW . nopbrmbrmq . IDX_OUT_SW = ( int_T * ) calloc ( 16 , sizeof ( int_T ) )
; rtDW . nopbrmbrmq . SWITCH_STATUS_INIT = ( int_T * ) calloc ( 16 , sizeof (
int_T ) ) ; rtDW . nopbrmbrmq . USWLAST = ( real_T * ) calloc ( 16 , sizeof (
real_T ) ) ; } MdlInitialize ( ) ; } void MdlOutputs ( int_T tid ) { real_T
a4cp20wioy ; real_T acbfked10g ; real_T ago2urujjb ; real_T bufw31vrar ;
real_T bz3towpjlr ; real_T c3oi34j1sp ; real_T c51hignkuk ; real_T cbztqtokqr
; real_T d1cotbw5h2 ; real_T dserhmea0y ; real_T dzxxkcwprr ; real_T
ecwkayc3c1 ; real_T f3vzhq4cwb ; real_T f4iylapppx ; real_T gepxctcr13 ;
real_T h3qb50hsvn ; real_T hnlb3fod4f ; real_T hrhabi5ifh ; real_T hyrw0mh4op
; real_T jmuz0todoh ; real_T k0qu5tzxih ; real_T k1frgvfwab ; real_T
kksikb3eww ; real_T ly3ezf414h ; real_T lzh3qxo4te ; real_T mbg4nhss5v ;
real_T mruxiin0wh ; real_T mu42bjiqp4 ; real_T n0hvyxgkxv ; real_T n43q2mtyxz
; real_T nd4n3q2ebz ; real_T nsev50c5ac ; real_T o3kmalb05k ; real_T
oblrkwwnkx ; real_T omprktok4g ; real_T or415koses ; int16_T S1 ; int16_T S2
; int16_T S3 ; int16_T S4 ; int16_T minSOC ; boolean_T i342ao01zb ; boolean_T
jhaewwhjil ; boolean_T jn5jmm5f0b ; boolean_T lulw25awed ; if ( ssIsSampleHit
( rtS , 0 , 0 ) ) { mbg4nhss5v = rtDW . publma5mit ; dzxxkcwprr = rtP .
R2_Gain * rtDW . publma5mit ; c51hignkuk = 1.000001 * dzxxkcwprr *
0.96711798839458663 / 0.9999 ; rtB . hjevaumr0c = rtDW . gqsgvislof ; } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . mjvjriaqf1 = rtP .
Currentfilter_NumCoef * rtDW . akd2jqznao ; rtB . iwg3uf4gow = ( rtB .
mjvjriaqf1 > rtP . Constant_Value ) ; if ( rtDW . l3kwie4ayw != 0 ) { rtDW .
hgr5mesxnb = rtB . hjevaumr0c ; if ( rtDW . hgr5mesxnb >= rtP . inti_UpperSat
) { rtDW . hgr5mesxnb = rtP . inti_UpperSat ; } else if ( rtDW . hgr5mesxnb
<= rtP . inti_LowerSat ) { rtDW . hgr5mesxnb = rtP . inti_LowerSat ; } } if (
( rtB . iwg3uf4gow > 0.0 ) && ( rtDW . hgu1herpdu <= 0 ) ) { rtDW .
hgr5mesxnb = rtB . hjevaumr0c ; if ( rtDW . hgr5mesxnb >= rtP . inti_UpperSat
) { rtDW . hgr5mesxnb = rtP . inti_UpperSat ; } else if ( rtDW . hgr5mesxnb
<= rtP . inti_LowerSat ) { rtDW . hgr5mesxnb = rtP . inti_LowerSat ; } } if (
rtDW . hgr5mesxnb >= rtP . inti_UpperSat ) { rtDW . hgr5mesxnb = rtP .
inti_UpperSat ; } else if ( rtDW . hgr5mesxnb <= rtP . inti_LowerSat ) { rtDW
. hgr5mesxnb = rtP . inti_LowerSat ; } rtB . onc44lw42c = rtP . Gain_Gain *
rtDW . hgr5mesxnb ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { i342ao01zb = (
rtB . onc44lw42c > dzxxkcwprr ) ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( rtB . onc44lw42c < rtP . Constant9_Value ) { rtB . lxt4khg2gr = rtP .
Constant9_Value ; } else { rtB . lxt4khg2gr = rtB . onc44lw42c ; } } if (
ssIsSampleHit ( rtS , 0 , 0 ) ) { if ( i342ao01zb ) { ecwkayc3c1 = dzxxkcwprr
; } else { ecwkayc3c1 = rtB . lxt4khg2gr ; } if ( c51hignkuk <= ecwkayc3c1 )
{ ecwkayc3c1 = dzxxkcwprr ; } k0qu5tzxih = - 0.0036959619703780581 *
mbg4nhss5v / ( mbg4nhss5v - ecwkayc3c1 ) * ecwkayc3c1 ; jmuz0todoh = - rtB .
iwg3uf4gow * 0.0036959619703780581 * rtB . mjvjriaqf1 * mbg4nhss5v / (
mbg4nhss5v - ecwkayc3c1 ) ; gepxctcr13 = rtP . R3_Gain * mbg4nhss5v ; if ( !
( rtB . onc44lw42c > gepxctcr13 ) ) { dzxxkcwprr = - gepxctcr13 * 0.999 * 0.1
* 0.9999 ; if ( rtB . onc44lw42c < dzxxkcwprr ) { gepxctcr13 = dzxxkcwprr ; }
else { gepxctcr13 = rtB . onc44lw42c ; } } } if ( ssIsSampleHit ( rtS , 1 , 0
) ) { rtB . dcxmkcvwrp = ( rtB . mjvjriaqf1 < rtP . Constant_Value_efypwvyyax
) ; rtB . nwqbfvqhii = rtDW . mt4lnyabvi ; } if ( ssIsSampleHit ( rtS , 0 , 0
) ) { switch ( ( int32_T ) rtP . Battery_BatType ) { case 1 : mu42bjiqp4 = -
( rtP . Constant4_Value * rtB . dcxmkcvwrp ) * 0.0036959619703780581 * ( rtP
. Constant4_Value * rtB . mjvjriaqf1 ) * ( 7.75499999999998 / ( rtP .
Constant4_Value * gepxctcr13 + 0.77549999999999808 ) ) ; break ; case 2 :
mu42bjiqp4 = rtP . Constant1_Value_ks0gbwvaxk * mbg4nhss5v ; mu42bjiqp4 = - (
rtP . Constant1_Value_ks0gbwvaxk * rtB . dcxmkcvwrp ) * 0.0036959619703780581
* ( rtP . Constant1_Value_ks0gbwvaxk * rtB . mjvjriaqf1 ) * mu42bjiqp4 / (
rtP . Constant1_Value_ks0gbwvaxk * gepxctcr13 + mu42bjiqp4 * 0.1 ) ; break ;
case 3 : mu42bjiqp4 = - ( rtP . Constant3_Value * rtB . dcxmkcvwrp ) *
0.0036959619703780581 * ( rtP . Constant3_Value * rtB . mjvjriaqf1 ) * (
7.75499999999998 / ( muDoubleScalarAbs ( rtP . Constant3_Value * gepxctcr13 )
+ 0.77549999999999808 ) ) ; break ; default : mu42bjiqp4 = - ( rtP .
Constant2_Value * rtB . dcxmkcvwrp ) * 0.0036959619703780581 * ( rtP .
Constant2_Value * rtB . mjvjriaqf1 ) * ( 7.75499999999998 / (
muDoubleScalarAbs ( rtP . Constant2_Value * gepxctcr13 ) +
0.77549999999999808 ) ) ; break ; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . motansc1ll = rtDW . lgifnif3a5 ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) )
{ switch ( ( int32_T ) rtP . Battery_BatType ) { case 1 : dzxxkcwprr = rtB .
nwqbfvqhii ; break ; case 2 : if ( ecwkayc3c1 > rtP . Saturation_UpperSat ) {
gepxctcr13 = rtP . Saturation_UpperSat ; } else if ( ecwkayc3c1 < rtP .
Saturation_LowerSat ) { gepxctcr13 = rtP . Saturation_LowerSat ; } else {
gepxctcr13 = ecwkayc3c1 ; } dzxxkcwprr = muDoubleScalarExp ( -
8.14159292035398 * gepxctcr13 ) * 0.31071106332851506 ; break ; case 3 :
dzxxkcwprr = rtB . nwqbfvqhii ; break ; default : dzxxkcwprr = rtB .
nwqbfvqhii ; break ; } dzxxkcwprr = ( ( ( ( k0qu5tzxih + jmuz0todoh ) +
mu42bjiqp4 ) + dzxxkcwprr ) + - 0.0 * ecwkayc3c1 ) + rtP .
Constant_Value_jorngiczgp ; if ( dzxxkcwprr > rtP . Constant1_Value ) { rtB .
lzsueoanmz = rtP . Constant1_Value ; } else if ( dzxxkcwprr < rtB .
motansc1ll ) { rtB . lzsueoanmz = rtB . motansc1ll ; } else { rtB .
lzsueoanmz = dzxxkcwprr ; } oblrkwwnkx = rtDW . gwrfs10hrl ; nsev50c5ac = rtP
. R2_Gain_jrqfqsl4vo * rtDW . gwrfs10hrl ; f3vzhq4cwb = 1.000001 * nsev50c5ac
* 0.96711798839458663 / 0.9999 ; rtB . acpftwtjmw = rtDW . hwcyuglaof ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . mjiupj41uc = rtP .
Currentfilter_NumCoef_iro0wbjjxt * rtDW . plmvxjbolt ; rtB . hr5m5k25h0 = (
rtB . mjiupj41uc > rtP . Constant_Value_pbqzqfbpnm ) ; if ( rtDW . fv1kok2dvs
!= 0 ) { rtDW . ax0ggg2g2u = rtB . acpftwtjmw ; if ( rtDW . ax0ggg2g2u >= rtP
. inti_UpperSat_itldayqrxp ) { rtDW . ax0ggg2g2u = rtP .
inti_UpperSat_itldayqrxp ; } else if ( rtDW . ax0ggg2g2u <= rtP .
inti_LowerSat_lz3gh0icex ) { rtDW . ax0ggg2g2u = rtP .
inti_LowerSat_lz3gh0icex ; } } if ( ( rtB . hr5m5k25h0 > 0.0 ) && ( rtDW .
l2qjsqryqq <= 0 ) ) { rtDW . ax0ggg2g2u = rtB . acpftwtjmw ; if ( rtDW .
ax0ggg2g2u >= rtP . inti_UpperSat_itldayqrxp ) { rtDW . ax0ggg2g2u = rtP .
inti_UpperSat_itldayqrxp ; } else if ( rtDW . ax0ggg2g2u <= rtP .
inti_LowerSat_lz3gh0icex ) { rtDW . ax0ggg2g2u = rtP .
inti_LowerSat_lz3gh0icex ; } } if ( rtDW . ax0ggg2g2u >= rtP .
inti_UpperSat_itldayqrxp ) { rtDW . ax0ggg2g2u = rtP .
inti_UpperSat_itldayqrxp ; } else if ( rtDW . ax0ggg2g2u <= rtP .
inti_LowerSat_lz3gh0icex ) { rtDW . ax0ggg2g2u = rtP .
inti_LowerSat_lz3gh0icex ; } rtB . agtjzus4mb = rtP . Gain_Gain_ozvwrv1fuy *
rtDW . ax0ggg2g2u ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { jn5jmm5f0b = (
rtB . agtjzus4mb > nsev50c5ac ) ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( rtB . agtjzus4mb < rtP . Constant9_Value_bfo0fnc5l1 ) { rtB . ax3gewsxiw =
rtP . Constant9_Value_bfo0fnc5l1 ; } else { rtB . ax3gewsxiw = rtB .
agtjzus4mb ; } } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { if ( jn5jmm5f0b ) {
o3kmalb05k = nsev50c5ac ; } else { o3kmalb05k = rtB . ax3gewsxiw ; } if (
f3vzhq4cwb <= o3kmalb05k ) { o3kmalb05k = nsev50c5ac ; } hrhabi5ifh = -
0.0036959619703780581 * oblrkwwnkx / ( oblrkwwnkx - o3kmalb05k ) * o3kmalb05k
; bufw31vrar = - rtB . hr5m5k25h0 * 0.0036959619703780581 * rtB . mjiupj41uc
* oblrkwwnkx / ( oblrkwwnkx - o3kmalb05k ) ; ly3ezf414h = rtP .
R3_Gain_dgx1dntlxw * oblrkwwnkx ; if ( ! ( rtB . agtjzus4mb > ly3ezf414h ) )
{ nsev50c5ac = - ly3ezf414h * 0.999 * 0.1 * 0.9999 ; if ( rtB . agtjzus4mb <
nsev50c5ac ) { ly3ezf414h = nsev50c5ac ; } else { ly3ezf414h = rtB .
agtjzus4mb ; } } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . mum0x2jb0i =
( rtB . mjiupj41uc < rtP . Constant_Value_hu3rmuppbn ) ; rtB . a5hdtqemrb =
rtDW . fai3hsvf1n ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { switch ( (
int32_T ) rtP . Battery1_BatType ) { case 1 : nd4n3q2ebz = - ( rtP .
Constant4_Value_p1xz0cpgth * rtB . mum0x2jb0i ) * 0.0036959619703780581 * (
rtP . Constant4_Value_p1xz0cpgth * rtB . mjiupj41uc ) * ( 7.75499999999998 /
( rtP . Constant4_Value_p1xz0cpgth * ly3ezf414h + 0.77549999999999808 ) ) ;
break ; case 2 : mu42bjiqp4 = rtP . Constant1_Value_jxqfbvs00y * oblrkwwnkx ;
nd4n3q2ebz = - ( rtP . Constant1_Value_jxqfbvs00y * rtB . mum0x2jb0i ) *
0.0036959619703780581 * ( rtP . Constant1_Value_jxqfbvs00y * rtB . mjiupj41uc
) * mu42bjiqp4 / ( rtP . Constant1_Value_jxqfbvs00y * ly3ezf414h + mu42bjiqp4
* 0.1 ) ; break ; case 3 : nd4n3q2ebz = - ( rtP . Constant3_Value_k030zkojhy
* rtB . mum0x2jb0i ) * 0.0036959619703780581 * ( rtP .
Constant3_Value_k030zkojhy * rtB . mjiupj41uc ) * ( 7.75499999999998 / (
muDoubleScalarAbs ( rtP . Constant3_Value_k030zkojhy * ly3ezf414h ) +
0.77549999999999808 ) ) ; break ; default : nd4n3q2ebz = - ( rtP .
Constant2_Value_nbkvr3eqsy * rtB . mum0x2jb0i ) * 0.0036959619703780581 * (
rtP . Constant2_Value_nbkvr3eqsy * rtB . mjiupj41uc ) * ( 7.75499999999998 /
( muDoubleScalarAbs ( rtP . Constant2_Value_nbkvr3eqsy * ly3ezf414h ) +
0.77549999999999808 ) ) ; break ; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . el1os0xk3p = rtDW . erhuzibllh ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) )
{ switch ( ( int32_T ) rtP . Battery1_BatType ) { case 1 : dzxxkcwprr = rtB .
a5hdtqemrb ; break ; case 2 : if ( o3kmalb05k > rtP .
Saturation_UpperSat_lxx4j3fnoa ) { k0qu5tzxih = rtP .
Saturation_UpperSat_lxx4j3fnoa ; } else if ( o3kmalb05k < rtP .
Saturation_LowerSat_kwi433xk5g ) { k0qu5tzxih = rtP .
Saturation_LowerSat_kwi433xk5g ; } else { k0qu5tzxih = o3kmalb05k ; }
dzxxkcwprr = muDoubleScalarExp ( - 8.14159292035398 * k0qu5tzxih ) *
0.31071106332851506 ; break ; case 3 : dzxxkcwprr = rtB . a5hdtqemrb ; break
; default : dzxxkcwprr = rtB . a5hdtqemrb ; break ; } lzh3qxo4te = ( ( ( (
hrhabi5ifh + bufw31vrar ) + nd4n3q2ebz ) + dzxxkcwprr ) + - 0.0 * o3kmalb05k
) + rtP . Constant_Value_fzmb45jy2r ; if ( lzh3qxo4te > rtP .
Constant1_Value_jelmmtr1rj ) { rtB . dmmlegxb5k = rtP .
Constant1_Value_jelmmtr1rj ; } else if ( lzh3qxo4te < rtB . el1os0xk3p ) {
rtB . dmmlegxb5k = rtB . el1os0xk3p ; } else { rtB . dmmlegxb5k = lzh3qxo4te
; } lzh3qxo4te = rtDW . egiqzmrt1h ; acbfked10g = rtP . R2_Gain_fij43s2whq *
rtDW . egiqzmrt1h ; omprktok4g = 1.000001 * acbfked10g * 0.96711798839458663
/ 0.9999 ; rtB . om4odxhgrn = rtDW . dwbi4pfdve ; } if ( ssIsSampleHit ( rtS
, 1 , 0 ) ) { rtB . gkflp5ycd1 = rtP . Currentfilter_NumCoef_lysterszrx *
rtDW . dygpf1ihj5 ; rtB . dr3dmc1br1 = ( rtB . gkflp5ycd1 > rtP .
Constant_Value_bksqnhysc0 ) ; if ( rtDW . keir5gxmdi != 0 ) { rtDW .
h04tbwqhfy = rtB . om4odxhgrn ; if ( rtDW . h04tbwqhfy >= rtP .
inti_UpperSat_nowwhgaxwk ) { rtDW . h04tbwqhfy = rtP .
inti_UpperSat_nowwhgaxwk ; } else if ( rtDW . h04tbwqhfy <= rtP .
inti_LowerSat_cwekkzbyq1 ) { rtDW . h04tbwqhfy = rtP .
inti_LowerSat_cwekkzbyq1 ; } } if ( ( rtB . dr3dmc1br1 > 0.0 ) && ( rtDW .
pdurl3rulw <= 0 ) ) { rtDW . h04tbwqhfy = rtB . om4odxhgrn ; if ( rtDW .
h04tbwqhfy >= rtP . inti_UpperSat_nowwhgaxwk ) { rtDW . h04tbwqhfy = rtP .
inti_UpperSat_nowwhgaxwk ; } else if ( rtDW . h04tbwqhfy <= rtP .
inti_LowerSat_cwekkzbyq1 ) { rtDW . h04tbwqhfy = rtP .
inti_LowerSat_cwekkzbyq1 ; } } if ( rtDW . h04tbwqhfy >= rtP .
inti_UpperSat_nowwhgaxwk ) { rtDW . h04tbwqhfy = rtP .
inti_UpperSat_nowwhgaxwk ; } else if ( rtDW . h04tbwqhfy <= rtP .
inti_LowerSat_cwekkzbyq1 ) { rtDW . h04tbwqhfy = rtP .
inti_LowerSat_cwekkzbyq1 ; } rtB . hohs45nws1 = rtP . Gain_Gain_jbuudt1ftk *
rtDW . h04tbwqhfy ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { jhaewwhjil = (
rtB . hohs45nws1 > acbfked10g ) ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( rtB . hohs45nws1 < rtP . Constant9_Value_nhyzz1ckmw ) { rtB . lz1jrcy1g1 =
rtP . Constant9_Value_nhyzz1ckmw ; } else { rtB . lz1jrcy1g1 = rtB .
hohs45nws1 ; } } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { if ( jhaewwhjil ) {
hyrw0mh4op = acbfked10g ; } else { hyrw0mh4op = rtB . lz1jrcy1g1 ; } if (
omprktok4g <= hyrw0mh4op ) { hyrw0mh4op = acbfked10g ; } cbztqtokqr = -
0.0036959619703780581 * lzh3qxo4te / ( lzh3qxo4te - hyrw0mh4op ) * hyrw0mh4op
; or415koses = - rtB . dr3dmc1br1 * 0.0036959619703780581 * rtB . gkflp5ycd1
* lzh3qxo4te / ( lzh3qxo4te - hyrw0mh4op ) ; dserhmea0y = rtP .
R3_Gain_de1tgv0zzw * lzh3qxo4te ; if ( ! ( rtB . hohs45nws1 > dserhmea0y ) )
{ acbfked10g = - dserhmea0y * 0.999 * 0.1 * 0.9999 ; if ( rtB . hohs45nws1 <
acbfked10g ) { dserhmea0y = acbfked10g ; } else { dserhmea0y = rtB .
hohs45nws1 ; } } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . mohby5bkk0 =
( rtB . gkflp5ycd1 < rtP . Constant_Value_owtewy0ssm ) ; rtB . ifr4l3aglp =
rtDW . fcxyycf4fu ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { switch ( (
int32_T ) rtP . Battery2_BatType ) { case 1 : k1frgvfwab = - ( rtP .
Constant4_Value_cmgjzabbd1 * rtB . mohby5bkk0 ) * 0.0036959619703780581 * (
rtP . Constant4_Value_cmgjzabbd1 * rtB . gkflp5ycd1 ) * ( 7.75499999999998 /
( rtP . Constant4_Value_cmgjzabbd1 * dserhmea0y + 0.77549999999999808 ) ) ;
break ; case 2 : mu42bjiqp4 = rtP . Constant1_Value_gbfcrdkgqa * lzh3qxo4te ;
k1frgvfwab = - ( rtP . Constant1_Value_gbfcrdkgqa * rtB . mohby5bkk0 ) *
0.0036959619703780581 * ( rtP . Constant1_Value_gbfcrdkgqa * rtB . gkflp5ycd1
) * mu42bjiqp4 / ( rtP . Constant1_Value_gbfcrdkgqa * dserhmea0y + mu42bjiqp4
* 0.1 ) ; break ; case 3 : k1frgvfwab = - ( rtP . Constant3_Value_hat1prtoip
* rtB . mohby5bkk0 ) * 0.0036959619703780581 * ( rtP .
Constant3_Value_hat1prtoip * rtB . gkflp5ycd1 ) * ( 7.75499999999998 / (
muDoubleScalarAbs ( rtP . Constant3_Value_hat1prtoip * dserhmea0y ) +
0.77549999999999808 ) ) ; break ; default : k1frgvfwab = - ( rtP .
Constant2_Value_gnk2tjoo5o * rtB . mohby5bkk0 ) * 0.0036959619703780581 * (
rtP . Constant2_Value_gnk2tjoo5o * rtB . gkflp5ycd1 ) * ( 7.75499999999998 /
( muDoubleScalarAbs ( rtP . Constant2_Value_gnk2tjoo5o * dserhmea0y ) +
0.77549999999999808 ) ) ; break ; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . hwspvdiqna = rtDW . ngguotoe1s ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) )
{ switch ( ( int32_T ) rtP . Battery2_BatType ) { case 1 : dzxxkcwprr = rtB .
ifr4l3aglp ; break ; case 2 : if ( hyrw0mh4op > rtP .
Saturation_UpperSat_blj3ug4rzx ) { hrhabi5ifh = rtP .
Saturation_UpperSat_blj3ug4rzx ; } else if ( hyrw0mh4op < rtP .
Saturation_LowerSat_o0i20janpw ) { hrhabi5ifh = rtP .
Saturation_LowerSat_o0i20janpw ; } else { hrhabi5ifh = hyrw0mh4op ; }
dzxxkcwprr = muDoubleScalarExp ( - 8.14159292035398 * hrhabi5ifh ) *
0.31071106332851506 ; break ; case 3 : dzxxkcwprr = rtB . ifr4l3aglp ; break
; default : dzxxkcwprr = rtB . ifr4l3aglp ; break ; } kksikb3eww = ( ( ( (
cbztqtokqr + or415koses ) + k1frgvfwab ) + dzxxkcwprr ) + - 0.0 * hyrw0mh4op
) + rtP . Constant_Value_kiu123temw ; if ( kksikb3eww > rtP .
Constant1_Value_jj3f5fu3xp ) { rtB . h0ohrdd4jd = rtP .
Constant1_Value_jj3f5fu3xp ; } else if ( kksikb3eww < rtB . hwspvdiqna ) {
rtB . h0ohrdd4jd = rtB . hwspvdiqna ; } else { rtB . h0ohrdd4jd = kksikb3eww
; } kksikb3eww = rtDW . jzwmczaemy ; f4iylapppx = rtP . R2_Gain_bawzgornhw *
rtDW . jzwmczaemy ; a4cp20wioy = 1.000001 * f4iylapppx * 0.96711798839458663
/ 0.9999 ; rtB . kt4i3eakjd = rtDW . bv5z5dog4q ; } if ( ssIsSampleHit ( rtS
, 1 , 0 ) ) { rtB . gnfbmjv1kd = rtP . Currentfilter_NumCoef_i44m2spe23 *
rtDW . c00p5tpsbl ; rtB . fsajkdm0eh = ( rtB . gnfbmjv1kd > rtP .
Constant_Value_kcr3np2p0u ) ; if ( rtDW . b2kal4igyh != 0 ) { rtDW .
chrr3t52id = rtB . kt4i3eakjd ; if ( rtDW . chrr3t52id >= rtP .
inti_UpperSat_lz4hujw0ip ) { rtDW . chrr3t52id = rtP .
inti_UpperSat_lz4hujw0ip ; } else if ( rtDW . chrr3t52id <= rtP .
inti_LowerSat_prmo311ajg ) { rtDW . chrr3t52id = rtP .
inti_LowerSat_prmo311ajg ; } } if ( ( rtB . fsajkdm0eh > 0.0 ) && ( rtDW .
gzqp4ynez5 <= 0 ) ) { rtDW . chrr3t52id = rtB . kt4i3eakjd ; if ( rtDW .
chrr3t52id >= rtP . inti_UpperSat_lz4hujw0ip ) { rtDW . chrr3t52id = rtP .
inti_UpperSat_lz4hujw0ip ; } else if ( rtDW . chrr3t52id <= rtP .
inti_LowerSat_prmo311ajg ) { rtDW . chrr3t52id = rtP .
inti_LowerSat_prmo311ajg ; } } if ( rtDW . chrr3t52id >= rtP .
inti_UpperSat_lz4hujw0ip ) { rtDW . chrr3t52id = rtP .
inti_UpperSat_lz4hujw0ip ; } else if ( rtDW . chrr3t52id <= rtP .
inti_LowerSat_prmo311ajg ) { rtDW . chrr3t52id = rtP .
inti_LowerSat_prmo311ajg ; } rtB . oawvzp4us4 = rtP . Gain_Gain_oyd440f2kz *
rtDW . chrr3t52id ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { lulw25awed = (
rtB . oawvzp4us4 > f4iylapppx ) ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( rtB . oawvzp4us4 < rtP . Constant9_Value_mgshhdhohr ) { rtB . jmflq5t0rg =
rtP . Constant9_Value_mgshhdhohr ; } else { rtB . jmflq5t0rg = rtB .
oawvzp4us4 ; } } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { if ( lulw25awed ) {
n43q2mtyxz = f4iylapppx ; } else { n43q2mtyxz = rtB . jmflq5t0rg ; } if (
a4cp20wioy <= n43q2mtyxz ) { n43q2mtyxz = f4iylapppx ; } h3qb50hsvn = -
0.0036959619703780581 * kksikb3eww / ( kksikb3eww - n43q2mtyxz ) * n43q2mtyxz
; bz3towpjlr = - rtB . fsajkdm0eh * 0.0036959619703780581 * rtB . gnfbmjv1kd
* kksikb3eww / ( kksikb3eww - n43q2mtyxz ) ; c3oi34j1sp = rtP .
R3_Gain_dbnoektfcm * kksikb3eww ; if ( ! ( rtB . oawvzp4us4 > c3oi34j1sp ) )
{ f4iylapppx = - c3oi34j1sp * 0.999 * 0.1 * 0.9999 ; if ( rtB . oawvzp4us4 <
f4iylapppx ) { c3oi34j1sp = f4iylapppx ; } else { c3oi34j1sp = rtB .
oawvzp4us4 ; } } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . nmhblmw2if =
( rtB . gnfbmjv1kd < rtP . Constant_Value_cqdbuv5p1f ) ; rtB . jus1psarxf =
rtDW . gcso21r0zq ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { switch ( (
int32_T ) rtP . Battery3_BatType ) { case 1 : mruxiin0wh = - ( rtP .
Constant4_Value_g4yqznci4m * rtB . nmhblmw2if ) * 0.0036959619703780581 * (
rtP . Constant4_Value_g4yqznci4m * rtB . gnfbmjv1kd ) * ( 7.75499999999998 /
( rtP . Constant4_Value_g4yqznci4m * c3oi34j1sp + 0.77549999999999808 ) ) ;
break ; case 2 : mu42bjiqp4 = rtP . Constant1_Value_olpeyohdie * kksikb3eww ;
mruxiin0wh = - ( rtP . Constant1_Value_olpeyohdie * rtB . nmhblmw2if ) *
0.0036959619703780581 * ( rtP . Constant1_Value_olpeyohdie * rtB . gnfbmjv1kd
) * mu42bjiqp4 / ( rtP . Constant1_Value_olpeyohdie * c3oi34j1sp + mu42bjiqp4
* 0.1 ) ; break ; case 3 : mruxiin0wh = - ( rtP . Constant3_Value_jcwsxsesu4
* rtB . nmhblmw2if ) * 0.0036959619703780581 * ( rtP .
Constant3_Value_jcwsxsesu4 * rtB . gnfbmjv1kd ) * ( 7.75499999999998 / (
muDoubleScalarAbs ( rtP . Constant3_Value_jcwsxsesu4 * c3oi34j1sp ) +
0.77549999999999808 ) ) ; break ; default : mruxiin0wh = - ( rtP .
Constant2_Value_mxw2f5zdvz * rtB . nmhblmw2if ) * 0.0036959619703780581 * (
rtP . Constant2_Value_mxw2f5zdvz * rtB . gnfbmjv1kd ) * ( 7.75499999999998 /
( muDoubleScalarAbs ( rtP . Constant2_Value_mxw2f5zdvz * c3oi34j1sp ) +
0.77549999999999808 ) ) ; break ; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . dzwffk2oci = rtDW . nw2cetseby ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) )
{ switch ( ( int32_T ) rtP . Battery3_BatType ) { case 1 : dzxxkcwprr = rtB .
jus1psarxf ; break ; case 2 : if ( n43q2mtyxz > rtP .
Saturation_UpperSat_c3l4zdyanc ) { cbztqtokqr = rtP .
Saturation_UpperSat_c3l4zdyanc ; } else if ( n43q2mtyxz < rtP .
Saturation_LowerSat_ois5i0qecq ) { cbztqtokqr = rtP .
Saturation_LowerSat_ois5i0qecq ; } else { cbztqtokqr = n43q2mtyxz ; }
dzxxkcwprr = muDoubleScalarExp ( - 8.14159292035398 * cbztqtokqr ) *
0.31071106332851506 ; break ; case 3 : dzxxkcwprr = rtB . jus1psarxf ; break
; default : dzxxkcwprr = rtB . jus1psarxf ; break ; } h3qb50hsvn = ( ( ( (
h3qb50hsvn + bz3towpjlr ) + mruxiin0wh ) + dzxxkcwprr ) + - 0.0 * n43q2mtyxz
) + rtP . Constant_Value_lfzq4ua142 ; if ( h3qb50hsvn > rtP .
Constant1_Value_mvsbgtlkyx ) { rtB . joihb0qv3k = rtP .
Constant1_Value_mvsbgtlkyx ; } else if ( h3qb50hsvn < rtB . dzwffk2oci ) {
rtB . joihb0qv3k = rtB . dzwffk2oci ; } else { rtB . joihb0qv3k = h3qb50hsvn
; } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { real_T accum ; int_T *
switch_status = ( int_T * ) rtDW . nopbrmbrmq . SWITCH_STATUS ; int_T *
switch_status_init = ( int_T * ) rtDW . nopbrmbrmq . SWITCH_STATUS_INIT ;
int_T * SwitchChange = ( int_T * ) rtDW . nopbrmbrmq . SW_CHG ; int_T *
gState = ( int_T * ) rtDW . nopbrmbrmq . G_STATE ; real_T * yswitch = (
real_T * ) rtDW . nopbrmbrmq . Y_SWITCH ; int_T * switchTypes = ( int_T * )
rtDW . nopbrmbrmq . SWITCH_TYPES ; int_T * idxOutSw = ( int_T * ) rtDW .
nopbrmbrmq . IDX_OUT_SW ; real_T * DxCol = ( real_T * ) rtDW . nopbrmbrmq .
DX_COL ; real_T * tmp2 = ( real_T * ) rtDW . nopbrmbrmq . TMP2 ; real_T *
uswlast = ( real_T * ) rtDW . nopbrmbrmq . USWLAST ; int_T newState ; int_T
swChanged = 0 ; int loopsToDo = 20 ; real_T temp ; memcpy (
switch_status_init , switch_status , 16 * sizeof ( int_T ) ) ; memcpy (
uswlast , & rtB . fdxhchca4n [ 0 ] , 16 * sizeof ( real_T ) ) ; do { if (
loopsToDo == 1 ) { swChanged = 0 ; { int_T i1 ; for ( i1 = 0 ; i1 < 16 ; i1
++ ) { swChanged = ( ( SwitchChange [ i1 ] = switch_status_init [ i1 ] -
switch_status [ i1 ] ) != 0 ) ? 1 : swChanged ; switch_status [ i1 ] =
switch_status_init [ i1 ] ; } } } else { real_T * Ds = ( real_T * ) rtDW .
nopbrmbrmq . DS ; { int_T i1 ; real_T * y0 = & rtB . fdxhchca4n [ 0 ] ; for (
i1 = 0 ; i1 < 20 ; i1 ++ ) { accum = 0.0 ; { int_T i2 ; const real_T * u0 = &
rtP . SwitchCurrents_Value [ 0 ] ; for ( i2 = 0 ; i2 < 16 ; i2 ++ ) { accum
+= * ( Ds ++ ) * u0 [ i2 ] ; } accum += * ( Ds ++ ) * rtB . lzsueoanmz ;
accum += * ( Ds ++ ) * rtB . dmmlegxb5k ; accum += * ( Ds ++ ) * rtB .
h0ohrdd4jd ; accum += * ( Ds ++ ) * rtB . joihb0qv3k ; } y0 [ i1 ] = accum ;
} } swChanged = 0 ; { int_T i1 ; real_T * y0 = & rtB . fdxhchca4n [ 0 ] ; for
( i1 = 0 ; i1 < 16 ; i1 ++ ) { switch ( switchTypes [ i1 ] ) { case 1 :
newState = gState [ i1 ] > 0 ? 1 : 0 ; break ; case 3 : newState = y0 [ i1 ]
> 0.0 ? 1 : ( ( y0 [ i1 ] < 0.0 ) ? 0 : switch_status [ i1 ] ) ; break ; }
swChanged = ( ( SwitchChange [ i1 ] = newState - switch_status [ i1 ] ) != 0
) ? 1 : swChanged ; switch_status [ i1 ] = newState ; } } } if ( swChanged )
{ real_T * Ds = ( real_T * ) rtDW . nopbrmbrmq . DS ; real_T a1 ; { int_T i1
; for ( i1 = 0 ; i1 < 16 ; i1 ++ ) { if ( SwitchChange [ i1 ] != 0 ) { a1 =
yswitch [ i1 ] * SwitchChange [ i1 ] ; temp = 1 / ( 1 - Ds [ i1 * 21 ] * a1 )
; { int_T i2 ; for ( i2 = 0 ; i2 < 20 ; i2 ++ ) { DxCol [ i2 ] = Ds [ i2 * 20
+ i1 ] * temp * a1 ; } } DxCol [ i1 ] = temp ; memcpy ( tmp2 , & Ds [ i1 * 20
] , 20 * sizeof ( real_T ) ) ; memset ( & Ds [ i1 * 20 ] , '\0' , 20 * sizeof
( real_T ) ) ; { int_T i2 ; for ( i2 = 0 ; i2 < 20 ; i2 ++ ) { a1 = DxCol [
i2 ] ; { int_T i3 ; for ( i3 = 0 ; i3 < 20 ; i3 ++ ) { Ds [ i2 * 20 + i3 ] +=
a1 * tmp2 [ i3 ] ; } } } } } } } } } while ( swChanged > 0 && -- loopsToDo >
0 ) ; if ( loopsToDo == 0 ) { real_T * Ds = ( real_T * ) rtDW . nopbrmbrmq .
DS ; { int_T i1 ; real_T * y0 = & rtB . fdxhchca4n [ 0 ] ; for ( i1 = 0 ; i1
< 20 ; i1 ++ ) { accum = 0.0 ; { int_T i2 ; const real_T * u0 = & rtP .
SwitchCurrents_Value [ 0 ] ; for ( i2 = 0 ; i2 < 16 ; i2 ++ ) { accum += * (
Ds ++ ) * u0 [ i2 ] ; } accum += * ( Ds ++ ) * rtB . lzsueoanmz ; accum += *
( Ds ++ ) * rtB . dmmlegxb5k ; accum += * ( Ds ++ ) * rtB . h0ohrdd4jd ;
accum += * ( Ds ++ ) * rtB . joihb0qv3k ; } y0 [ i1 ] = accum ; } } } { int_T
i1 ; real_T * y1 = & rtB . pnhylngzop [ 0 ] ; for ( i1 = 0 ; i1 < 16 ; i1 ++
) { y1 [ i1 ] = ( real_T ) switch_status [ i1 ] ; } } } } if ( ssIsSampleHit
( rtS , 0 , 0 ) ) { mbg4nhss5v = ( 1.0 - ecwkayc3c1 / ( rtP . R4_Gain *
mbg4nhss5v ) ) * 100.0 ; if ( mbg4nhss5v > rtP .
Saturation_UpperSat_pcz043fnep ) { rtB . g0jp2bmgqd = rtP .
Saturation_UpperSat_pcz043fnep ; } else if ( mbg4nhss5v < rtP .
Saturation_LowerSat_b05y2t0vvl ) { rtB . g0jp2bmgqd = rtP .
Saturation_LowerSat_b05y2t0vvl ; } else { rtB . g0jp2bmgqd = mbg4nhss5v ; }
mbg4nhss5v = ( 1.0 - o3kmalb05k / ( rtP . R4_Gain_ayggl2vp1n * oblrkwwnkx ) )
* 100.0 ; if ( mbg4nhss5v > rtP . Saturation_UpperSat_aqwzuangfk ) { rtB .
jir35ajm40 = rtP . Saturation_UpperSat_aqwzuangfk ; } else if ( mbg4nhss5v <
rtP . Saturation_LowerSat_bcd3czsgyq ) { rtB . jir35ajm40 = rtP .
Saturation_LowerSat_bcd3czsgyq ; } else { rtB . jir35ajm40 = mbg4nhss5v ; }
mbg4nhss5v = ( 1.0 - hyrw0mh4op / ( rtP . R4_Gain_ckkisgzyfx * lzh3qxo4te ) )
* 100.0 ; if ( mbg4nhss5v > rtP . Saturation_UpperSat_i3x3oscagf ) { rtB .
gl1tfdyozx = rtP . Saturation_UpperSat_i3x3oscagf ; } else if ( mbg4nhss5v <
rtP . Saturation_LowerSat_gnz45aadu0 ) { rtB . gl1tfdyozx = rtP .
Saturation_LowerSat_gnz45aadu0 ; } else { rtB . gl1tfdyozx = mbg4nhss5v ; }
mbg4nhss5v = ( 1.0 - n43q2mtyxz / ( rtP . R4_Gain_hqvi3z0ayd * kksikb3eww ) )
* 100.0 ; if ( mbg4nhss5v > rtP . Saturation_UpperSat_ezdhxfyofu ) { rtB .
c0jlhyxegg = rtP . Saturation_UpperSat_ezdhxfyofu ; } else if ( mbg4nhss5v <
rtP . Saturation_LowerSat_i2fffiw1vk ) { rtB . c0jlhyxegg = rtP .
Saturation_LowerSat_i2fffiw1vk ; } else { rtB . c0jlhyxegg = mbg4nhss5v ; }
oblrkwwnkx = muDoubleScalarRound ( rtB . g0jp2bmgqd ) ; if ( oblrkwwnkx <
32768.0 ) { if ( oblrkwwnkx >= - 32768.0 ) { S1 = ( int16_T ) oblrkwwnkx ; }
else { S1 = MIN_int16_T ; } } else if ( oblrkwwnkx >= 32768.0 ) { S1 =
MAX_int16_T ; } else { S1 = 0 ; } oblrkwwnkx = muDoubleScalarRound ( rtB .
jir35ajm40 ) ; if ( oblrkwwnkx < 32768.0 ) { if ( oblrkwwnkx >= - 32768.0 ) {
S2 = ( int16_T ) oblrkwwnkx ; } else { S2 = MIN_int16_T ; } } else if (
oblrkwwnkx >= 32768.0 ) { S2 = MAX_int16_T ; } else { S2 = 0 ; } oblrkwwnkx =
muDoubleScalarRound ( rtB . gl1tfdyozx ) ; if ( oblrkwwnkx < 32768.0 ) { if (
oblrkwwnkx >= - 32768.0 ) { S3 = ( int16_T ) oblrkwwnkx ; } else { S3 =
MIN_int16_T ; } } else if ( oblrkwwnkx >= 32768.0 ) { S3 = MAX_int16_T ; }
else { S3 = 0 ; } oblrkwwnkx = muDoubleScalarRound ( rtB . c0jlhyxegg ) ; if
( oblrkwwnkx < 32768.0 ) { if ( oblrkwwnkx >= - 32768.0 ) { S4 = ( int16_T )
oblrkwwnkx ; } else { S4 = MIN_int16_T ; } } else if ( oblrkwwnkx >= 32768.0
) { S4 = MAX_int16_T ; } else { S4 = 0 ; } rtB . jge13amd3n = 0.0 ; rtB .
cpufh1imvv = 0.0 ; rtB . pjbiqezomx = 0.0 ; rtB . mtnqnf1tgq = 0.0 ; minSOC =
S1 ; if ( S1 > S2 ) { minSOC = S2 ; } if ( minSOC > S3 ) { minSOC = S3 ; } if
( minSOC > S4 ) { minSOC = S4 ; } while ( ( ( S1 != S2 ) != S3 ) != S4 ) { if
( S1 == minSOC ) { if ( S2 == minSOC ) { if ( S3 == minSOC ) { rtB .
mtnqnf1tgq = 1.0 ; } else if ( S4 == minSOC ) { rtB . pjbiqezomx = 1.0 ; }
else { rtB . pjbiqezomx = 1.0 ; rtB . mtnqnf1tgq = 1.0 ; } } else if ( S3 ==
minSOC ) { if ( S4 == minSOC ) { rtB . cpufh1imvv = 1.0 ; } else if ( S1 ==
minSOC ) { rtB . cpufh1imvv = 1.0 ; rtB . mtnqnf1tgq = 1.0 ; } } else if ( S4
== minSOC ) { rtB . cpufh1imvv = 1.0 ; rtB . pjbiqezomx = 1.0 ; } else { rtB
. cpufh1imvv = 1.0 ; rtB . pjbiqezomx = 1.0 ; rtB . mtnqnf1tgq = 1.0 ; } } if
( S2 == minSOC ) { if ( S3 == minSOC ) { if ( S1 == minSOC ) { rtB .
mtnqnf1tgq = 1.0 ; } else if ( S4 == minSOC ) { rtB . jge13amd3n = 1.0 ; }
else { rtB . jge13amd3n = 1.0 ; rtB . mtnqnf1tgq = 1.0 ; } } else if ( S4 ==
minSOC ) { if ( S1 == minSOC ) { rtB . pjbiqezomx = 1.0 ; } else if ( S2 ==
minSOC ) { rtB . jge13amd3n = 1.0 ; rtB . pjbiqezomx = 1.0 ; } } else if ( S1
== minSOC ) { rtB . pjbiqezomx = 1.0 ; rtB . mtnqnf1tgq = 1.0 ; } else { rtB
. jge13amd3n = 1.0 ; rtB . pjbiqezomx = 1.0 ; rtB . mtnqnf1tgq = 1.0 ; } } if
( S3 == minSOC ) { if ( S1 == minSOC ) { if ( S2 == minSOC ) { rtB .
mtnqnf1tgq = 1.0 ; } else if ( S4 == minSOC ) { rtB . cpufh1imvv = 1.0 ; }
else { rtB . cpufh1imvv = 1.0 ; rtB . mtnqnf1tgq = 1.0 ; } } else if ( S4 ==
minSOC ) { if ( S2 == minSOC ) { rtB . jge13amd3n = 1.0 ; } else { rtB .
jge13amd3n = 1.0 ; rtB . cpufh1imvv = 1.0 ; } } else if ( S2 == minSOC ) {
rtB . jge13amd3n = 1.0 ; rtB . mtnqnf1tgq = 1.0 ; } else { rtB . jge13amd3n =
1.0 ; rtB . cpufh1imvv = 1.0 ; rtB . mtnqnf1tgq = 1.0 ; } } if ( S4 == minSOC
) { if ( S1 == minSOC ) { if ( S2 == minSOC ) { rtB . pjbiqezomx = 1.0 ; }
else if ( S3 == minSOC ) { rtB . cpufh1imvv = 1.0 ; } else { rtB . cpufh1imvv
= 1.0 ; rtB . pjbiqezomx = 1.0 ; } } else if ( S2 == minSOC ) { if ( S3 ==
minSOC ) { rtB . jge13amd3n = 1.0 ; } else { rtB . jge13amd3n = 1.0 ; rtB .
cpufh1imvv = 1.0 ; } } else if ( S3 == minSOC ) { rtB . jge13amd3n = 1.0 ;
rtB . cpufh1imvv = 1.0 ; } else { rtB . jge13amd3n = 1.0 ; rtB . cpufh1imvv =
1.0 ; rtB . pjbiqezomx = 1.0 ; } } } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . ggq0mzmget = rtP . donotdeletethisgain_Gain * rtB . fdxhchca4n [ 16 ] ;
rtB . f5mbbavims = rtP . donotdeletethisgain_Gain_bg3gl2myht * rtB .
fdxhchca4n [ 17 ] ; rtB . hwrfe4inel = rtP .
donotdeletethisgain_Gain_o42imifl5k * rtB . fdxhchca4n [ 18 ] ; rtB .
puaah5a5v4 = rtP . donotdeletethisgain_Gain_esi3l1j2do * rtB . fdxhchca4n [
19 ] ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { } if ( ssIsSampleHit ( rtS ,
1 , 0 ) ) { rtB . gxiis152id = rtP . R_Gain * rtB . f5mbbavims ; } if (
ssIsSampleHit ( rtS , 0 , 0 ) ) { ago2urujjb = rtB . dmmlegxb5k - rtB .
gxiis152id ; } { if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { if ( rtDW .
d0qmjtu0wc . AQHandles [ 0 ] && ssGetLogOutput ( rtS ) ) { sdiWriteSignal (
rtDW . d0qmjtu0wc . AQHandles [ 0 ] , ssGetTaskTime ( rtS , 0 ) , ( char * )
& rtB . jir35ajm40 + 0 ) ; sdiWriteSignal ( rtDW . d0qmjtu0wc . AQHandles [ 2
] , ssGetTaskTime ( rtS , 0 ) , ( char * ) & ago2urujjb + 0 ) ; } } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( rtDW . d0qmjtu0wc . AQHandles [ 1 ] &&
ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . d0qmjtu0wc . AQHandles [ 1
] , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . f5mbbavims + 0 ) ; } } }
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . j1svqdlmmu = rtP .
R_Gain_g4gmpqe5wx * rtB . hwrfe4inel ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) )
{ hnlb3fod4f = rtB . h0ohrdd4jd - rtB . j1svqdlmmu ; } { if ( ssIsSampleHit (
rtS , 0 , 0 ) ) { if ( rtDW . ogi3lqi4h3 . AQHandles [ 0 ] && ssGetLogOutput
( rtS ) ) { sdiWriteSignal ( rtDW . ogi3lqi4h3 . AQHandles [ 0 ] ,
ssGetTaskTime ( rtS , 0 ) , ( char * ) & rtB . gl1tfdyozx + 0 ) ;
sdiWriteSignal ( rtDW . ogi3lqi4h3 . AQHandles [ 2 ] , ssGetTaskTime ( rtS ,
0 ) , ( char * ) & hnlb3fod4f + 0 ) ; } } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { if ( rtDW . ogi3lqi4h3 . AQHandles [ 1 ] && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . ogi3lqi4h3 . AQHandles [ 1 ] , ssGetTaskTime ( rtS ,
1 ) , ( char * ) & rtB . hwrfe4inel + 0 ) ; } } } if ( ssIsSampleHit ( rtS ,
1 , 0 ) ) { rtB . nedmckl1ap = rtP . R_Gain_jixg1xytle * rtB . puaah5a5v4 ; }
if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { d1cotbw5h2 = rtB . joihb0qv3k - rtB .
nedmckl1ap ; } { if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { if ( rtDW .
gdkxwpsnoh . AQHandles [ 0 ] && ssGetLogOutput ( rtS ) ) { sdiWriteSignal (
rtDW . gdkxwpsnoh . AQHandles [ 0 ] , ssGetTaskTime ( rtS , 0 ) , ( char * )
& rtB . c0jlhyxegg + 0 ) ; sdiWriteSignal ( rtDW . gdkxwpsnoh . AQHandles [ 2
] , ssGetTaskTime ( rtS , 0 ) , ( char * ) & d1cotbw5h2 + 0 ) ; } } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( rtDW . gdkxwpsnoh . AQHandles [ 1 ] &&
ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . gdkxwpsnoh . AQHandles [ 1
] , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . puaah5a5v4 + 0 ) ; } } }
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . fbvg15yoxf = rtP .
R_Gain_cwdppwgit4 * rtB . ggq0mzmget ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) )
{ n0hvyxgkxv = rtB . lzsueoanmz - rtB . fbvg15yoxf ; } { if ( ssIsSampleHit (
rtS , 0 , 0 ) ) { if ( rtDW . hbso4bjjpz . AQHandles [ 0 ] && ssGetLogOutput
( rtS ) ) { sdiWriteSignal ( rtDW . hbso4bjjpz . AQHandles [ 0 ] ,
ssGetTaskTime ( rtS , 0 ) , ( char * ) & rtB . g0jp2bmgqd + 0 ) ;
sdiWriteSignal ( rtDW . hbso4bjjpz . AQHandles [ 2 ] , ssGetTaskTime ( rtS ,
0 ) , ( char * ) & n0hvyxgkxv + 0 ) ; } } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { if ( rtDW . hbso4bjjpz . AQHandles [ 1 ] && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . hbso4bjjpz . AQHandles [ 1 ] , ssGetTaskTime ( rtS ,
1 ) , ( char * ) & rtB . ggq0mzmget + 0 ) ; } } } if ( ssIsSampleHit ( rtS ,
0 , 0 ) ) { { if ( rtDW . ngziftwkrd . AQHandles && ssGetLogOutput ( rtS ) )
{ sdiWriteSignal ( rtDW . ngziftwkrd . AQHandles , ssGetTaskTime ( rtS , 0 )
, ( char * ) & rtB . jir35ajm40 + 0 ) ; } } } if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { { if ( rtDW . ejblfx2g3i . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . ejblfx2g3i . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . f5mbbavims + 0 ) ; } } } if ( ssIsSampleHit ( rtS , 0 , 0
) ) { { if ( rtDW . c2ed1fnksn . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . c2ed1fnksn . AQHandles , ssGetTaskTime ( rtS , 0 ) ,
( char * ) & rtB . gl1tfdyozx + 0 ) ; } } } if ( ssIsSampleHit ( rtS , 1 , 0
) ) { { if ( rtDW . j4poblttty . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . j4poblttty . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . hwrfe4inel + 0 ) ; } } } if ( ssIsSampleHit ( rtS , 0 , 0
) ) { { if ( rtDW . f43wxvhzgt . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . f43wxvhzgt . AQHandles , ssGetTaskTime ( rtS , 0 ) ,
( char * ) & rtB . c0jlhyxegg + 0 ) ; } } } if ( ssIsSampleHit ( rtS , 1 , 0
) ) { { if ( rtDW . ghxaxtnllt . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . ghxaxtnllt . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . puaah5a5v4 + 0 ) ; } } } if ( ssIsSampleHit ( rtS , 0 , 0
) ) { { if ( rtDW . kt1yw354el . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . kt1yw354el . AQHandles , ssGetTaskTime ( rtS , 0 ) ,
( char * ) & rtB . g0jp2bmgqd + 0 ) ; } } } if ( ssIsSampleHit ( rtS , 1 , 0
) ) { { if ( rtDW . d2ou5um4xo . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . d2ou5um4xo . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . ggq0mzmget + 0 ) ; } } } if ( ssIsSampleHit ( rtS , 0 , 0
) ) { { if ( rtDW . f2agk1lwei . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . f2agk1lwei . AQHandles , ssGetTaskTime ( rtS , 0 ) ,
( char * ) & rtB . cpufh1imvv + 0 ) ; } } { if ( rtDW . nyvkm1zm5h .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . nyvkm1zm5h .
AQHandles , ssGetTaskTime ( rtS , 0 ) , ( char * ) & rtB . pjbiqezomx + 0 ) ;
} } { if ( rtDW . nip5y111ia . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . nip5y111ia . AQHandles , ssGetTaskTime ( rtS , 0 ) ,
( char * ) & rtB . mtnqnf1tgq + 0 ) ; } } { if ( rtDW . i44rlgscpk .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . i44rlgscpk .
AQHandles , ssGetTaskTime ( rtS , 0 ) , ( char * ) & rtB . jge13amd3n + 0 ) ;
} } rtB . o4q0knkfhp = rtP . Gain2_Gain * ecwkayc3c1 ; } if ( ssIsSampleHit (
rtS , 1 , 0 ) ) { rtB . bhljgeggu3 = ( ( real_T ) ( rtB . ggq0mzmget < rtP .
Constant_Value_ogegtmkzv0 ) * rtP . Gain4_Gain - rtB . nwqbfvqhii ) *
muDoubleScalarAbs ( rtB . ggq0mzmget ) * rtP . Gain1_Gain ; rtB . e03bm2zbdm
= rtP . R1_Gain * rtB . ggq0mzmget ; rtB . mniup0awbm = ( ( real_T ) ( rtB .
f5mbbavims < rtP . Constant_Value_h5irp45zuu ) * rtP . Gain4_Gain_kh00znyazs
- rtB . a5hdtqemrb ) * muDoubleScalarAbs ( rtB . f5mbbavims ) * rtP .
Gain1_Gain_og11bwmhu2 ; rtB . ehmsjwt2y2 = rtP . R1_Gain_k1h1x1zryv * rtB .
f5mbbavims ; rtB . ldf12bxawt = ( ( real_T ) ( rtB . hwrfe4inel < rtP .
Constant_Value_k5pwul1wle ) * rtP . Gain4_Gain_fstjjgzlds - rtB . ifr4l3aglp
) * muDoubleScalarAbs ( rtB . hwrfe4inel ) * rtP . Gain1_Gain_anymdqpqln ; }
if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { rtB . nbtiexyflg = rtP .
Gain2_Gain_m4x3vq3y1f * o3kmalb05k ; rtB . ppovsif5nu = rtP .
Gain2_Gain_jptbha03po * hyrw0mh4op ; rtB . cds1qoxtkz = rtP .
Gain2_Gain_exz2fvuzmi * n43q2mtyxz ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . aggsod1r3b = rtP . R1_Gain_elo0441xsu * rtB . hwrfe4inel ; rtB .
jjxxtqfeeb = ( ( real_T ) ( rtB . puaah5a5v4 < rtP .
Constant_Value_nkaxnatvkv ) * rtP . Gain4_Gain_hul13ajzj3 - rtB . jus1psarxf
) * muDoubleScalarAbs ( rtB . puaah5a5v4 ) * rtP . Gain1_Gain_m4axzds55u ;
rtB . gielivfeiq = rtP . R1_Gain_f1ushaohtw * rtB . puaah5a5v4 ; }
UNUSED_PARAMETER ( tid ) ; } void MdlOutputsTID2 ( int_T tid ) {
UNUSED_PARAMETER ( tid ) ; } void MdlUpdate ( int_T tid ) { if (
ssIsSampleHit ( rtS , 0 , 0 ) ) { rtDW . publma5mit = rtP . Constant12_Value
; rtDW . gqsgvislof = rtB . o4q0knkfhp ; } if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtDW . akd2jqznao = ( rtB . ggq0mzmget - rtP . Currentfilter_DenCoef [ 1
] * rtDW . akd2jqznao ) / rtP . Currentfilter_DenCoef [ 0 ] ; rtDW .
l3kwie4ayw = 0U ; rtDW . hgr5mesxnb += rtP . inti_gainval * rtB . ggq0mzmget
; if ( rtDW . hgr5mesxnb >= rtP . inti_UpperSat ) { rtDW . hgr5mesxnb = rtP .
inti_UpperSat ; } else if ( rtDW . hgr5mesxnb <= rtP . inti_LowerSat ) { rtDW
. hgr5mesxnb = rtP . inti_LowerSat ; } if ( rtB . iwg3uf4gow > 0.0 ) { rtDW .
hgu1herpdu = 1 ; } else if ( rtB . iwg3uf4gow < 0.0 ) { rtDW . hgu1herpdu = -
1 ; } else if ( rtB . iwg3uf4gow == 0.0 ) { rtDW . hgu1herpdu = 0 ; } else {
rtDW . hgu1herpdu = 2 ; } rtDW . mt4lnyabvi += rtP .
DiscreteTimeIntegrator_gainval * rtB . bhljgeggu3 ; rtDW . lgifnif3a5 = rtB .
e03bm2zbdm ; rtDW . plmvxjbolt = ( rtB . f5mbbavims - rtP .
Currentfilter_DenCoef_l3txc5dehe [ 1 ] * rtDW . plmvxjbolt ) / rtP .
Currentfilter_DenCoef_l3txc5dehe [ 0 ] ; } if ( ssIsSampleHit ( rtS , 0 , 0 )
) { rtDW . gwrfs10hrl = rtP . Constant12_Value_df3z3yuypl ; rtDW . hwcyuglaof
= rtB . nbtiexyflg ; rtDW . egiqzmrt1h = rtP . Constant12_Value_ktnzmkcekm ;
} if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . fv1kok2dvs = 0U ; rtDW .
ax0ggg2g2u += rtP . inti_gainval_cihsr01gna * rtB . f5mbbavims ; if ( rtDW .
ax0ggg2g2u >= rtP . inti_UpperSat_itldayqrxp ) { rtDW . ax0ggg2g2u = rtP .
inti_UpperSat_itldayqrxp ; } else if ( rtDW . ax0ggg2g2u <= rtP .
inti_LowerSat_lz3gh0icex ) { rtDW . ax0ggg2g2u = rtP .
inti_LowerSat_lz3gh0icex ; } if ( rtB . hr5m5k25h0 > 0.0 ) { rtDW .
l2qjsqryqq = 1 ; } else if ( rtB . hr5m5k25h0 < 0.0 ) { rtDW . l2qjsqryqq = -
1 ; } else if ( rtB . hr5m5k25h0 == 0.0 ) { rtDW . l2qjsqryqq = 0 ; } else {
rtDW . l2qjsqryqq = 2 ; } rtDW . fai3hsvf1n += rtP .
DiscreteTimeIntegrator_gainval_gderi0p3qj * rtB . mniup0awbm ; rtDW .
erhuzibllh = rtB . ehmsjwt2y2 ; rtDW . dygpf1ihj5 = ( rtB . hwrfe4inel - rtP
. Currentfilter_DenCoef_i2hd2zaaxr [ 1 ] * rtDW . dygpf1ihj5 ) / rtP .
Currentfilter_DenCoef_i2hd2zaaxr [ 0 ] ; rtDW . keir5gxmdi = 0U ; rtDW .
h04tbwqhfy += rtP . inti_gainval_ev3cmzfwwq * rtB . hwrfe4inel ; if ( rtDW .
h04tbwqhfy >= rtP . inti_UpperSat_nowwhgaxwk ) { rtDW . h04tbwqhfy = rtP .
inti_UpperSat_nowwhgaxwk ; } else if ( rtDW . h04tbwqhfy <= rtP .
inti_LowerSat_cwekkzbyq1 ) { rtDW . h04tbwqhfy = rtP .
inti_LowerSat_cwekkzbyq1 ; } if ( rtB . dr3dmc1br1 > 0.0 ) { rtDW .
pdurl3rulw = 1 ; } else if ( rtB . dr3dmc1br1 < 0.0 ) { rtDW . pdurl3rulw = -
1 ; } else if ( rtB . dr3dmc1br1 == 0.0 ) { rtDW . pdurl3rulw = 0 ; } else {
rtDW . pdurl3rulw = 2 ; } rtDW . fcxyycf4fu += rtP .
DiscreteTimeIntegrator_gainval_dnjz2mm3rw * rtB . ldf12bxawt ; rtDW .
ngguotoe1s = rtB . aggsod1r3b ; } if ( ssIsSampleHit ( rtS , 0 , 0 ) ) { rtDW
. dwbi4pfdve = rtB . ppovsif5nu ; rtDW . jzwmczaemy = rtP .
Constant12_Value_bncp0krrox ; rtDW . bv5z5dog4q = rtB . cds1qoxtkz ; } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . c00p5tpsbl = ( rtB . puaah5a5v4 -
rtP . Currentfilter_DenCoef_ecedmvii5j [ 1 ] * rtDW . c00p5tpsbl ) / rtP .
Currentfilter_DenCoef_ecedmvii5j [ 0 ] ; rtDW . b2kal4igyh = 0U ; rtDW .
chrr3t52id += rtP . inti_gainval_goukxg31nf * rtB . puaah5a5v4 ; if ( rtDW .
chrr3t52id >= rtP . inti_UpperSat_lz4hujw0ip ) { rtDW . chrr3t52id = rtP .
inti_UpperSat_lz4hujw0ip ; } else if ( rtDW . chrr3t52id <= rtP .
inti_LowerSat_prmo311ajg ) { rtDW . chrr3t52id = rtP .
inti_LowerSat_prmo311ajg ; } if ( rtB . fsajkdm0eh > 0.0 ) { rtDW .
gzqp4ynez5 = 1 ; } else if ( rtB . fsajkdm0eh < 0.0 ) { rtDW . gzqp4ynez5 = -
1 ; } else if ( rtB . fsajkdm0eh == 0.0 ) { rtDW . gzqp4ynez5 = 0 ; } else {
rtDW . gzqp4ynez5 = 2 ; } rtDW . gcso21r0zq += rtP .
DiscreteTimeIntegrator_gainval_jfckqwmoq4 * rtB . jjxxtqfeeb ; rtDW .
nw2cetseby = rtB . gielivfeiq ; { int_T * gState = ( int_T * ) rtDW .
nopbrmbrmq . G_STATE ; * ( gState ++ ) = ( int_T ) rtB . jge13amd3n ; * (
gState ++ ) = ( int_T ) rtB . cpufh1imvv ; * ( gState ++ ) = ( int_T ) rtB .
pjbiqezomx ; * ( gState ++ ) = ( int_T ) rtB . mtnqnf1tgq ; * ( gState ++ ) =
( int_T ) rtP . Constant_Value_eczelweelu ; * ( gState ++ ) = ( int_T ) rtP .
Constant1_Value_hdj1qeobnu ; * ( gState ++ ) = ( int_T ) rtP .
Constant2_Value_ct4fvdp3kc ; * ( gState ++ ) = ( int_T ) rtP .
Constant3_Value_cddtuuqxak ; * ( gState ++ ) = ( int_T ) 0.0 ; * ( gState ++
) = ( int_T ) 0.0 ; * ( gState ++ ) = ( int_T ) 0.0 ; * ( gState ++ ) = (
int_T ) 0.0 ; * ( gState ++ ) = ( int_T ) 0.0 ; * ( gState ++ ) = ( int_T )
0.0 ; * ( gState ++ ) = ( int_T ) 0.0 ; * ( gState ++ ) = ( int_T ) 0.0 ; } }
UNUSED_PARAMETER ( tid ) ; } void MdlUpdateTID2 ( int_T tid ) {
UNUSED_PARAMETER ( tid ) ; } void MdlTerminate ( void ) { { free ( rtDW .
nopbrmbrmq . DS ) ; free ( rtDW . nopbrmbrmq . DX_COL ) ; free ( rtDW .
nopbrmbrmq . TMP2 ) ; free ( rtDW . nopbrmbrmq . G_STATE ) ; free ( rtDW .
nopbrmbrmq . SWITCH_STATUS ) ; free ( rtDW . nopbrmbrmq . SW_CHG ) ; free (
rtDW . nopbrmbrmq . SWITCH_STATUS_INIT ) ; } { if ( rtDW . d0qmjtu0wc .
AQHandles [ 0 ] ) { sdiTerminateStreaming ( & rtDW . d0qmjtu0wc . AQHandles [
0 ] ) ; } if ( rtDW . d0qmjtu0wc . AQHandles [ 1 ] ) { sdiTerminateStreaming
( & rtDW . d0qmjtu0wc . AQHandles [ 1 ] ) ; } if ( rtDW . d0qmjtu0wc .
AQHandles [ 2 ] ) { sdiTerminateStreaming ( & rtDW . d0qmjtu0wc . AQHandles [
2 ] ) ; } } { if ( rtDW . ogi3lqi4h3 . AQHandles [ 0 ] ) {
sdiTerminateStreaming ( & rtDW . ogi3lqi4h3 . AQHandles [ 0 ] ) ; } if ( rtDW
. ogi3lqi4h3 . AQHandles [ 1 ] ) { sdiTerminateStreaming ( & rtDW .
ogi3lqi4h3 . AQHandles [ 1 ] ) ; } if ( rtDW . ogi3lqi4h3 . AQHandles [ 2 ] )
{ sdiTerminateStreaming ( & rtDW . ogi3lqi4h3 . AQHandles [ 2 ] ) ; } } { if
( rtDW . gdkxwpsnoh . AQHandles [ 0 ] ) { sdiTerminateStreaming ( & rtDW .
gdkxwpsnoh . AQHandles [ 0 ] ) ; } if ( rtDW . gdkxwpsnoh . AQHandles [ 1 ] )
{ sdiTerminateStreaming ( & rtDW . gdkxwpsnoh . AQHandles [ 1 ] ) ; } if (
rtDW . gdkxwpsnoh . AQHandles [ 2 ] ) { sdiTerminateStreaming ( & rtDW .
gdkxwpsnoh . AQHandles [ 2 ] ) ; } } { if ( rtDW . hbso4bjjpz . AQHandles [ 0
] ) { sdiTerminateStreaming ( & rtDW . hbso4bjjpz . AQHandles [ 0 ] ) ; } if
( rtDW . hbso4bjjpz . AQHandles [ 1 ] ) { sdiTerminateStreaming ( & rtDW .
hbso4bjjpz . AQHandles [ 1 ] ) ; } if ( rtDW . hbso4bjjpz . AQHandles [ 2 ] )
{ sdiTerminateStreaming ( & rtDW . hbso4bjjpz . AQHandles [ 2 ] ) ; } } { if
( rtDW . ngziftwkrd . AQHandles ) { sdiTerminateStreaming ( & rtDW .
ngziftwkrd . AQHandles ) ; } } { if ( rtDW . ejblfx2g3i . AQHandles ) {
sdiTerminateStreaming ( & rtDW . ejblfx2g3i . AQHandles ) ; } } { if ( rtDW .
c2ed1fnksn . AQHandles ) { sdiTerminateStreaming ( & rtDW . c2ed1fnksn .
AQHandles ) ; } } { if ( rtDW . j4poblttty . AQHandles ) {
sdiTerminateStreaming ( & rtDW . j4poblttty . AQHandles ) ; } } { if ( rtDW .
f43wxvhzgt . AQHandles ) { sdiTerminateStreaming ( & rtDW . f43wxvhzgt .
AQHandles ) ; } } { if ( rtDW . ghxaxtnllt . AQHandles ) {
sdiTerminateStreaming ( & rtDW . ghxaxtnllt . AQHandles ) ; } } { if ( rtDW .
kt1yw354el . AQHandles ) { sdiTerminateStreaming ( & rtDW . kt1yw354el .
AQHandles ) ; } } { if ( rtDW . d2ou5um4xo . AQHandles ) {
sdiTerminateStreaming ( & rtDW . d2ou5um4xo . AQHandles ) ; } } { if ( rtDW .
f2agk1lwei . AQHandles ) { sdiTerminateStreaming ( & rtDW . f2agk1lwei .
AQHandles ) ; } } { if ( rtDW . nyvkm1zm5h . AQHandles ) {
sdiTerminateStreaming ( & rtDW . nyvkm1zm5h . AQHandles ) ; } } { if ( rtDW .
nip5y111ia . AQHandles ) { sdiTerminateStreaming ( & rtDW . nip5y111ia .
AQHandles ) ; } } { if ( rtDW . i44rlgscpk . AQHandles ) {
sdiTerminateStreaming ( & rtDW . i44rlgscpk . AQHandles ) ; } } } static void
mr_passive_cellBalancing_cacheDataAsMxArray ( mxArray * destArray , mwIndex i
, int j , const void * srcData , size_t numBytes ) ; static void
mr_passive_cellBalancing_cacheDataAsMxArray ( mxArray * destArray , mwIndex i
, int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_passive_cellBalancing_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ;
static void mr_passive_cellBalancing_restoreDataFromMxArray ( void * destData
, const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy (
( uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_passive_cellBalancing_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) ; static void
mr_passive_cellBalancing_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j
, mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_passive_cellBalancing_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_passive_cellBalancing_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) { const uint_T varVal = (
uint_T ) mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return
varVal & ( ( 1u << numBits ) - 1u ) ; } static void
mr_passive_cellBalancing_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_passive_cellBalancing_cacheDataToMxArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_passive_cellBalancing_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_passive_cellBalancing_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_passive_cellBalancing_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_passive_cellBalancing_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_passive_cellBalancing_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ;
static uint_T mr_passive_cellBalancing_extractBitFieldFromCellArrayWithOffset
( const mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T
numBits ) { const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_passive_cellBalancing_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "rtB" , "rtDW" , "NULL_PrevZCX"
, } ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * )
& ( rtB ) , sizeof ( rtB ) ) ; { static const char * rtdwDataFieldNames [ 41
] = { "rtDW.akd2jqznao" , "rtDW.hgr5mesxnb" , "rtDW.mt4lnyabvi" ,
"rtDW.plmvxjbolt" , "rtDW.ax0ggg2g2u" , "rtDW.fai3hsvf1n" , "rtDW.dygpf1ihj5"
, "rtDW.h04tbwqhfy" , "rtDW.fcxyycf4fu" , "rtDW.c00p5tpsbl" ,
"rtDW.chrr3t52id" , "rtDW.gcso21r0zq" , "rtDW.publma5mit" , "rtDW.gqsgvislof"
, "rtDW.lgifnif3a5" , "rtDW.gwrfs10hrl" , "rtDW.hwcyuglaof" ,
"rtDW.erhuzibllh" , "rtDW.egiqzmrt1h" , "rtDW.dwbi4pfdve" , "rtDW.ngguotoe1s"
, "rtDW.jzwmczaemy" , "rtDW.bv5z5dog4q" , "rtDW.nw2cetseby" ,
"rtDW.kigcmuxibu" , "rtDW.hgu1herpdu" , "rtDW.l2qjsqryqq" , "rtDW.pdurl3rulw"
, "rtDW.gzqp4ynez5" , "rtDW.l3kwie4ayw" , "rtDW.io1i4lyocz" ,
"rtDW.mxkplkbb4c" , "rtDW.fv1kok2dvs" , "rtDW.hmdsgmwt5t" , "rtDW.gdrkw3ubvp"
, "rtDW.keir5gxmdi" , "rtDW.gei4lsz0rp" , "rtDW.mvkhilmq5l" ,
"rtDW.b2kal4igyh" , "rtDW.jzijfqoq10" , "rtDW.lhseafldnw" , } ; mxArray *
rtdwData = mxCreateStructMatrix ( 1 , 1 , 41 , rtdwDataFieldNames ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 0 , ( const void
* ) & ( rtDW . akd2jqznao ) , sizeof ( rtDW . akd2jqznao ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 1 , ( const void
* ) & ( rtDW . hgr5mesxnb ) , sizeof ( rtDW . hgr5mesxnb ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const void
* ) & ( rtDW . mt4lnyabvi ) , sizeof ( rtDW . mt4lnyabvi ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const void
* ) & ( rtDW . plmvxjbolt ) , sizeof ( rtDW . plmvxjbolt ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const void
* ) & ( rtDW . ax0ggg2g2u ) , sizeof ( rtDW . ax0ggg2g2u ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const void
* ) & ( rtDW . fai3hsvf1n ) , sizeof ( rtDW . fai3hsvf1n ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const void
* ) & ( rtDW . dygpf1ihj5 ) , sizeof ( rtDW . dygpf1ihj5 ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const void
* ) & ( rtDW . h04tbwqhfy ) , sizeof ( rtDW . h04tbwqhfy ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 8 , ( const void
* ) & ( rtDW . fcxyycf4fu ) , sizeof ( rtDW . fcxyycf4fu ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 9 , ( const void
* ) & ( rtDW . c00p5tpsbl ) , sizeof ( rtDW . c00p5tpsbl ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 10 , ( const
void * ) & ( rtDW . chrr3t52id ) , sizeof ( rtDW . chrr3t52id ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 11 , ( const
void * ) & ( rtDW . gcso21r0zq ) , sizeof ( rtDW . gcso21r0zq ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 12 , ( const
void * ) & ( rtDW . publma5mit ) , sizeof ( rtDW . publma5mit ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 13 , ( const
void * ) & ( rtDW . gqsgvislof ) , sizeof ( rtDW . gqsgvislof ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 14 , ( const
void * ) & ( rtDW . lgifnif3a5 ) , sizeof ( rtDW . lgifnif3a5 ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 15 , ( const
void * ) & ( rtDW . gwrfs10hrl ) , sizeof ( rtDW . gwrfs10hrl ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 16 , ( const
void * ) & ( rtDW . hwcyuglaof ) , sizeof ( rtDW . hwcyuglaof ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 17 , ( const
void * ) & ( rtDW . erhuzibllh ) , sizeof ( rtDW . erhuzibllh ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 18 , ( const
void * ) & ( rtDW . egiqzmrt1h ) , sizeof ( rtDW . egiqzmrt1h ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 19 , ( const
void * ) & ( rtDW . dwbi4pfdve ) , sizeof ( rtDW . dwbi4pfdve ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 20 , ( const
void * ) & ( rtDW . ngguotoe1s ) , sizeof ( rtDW . ngguotoe1s ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 21 , ( const
void * ) & ( rtDW . jzwmczaemy ) , sizeof ( rtDW . jzwmczaemy ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 22 , ( const
void * ) & ( rtDW . bv5z5dog4q ) , sizeof ( rtDW . bv5z5dog4q ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 23 , ( const
void * ) & ( rtDW . nw2cetseby ) , sizeof ( rtDW . nw2cetseby ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 24 , ( const
void * ) & ( rtDW . kigcmuxibu ) , sizeof ( rtDW . kigcmuxibu ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 25 , ( const
void * ) & ( rtDW . hgu1herpdu ) , sizeof ( rtDW . hgu1herpdu ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 26 , ( const
void * ) & ( rtDW . l2qjsqryqq ) , sizeof ( rtDW . l2qjsqryqq ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 27 , ( const
void * ) & ( rtDW . pdurl3rulw ) , sizeof ( rtDW . pdurl3rulw ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 28 , ( const
void * ) & ( rtDW . gzqp4ynez5 ) , sizeof ( rtDW . gzqp4ynez5 ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 29 , ( const
void * ) & ( rtDW . l3kwie4ayw ) , sizeof ( rtDW . l3kwie4ayw ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 30 , ( const
void * ) & ( rtDW . io1i4lyocz ) , sizeof ( rtDW . io1i4lyocz ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 31 , ( const
void * ) & ( rtDW . mxkplkbb4c ) , sizeof ( rtDW . mxkplkbb4c ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 32 , ( const
void * ) & ( rtDW . fv1kok2dvs ) , sizeof ( rtDW . fv1kok2dvs ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 33 , ( const
void * ) & ( rtDW . hmdsgmwt5t ) , sizeof ( rtDW . hmdsgmwt5t ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 34 , ( const
void * ) & ( rtDW . gdrkw3ubvp ) , sizeof ( rtDW . gdrkw3ubvp ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 35 , ( const
void * ) & ( rtDW . keir5gxmdi ) , sizeof ( rtDW . keir5gxmdi ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 36 , ( const
void * ) & ( rtDW . gei4lsz0rp ) , sizeof ( rtDW . gei4lsz0rp ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 37 , ( const
void * ) & ( rtDW . mvkhilmq5l ) , sizeof ( rtDW . mvkhilmq5l ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 38 , ( const
void * ) & ( rtDW . b2kal4igyh ) , sizeof ( rtDW . b2kal4igyh ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 39 , ( const
void * ) & ( rtDW . jzijfqoq10 ) , sizeof ( rtDW . jzijfqoq10 ) ) ;
mr_passive_cellBalancing_cacheDataAsMxArray ( rtdwData , 0 , 40 , ( const
void * ) & ( rtDW . lhseafldnw ) , sizeof ( rtDW . lhseafldnw ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_passive_cellBalancing_SetDWork ( const mxArray * ssDW ) { ( void ) ssDW ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtB ) , ssDW
, 0 , 0 , sizeof ( rtB ) ) ; { const mxArray * rtdwData = mxGetFieldByNumber
( ssDW , 0 , 1 ) ; mr_passive_cellBalancing_restoreDataFromMxArray ( ( void *
) & ( rtDW . akd2jqznao ) , rtdwData , 0 , 0 , sizeof ( rtDW . akd2jqznao ) )
; mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hgr5mesxnb ) , rtdwData , 0 , 1 , sizeof ( rtDW . hgr5mesxnb ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
mt4lnyabvi ) , rtdwData , 0 , 2 , sizeof ( rtDW . mt4lnyabvi ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
plmvxjbolt ) , rtdwData , 0 , 3 , sizeof ( rtDW . plmvxjbolt ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ax0ggg2g2u ) , rtdwData , 0 , 4 , sizeof ( rtDW . ax0ggg2g2u ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
fai3hsvf1n ) , rtdwData , 0 , 5 , sizeof ( rtDW . fai3hsvf1n ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
dygpf1ihj5 ) , rtdwData , 0 , 6 , sizeof ( rtDW . dygpf1ihj5 ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
h04tbwqhfy ) , rtdwData , 0 , 7 , sizeof ( rtDW . h04tbwqhfy ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
fcxyycf4fu ) , rtdwData , 0 , 8 , sizeof ( rtDW . fcxyycf4fu ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
c00p5tpsbl ) , rtdwData , 0 , 9 , sizeof ( rtDW . c00p5tpsbl ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
chrr3t52id ) , rtdwData , 0 , 10 , sizeof ( rtDW . chrr3t52id ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
gcso21r0zq ) , rtdwData , 0 , 11 , sizeof ( rtDW . gcso21r0zq ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
publma5mit ) , rtdwData , 0 , 12 , sizeof ( rtDW . publma5mit ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
gqsgvislof ) , rtdwData , 0 , 13 , sizeof ( rtDW . gqsgvislof ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
lgifnif3a5 ) , rtdwData , 0 , 14 , sizeof ( rtDW . lgifnif3a5 ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
gwrfs10hrl ) , rtdwData , 0 , 15 , sizeof ( rtDW . gwrfs10hrl ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hwcyuglaof ) , rtdwData , 0 , 16 , sizeof ( rtDW . hwcyuglaof ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
erhuzibllh ) , rtdwData , 0 , 17 , sizeof ( rtDW . erhuzibllh ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
egiqzmrt1h ) , rtdwData , 0 , 18 , sizeof ( rtDW . egiqzmrt1h ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
dwbi4pfdve ) , rtdwData , 0 , 19 , sizeof ( rtDW . dwbi4pfdve ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ngguotoe1s ) , rtdwData , 0 , 20 , sizeof ( rtDW . ngguotoe1s ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
jzwmczaemy ) , rtdwData , 0 , 21 , sizeof ( rtDW . jzwmczaemy ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
bv5z5dog4q ) , rtdwData , 0 , 22 , sizeof ( rtDW . bv5z5dog4q ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nw2cetseby ) , rtdwData , 0 , 23 , sizeof ( rtDW . nw2cetseby ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
kigcmuxibu ) , rtdwData , 0 , 24 , sizeof ( rtDW . kigcmuxibu ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hgu1herpdu ) , rtdwData , 0 , 25 , sizeof ( rtDW . hgu1herpdu ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
l2qjsqryqq ) , rtdwData , 0 , 26 , sizeof ( rtDW . l2qjsqryqq ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
pdurl3rulw ) , rtdwData , 0 , 27 , sizeof ( rtDW . pdurl3rulw ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
gzqp4ynez5 ) , rtdwData , 0 , 28 , sizeof ( rtDW . gzqp4ynez5 ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
l3kwie4ayw ) , rtdwData , 0 , 29 , sizeof ( rtDW . l3kwie4ayw ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
io1i4lyocz ) , rtdwData , 0 , 30 , sizeof ( rtDW . io1i4lyocz ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
mxkplkbb4c ) , rtdwData , 0 , 31 , sizeof ( rtDW . mxkplkbb4c ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
fv1kok2dvs ) , rtdwData , 0 , 32 , sizeof ( rtDW . fv1kok2dvs ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hmdsgmwt5t ) , rtdwData , 0 , 33 , sizeof ( rtDW . hmdsgmwt5t ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
gdrkw3ubvp ) , rtdwData , 0 , 34 , sizeof ( rtDW . gdrkw3ubvp ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
keir5gxmdi ) , rtdwData , 0 , 35 , sizeof ( rtDW . keir5gxmdi ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
gei4lsz0rp ) , rtdwData , 0 , 36 , sizeof ( rtDW . gei4lsz0rp ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
mvkhilmq5l ) , rtdwData , 0 , 37 , sizeof ( rtDW . mvkhilmq5l ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
b2kal4igyh ) , rtdwData , 0 , 38 , sizeof ( rtDW . b2kal4igyh ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
jzijfqoq10 ) , rtdwData , 0 , 39 , sizeof ( rtDW . jzijfqoq10 ) ) ;
mr_passive_cellBalancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
lhseafldnw ) , rtdwData , 0 , 40 , sizeof ( rtDW . lhseafldnw ) ) ; } }
mxArray * mr_passive_cellBalancing_GetSimStateDisallowedBlocks ( ) { mxArray
* data = mxCreateCellMatrix ( 4 , 3 ) ; mwIndex subs [ 2 ] , offset ; {
static const char * blockType [ 4 ] = { "S-Function" , "Scope" , "Scope" ,
"S-Function" , } ; static const char * blockPath [ 4 ] = {
"passive_cellBalancing/powergui/EquivalentModel1/State-Space" ,
"passive_cellBalancing/Scope4" , "passive_cellBalancing/Scope5" ,
"passive_cellBalancing/powergui/EquivalentModel1/State-Space" , } ; static
const int reason [ 4 ] = { 0 , 0 , 0 , 2 , } ; for ( subs [ 0 ] = 0 ; subs [
0 ] < 4 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateString ( blockType [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 2 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateDoubleScalar ( ( double ) reason [ subs [ 0 ] ] ) ) ; } } return data
; } void MdlInitializeSizes ( void ) { ssSetNumContStates ( rtS , 0 ) ;
ssSetNumY ( rtS , 0 ) ; ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough ( rtS
, 0 ) ; ssSetNumSampleTimes ( rtS , 2 ) ; ssSetNumBlocks ( rtS , 466 ) ;
ssSetNumBlockIO ( rtS , 66 ) ; ssSetNumBlockParams ( rtS , 572 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 , 0.0 ) ;
ssSetSampleTime ( rtS , 1 , 5.0E-5 ) ; ssSetOffsetTime ( rtS , 0 , 1.0 ) ;
ssSetOffsetTime ( rtS , 1 , 0.0 ) ; } void raccel_set_checksum ( ) {
ssSetChecksumVal ( rtS , 0 , 38781694U ) ; ssSetChecksumVal ( rtS , 1 ,
3171215141U ) ; ssSetChecksumVal ( rtS , 2 , 1037466258U ) ; ssSetChecksumVal
( rtS , 3 , 3656089373U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; ( void ) memset ( ( char * ) rtS , 0 ,
sizeof ( SimStruct ) ) ; ( void ) memset ( ( char * ) & mdlInfo , 0 , sizeof
( struct _ssMdlInfo ) ) ; ssSetMdlInfoPtr ( rtS , & mdlInfo ) ;
ssSetExecutionInfo ( rtS , executionInfo ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; } { void * dwork = ( void * ) & rtDW ; ssSetRootDWork ( rtS , dwork
) ; ( void ) memset ( dwork , 0 , sizeof ( DW ) ) ; } { static
DataTypeTransInfo dtInfo ; ( void ) memset ( ( char_T * ) & dtInfo , 0 ,
sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS , & dtInfo ) ; dtInfo .
numDataTypes = 14 ; dtInfo . dataTypeSizes = & rtDataTypeSizes [ 0 ] ; dtInfo
. dataTypeNames = & rtDataTypeNames [ 0 ] ; dtInfo . BTransTable = &
rtBTransTable ; dtInfo . PTransTable = & rtPTransTable ; dtInfo .
dataTypeInfoTable = rtDataTypeInfoTable ; }
passive_cellBalancing_InitializeDataMapInfo ( ) ;
ssSetIsRapidAcceleratorActive ( rtS , true ) ; ssSetRootSS ( rtS , rtS ) ;
ssSetVersion ( rtS , SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS ,
"passive_cellBalancing" ) ; ssSetPath ( rtS , "passive_cellBalancing" ) ;
ssSetTStart ( rtS , 0.0 ) ; ssSetTFinal ( rtS , 500.0 ) ; { static RTWLogInfo
rt_DataLoggingInfo ; rt_DataLoggingInfo . loggingInterval = ( NULL ) ;
ssSetRTWLogInfo ( rtS , & rt_DataLoggingInfo ) ; } { { static int_T
rt_LoggedStateWidths [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 }
; static int_T rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 } ; static int_T rt_LoggedStateDimensions [ ] = { 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; static boolean_T
rt_LoggedStateIsVarDims [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
} ; static BuiltInDTypeId rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE } ; static int_T
rt_LoggedStateComplexSignals [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 } ; static RTWPreprocessingFcnPtr rt_LoggingStatePreprocessingFcnPtrs [
] = { ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , (
NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) } ; static
const char_T * rt_LoggedStateLabels [ ] = { "states" , "DSTATE" , "DSTATE" ,
"states" , "DSTATE" , "DSTATE" , "states" , "DSTATE" , "DSTATE" , "states" ,
"DSTATE" , "DSTATE" } ; static const char_T * rt_LoggedStateBlockNames [ ] =
{ "passive_cellBalancing/Battery/Model/Current filter" ,
"passive_cellBalancing/Battery/Model/int(i)" ,
"passive_cellBalancing/Battery/Model/Exp/Discrete-Time\nIntegrator" ,
"passive_cellBalancing/Battery1/Model/Current filter" ,
"passive_cellBalancing/Battery1/Model/int(i)" ,
"passive_cellBalancing/Battery1/Model/Exp/Discrete-Time\nIntegrator" ,
"passive_cellBalancing/Battery2/Model/Current filter" ,
"passive_cellBalancing/Battery2/Model/int(i)" ,
"passive_cellBalancing/Battery2/Model/Exp/Discrete-Time\nIntegrator" ,
"passive_cellBalancing/Battery3/Model/Current filter" ,
"passive_cellBalancing/Battery3/Model/int(i)" ,
"passive_cellBalancing/Battery3/Model/Exp/Discrete-Time\nIntegrator" } ;
static const char_T * rt_LoggedStateNames [ ] = { "states" , "DSTATE" ,
"DSTATE" , "states" , "DSTATE" , "DSTATE" , "states" , "DSTATE" , "DSTATE" ,
"states" , "DSTATE" , "DSTATE" } ; static boolean_T rt_LoggedStateCrossMdlRef
[ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static
RTWLogDataTypeConvert rt_RTWLogDataTypeConvert [ ] = { { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } } ; static int_T rt_LoggedStateIdxList [ ] = { 0 , 1 ,
2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 } ; static RTWLogSignalInfo
rt_LoggedStateSignalInfo = { 12 , rt_LoggedStateWidths ,
rt_LoggedStateNumDimensions , rt_LoggedStateDimensions ,
rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 12 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtDW . akd2jqznao ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtDW . hgr5mesxnb ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtDW . mt4lnyabvi ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) & rtDW . plmvxjbolt ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) & rtDW . ax0ggg2g2u ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) & rtDW . fai3hsvf1n ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) & rtDW . dygpf1ihj5 ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) & rtDW . h04tbwqhfy ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) & rtDW . fcxyycf4fu ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtDW . c00p5tpsbl ;
rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) & rtDW . chrr3t52id ;
rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtDW . gcso21r0zq ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
ssSolverInfo slvrInfo ; ssSetStepSize ( rtS , 5.0E-5 ) ; ssSetMinStepSize (
rtS , 0.0 ) ; ssSetMaxNumMinSteps ( rtS , - 1 ) ; ssSetMinStepViolatedError (
rtS , 0 ) ; ssSetMaxStepSize ( rtS , 5.0E-5 ) ; ssSetSolverMaxOrder ( rtS , -
1 ) ; ssSetSolverRefineFactor ( rtS , 1 ) ; ssSetOutputTimes ( rtS , ( NULL )
) ; ssSetNumOutputTimes ( rtS , 0 ) ; ssSetOutputTimesOnly ( rtS , 0 ) ;
ssSetOutputTimesIndex ( rtS , 0 ) ; ssSetZCCacheNeedsReset ( rtS , 0 ) ;
ssSetDerivCacheNeedsReset ( rtS , 0 ) ; ssSetNumNonContDerivSigInfos ( rtS ,
0 ) ; ssSetNonContDerivSigInfos ( rtS , ( NULL ) ) ; ssSetSolverInfo ( rtS ,
& slvrInfo ) ; ssSetSolverName ( rtS , "VariableStepDiscrete" ) ;
ssSetVariableStepSolver ( rtS , 1 ) ; ssSetSolverConsistencyChecking ( rtS ,
0 ) ; ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ;
ssSetSolverRobustResetMethod ( rtS , 0 ) ; ssSetSolverStateProjection ( rtS ,
0 ) ; ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelLogData ( rtS , rt_UpdateTXYLogVars ) ;
ssSetModelLogDataIfInInterval ( rtS , rt_UpdateTXXFYLogVars ) ;
ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetTNextTid ( rtS , INT_MIN ) ;
ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 0 ) ; } ssSetChecksumVal ( rtS , 0 , 38781694U
) ; ssSetChecksumVal ( rtS , 1 , 3171215141U ) ; ssSetChecksumVal ( rtS , 2 ,
1037466258U ) ; ssSetChecksumVal ( rtS , 3 , 3656089373U ) ; { static const
sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE ; static RTWExtModeInfo
rt_ExtModeInfo ; static const sysRanDType * systemRan [ 30 ] ;
gblRTWExtModeInfo = & rt_ExtModeInfo ; ssSetRTWExtModeInfo ( rtS , &
rt_ExtModeInfo ) ; rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo ,
systemRan ) ; systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = &
rtAlwaysEnabled ; systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = &
rtAlwaysEnabled ; systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = &
rtAlwaysEnabled ; systemRan [ 6 ] = & rtAlwaysEnabled ; systemRan [ 7 ] = &
rtAlwaysEnabled ; systemRan [ 8 ] = & rtAlwaysEnabled ; systemRan [ 9 ] = &
rtAlwaysEnabled ; systemRan [ 10 ] = & rtAlwaysEnabled ; systemRan [ 11 ] = &
rtAlwaysEnabled ; systemRan [ 12 ] = & rtAlwaysEnabled ; systemRan [ 13 ] = &
rtAlwaysEnabled ; systemRan [ 14 ] = & rtAlwaysEnabled ; systemRan [ 15 ] = &
rtAlwaysEnabled ; systemRan [ 16 ] = & rtAlwaysEnabled ; systemRan [ 17 ] = &
rtAlwaysEnabled ; systemRan [ 18 ] = & rtAlwaysEnabled ; systemRan [ 19 ] = &
rtAlwaysEnabled ; systemRan [ 20 ] = & rtAlwaysEnabled ; systemRan [ 21 ] = &
rtAlwaysEnabled ; systemRan [ 22 ] = & rtAlwaysEnabled ; systemRan [ 23 ] = &
rtAlwaysEnabled ; systemRan [ 24 ] = & rtAlwaysEnabled ; systemRan [ 25 ] = &
rtAlwaysEnabled ; systemRan [ 26 ] = & rtAlwaysEnabled ; systemRan [ 27 ] = &
rtAlwaysEnabled ; systemRan [ 28 ] = & rtAlwaysEnabled ; systemRan [ 29 ] = &
rtAlwaysEnabled ; rteiSetModelMappingInfoPtr ( ssGetRTWExtModeInfo ( rtS ) ,
& ssGetModelMappingInfo ( rtS ) ) ; rteiSetChecksumsPtr ( ssGetRTWExtModeInfo
( rtS ) , ssGetChecksums ( rtS ) ) ; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS
) , ssGetTPtr ( rtS ) ) ; } slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_passive_cellBalancing_GetSimStateDisallowedBlocks ) ;
slsaGetWorkFcnForSimTargetOP ( rtS , mr_passive_cellBalancing_GetDWork ) ;
slsaSetWorkFcnForSimTargetOP ( rtS , mr_passive_cellBalancing_SetDWork ) ;
rtP . Saturation_LowerSat = rtMinusInf ; rtP . Saturation_LowerSat_kwi433xk5g
= rtMinusInf ; rtP . Saturation_LowerSat_o0i20janpw = rtMinusInf ; rtP .
Saturation_LowerSat_ois5i0qecq = rtMinusInf ; rtP . inti_LowerSat =
rtMinusInf ; rtP . inti_LowerSat_lz3gh0icex = rtMinusInf ; rtP .
inti_LowerSat_cwekkzbyq1 = rtMinusInf ; rtP . inti_LowerSat_prmo311ajg =
rtMinusInf ; rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if (
ssGetErrorStatus ( rtS ) ) { return rtS ; } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 2 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID2 ( tid ) ; }
