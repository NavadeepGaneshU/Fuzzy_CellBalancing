  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtP)
    ;%
      section.nData     = 154;
      section.data(154)  = dumData; %prealloc
      
	  ;% rtP.Battery_BatType
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtP.Battery1_BatType
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtP.Battery2_BatType
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtP.Battery3_BatType
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtP.Saturation_UpperSat
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtP.Saturation_LowerSat
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtP.Saturation_UpperSat_lxx4j3fnoa
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtP.Saturation_LowerSat_kwi433xk5g
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtP.Saturation_UpperSat_blj3ug4rzx
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtP.Saturation_LowerSat_o0i20janpw
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtP.Saturation_UpperSat_c3l4zdyanc
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtP.Saturation_LowerSat_ois5i0qecq
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtP.Constant_Value
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtP.Constant_Value_efypwvyyax
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtP.Constant_Value_ogegtmkzv0
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtP.Constant_Value_pbqzqfbpnm
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtP.Constant_Value_hu3rmuppbn
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtP.Constant_Value_h5irp45zuu
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtP.Constant_Value_bksqnhysc0
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtP.Constant_Value_owtewy0ssm
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtP.Constant_Value_k5pwul1wle
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtP.Constant_Value_kcr3np2p0u
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtP.Constant_Value_cqdbuv5p1f
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtP.Constant_Value_nkaxnatvkv
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtP.itinit1_InitialCondition
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtP.R2_Gain
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtP.Currentfilter_NumCoef
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtP.Currentfilter_DenCoef
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtP.Currentfilter_InitialStates
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 29;
	
	  ;% rtP.itinit_InitialCondition
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 30;
	
	  ;% rtP.inti_gainval
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 31;
	
	  ;% rtP.inti_UpperSat
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 32;
	
	  ;% rtP.inti_LowerSat
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 33;
	
	  ;% rtP.Gain_Gain
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 34;
	
	  ;% rtP.R3_Gain
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 35;
	
	  ;% rtP.DiscreteTimeIntegrator_gainval
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 36;
	
	  ;% rtP.DiscreteTimeIntegrator_IC
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 37;
	
	  ;% rtP.Memory2_InitialCondition
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 38;
	
	  ;% rtP.itinit1_InitialCondition_l3j5mkh0dv
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 39;
	
	  ;% rtP.R2_Gain_jrqfqsl4vo
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 40;
	
	  ;% rtP.Currentfilter_NumCoef_iro0wbjjxt
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 41;
	
	  ;% rtP.Currentfilter_DenCoef_l3txc5dehe
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 42;
	
	  ;% rtP.Currentfilter_InitialStates_owagqxfijb
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 44;
	
	  ;% rtP.itinit_InitialCondition_pv4h4vt0ps
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 45;
	
	  ;% rtP.inti_gainval_cihsr01gna
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 46;
	
	  ;% rtP.inti_UpperSat_itldayqrxp
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 47;
	
	  ;% rtP.inti_LowerSat_lz3gh0icex
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 48;
	
	  ;% rtP.Gain_Gain_ozvwrv1fuy
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 49;
	
	  ;% rtP.R3_Gain_dgx1dntlxw
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 50;
	
	  ;% rtP.DiscreteTimeIntegrator_gainval_gderi0p3qj
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 51;
	
	  ;% rtP.DiscreteTimeIntegrator_IC_hmtkq2c0dj
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 52;
	
	  ;% rtP.Memory2_InitialCondition_kg5jloynof
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 53;
	
	  ;% rtP.itinit1_InitialCondition_go30gfvhlp
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 54;
	
	  ;% rtP.R2_Gain_fij43s2whq
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 55;
	
	  ;% rtP.Currentfilter_NumCoef_lysterszrx
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 56;
	
	  ;% rtP.Currentfilter_DenCoef_i2hd2zaaxr
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 57;
	
	  ;% rtP.Currentfilter_InitialStates_f33gifoztx
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 59;
	
	  ;% rtP.itinit_InitialCondition_nf4pvnucgc
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 60;
	
	  ;% rtP.inti_gainval_ev3cmzfwwq
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 61;
	
	  ;% rtP.inti_UpperSat_nowwhgaxwk
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 62;
	
	  ;% rtP.inti_LowerSat_cwekkzbyq1
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 63;
	
	  ;% rtP.Gain_Gain_jbuudt1ftk
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 64;
	
	  ;% rtP.R3_Gain_de1tgv0zzw
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 65;
	
	  ;% rtP.DiscreteTimeIntegrator_gainval_dnjz2mm3rw
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 66;
	
	  ;% rtP.DiscreteTimeIntegrator_IC_gkofv4otem
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 67;
	
	  ;% rtP.Memory2_InitialCondition_pmjxv0kff4
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 68;
	
	  ;% rtP.itinit1_InitialCondition_dgjqnmxq2c
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 69;
	
	  ;% rtP.R2_Gain_bawzgornhw
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 70;
	
	  ;% rtP.Currentfilter_NumCoef_i44m2spe23
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 71;
	
	  ;% rtP.Currentfilter_DenCoef_ecedmvii5j
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 72;
	
	  ;% rtP.Currentfilter_InitialStates_b3vhzanude
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 74;
	
	  ;% rtP.itinit_InitialCondition_arquskxlx3
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 75;
	
	  ;% rtP.inti_gainval_goukxg31nf
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 76;
	
	  ;% rtP.inti_UpperSat_lz4hujw0ip
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 77;
	
	  ;% rtP.inti_LowerSat_prmo311ajg
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 78;
	
	  ;% rtP.Gain_Gain_oyd440f2kz
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 79;
	
	  ;% rtP.R3_Gain_dbnoektfcm
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 80;
	
	  ;% rtP.DiscreteTimeIntegrator_gainval_jfckqwmoq4
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 81;
	
	  ;% rtP.DiscreteTimeIntegrator_IC_epy4ipnsuc
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 82;
	
	  ;% rtP.Memory2_InitialCondition_mn5xrqtpcm
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 83;
	
	  ;% rtP.StateSpace_DS_param
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 84;
	
	  ;% rtP.R4_Gain
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 484;
	
	  ;% rtP.Saturation_UpperSat_pcz043fnep
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 485;
	
	  ;% rtP.Saturation_LowerSat_b05y2t0vvl
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 486;
	
	  ;% rtP.R4_Gain_ayggl2vp1n
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 487;
	
	  ;% rtP.Saturation_UpperSat_aqwzuangfk
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 488;
	
	  ;% rtP.Saturation_LowerSat_bcd3czsgyq
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 489;
	
	  ;% rtP.R4_Gain_ckkisgzyfx
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 490;
	
	  ;% rtP.Saturation_UpperSat_i3x3oscagf
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 491;
	
	  ;% rtP.Saturation_LowerSat_gnz45aadu0
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 492;
	
	  ;% rtP.R4_Gain_hqvi3z0ayd
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 493;
	
	  ;% rtP.Saturation_UpperSat_ezdhxfyofu
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 494;
	
	  ;% rtP.Saturation_LowerSat_i2fffiw1vk
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 495;
	
	  ;% rtP.donotdeletethisgain_Gain
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 496;
	
	  ;% rtP.donotdeletethisgain_Gain_bg3gl2myht
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 497;
	
	  ;% rtP.donotdeletethisgain_Gain_o42imifl5k
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 498;
	
	  ;% rtP.donotdeletethisgain_Gain_esi3l1j2do
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 499;
	
	  ;% rtP.R_Gain
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 500;
	
	  ;% rtP.R_Gain_g4gmpqe5wx
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 501;
	
	  ;% rtP.R_Gain_jixg1xytle
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 502;
	
	  ;% rtP.R_Gain_cwdppwgit4
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 503;
	
	  ;% rtP.Gain4_Gain
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 504;
	
	  ;% rtP.Gain1_Gain
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 505;
	
	  ;% rtP.Gain2_Gain
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 506;
	
	  ;% rtP.R1_Gain
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 507;
	
	  ;% rtP.Gain4_Gain_kh00znyazs
	  section.data(106).logicalSrcIdx = 105;
	  section.data(106).dtTransOffset = 508;
	
	  ;% rtP.Gain1_Gain_og11bwmhu2
	  section.data(107).logicalSrcIdx = 106;
	  section.data(107).dtTransOffset = 509;
	
	  ;% rtP.Gain2_Gain_m4x3vq3y1f
	  section.data(108).logicalSrcIdx = 107;
	  section.data(108).dtTransOffset = 510;
	
	  ;% rtP.R1_Gain_k1h1x1zryv
	  section.data(109).logicalSrcIdx = 108;
	  section.data(109).dtTransOffset = 511;
	
	  ;% rtP.Gain4_Gain_fstjjgzlds
	  section.data(110).logicalSrcIdx = 109;
	  section.data(110).dtTransOffset = 512;
	
	  ;% rtP.Gain1_Gain_anymdqpqln
	  section.data(111).logicalSrcIdx = 110;
	  section.data(111).dtTransOffset = 513;
	
	  ;% rtP.Gain2_Gain_jptbha03po
	  section.data(112).logicalSrcIdx = 111;
	  section.data(112).dtTransOffset = 514;
	
	  ;% rtP.R1_Gain_elo0441xsu
	  section.data(113).logicalSrcIdx = 112;
	  section.data(113).dtTransOffset = 515;
	
	  ;% rtP.Gain4_Gain_hul13ajzj3
	  section.data(114).logicalSrcIdx = 113;
	  section.data(114).dtTransOffset = 516;
	
	  ;% rtP.Gain1_Gain_m4axzds55u
	  section.data(115).logicalSrcIdx = 114;
	  section.data(115).dtTransOffset = 517;
	
	  ;% rtP.Gain2_Gain_exz2fvuzmi
	  section.data(116).logicalSrcIdx = 115;
	  section.data(116).dtTransOffset = 518;
	
	  ;% rtP.R1_Gain_f1ushaohtw
	  section.data(117).logicalSrcIdx = 116;
	  section.data(117).dtTransOffset = 519;
	
	  ;% rtP.SwitchCurrents_Value
	  section.data(118).logicalSrcIdx = 117;
	  section.data(118).dtTransOffset = 520;
	
	  ;% rtP.Constant_Value_jorngiczgp
	  section.data(119).logicalSrcIdx = 118;
	  section.data(119).dtTransOffset = 536;
	
	  ;% rtP.Constant1_Value
	  section.data(120).logicalSrcIdx = 119;
	  section.data(120).dtTransOffset = 537;
	
	  ;% rtP.Constant12_Value
	  section.data(121).logicalSrcIdx = 120;
	  section.data(121).dtTransOffset = 538;
	
	  ;% rtP.Constant9_Value
	  section.data(122).logicalSrcIdx = 121;
	  section.data(122).dtTransOffset = 539;
	
	  ;% rtP.Constant1_Value_ks0gbwvaxk
	  section.data(123).logicalSrcIdx = 122;
	  section.data(123).dtTransOffset = 540;
	
	  ;% rtP.Constant2_Value
	  section.data(124).logicalSrcIdx = 123;
	  section.data(124).dtTransOffset = 541;
	
	  ;% rtP.Constant3_Value
	  section.data(125).logicalSrcIdx = 124;
	  section.data(125).dtTransOffset = 542;
	
	  ;% rtP.Constant4_Value
	  section.data(126).logicalSrcIdx = 125;
	  section.data(126).dtTransOffset = 543;
	
	  ;% rtP.Constant_Value_fzmb45jy2r
	  section.data(127).logicalSrcIdx = 126;
	  section.data(127).dtTransOffset = 544;
	
	  ;% rtP.Constant1_Value_jelmmtr1rj
	  section.data(128).logicalSrcIdx = 127;
	  section.data(128).dtTransOffset = 545;
	
	  ;% rtP.Constant12_Value_df3z3yuypl
	  section.data(129).logicalSrcIdx = 128;
	  section.data(129).dtTransOffset = 546;
	
	  ;% rtP.Constant9_Value_bfo0fnc5l1
	  section.data(130).logicalSrcIdx = 129;
	  section.data(130).dtTransOffset = 547;
	
	  ;% rtP.Constant1_Value_jxqfbvs00y
	  section.data(131).logicalSrcIdx = 130;
	  section.data(131).dtTransOffset = 548;
	
	  ;% rtP.Constant2_Value_nbkvr3eqsy
	  section.data(132).logicalSrcIdx = 131;
	  section.data(132).dtTransOffset = 549;
	
	  ;% rtP.Constant3_Value_k030zkojhy
	  section.data(133).logicalSrcIdx = 132;
	  section.data(133).dtTransOffset = 550;
	
	  ;% rtP.Constant4_Value_p1xz0cpgth
	  section.data(134).logicalSrcIdx = 133;
	  section.data(134).dtTransOffset = 551;
	
	  ;% rtP.Constant_Value_kiu123temw
	  section.data(135).logicalSrcIdx = 134;
	  section.data(135).dtTransOffset = 552;
	
	  ;% rtP.Constant1_Value_jj3f5fu3xp
	  section.data(136).logicalSrcIdx = 135;
	  section.data(136).dtTransOffset = 553;
	
	  ;% rtP.Constant12_Value_ktnzmkcekm
	  section.data(137).logicalSrcIdx = 136;
	  section.data(137).dtTransOffset = 554;
	
	  ;% rtP.Constant9_Value_nhyzz1ckmw
	  section.data(138).logicalSrcIdx = 137;
	  section.data(138).dtTransOffset = 555;
	
	  ;% rtP.Constant1_Value_gbfcrdkgqa
	  section.data(139).logicalSrcIdx = 138;
	  section.data(139).dtTransOffset = 556;
	
	  ;% rtP.Constant2_Value_gnk2tjoo5o
	  section.data(140).logicalSrcIdx = 139;
	  section.data(140).dtTransOffset = 557;
	
	  ;% rtP.Constant3_Value_hat1prtoip
	  section.data(141).logicalSrcIdx = 140;
	  section.data(141).dtTransOffset = 558;
	
	  ;% rtP.Constant4_Value_cmgjzabbd1
	  section.data(142).logicalSrcIdx = 141;
	  section.data(142).dtTransOffset = 559;
	
	  ;% rtP.Constant_Value_lfzq4ua142
	  section.data(143).logicalSrcIdx = 142;
	  section.data(143).dtTransOffset = 560;
	
	  ;% rtP.Constant1_Value_mvsbgtlkyx
	  section.data(144).logicalSrcIdx = 143;
	  section.data(144).dtTransOffset = 561;
	
	  ;% rtP.Constant12_Value_bncp0krrox
	  section.data(145).logicalSrcIdx = 144;
	  section.data(145).dtTransOffset = 562;
	
	  ;% rtP.Constant9_Value_mgshhdhohr
	  section.data(146).logicalSrcIdx = 145;
	  section.data(146).dtTransOffset = 563;
	
	  ;% rtP.Constant1_Value_olpeyohdie
	  section.data(147).logicalSrcIdx = 146;
	  section.data(147).dtTransOffset = 564;
	
	  ;% rtP.Constant2_Value_mxw2f5zdvz
	  section.data(148).logicalSrcIdx = 147;
	  section.data(148).dtTransOffset = 565;
	
	  ;% rtP.Constant3_Value_jcwsxsesu4
	  section.data(149).logicalSrcIdx = 148;
	  section.data(149).dtTransOffset = 566;
	
	  ;% rtP.Constant4_Value_g4yqznci4m
	  section.data(150).logicalSrcIdx = 149;
	  section.data(150).dtTransOffset = 567;
	
	  ;% rtP.Constant_Value_eczelweelu
	  section.data(151).logicalSrcIdx = 150;
	  section.data(151).dtTransOffset = 568;
	
	  ;% rtP.Constant1_Value_hdj1qeobnu
	  section.data(152).logicalSrcIdx = 151;
	  section.data(152).dtTransOffset = 569;
	
	  ;% rtP.Constant2_Value_ct4fvdp3kc
	  section.data(153).logicalSrcIdx = 152;
	  section.data(153).dtTransOffset = 570;
	
	  ;% rtP.Constant3_Value_cddtuuqxak
	  section.data(154).logicalSrcIdx = 153;
	  section.data(154).dtTransOffset = 571;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtB)
    ;%
      section.nData     = 66;
      section.data(66)  = dumData; %prealloc
      
	  ;% rtB.mjvjriaqf1
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.iwg3uf4gow
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.hjevaumr0c
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtB.onc44lw42c
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtB.lxt4khg2gr
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtB.dcxmkcvwrp
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtB.nwqbfvqhii
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtB.motansc1ll
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtB.lzsueoanmz
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtB.mjiupj41uc
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtB.hr5m5k25h0
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtB.acpftwtjmw
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtB.agtjzus4mb
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtB.ax3gewsxiw
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtB.mum0x2jb0i
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtB.a5hdtqemrb
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtB.el1os0xk3p
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtB.dmmlegxb5k
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtB.gkflp5ycd1
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtB.dr3dmc1br1
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtB.om4odxhgrn
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtB.hohs45nws1
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtB.lz1jrcy1g1
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtB.mohby5bkk0
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtB.ifr4l3aglp
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtB.hwspvdiqna
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtB.h0ohrdd4jd
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtB.gnfbmjv1kd
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtB.fsajkdm0eh
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtB.kt4i3eakjd
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtB.oawvzp4us4
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtB.jmflq5t0rg
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtB.nmhblmw2if
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtB.jus1psarxf
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtB.dzwffk2oci
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 34;
	
	  ;% rtB.joihb0qv3k
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 35;
	
	  ;% rtB.fdxhchca4n
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 36;
	
	  ;% rtB.pnhylngzop
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 56;
	
	  ;% rtB.g0jp2bmgqd
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 72;
	
	  ;% rtB.jir35ajm40
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 73;
	
	  ;% rtB.gl1tfdyozx
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 74;
	
	  ;% rtB.c0jlhyxegg
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 75;
	
	  ;% rtB.ggq0mzmget
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 76;
	
	  ;% rtB.f5mbbavims
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 77;
	
	  ;% rtB.hwrfe4inel
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 78;
	
	  ;% rtB.puaah5a5v4
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 79;
	
	  ;% rtB.gxiis152id
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 80;
	
	  ;% rtB.j1svqdlmmu
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 81;
	
	  ;% rtB.nedmckl1ap
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 82;
	
	  ;% rtB.fbvg15yoxf
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 83;
	
	  ;% rtB.bhljgeggu3
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 84;
	
	  ;% rtB.o4q0knkfhp
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 85;
	
	  ;% rtB.e03bm2zbdm
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 86;
	
	  ;% rtB.mniup0awbm
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 87;
	
	  ;% rtB.nbtiexyflg
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 88;
	
	  ;% rtB.ehmsjwt2y2
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 89;
	
	  ;% rtB.ldf12bxawt
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 90;
	
	  ;% rtB.ppovsif5nu
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 91;
	
	  ;% rtB.aggsod1r3b
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 92;
	
	  ;% rtB.jjxxtqfeeb
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 93;
	
	  ;% rtB.cds1qoxtkz
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 94;
	
	  ;% rtB.gielivfeiq
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 95;
	
	  ;% rtB.jge13amd3n
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 96;
	
	  ;% rtB.cpufh1imvv
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 97;
	
	  ;% rtB.pjbiqezomx
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 98;
	
	  ;% rtB.mtnqnf1tgq
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 99;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 5;
    sectIdxOffset = 1;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtDW)
    ;%
      section.nData     = 24;
      section.data(24)  = dumData; %prealloc
      
	  ;% rtDW.akd2jqznao
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.hgr5mesxnb
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.mt4lnyabvi
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.plmvxjbolt
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.ax0ggg2g2u
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.fai3hsvf1n
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.dygpf1ihj5
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.h04tbwqhfy
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.fcxyycf4fu
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.c00p5tpsbl
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.chrr3t52id
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.gcso21r0zq
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtDW.publma5mit
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtDW.gqsgvislof
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtDW.lgifnif3a5
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtDW.gwrfs10hrl
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtDW.hwcyuglaof
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtDW.erhuzibllh
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtDW.egiqzmrt1h
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtDW.dwbi4pfdve
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtDW.ngguotoe1s
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtDW.jzwmczaemy
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtDW.bv5z5dog4q
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtDW.nw2cetseby
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 19;
      section.data(19)  = dumData; %prealloc
      
	  ;% rtDW.nopbrmbrmq.AS
	  section.data(1).logicalSrcIdx = 24;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.mcginysbcv.LoggedData
	  section.data(2).logicalSrcIdx = 25;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.a3ftdsui15.LoggedData
	  section.data(3).logicalSrcIdx = 26;
	  section.data(3).dtTransOffset = 5;
	
	  ;% rtDW.d0qmjtu0wc.AQHandles
	  section.data(4).logicalSrcIdx = 27;
	  section.data(4).dtTransOffset = 9;
	
	  ;% rtDW.ogi3lqi4h3.AQHandles
	  section.data(5).logicalSrcIdx = 28;
	  section.data(5).dtTransOffset = 12;
	
	  ;% rtDW.gdkxwpsnoh.AQHandles
	  section.data(6).logicalSrcIdx = 29;
	  section.data(6).dtTransOffset = 15;
	
	  ;% rtDW.hbso4bjjpz.AQHandles
	  section.data(7).logicalSrcIdx = 30;
	  section.data(7).dtTransOffset = 18;
	
	  ;% rtDW.ngziftwkrd.AQHandles
	  section.data(8).logicalSrcIdx = 31;
	  section.data(8).dtTransOffset = 21;
	
	  ;% rtDW.ejblfx2g3i.AQHandles
	  section.data(9).logicalSrcIdx = 32;
	  section.data(9).dtTransOffset = 22;
	
	  ;% rtDW.c2ed1fnksn.AQHandles
	  section.data(10).logicalSrcIdx = 33;
	  section.data(10).dtTransOffset = 23;
	
	  ;% rtDW.j4poblttty.AQHandles
	  section.data(11).logicalSrcIdx = 34;
	  section.data(11).dtTransOffset = 24;
	
	  ;% rtDW.f43wxvhzgt.AQHandles
	  section.data(12).logicalSrcIdx = 35;
	  section.data(12).dtTransOffset = 25;
	
	  ;% rtDW.ghxaxtnllt.AQHandles
	  section.data(13).logicalSrcIdx = 36;
	  section.data(13).dtTransOffset = 26;
	
	  ;% rtDW.kt1yw354el.AQHandles
	  section.data(14).logicalSrcIdx = 37;
	  section.data(14).dtTransOffset = 27;
	
	  ;% rtDW.d2ou5um4xo.AQHandles
	  section.data(15).logicalSrcIdx = 38;
	  section.data(15).dtTransOffset = 28;
	
	  ;% rtDW.f2agk1lwei.AQHandles
	  section.data(16).logicalSrcIdx = 39;
	  section.data(16).dtTransOffset = 29;
	
	  ;% rtDW.nyvkm1zm5h.AQHandles
	  section.data(17).logicalSrcIdx = 40;
	  section.data(17).dtTransOffset = 30;
	
	  ;% rtDW.nip5y111ia.AQHandles
	  section.data(18).logicalSrcIdx = 41;
	  section.data(18).dtTransOffset = 31;
	
	  ;% rtDW.i44rlgscpk.AQHandles
	  section.data(19).logicalSrcIdx = 42;
	  section.data(19).dtTransOffset = 32;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.kigcmuxibu
	  section.data(1).logicalSrcIdx = 43;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 4;
      section.data(4)  = dumData; %prealloc
      
	  ;% rtDW.hgu1herpdu
	  section.data(1).logicalSrcIdx = 44;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.l2qjsqryqq
	  section.data(2).logicalSrcIdx = 45;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.pdurl3rulw
	  section.data(3).logicalSrcIdx = 46;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.gzqp4ynez5
	  section.data(4).logicalSrcIdx = 47;
	  section.data(4).dtTransOffset = 3;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 12;
      section.data(12)  = dumData; %prealloc
      
	  ;% rtDW.l3kwie4ayw
	  section.data(1).logicalSrcIdx = 48;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.io1i4lyocz
	  section.data(2).logicalSrcIdx = 49;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.mxkplkbb4c
	  section.data(3).logicalSrcIdx = 50;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.fv1kok2dvs
	  section.data(4).logicalSrcIdx = 51;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.hmdsgmwt5t
	  section.data(5).logicalSrcIdx = 52;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.gdrkw3ubvp
	  section.data(6).logicalSrcIdx = 53;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.keir5gxmdi
	  section.data(7).logicalSrcIdx = 54;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.gei4lsz0rp
	  section.data(8).logicalSrcIdx = 55;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.mvkhilmq5l
	  section.data(9).logicalSrcIdx = 56;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.b2kal4igyh
	  section.data(10).logicalSrcIdx = 57;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.jzijfqoq10
	  section.data(11).logicalSrcIdx = 58;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.lhseafldnw
	  section.data(12).logicalSrcIdx = 59;
	  section.data(12).dtTransOffset = 11;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 38781694;
  targMap.checksum1 = 3171215141;
  targMap.checksum2 = 1037466258;
  targMap.checksum3 = 3656089373;

