#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "passive_cellBalancing_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "passive_cellBalancing.h"
#include "passive_cellBalancing_capi.h"
#include "passive_cellBalancing_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 29 , TARGET_STRING
( "passive_cellBalancing/MATLABFunction" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 1 , 29 , TARGET_STRING ( "passive_cellBalancing/MATLABFunction"
) , TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , { 2 , 29 , TARGET_STRING (
"passive_cellBalancing/MATLABFunction" ) , TARGET_STRING ( "" ) , 2 , 0 , 0 ,
0 , 0 } , { 3 , 29 , TARGET_STRING ( "passive_cellBalancing/MATLABFunction" )
, TARGET_STRING ( "" ) , 3 , 0 , 0 , 0 , 0 } , { 4 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Current Measurement/do not delete this gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 5 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Data Type Conversion1" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 1 } , { 6 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Data Type Conversion2" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 1 } , { 7 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Gain" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 8 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 9 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/R" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 10 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/R1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 11 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Memory2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 1 } , { 12 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/it init" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 13 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Saturation" ) , TARGET_STRING (
"SOC (%)" ) , 0 , 0 , 0 , 0 , 0 } , { 14 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Current filter" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 1 } , { 15 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Current Measurement/do not delete this gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 16 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Data Type Conversion1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 17 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Data Type Conversion2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 18 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Gain" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 19 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 20 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/R" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 21 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/R1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 22 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Memory2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 1 } , { 23 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/it init" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 24 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Saturation" ) , TARGET_STRING (
"SOC (%)" ) , 0 , 0 , 0 , 0 , 0 } , { 25 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Current filter" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 26 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Current Measurement/do not delete this gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 27 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Data Type Conversion1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 28 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Data Type Conversion2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 29 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Gain" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 30 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 31 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/R" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 32 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/R1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 33 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Memory2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 1 } , { 34 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/it init" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 35 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Saturation" ) , TARGET_STRING (
"SOC (%)" ) , 0 , 0 , 0 , 0 , 0 } , { 36 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Current filter" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 37 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Current Measurement/do not delete this gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 38 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Data Type Conversion1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 39 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Data Type Conversion2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 40 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Gain" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 41 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 42 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/R" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 43 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/R1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 44 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Memory2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 1 } , { 45 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/it init" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 46 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Saturation" ) , TARGET_STRING (
"SOC (%)" ) , 0 , 0 , 0 , 0 , 0 } , { 47 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Current filter" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 48 , 0 , TARGET_STRING (
"passive_cellBalancing/powergui/EquivalentModel1/State-Space" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 1 } , { 49 , 0 , TARGET_STRING (
"passive_cellBalancing/powergui/EquivalentModel1/State-Space" ) ,
TARGET_STRING ( "" ) , 1 , 0 , 2 , 0 , 1 } , { 50 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 51 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 52 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 53 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 54 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 55 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 56 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 57 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 58 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 59 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 60 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 61 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 62 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 63 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 64 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 65 , 0 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_BlockParameters
rtBlockParameters [ ] = { { 66 , TARGET_STRING (
"passive_cellBalancing/Battery" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 }
, { 67 , TARGET_STRING ( "passive_cellBalancing/Battery1" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 68 , TARGET_STRING (
"passive_cellBalancing/Battery2" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0
} , { 69 , TARGET_STRING ( "passive_cellBalancing/Battery3" ) , TARGET_STRING
( "BatType" ) , 0 , 0 , 0 } , { 70 , TARGET_STRING (
"passive_cellBalancing/Constant" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 }
, { 71 , TARGET_STRING ( "passive_cellBalancing/Constant1" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 72 , TARGET_STRING (
"passive_cellBalancing/Constant2" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 }
, { 73 , TARGET_STRING ( "passive_cellBalancing/Constant3" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 74 , TARGET_STRING (
"passive_cellBalancing/Battery/Current Measurement/do not delete this gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 75 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Constant" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 76 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Constant1" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 77 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Constant12" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 78 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Constant9" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 79 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/int(i)" ) , TARGET_STRING ( "gainval" )
, 0 , 0 , 0 } , { 80 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 81 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 82 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Gain" ) , TARGET_STRING ( "Gain" ) , 0 ,
0 , 0 } , { 83 , TARGET_STRING ( "passive_cellBalancing/Battery/Model/Gain2"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 84 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/R" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 85 , TARGET_STRING ( "passive_cellBalancing/Battery/Model/R1" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 86 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/R2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 87 , TARGET_STRING ( "passive_cellBalancing/Battery/Model/R3" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 88 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/R4" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 89 , TARGET_STRING ( "passive_cellBalancing/Battery/Model/Memory2"
) , TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 90 , TARGET_STRING
( "passive_cellBalancing/Battery/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 91 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 92 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 93 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 94 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Current filter" ) , TARGET_STRING (
"Numerator" ) , 0 , 0 , 0 } , { 95 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Current filter" ) , TARGET_STRING (
"Denominator" ) , 0 , 3 , 0 } , { 96 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Current filter" ) , TARGET_STRING (
"InitialStates" ) , 0 , 0 , 0 } , { 97 , TARGET_STRING (
"passive_cellBalancing/Battery1/Current Measurement/do not delete this gain"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 98 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Constant" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 99 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Constant1" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 100 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Constant12" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 101 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Constant9" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 102 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/int(i)" ) , TARGET_STRING ( "gainval" )
, 0 , 0 , 0 } , { 103 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 104 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 105 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Gain" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 106 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 107 , TARGET_STRING ( "passive_cellBalancing/Battery1/Model/R"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 108 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 ,
0 , 0 } , { 109 , TARGET_STRING ( "passive_cellBalancing/Battery1/Model/R2" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 110 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 ,
0 , 0 } , { 111 , TARGET_STRING ( "passive_cellBalancing/Battery1/Model/R4" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 112 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Memory2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 113 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 114 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 115 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 116 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 117 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Current filter" ) , TARGET_STRING (
"Numerator" ) , 0 , 0 , 0 } , { 118 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Current filter" ) , TARGET_STRING (
"Denominator" ) , 0 , 3 , 0 } , { 119 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Current filter" ) , TARGET_STRING (
"InitialStates" ) , 0 , 0 , 0 } , { 120 , TARGET_STRING (
"passive_cellBalancing/Battery2/Current Measurement/do not delete this gain"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 121 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Constant" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 122 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Constant1" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 123 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Constant12" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 124 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Constant9" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 125 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/int(i)" ) , TARGET_STRING ( "gainval" )
, 0 , 0 , 0 } , { 126 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 127 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 128 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Gain" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 129 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 130 , TARGET_STRING ( "passive_cellBalancing/Battery2/Model/R"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 131 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 ,
0 , 0 } , { 132 , TARGET_STRING ( "passive_cellBalancing/Battery2/Model/R2" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 133 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 ,
0 , 0 } , { 134 , TARGET_STRING ( "passive_cellBalancing/Battery2/Model/R4" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 135 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Memory2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 136 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 137 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 138 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 139 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 140 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Current filter" ) , TARGET_STRING (
"Numerator" ) , 0 , 0 , 0 } , { 141 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Current filter" ) , TARGET_STRING (
"Denominator" ) , 0 , 3 , 0 } , { 142 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Current filter" ) , TARGET_STRING (
"InitialStates" ) , 0 , 0 , 0 } , { 143 , TARGET_STRING (
"passive_cellBalancing/Battery3/Current Measurement/do not delete this gain"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 144 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Constant" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 145 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Constant1" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 146 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Constant12" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 147 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Constant9" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 148 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/int(i)" ) , TARGET_STRING ( "gainval" )
, 0 , 0 , 0 } , { 149 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/int(i)" ) , TARGET_STRING (
"UpperSaturationLimit" ) , 0 , 0 , 0 } , { 150 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 151 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Gain" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 152 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 153 , TARGET_STRING ( "passive_cellBalancing/Battery3/Model/R"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 154 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/R1" ) , TARGET_STRING ( "Gain" ) , 0 ,
0 , 0 } , { 155 , TARGET_STRING ( "passive_cellBalancing/Battery3/Model/R2" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 156 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/R3" ) , TARGET_STRING ( "Gain" ) , 0 ,
0 , 0 } , { 157 , TARGET_STRING ( "passive_cellBalancing/Battery3/Model/R4" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 158 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Memory2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 159 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 160 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 161 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 162 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 163 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Current filter" ) , TARGET_STRING (
"Numerator" ) , 0 , 0 , 0 } , { 164 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Current filter" ) , TARGET_STRING (
"Denominator" ) , 0 , 3 , 0 } , { 165 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Current filter" ) , TARGET_STRING (
"InitialStates" ) , 0 , 0 , 0 } , { 166 , TARGET_STRING (
"passive_cellBalancing/powergui/EquivalentModel1/State-Space" ) ,
TARGET_STRING ( "DS_param" ) , 0 , 4 , 0 } , { 167 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Compare To Zero/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 168 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 169 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/E_dyn Charge/Constant1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 170 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/E_dyn Charge/Constant2" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 171 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/E_dyn Charge/Constant3" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 172 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/E_dyn Charge/Constant4" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 173 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "gainval" ) , 0 , 0 , 0 } , { 174 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 175 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" )
, 0 , 0 , 0 } , { 176 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" )
, 0 , 0 , 0 } , { 177 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 178 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 179 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Compare To Zero/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 180 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 181 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/E_dyn Charge/Constant1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 182 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/E_dyn Charge/Constant2" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 183 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/E_dyn Charge/Constant3" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 184 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/E_dyn Charge/Constant4" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 185 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "gainval" ) , 0 , 0 , 0 } , { 186 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 187 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" )
, 0 , 0 , 0 } , { 188 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" )
, 0 , 0 , 0 } , { 189 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 190 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 191 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Compare To Zero/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 192 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 193 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/E_dyn Charge/Constant1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 194 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/E_dyn Charge/Constant2" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 195 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/E_dyn Charge/Constant3" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 196 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/E_dyn Charge/Constant4" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 197 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "gainval" ) , 0 , 0 , 0 } , { 198 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 199 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" )
, 0 , 0 , 0 } , { 200 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" )
, 0 , 0 , 0 } , { 201 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 202 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 203 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Compare To Zero/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 204 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 205 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/E_dyn Charge/Constant1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 206 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/E_dyn Charge/Constant2" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 207 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/E_dyn Charge/Constant3" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 208 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/E_dyn Charge/Constant4" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 209 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "gainval" ) , 0 , 0 , 0 } , { 210 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Exp/Discrete-Time Integrator" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 211 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" )
, 0 , 0 , 0 } , { 212 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" )
, 0 , 0 , 0 } , { 213 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 214 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 215 , TARGET_STRING (
"passive_cellBalancing/powergui/EquivalentModel1/Sources/SwitchCurrents" ) ,
TARGET_STRING ( "Value" ) , 0 , 2 , 0 } , { 216 , TARGET_STRING (
"passive_cellBalancing/Battery/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 217 , TARGET_STRING (
"passive_cellBalancing/Battery1/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 218 , TARGET_STRING (
"passive_cellBalancing/Battery2/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 219 , TARGET_STRING (
"passive_cellBalancing/Battery3/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 } } ; static int_T rt_LoggedStateIdxList [ ] = { - 1 } ; static const
rtwCAPI_Signals rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 , 0 , 0 } } ; static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0 , 0 ,
( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_ModelParameters rtModelParameters [ ] = { { 0 , ( NULL ) , 0 , 0 , 0
} } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . jge13amd3n , & rtB . cpufh1imvv ,
& rtB . pjbiqezomx , & rtB . mtnqnf1tgq , & rtB . ggq0mzmget , & rtB .
dcxmkcvwrp , & rtB . iwg3uf4gow , & rtB . onc44lw42c , & rtB . o4q0knkfhp , &
rtB . fbvg15yoxf , & rtB . e03bm2zbdm , & rtB . motansc1ll , & rtB .
hjevaumr0c , & rtB . g0jp2bmgqd , & rtB . mjvjriaqf1 , & rtB . f5mbbavims , &
rtB . mum0x2jb0i , & rtB . hr5m5k25h0 , & rtB . agtjzus4mb , & rtB .
nbtiexyflg , & rtB . gxiis152id , & rtB . ehmsjwt2y2 , & rtB . el1os0xk3p , &
rtB . acpftwtjmw , & rtB . jir35ajm40 , & rtB . mjiupj41uc , & rtB .
hwrfe4inel , & rtB . mohby5bkk0 , & rtB . dr3dmc1br1 , & rtB . hohs45nws1 , &
rtB . ppovsif5nu , & rtB . j1svqdlmmu , & rtB . aggsod1r3b , & rtB .
hwspvdiqna , & rtB . om4odxhgrn , & rtB . gl1tfdyozx , & rtB . gkflp5ycd1 , &
rtB . puaah5a5v4 , & rtB . nmhblmw2if , & rtB . fsajkdm0eh , & rtB .
oawvzp4us4 , & rtB . cds1qoxtkz , & rtB . nedmckl1ap , & rtB . gielivfeiq , &
rtB . dzwffk2oci , & rtB . kt4i3eakjd , & rtB . c0jlhyxegg , & rtB .
gnfbmjv1kd , & rtB . fdxhchca4n [ 0 ] , & rtB . pnhylngzop [ 0 ] , & rtB .
nwqbfvqhii , & rtB . bhljgeggu3 , & rtB . lzsueoanmz , & rtB . lxt4khg2gr , &
rtB . a5hdtqemrb , & rtB . mniup0awbm , & rtB . dmmlegxb5k , & rtB .
ax3gewsxiw , & rtB . ifr4l3aglp , & rtB . ldf12bxawt , & rtB . h0ohrdd4jd , &
rtB . lz1jrcy1g1 , & rtB . jus1psarxf , & rtB . jjxxtqfeeb , & rtB .
joihb0qv3k , & rtB . jmflq5t0rg , & rtP . Battery_BatType , & rtP .
Battery1_BatType , & rtP . Battery2_BatType , & rtP . Battery3_BatType , &
rtP . Constant_Value_eczelweelu , & rtP . Constant1_Value_hdj1qeobnu , & rtP
. Constant2_Value_ct4fvdp3kc , & rtP . Constant3_Value_cddtuuqxak , & rtP .
donotdeletethisgain_Gain , & rtP . Constant_Value_jorngiczgp , & rtP .
Constant1_Value , & rtP . Constant12_Value , & rtP . Constant9_Value , & rtP
. inti_gainval , & rtP . inti_UpperSat , & rtP . inti_LowerSat , & rtP .
Gain_Gain , & rtP . Gain2_Gain , & rtP . R_Gain_cwdppwgit4 , & rtP . R1_Gain
, & rtP . R2_Gain , & rtP . R3_Gain , & rtP . R4_Gain , & rtP .
Memory2_InitialCondition , & rtP . itinit_InitialCondition , & rtP .
itinit1_InitialCondition , & rtP . Saturation_UpperSat_pcz043fnep , & rtP .
Saturation_LowerSat_b05y2t0vvl , & rtP . Currentfilter_NumCoef , & rtP .
Currentfilter_DenCoef [ 0 ] , & rtP . Currentfilter_InitialStates , & rtP .
donotdeletethisgain_Gain_bg3gl2myht , & rtP . Constant_Value_fzmb45jy2r , &
rtP . Constant1_Value_jelmmtr1rj , & rtP . Constant12_Value_df3z3yuypl , &
rtP . Constant9_Value_bfo0fnc5l1 , & rtP . inti_gainval_cihsr01gna , & rtP .
inti_UpperSat_itldayqrxp , & rtP . inti_LowerSat_lz3gh0icex , & rtP .
Gain_Gain_ozvwrv1fuy , & rtP . Gain2_Gain_m4x3vq3y1f , & rtP . R_Gain , & rtP
. R1_Gain_k1h1x1zryv , & rtP . R2_Gain_jrqfqsl4vo , & rtP .
R3_Gain_dgx1dntlxw , & rtP . R4_Gain_ayggl2vp1n , & rtP .
Memory2_InitialCondition_kg5jloynof , & rtP .
itinit_InitialCondition_pv4h4vt0ps , & rtP .
itinit1_InitialCondition_l3j5mkh0dv , & rtP . Saturation_UpperSat_aqwzuangfk
, & rtP . Saturation_LowerSat_bcd3czsgyq , & rtP .
Currentfilter_NumCoef_iro0wbjjxt , & rtP . Currentfilter_DenCoef_l3txc5dehe [
0 ] , & rtP . Currentfilter_InitialStates_owagqxfijb , & rtP .
donotdeletethisgain_Gain_o42imifl5k , & rtP . Constant_Value_kiu123temw , &
rtP . Constant1_Value_jj3f5fu3xp , & rtP . Constant12_Value_ktnzmkcekm , &
rtP . Constant9_Value_nhyzz1ckmw , & rtP . inti_gainval_ev3cmzfwwq , & rtP .
inti_UpperSat_nowwhgaxwk , & rtP . inti_LowerSat_cwekkzbyq1 , & rtP .
Gain_Gain_jbuudt1ftk , & rtP . Gain2_Gain_jptbha03po , & rtP .
R_Gain_g4gmpqe5wx , & rtP . R1_Gain_elo0441xsu , & rtP . R2_Gain_fij43s2whq ,
& rtP . R3_Gain_de1tgv0zzw , & rtP . R4_Gain_ckkisgzyfx , & rtP .
Memory2_InitialCondition_pmjxv0kff4 , & rtP .
itinit_InitialCondition_nf4pvnucgc , & rtP .
itinit1_InitialCondition_go30gfvhlp , & rtP . Saturation_UpperSat_i3x3oscagf
, & rtP . Saturation_LowerSat_gnz45aadu0 , & rtP .
Currentfilter_NumCoef_lysterszrx , & rtP . Currentfilter_DenCoef_i2hd2zaaxr [
0 ] , & rtP . Currentfilter_InitialStates_f33gifoztx , & rtP .
donotdeletethisgain_Gain_esi3l1j2do , & rtP . Constant_Value_lfzq4ua142 , &
rtP . Constant1_Value_mvsbgtlkyx , & rtP . Constant12_Value_bncp0krrox , &
rtP . Constant9_Value_mgshhdhohr , & rtP . inti_gainval_goukxg31nf , & rtP .
inti_UpperSat_lz4hujw0ip , & rtP . inti_LowerSat_prmo311ajg , & rtP .
Gain_Gain_oyd440f2kz , & rtP . Gain2_Gain_exz2fvuzmi , & rtP .
R_Gain_jixg1xytle , & rtP . R1_Gain_f1ushaohtw , & rtP . R2_Gain_bawzgornhw ,
& rtP . R3_Gain_dbnoektfcm , & rtP . R4_Gain_hqvi3z0ayd , & rtP .
Memory2_InitialCondition_mn5xrqtpcm , & rtP .
itinit_InitialCondition_arquskxlx3 , & rtP .
itinit1_InitialCondition_dgjqnmxq2c , & rtP . Saturation_UpperSat_ezdhxfyofu
, & rtP . Saturation_LowerSat_i2fffiw1vk , & rtP .
Currentfilter_NumCoef_i44m2spe23 , & rtP . Currentfilter_DenCoef_ecedmvii5j [
0 ] , & rtP . Currentfilter_InitialStates_b3vhzanude , & rtP .
StateSpace_DS_param [ 0 ] , & rtP . Constant_Value , & rtP .
Constant_Value_efypwvyyax , & rtP . Constant1_Value_ks0gbwvaxk , & rtP .
Constant2_Value , & rtP . Constant3_Value , & rtP . Constant4_Value , & rtP .
DiscreteTimeIntegrator_gainval , & rtP . DiscreteTimeIntegrator_IC , & rtP .
Gain1_Gain , & rtP . Gain4_Gain , & rtP . Saturation_UpperSat , & rtP .
Saturation_LowerSat , & rtP . Constant_Value_pbqzqfbpnm , & rtP .
Constant_Value_hu3rmuppbn , & rtP . Constant1_Value_jxqfbvs00y , & rtP .
Constant2_Value_nbkvr3eqsy , & rtP . Constant3_Value_k030zkojhy , & rtP .
Constant4_Value_p1xz0cpgth , & rtP .
DiscreteTimeIntegrator_gainval_gderi0p3qj , & rtP .
DiscreteTimeIntegrator_IC_hmtkq2c0dj , & rtP . Gain1_Gain_og11bwmhu2 , & rtP
. Gain4_Gain_kh00znyazs , & rtP . Saturation_UpperSat_lxx4j3fnoa , & rtP .
Saturation_LowerSat_kwi433xk5g , & rtP . Constant_Value_bksqnhysc0 , & rtP .
Constant_Value_owtewy0ssm , & rtP . Constant1_Value_gbfcrdkgqa , & rtP .
Constant2_Value_gnk2tjoo5o , & rtP . Constant3_Value_hat1prtoip , & rtP .
Constant4_Value_cmgjzabbd1 , & rtP .
DiscreteTimeIntegrator_gainval_dnjz2mm3rw , & rtP .
DiscreteTimeIntegrator_IC_gkofv4otem , & rtP . Gain1_Gain_anymdqpqln , & rtP
. Gain4_Gain_fstjjgzlds , & rtP . Saturation_UpperSat_blj3ug4rzx , & rtP .
Saturation_LowerSat_o0i20janpw , & rtP . Constant_Value_kcr3np2p0u , & rtP .
Constant_Value_cqdbuv5p1f , & rtP . Constant1_Value_olpeyohdie , & rtP .
Constant2_Value_mxw2f5zdvz , & rtP . Constant3_Value_jcwsxsesu4 , & rtP .
Constant4_Value_g4yqznci4m , & rtP .
DiscreteTimeIntegrator_gainval_jfckqwmoq4 , & rtP .
DiscreteTimeIntegrator_IC_epy4ipnsuc , & rtP . Gain1_Gain_m4axzds55u , & rtP
. Gain4_Gain_hul13ajzj3 , & rtP . Saturation_UpperSat_c3l4zdyanc , & rtP .
Saturation_LowerSat_ois5i0qecq , & rtP . SwitchCurrents_Value [ 0 ] , & rtP .
Constant_Value_ogegtmkzv0 , & rtP . Constant_Value_h5irp45zuu , & rtP .
Constant_Value_k5pwul1wle , & rtP . Constant_Value_nkaxnatvkv , } ; static
int32_T * rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_VECTOR , 2 , 2 , 0 } , {
rtwCAPI_VECTOR , 4 , 2 , 0 } , { rtwCAPI_VECTOR , 6 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 8 , 2 , 0 } } ; static const uint_T
rtDimensionArray [ ] = { 1 , 1 , 20 , 1 , 16 , 1 , 1 , 2 , 20 , 20 } ; static
const real_T rtcapiStoredFloats [ ] = { 0.0 , 1.0 , 5.0E-5 } ; static const
rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static const rtwCAPI_SampleTimeMap
rtSampleTimeMap [ ] = { { ( const void * ) & rtcapiStoredFloats [ 0 ] , (
const void * ) & rtcapiStoredFloats [ 1 ] , 0 , 0 } , { ( const void * ) &
rtcapiStoredFloats [ 2 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , 1 ,
0 } } ; static rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals
, 66 , rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 154 ,
rtModelParameters , 0 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 38781694U , 3171215141U , 1037466258U , 3656089373U } , ( NULL ) , 0 , 0
, rt_LoggedStateIdxList } ; const rtwCAPI_ModelMappingStaticInfo *
passive_cellBalancing_GetCAPIStaticMap ( void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void passive_cellBalancing_InitializeDataMapInfo ( void ) {
rtwCAPI_SetVersion ( ( * rt_dataMapInfoPtr ) . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( ( * rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetDataAddressMap ( ( * rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ;
rtwCAPI_SetVarDimsAddressMap ( ( * rt_dataMapInfoPtr ) . mmi ,
rtVarDimsAddrMap ) ; rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr )
. mmi , ( NULL ) ) ; rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi
, ( NULL ) ) ; rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi ,
0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void passive_cellBalancing_host_InitializeDataMapInfo (
passive_cellBalancing_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
