#ifndef RTW_HEADER_passive_cellBalancing_capi_h
#define RTW_HEADER_passive_cellBalancing_capi_h
#include "passive_cellBalancing.h"
extern void passive_cellBalancing_InitializeDataMapInfo ( void ) ;
#endif
